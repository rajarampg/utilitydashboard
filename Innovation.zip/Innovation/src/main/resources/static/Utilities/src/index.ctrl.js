/**
 * Created by vn94857 on 12/26/2016.
 */
'use strict';
angular
    .module('app.core',['ui.grid', 'ui.grid.expandable', 'ui.grid.pagination','ui.bootstrap', 'ui.grid.resizeColumns', 'ng-fusioncharts', 'xeditable', 'dndLists', 'angular-loading-bar', 'tableSort'])
    .controller('IndexController', function($scope, $http, $timeout, $parse, $filter) {
        $scope.dataJson = {};
        $scope.arw = '';
        /*UI Grid
        $scope.data = [
            {
                "id": 1,
                "innovation_name": "Automation",
                "innovation_description": "new Application",
                "innovation_owner": "Prudhvi",
                "approved_by": "Karthik",
                "approved_on": "25-12-16",
                "approver_Comments": "Approved",
                "assigned_to": "Aswin",
                "assgied_on": "25-12-16",
                "innovation_start_date": "25-12-16",
                "innovation_end_date": "25-07-17",
                "status": "In-Progress",
                "comments": "Good",
                "created_by": "Aswin",
                "created_on": "25-12-16",
                "modified_by": "Aswin",
                "modified_on": "25-1-17",
                "active": "True"
            }
        ];
        $scope.gridOptions = {
            enableColumnResizing: true,
            paginationPageSizes: [25, 50, 75],
            paginationPageSize: 25
        };
        $scope.gridOptions.columnDefs = [
            { name: 'ID', field: 'id', cellTooltip: true, headerTooltip:true, enableHiding: false, width: 50},
            { name: 'Innovation', field: 'innovation_name', cellTooltip: true, headerTooltip:true, enableHiding: false,  width: 120},
            { name: 'Description', field: 'innovation_description', cellTooltip: true, headerTooltip:true, enableHiding: false,  width: 120},
            { name: 'Owner', field: 'innovation_owner', cellTooltip: true, headerTooltip:true, enableHiding: false,  width: 120},
            { name: 'Approver', field: 'approved_by', cellTooltip: true, headerTooltip:true, enableHiding: false,  width: 120},
            { name: 'Approved On', field: 'approved_on', cellTooltip: true, headerTooltip:true, enableHiding: false,  width: 120},
            { name: 'Approver Comments', field: 'approver_Comments', cellTooltip: true, headerTooltip:true, enableHiding: false,  width: 120},
            { name: 'Assigned To', field: 'assigned_to', cellTooltip: true, headerTooltip:true, enableHiding: false,  width: 120},
            { name: 'Assigned On', field: 'assgied_on', cellTooltip: true, headerTooltip:true, enableHiding: false,  width: 120},
            { name: 'Innovation Start Date', field: 'innovation_start_date', cellTooltip: true, headerTooltip:true, enableHiding: false,  width: 120},
            { name: 'Innovation End Date', field: 'innovation_end_date', cellTooltip: true, headerTooltip:true, enableHiding: false,  width: 120},
            { name: 'Status', field: 'status', cellTooltip: true, headerTooltip:true, enableHiding: false,  width: 80},
            { name: 'Comments', field: 'comments', cellTooltip: true, headerTooltip:true, enableHiding: false,  width: 120},
            { name: 'Created By', field: 'created_by', cellTooltip: true, headerTooltip:true, enableHiding: false,  width: 120},
            { name: 'Created On', field: 'created_on', cellTooltip: true, headerTooltip:true, enableHiding: false,  width: 120},
            { name: 'Modified By', field: 'modified_by', cellTooltip: true, headerTooltip:true, enableHiding: false,  width: 120},
            { name: 'Modified On', field: 'modified_on', cellTooltip: true, headerTooltip:true, enableHiding: false, width: 120},
            { name: 'Active', field: 'active', cellTooltip: true, enableHiding: false, headerTooltip:true, width: 80}
        ];

        $scope.gridOptions.data = $scope.data;
        */
        $scope.shwmdl = function(val){
            $scope.crntsts = val;
            ngDialog.openConfirm({
                template: '../assets/html/CustomModal.html',
                className: 'ngdialog-theme-default',
                scope: $scope
            }).then(
                function (value) {
                    console.log("confirm");
                },
                function (reason) {
                    console.log('Modal promise rejected. Reason: ', reason);
            });
        };
        $scope.pieData = '';

        $scope.stsData = [
            {
                "value" : "Yet-To-Start",
                "name" : "Yet-To-Start"
            },
            {
                "value" : "Completed",
                "name" : "Completed"
            },
            {
                "value" : "In-Progress",
                "name" : "In-Progress"
            }
        ];
        $scope.pieData = [
            {
                label: "In-Progress",
                value: ""
            },
            {
                label: "Completed",
                value: ""
            },
            {
                label: "Yet-To-Start",
                value: ""
            }
        ];
        //pie chart
        $scope.myDataSource = {
            chart: {
                caption: "Utilities Status",
                subcaption: "2016 - 2017",
                startingangle: "120",
                showlabels: "0",
                showlegend: "1",
                enablemultislicing: "0",
                slicingdistance: "15",
                showpercentvalues: "1",
                showpercentintooltip: "0",
                plottooltext: "Status : $label No.of.utilities : $datavalue",
                theme: "fint"
            },
            data: $scope.pieData
        };
        //end pie
        //graph chart
        $scope.attrs = {
            "caption": "Utilities - 2017",
            "numberprefix": "",
            "plotgradientcolor": "",
            "bgcolor": "FFFFFF",
            "showalternatehgridcolor": "0",
            "divlinecolor": "CCCCCC",
            "showvalues": "0",
            "showcanvasborder": "0",
            "canvasborderalpha": "0",
            "canvasbordercolor": "CCCCCC",
            "canvasborderthickness": "1",
            "yaxismaxvalue": "50",
            "captionpadding": "10",
            "linethickness": "3",
            "yaxisvaluespadding": "15",
            "legendshadow": "0",
            "legendborderalpha": "0",
            "palettecolors": "#f8bd19,#008ee4,#33bdda,#e44a00,#6baa01,#583e78",
            "showborder": "0"
        };

        $scope.categories = [
            {
                "category": [
                    {
                        "label": "week1"
                    },
                    {
                        "label": "Week2"
                    },
                    {
                        "label": "Week3"
                    },
                    {
                        "label": "Week4"
                    }
                ]
            }
        ];

        $scope.dataset = [
            {
                "seriesname": "In-Progress",
                "data": [
                    {
                        "value": "10"
                    },
                    {
                        "value": "15"
                    },
                    {
                        "value": "20"
                    },
                    {
                        "value": "25"
                    }
                ]
            },
            {
                "seriesname": "Yet-To-Start",
                "data": [
                    {
                        "value": "35"
                    },
                    {
                        "value": "28"
                    },
                    {
                        "value": "20"
                    },
                    {
                        "value": "5"
                    }
                ]
            },
            {
                "seriesname": "Completed",
                "data": [
                    {
                        "value": "5"
                    },
                    {
                        "value": "7"
                    },
                    {
                        "value": "10"
                    },
                    {
                        "value": "20"
                    }
                ]
            }
        ];
        //end chart
        //Drag Drop Strt
        $scope.loading = true;
        $scope.models = [
            {listName: "Available Columns", items: [], dragging: false},
            {listName: "Selected for Report", items: [], dragging: false}
        ];

        var list_data = ["Utilities","Description","Ideated By","Enforcer","Status","Module","Published"/*,"Comments","Created By","Modified By","Active"*/];

        var list_id = ["innovation_name","innovation_description","innovation_owner","assigned_to","status","module","publish_stat"/*,"comments","created_by","modified_by","active"*/];

        $scope.models[0].items = [];
        $scope.models[1].items = [];

        for (var i = 0; i < list_data.length ; i++) {
            $scope.models[0].items.push({label: list_data[i],id : list_id[i] });
        }

        /**
         * dnd-dragging determines what data gets serialized and send to the receiver
         * of the drop. While we usually just send a single object, we send the array
         * of all selected items here.
         */
        $scope.getSelectedItemsIncluding = function(list, item) {
            item.selected = true;
            return list.items.filter(function(item) { return item.selected; });
        };
        /**
         * We set the list into dragging state, meaning the items that are being
         * dragged are hidden. We also use the HTML5 API directly to set a custom
         * image, since otherwise only the one item that the user actually dragged
         * would be shown as drag image.
         */
        $scope.onDragstart = function(list, event) {
            list.dragging = true;
            if (event.dataTransfer.setDragImage) {
                var img = new Image();
                //img.src = 'framework/vendor/ic_content_copy_black_24dp_2x.png';
                event.dataTransfer.setDragImage(img, 0, 0);
            }
        };
        /**
         * In the dnd-drop callback, we now have to handle the data array that we
         * sent above. We handle the insertion into the list ourselves. By returning
         * true, the dnd-list directive won't do the insertion itself.
         */
        $scope.onDrop = function(list, items, index) {
            angular.forEach(items, function(item) { item.selected = false; });
            list.items = list.items.slice(0, index)
                .concat(items)
                .concat(list.items.slice(index));
            return true;
        };
        /**
         * Last but not least, we have to remove the previously dragged items in the
         * dnd-moved callback.
         */
        $scope.onMoved = function(list) {
            list.items = list.items.filter(function(item) { return !item.selected; });
        };
        //End PDrag Drop
        //Srtr Table
        $scope.filtering = false;
        $scope.loading = true;
        for (var i in $scope.searchfilter)
        {
            delete $scope.searchfilter[i] ;

        }
        $scope.searchfilter = {};
        $scope.togglefilter = function() {
            $scope.filtering = !$scope.filtering;
            if(!$scope.filtering)
            {
                for (var i in $scope.searchfilter)
                {
                    delete $scope.searchfilter[i] ;
                }
                $scope.searchfilter = {};
            } else
            {
                for (var j in $scope.searchfilter)
                {
                    $scope.searchfilter[j] = '';
                }
            }
        };
        $scope.buttonName = 'Get Report';
        $scope.reportdata = [];
        $scope.getdragdrop = function(){
            $scope.loading = true;
        };
        $scope.optSelctd = function(){
            switch ($scope.slctd) {
                case 'addUtility':
                    $scope.dataJson = {};
                    $scope.arw = "addUtility";
                    break;
                case 'chrtView':
                    var url = "https://ozarks.accenture.com/UtilityDashboard/innovationdetails/getAllDetails";
                    var response = $http({method : 'GET',url : url, contentType: 'application/json'});
                    response.success(function(data, status, headers, config) {
                        var reportdata = angular.fromJson(data);
                        /*data for Pie Chart*/
                        var inProgress = $filter('filter')(reportdata, { status: "In-Progress" });
                        $scope.inProgress = inProgress;
                        var inProgressLen = inProgress.length;
                        var yetToStart = $filter('filter')(reportdata, { status: "Yet-To-Start" });
                        $scope.yetToStart = yetToStart;
                        var yetToStartLen = yetToStart.length;
                        var Completed = $filter('filter')(reportdata, { status: "Completed" });
                        $scope.completed = Completed;
                        var CompletedLen = Completed.length;
                        angular.forEach($scope.pieData, function(data, key){
                            switch (data.label) {
                                case 'In-Progress':
                                    data.value = inProgressLen;
                                    break;
                                case 'Yet-To-Start':
                                    data.value = yetToStartLen;
                                    break;
                                case 'Completed':
                                    data.value = CompletedLen;
                                    break;
                                default:
                                    break;
                            }
                        });
                        $scope.pieTblData = [
                            {
                                "status" : "In-Progress",
                                "qty": inProgressLen
                            },
                            {
                                "status" : "Yet-To-Start",
                                "qty": yetToStartLen
                            },
                            {
                                "status" : "Completed",
                                "qty": CompletedLen
                            }
                        ];
                        $scope.arw = "chrtView";
                        /*End of data for Pie Chart*/
                    });
                    response.error(function(data, status, headers, config) {
                        alert("Oh Snap!! Something went wrong, please try again after some time!!!");
                    });
                    break;
                case 'grphView':
                    $scope.arw = "grphView";
                    break;
                case 'tab':
                    $scope.arw = "tab";
                    break;
                default:
                    $scope.arw = '';
                    break;
            }
        };
        $scope.crtUtlity = function(){
            var url = "https://ozarks.accenture.com/UtilityDashboard/innovationdetails/userinput";
            if($scope.dataJson && $scope.dataJson.innovation_name && $scope.dataJson.status) {
                var response = $http({
                    method: 'POST',
                    url: url,
                    contentType: 'application/json',
                    data: $scope.dataJson
                });
                response.success(function (data, status, headers, config) {
                    alert("Utility saved successfully!!!");
                });
                response.error(function (data, status, headers, config) {
                    alert("Oh Snap!! Something went wrong, please try again after some time!!!");
                });
            }else{
                alert("Please enter atleast Innovation name and status!!!");
            }
        };
        $scope.getreport = function() {
            if ($scope.models[1].items.length >= 1) {
                $scope.isDisabled = true;
                $scope.buttonName = 'Loading data..';
                $scope.sortType = $scope.models[1].items[0].id; //default first field sorted
                var url = "https://ozarks.accenture.com/UtilityDashboard/innovationdetails/getAllDetails";
                $scope.reportName = 'Utilities Details';
                for (var i = 0; i < $scope.models[1].items.length; i++) {
                    var idvalue = 'searchfilter.' + $scope.models[1].items[i].id;
                    var model = $parse(idvalue);
                    model.assign($scope, "");
                }
                var response = $http({method: 'GET', url: url, contentType: 'application/json'});
                response.success(function (data, status, headers, config) {

                    for (var i = 0; i < $scope.models[1].items.length; i++) {
                        var idvalue = 'searchfilter.' + $scope.models[1].items[i].id;
                        var model = $parse(idvalue);
                        model.assign($scope, "");
                    }
                    $scope.reportdata = angular.fromJson(data);
                    $scope.loading = false;
                    $scope.buttonName = 'Get Report';
                    $scope.isDisabled = false;
                });
                response.error(function (data, status, headers, config) {
                    alert("Oh Snap!! Something went wrong, please try again after some time!!!");
                    $scope.loading = true;
                    $scope.buttonName = 'Get Report';
                    $scope.isDisabled = false;
                });
            }else{
                alert("Please select atleast one column!!!");
            }
        };
    });

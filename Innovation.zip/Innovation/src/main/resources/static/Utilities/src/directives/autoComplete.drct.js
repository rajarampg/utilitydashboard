(function() {
    angular.module("app.core")
        .directive("autoComplete", autoComplete);

    autoComplete.$inject = [];

    function autoComplete() {
        var directive = {
            restrict : "E",
            template : "<input type='text' class='drpdown' ng-model='vm.model' placeholder='Enter Text' typeahead='item.name as item.name for item in vm.inputdata | filter:$viewValue | limitTo:8'>",
            scope : {
                model: "=",
                inputdata: "="
            },
            controller : autoCompleteController,
            controllerAs : "vm",
            bindToController : true
        };

        return directive;
    }

    autoCompleteController.$inject = [];

    function autoCompleteController() {
        var vm = this;

    }
})();
package com.walmart.innovationdetails.model;

import org.springframework.stereotype.Component;

import com.walmart.innovationdetails.dto.jaxb.InnovationSkill;

@Component
public class InnovationSkillMapper {

public InnovationSkillMapping detailsMapper(InnovationSkill innovation) {

 InnovationSkillMapping innovationSkillMapping = new InnovationSkillMapping();

// innovationSkillMapping.setId(innovation.getId());
 innovationSkillMapping.setApproved_by(innovation.getApproved_by());
 innovationSkillMapping.setApproved_on(innovation.getApproved_on());
 innovationSkillMapping.setApprover_comments(innovation.getApprover_comments());
 innovationSkillMapping.setAssigned_on(innovation.getAssigned_on());
 innovationSkillMapping.setAssigned_to(innovation.getAssigned_to());
 innovationSkillMapping.setComments(innovation.getComments());
 innovationSkillMapping.setModule(innovation.getModule());
 innovationSkillMapping.setPublishStatus(innovation.getPublish_stat());
 innovationSkillMapping.setCreated_by(innovation.getCreated_by());
 innovationSkillMapping.setCreated_on(innovation.getCreated_on());
 innovationSkillMapping.setInnovation_description(innovation.getInnovation_description());
 innovationSkillMapping.setInnovation_end_date(innovation.getInnovation_end_date());
 innovationSkillMapping.setInnovation_name(innovation.getInnovation_name());
 innovationSkillMapping.setInnovation_owner(innovation.getInnovation_owner());
 innovationSkillMapping.setInnovation_start_date(innovation.getInnovation_start_date());
 innovationSkillMapping.setModified_by(innovation.getModified_by());
 innovationSkillMapping.setModified_on(innovation.getModified_on());
 innovationSkillMapping.setStatus(innovation.getStatus());
 innovationSkillMapping.setActive(innovation.isActive());
 return innovationSkillMapping;
 }

}

package com.walmart.innovationdetails.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.walmart.innovationdetails.dao.api.InnovationDetailsDao;
import com.walmart.innovationdetails.dto.jaxb.InnovationSkill;
import com.walmart.innovationdetails.model.InnovationSkillMapping;

@Repository

public class InnovationDetailsDaoImpl implements InnovationDetailsDao {




 @SuppressWarnings("unused")
 public void insertWithPreparedStatement(InnovationSkill innovation) throws SQLException {
 Connection connection = null;

 PreparedStatement createPreparedStatement = null;
 PreparedStatement insertPreparedStatement = null;
 PreparedStatement selectPreparedStatement = null;



 String SelectQuery = "select * from innovationdetails";

try {
 connection.setAutoCommit(false);

createPreparedStatement = connection.prepareStatement("Innovation/create.sql");
 createPreparedStatement.executeUpdate();
 createPreparedStatement.close();

insertPreparedStatement = connection.prepareStatement("Innovation/insert.sql");
// insertPreparedStatement.setInt(1,innovation.getId() );
 insertPreparedStatement.setString(2, innovation.getInnovation_name());
 insertPreparedStatement.setString(3,innovation.getInnovation_description() );
 insertPreparedStatement.setString(4, innovation.getInnovation_owner());
 insertPreparedStatement.setString(5,innovation.getApproved_by());
 insertPreparedStatement.setDate(6, innovation.getApproved_on());
 insertPreparedStatement.setString(7,innovation.getApprover_comments() );
 insertPreparedStatement.setString(8, innovation.getAssigned_to());
 insertPreparedStatement.setDate(9,innovation.getAssigned_on());
 insertPreparedStatement.setDate(10, innovation.getInnovation_start_date());
 insertPreparedStatement.setDate(11,innovation.getInnovation_end_date());
 insertPreparedStatement.setString(12, innovation.getStatus());
 insertPreparedStatement.setString(13,innovation.getComments());
 insertPreparedStatement.setString(14, innovation.getCreated_by());
 insertPreparedStatement.setDate(15,innovation.getCreated_on());
 insertPreparedStatement.setString(16, innovation.getModified_by());
 insertPreparedStatement.setDate(17,innovation.getModified_on() );
 insertPreparedStatement.setBoolean(18, innovation.isActive());

 insertPreparedStatement.executeUpdate();
 insertPreparedStatement.close();

selectPreparedStatement = connection.prepareStatement(SelectQuery);
 ResultSet rs = selectPreparedStatement.executeQuery();
 System.out.println("H2 In-Memory Database inserted through PreparedStatement");
 while (rs.next()) {
 System.out.println("Id " + rs.getInt("id") + " Name " + rs.getString("innovation_name"));
 }
 selectPreparedStatement.close();

connection.commit();
 } catch (SQLException e) {
 System.out.println("Exception Message " + e.getLocalizedMessage());
 } catch (Exception e) {
 e.printStackTrace();
 } finally {
 connection.close();
 }
}

@Override
 public List<InnovationSkillMapping> findById(int id) throws SQLException {
 // TODO Auto-generated method stub
 return null;
 }
}

// private static Connection getDBConnection() {
// Connection dbConnection = null;
// try {
// Class.forName(DB_DRIVER);
// } catch (ClassNotFoundException e) {
// System.out.println(e.getMessage());
// }
// try {
// dbConnection = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
// return dbConnection;
// } catch (SQLException e) {
// System.out

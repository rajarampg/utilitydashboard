/**
 * 
 */
package com.walmart.innovationdetails.common;

/**
 * @author ragov2
 *
 */
public class ResponseMessage {

 private Integer responseCode;
 private String responseMessage;
 /**
 * @return the responseCode
 */
 public Integer getResponseCode() {
 return responseCode;
 }
 /**
 * @param responseCode the responseCode to set
 */
 public void setResponseCode(Integer responseCode) {
 this.responseCode = responseCode;
 }
 /**
 * @return the responseMessage
 */
 public String getResponseMessage() {
 return responseMessage;
 }
 /**
 * @param responseMessage the responseMessage to set
 */
 public void setResponseMessage(String responseMessage) {
 this.responseMessage = responseMessage;
 }

}

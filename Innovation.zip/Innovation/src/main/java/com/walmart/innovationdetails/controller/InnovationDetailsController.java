package com.walmart.innovationdetails.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.innovationdetails.common.ApplicationConstants;
import com.walmart.innovationdetails.common.ResponseMessage;
import com.walmart.innovationdetails.dto.jaxb.InnovationSkill;
import com.walmart.innovationdetails.model.InnovationSkillMapping;
import com.walmart.innovationdetails.services.api.InnovationDetailsService;

@CrossOrigin
@RestController
@RequestMapping(value = "/innovationdetails")
public class InnovationDetailsController {

@Autowired
 InnovationDetailsService innovationDetailsService;

 private static final Logger logger = LogManager
 .getLogger(InnovationDetailsController.class);

 @RequestMapping(value = "/userinput", method = RequestMethod.POST, headers = "Accept=application/json",produces="application/json",consumes = "application/json")

 @ResponseBody
 public ResponseMessage captureInnovationDetails(@RequestBody InnovationSkill innovation) {
 ResponseMessage respMsg= new ResponseMessage();

try {
 String respFromService=innovationDetailsService.captureInnovationDetails(innovation);
 respMsg.setResponseCode(ApplicationConstants.SUCCESS_CODE);
respMsg.setResponseMessage(respFromService);
 } catch (Exception e) {
 // TODO: handle exception
 respMsg.setResponseCode(ApplicationConstants.SERVER_EXCEPTION_CODE);
 respMsg.setResponseMessage(ApplicationConstants.SERVER_EXCEPTION_MSG);
 }

 return respMsg;
 }

 @RequestMapping(value = "/getDetails/{id}", method = RequestMethod.GET)
 @ResponseBody
 public List<InnovationSkillMapping> getInnovationDetails(
 @PathVariable String id) {
 return innovationDetailsService.getInnovationDetails(id);
 }

@RequestMapping(value = "/getAllDetails", method = RequestMethod.GET,produces="application/json")
 @ResponseBody
 public List<InnovationSkillMapping> getAllInnovationDetails(
 ) {
 return innovationDetailsService.getAllInnovationDetails();
 }


 @RequestMapping(value = "/deleteDetails/{id}", method = RequestMethod.DELETE,produces="application/json")
 @ResponseBody
 public ResponseMessage deleteInnovationDetailsById(
 @PathVariable String id) {
 ResponseMessage respMsg= new ResponseMessage();
 try {
 String respMsgFromService=innovationDetailsService.deleteInnovationDetailsById(id);
 respMsg.setResponseCode(ApplicationConstants.SUCCESS_CODE);
 respMsg.setResponseMessage(respMsgFromService);
 } catch (Exception e) {
 // TODO: handle exception
 respMsg.setResponseCode(ApplicationConstants.SERVER_EXCEPTION_CODE);
 respMsg.setResponseMessage(ApplicationConstants.SERVER_EXCEPTION_MSG);
 }

 return respMsg;
 }

 @RequestMapping(value = "/deleteAllDetails", method = RequestMethod.DELETE,produces="application/json")
 @ResponseBody
 public ResponseMessage deleteAllInnovationDetails(
 ) {
 ResponseMessage respMsg= new ResponseMessage();
 try {
 String respMsgFromService=innovationDetailsService.deleteAllInnovationDetails();
 respMsg.setResponseCode(ApplicationConstants.SUCCESS_CODE);
 respMsg.setResponseMessage(respMsgFromService);
 } catch (Exception e) {
 // TODO: handle exception
 respMsg.setResponseCode(ApplicationConstants.SERVER_EXCEPTION_CODE);
respMsg.setResponseMessage(ApplicationConstants.SERVER_EXCEPTION_MSG);
 }

 return respMsg;
 }

}

package com.walmart.innovationdetails.dao.api;

import java.sql.SQLException;
import java.util.List;

import com.walmart.innovationdetails.dto.jaxb.InnovationSkill;
import com.walmart.innovationdetails.model.InnovationSkillMapping;


public interface InnovationDetailsDao {

 public void insertWithPreparedStatement(InnovationSkill innovation) throws SQLException ;

public List<InnovationSkillMapping> findById(int id) throws SQLException;
}

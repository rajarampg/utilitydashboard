package com.walmart.innovationdetails.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walmart.innovationdetails.dto.jaxb.InnovationSkill;
import com.walmart.innovationdetails.model.InnovationSkillMapper;
import com.walmart.innovationdetails.model.InnovationSkillMapping;
import com.walmart.innovationdetails.model.InnovationSkillRepository;
import com.walmart.innovationdetails.services.api.InnovationDetailsService;

/**
 * Class documentation text
 * 
 * @author SriKamakshi
 * @Time 2017/01/19 17:27:05
 */
@Component
public class InnovationDetailsServiceImpl implements InnovationDetailsService {

@Autowired
 InnovationSkillMapper innovationMapper;

@Autowired
 InnovationSkillRepository innovationRepo;
 //
 // @Autowired
 // InnovationDetailsDao innovationDetailsDao;

@Override
 public String captureInnovationDetails(InnovationSkill innovation) {

InnovationSkillMapping innovationinfo = innovationMapper.detailsMapper(innovation);
 String status="Failed to store the details!";

try {
 innovationRepo.save(innovationinfo);
 // innovationDetailsDao.save(innovationinfo);
 status="Successfully stored the details!";

} catch (Exception e) {
 System.out.println("Exception" + e);
 }
 return status;

}

@Override
 public List<InnovationSkillMapping> getInnovationDetails(String id) {

List<InnovationSkillMapping> innovation = new ArrayList<InnovationSkillMapping>();

try {
 innovation = innovationRepo.findByInnovationName(id);
 } catch (Exception e) {
 System.out.println("Exception" + e);
 }

return innovation;
 }

@Override
 public List<InnovationSkillMapping> getAllInnovationDetails() {
 // TODO Auto-generated method stub
 List<InnovationSkillMapping> innovation = new ArrayList<InnovationSkillMapping>();

try {
 innovation = (List<InnovationSkillMapping>) innovationRepo.findAll();
 } catch (Exception e) {
 System.out.println("Exception" + e);
 }

return innovation;
 }


@Override
 public String deleteInnovationDetailsById(String id) {
 // TODO Auto-generated method stub
 String status = "Failed to delete innovation details!";
 try {
 innovationRepo.delete(id);
 status="Successfully deleted the innovation details!";
 } catch (Exception e) {
 System.out.println("Exception" + e);
 }

return status;
 }


 @Override
 public String deleteAllInnovationDetails() {
 // TODO Auto-generated method stub
 String status = "Clean up failed!";
 try {
 innovationRepo.deleteAll();
 status="Successfully cleaned up the DB!";
 } catch (Exception e) {
 System.out.println("Exception" + e);
 }

return status;
 }

}

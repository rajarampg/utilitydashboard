package com.walmart.innovationdetails.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;


@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)
@Table(name = "innovationdetails")
public class InnovationSkillMapping implements Serializable {

/**
 * 
 */
 private static final long serialVersionUID = 1L;
//@Id
// @GeneratedValue(strategy = GenerationType.AUTO)
// @Column(name="id")
// private int id;

 @Id
 @Column(name="innovation_name")
 private String innovationName;

 @Column(name="innovation_description")
 private String innovation_description;

 @Column(name="innovation_owner")
 private String innovation_owner;

 @Column(name="approved_by")
 private String approved_by;

 @Column(name="approved_on")
 private Date approved_on;

 @Column(name="approver_comments")
 private String approver_comments;

 @Column(name="assigned_to")
private String assigned_to;

 @Column(name="assgied_on")
 private Date assigned_on;

 @Column(name="innovation_start_date")
 private Date innovation_start_date;

 @Column(name="innovation_end_date")
 private Date innovation_end_date;

 @Column(name="status")
 private String status;

 @Column(name="comments")
 private String comments;
 
 @Column(name="module")
 private String module;
 
 
@Column(name="publish_stat")
 private String publishStatus;

 @Column(name="created_by")
 private String created_by;

 @Column(name="created_on")
 private Date created_on;

 @Column(name="modified_by")
 private String modified_by;

 @Column(name="modified_on")
 private Date modified_on;

 @Column(name="active")
 private boolean active;

// public int getId() {
// return id;
// }
//
// public void setId(int id) {
// this.id = id;
// }

public String getInnovation_name() {
 return innovationName;
 }

public void setInnovation_name(String innovation_name) {
 this.innovationName = innovation_name;
 }

public String getInnovation_description() {
 return innovation_description;
 }

public void setInnovation_description(String innovation_description) {
 this.innovation_description = innovation_description;
 }

public String getInnovation_owner() {
 return innovation_owner;
 }

public void setInnovation_owner(String innovation_owner) {
 this.innovation_owner = innovation_owner;
 }

public String getApproved_by() {
 return approved_by;
 }

public void setApproved_by(String approved_by) {
 this.approved_by = approved_by;
 }

public Date getApproved_on() {
 return approved_on;
 }

public void setApproved_on(Date approved_on) {
 this.approved_on = approved_on;
 }

public String getApprover_comments() {
return approver_comments;
 }

public void setApprover_comments(String approver_comments) {
 this.approver_comments = approver_comments;
 }

public String getAssigned_to() {
 return assigned_to;
 }

public void setAssigned_to(String assigned_to) {
 this.assigned_to = assigned_to;
 }

public Date getAssigned_on() {
 return assigned_on;
 }

public void setAssigned_on(Date assigned_on) {
 this.assigned_on = assigned_on;
 }

public Date getInnovation_start_date() {
return innovation_start_date;
 }

public void setInnovation_start_date(Date innovation_start_date) {
 this.innovation_start_date = innovation_start_date;
 }

public Date getInnovation_end_date() {
return innovation_end_date;
 }

public void setInnovation_end_date(Date innovation_end_date) {
 this.innovation_end_date = innovation_end_date;
 }

public String getStatus() {
 return status;
 }

public void setStatus(String status) {
 this.status = status;
 }

public String getComments() {
 return comments;
 }

public void setComments(String comments) {
 this.comments = comments;
 }

public String getModule() {
	return module;
}

public void setModule(String module) {
	this.module = module;
}

public String getPublishStatus() {
	return publishStatus;
}

public void setPublishStatus(String publishStatus) {
	this.publishStatus = publishStatus;
}


public String getCreated_by() {
 return created_by;
 }

public void setCreated_by(String created_by) {
 this.created_by = created_by;
 }

public Date getCreated_on() {
 return created_on;
 }

public void setCreated_on(Date created_on) {
 this.created_on = created_on;
 }

public String getModified_by() {
 return modified_by;
 }

public void setModified_by(String modified_by) {
 this.modified_by = modified_by;
 }

public Date getModified_on() {
 return modified_on;
 }

public void setModified_on(Date modified_on) {
 this.modified_on = modified_on;
 }

public boolean isActive() {
 return active;
 }

public void setActive(boolean active) {
 this.active = active;
 }

public static long getSerialversionuid() {
 return serialVersionUID;
 }
}

package com.walmart.innovationdetails.model;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

public interface InnovationSkillRepository extends CrudRepository<InnovationSkillMapping, String>,JpaSpecificationExecutor<InnovationSkillMapping>{

List<InnovationSkillMapping> findByInnovationName(String innovationName);

}

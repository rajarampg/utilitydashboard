package com.walmart.innovationdetails.services.api;

import java.util.List;

import com.walmart.innovationdetails.dto.jaxb.InnovationSkill;
import com.walmart.innovationdetails.model.InnovationSkillMapping;

public interface InnovationDetailsService {

 public String captureInnovationDetails(InnovationSkill innovation);

public List<InnovationSkillMapping> getInnovationDetails(String id);
 public List<InnovationSkillMapping> getAllInnovationDetails();

String deleteAllInnovationDetails();

String deleteInnovationDetailsById(String id);
}

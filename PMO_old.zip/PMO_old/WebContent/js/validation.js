function isNumber(evt)
 {
	 var iKeyCode =(evt.which) ? evt.which :evt.KeyCode;
	 if (!(iKeyCode == 8 || iKeyCode == 13) && (iKeyCode < 48 || iKeyCode > 57)) {
		 alert("Please Enter Only Number");
		 return false;
		 }		
 }

function streamFilter(tgtElement){
	var portfolio = this.value;
	var filteredElements = [];
	filteredElements.push(allStreams[0]);
	allStreams.each(function(){
		if($(this).attr('class') == portfolio){
			filteredElements.push(this);
		}
	});
	allStreams.remove();
	$(tgtElement.data).append(filteredElements);
}

function getLocationId(locationType){
	var identifier='';
	switch(locationType){
		case 'Onshore':
			identifier = 'onshoreloc';
			break;
		case 'IDC':
			identifier = 'offshoreloc';
			break;
		case 'PDC':
			identifier = 'pdcloc';
			break;
	}
	return identifier;
}

function checkForNull(string){
	if(string === undefined)
		return "";
	else
		return string;
}

function addReqAttr(fieldValue){
	console.log(fieldValue);
	removeAttrs();
	switch(fieldValue){
	case 'onshoreloc':
		$('#onshoreloc').attr("required", "");
		$('#visa').attr("required", true);
		$('#durationDrop').attr("required", "");
		break;
	case 'offshoreloc':
		$('#offshoreloc').attr("required", "");
		break;
	case 'pdcloc':
		document.getElementById("pdcloc").required = true;
		break;
	}
}

function removeAttrs(){
	$('#onshoreloc').removeAttr("required");
	$('#visa').removeAttr("required");
	$('#durationDrop').removeAttr("required");
	$('#offshoreloc').removeAttr("required");
	$('#pdcloc').removeAttr("required");
}



$(function(){
	/*$(".fieldCheck").off("focus").on("focus",function(){
		$(this).removeClass("redAlert");
		$("#error_alert,#error_alert_eid").hide();
	});*/	
	$('textarea[maxlength]').on('keyup blur', function() {		
	    // Store the maxlength and value of the field.
	    var maxlength = $(this).attr('maxlength');
	    var val = $(this).val();

	    // Trim the field if it has content over the maxlength.
	    if (val.length > maxlength) {
	        $(this).val(val.slice(0, maxlength));
	    }
	});
	
/*	$("#roffExitDate").off("click").on("click", function(){
		if($(this).is(":checked")){
			$(this).parents(".panel-body").find("#roffDate").val("Exit").attr("disabled",true);
			$(".rolloffreason").hide();
	 	    $(".exitreason").show();
		}
		else
		{
			$(this).parents(".panel-body").find("#roffDate").val("").attr("disabled",false);
			$(".rolloffreason,.exitreason").hide();
		}
	});*/
	
	//$("#myModal").on("hide.bs.modal",function(e){console.log("called");e.preventDefault();});
	
});
$.fn.populateDialogBox = function()
{
    function hidefield(){
		$("#visatype").hide();
		$("#duration").hide();
	}  
     
function showfield(){
		$("#visatype").show();
		$("#duration").show();
	} 
	var getListDatas = $(this).parents("tr").children("td");	
	$.each(getListDatas,function(i,v){			console.log($("#myModal").find(".form-control").eq(i).prop("tagName"), $(v).text());
		$("#myModal").find(".form-control").eq(i).val($(v).text());			
	});
	
	hidefield();

	var site= $('#siteLocation').val();
	if(site=="Onshore"){
		showfield();
	}
	else{
		
		hidefield();
	}
	
	
	  var onlocation = '<option selected="selected" value=""> Choose Location </option> <option value="Bentonville">Bentonville</option>';
	  var offlocation = '<option selected="selected" value=""> Choose Location </option><option value="Chennai">Chennai</option><option value="Bangalore">Bangalore</option><option value="Gurgaon">Gurgaon</option>';
	  $("#siteLocation").on('change',function(){
	        if($(this).val()=="OnShore"){
	            $("#offshoreloc").html(onlocation);
	        }else if($(this).val()=="OffShore"){
	            $("#offshoreloc").html(offlocation);
	        }
	    }); 
	    
	
	
	
};

$.fn.save_change_call = function()
{	
	
	checkFields();	
	
	if(!checkFields().inpFld && !checkFields().emlFld && !checkFields().Vdate && !checkFields().RODate && !checkFields().AOdate)
		{
			$.ajax({
				 type:'POST',
			     url:'devSave',			     
			     data: $("#basicBootstrapForm").serializeArray(),
			     success: function (data) {
			            alert("Details Saved successfully");
			            $("#basicBootstrapForm").submit();
			    }
			});
		}
	else
		{
			$("#myModal").on("hide.bs.modal",function(e){				
				e.preventDefault();
				$(this).off("hide.bs.modal");
				});				
		}
};

$.fn.delete_EmpDetails_fn = function(){	
	var CurEmployeeId = $("#basicBootstrapForm").find("#empIdModal").val();
	$.ajax({
		 type:'GET',
	     url:'devDetails?action=delete&employee_id='+CurEmployeeId,	    
	     success: function (data) {	
            	 alert("Details Deleted successfully");             	
	            $("#basicBootstrapForm").submit();
	            
	    }
	});
	
};
/*$.fn.delete_HardwareDetails_fn = function(){	
	var CurHardwareId = $("#basicBootstrapFormUpdateRsa").find("#rsaupdate").val();
	 
	$.ajax({
		 type:'GET',
	     url:'hardwareDelete?page=rsa&hardware_id='+CurHardwareId,	    
	     success: function (data) {	          
	            alert("Details Deleted successfully");
	           
	           $("#basicBootstrapFormUpdateRsa").submit();
	            
	    }
	});
	
};*/

$.fn.delete_HardwareDetails_fn_Mob = function(){	
	var CurHardwareIdMob = $("#basicBootstrapFormUpdateMob").find("#mobupdate").val();
	 
	$.ajax({
		 type:'GET',
	     url:'hardwareDelete?page=mob&hardware_id='+CurHardwareIdMob,	    
	     success: function (data) {	          
	            alert("Details Deleted successfully");
	           
	            $("#basicBootstrapFormUpdateMob").submit();
	            
	    }
	});

};

$.fn.delete_HardwareDetails_fn_Lap = function(){	
	var CurHardwareIdLap = $("#basicBootstrapFormUpdateLap").find("#lapupdate").val();
	 
	$.ajax({
		 type:'GET',
	     url:'hardwareDelete?page=lap&hardware_id='+CurHardwareIdLap,	    
	     success: function (data) {	          
	            alert("Details Deleted successfully");
	            
	           $("#basicBootstrapFormUpdateLap").submit();
	            
	    }
	});

};
function main_submit_fnc(e)
{
	var requestdate = $("#requestdate").val();
	var grantdate = $("#grantdate").val();
	checkFields();
	if(checkFields().inpFld || checkFields().emlFld || checkFields().Vdate || checkFields().RODate || checkFields().AOdate){
			
			if(checkFields().inpFld && checkFields().emlFld && checkFields().Vdate)
				{					
					$("#main_error_alert").html("Please fill the mandatory fields</br>Please provide valid Enterprise Id</br>Please provide valid date(s)");
				}
			else if(checkFields().inpFld && checkFields().emlFld)
				{					
					$("#main_error_alert").html("Please fill the mandatory fields</br>Please provide valid Enterprise Id");
				}
			else if(checkFields().inpFld)
				{	
					$("#main_error_alert").html("Please fill the mandatory fields");
				}
			else if(checkFields().emlFld)
				{	
					$("#main_error_alert").html("Please provide valid Enterprise Id");
				}	
			else if(checkFields().Vdate)
				{
					$("#main_error_alert").html("Please provide valid date(s)");				
				}
			else if(checkFields().RODate)
				{
					$("#main_error_alert").html("Roll Off Date cannot be lesser than Roll On Date");				
				}
			else if(checkFields().AOdate)
			{
				$("#main_error_alert").html(" grant Date cannot be lesser than Access Date");				
			}

			/*if(dateCompare(requestdate,grantdate))
							{
							if(dateCompare(rollondate,requestdate))
								{
								
								}
							else
								{
								$("#main_error_alert").html("Rollon Date cannot be lesser than Request Date and Grant Date");
								}
							
							}
						else
							{
							$("#main_error_alert").html("Grant Date and Request Date cannot be same or lesser than Request Date");
							}*/
			
			

			$('html, body').animate({scrollTop: 0}, "slow");
			return false;
			
	
	}
		return true;
	//e.preventDefault();
}

function checkFields(){
	var emptyInput = false;
	var emailInput = false;
	var validDate = false;
	var rollOffDateVal = false;
   var accesdate=false;
	$(".fieldCheck").removeClass("redAlert");
	$(".fieldCheck").each(function(){

		if($(this).val()=="")
			{
				if($(this).attr("id") == "roffDate")
					{
						if(!$(this).parents(".panel-body").find("#roffExitDate").is(":checked"))
							{
								$(this).addClass("redAlert");			
								emptyInput = true;
							}
					}
				else{
					$(this).addClass("redAlert");			
					emptyInput = true;
				}
				
			}
		else if($(this).attr("name")== "enterpriseId" || $(this).attr("name")== "eidModal")
			{				
				if(!validateEmail($(this).val())){
					$(this).removeClass("redAlert").addClass("redAlert");					
					emptyInput = true;
					emailInput = true;
				}				
			}
		
		else if($(this).attr("id") == "rollonDate")
			{
				//if(isValidDate($("#rollonDate").val()) && (isValidDate($("#roffDate").val()) || $(this).parents(".panel-body").find("#roffExitDate").is(":checked")))
				if(!isValidDate($("#rollonDate").val()))
					{
						$(this).removeClass("redAlert").addClass("redAlert");
						validDate = true;					
					}				
			}
			else if ($(this).attr("id") == "requestdate" || $(this).attr("id") == "grantdate")
			{
			if (isValidDate($("#requestdate").val()) && isValidDate($("#grantdate").val()))
				{
				if(!dateCompare($("#requestdate").val(),$("#grantdate").val()))
					{
						$(this).removeClass("redAlert").addClass("redAlert");
						accesdate=true;
					}
				}
			else
				{
					$(this).removeClass("redAlert").addClass("redAlert");
					validDate = true;	
				}
			}			
	});
	return {"inpFld":emptyInput,"emlFld":emailInput,"Vdate":validDate,"RODate":rollOffDateVal,"AOdate":accesdate};
	
}

function isAlphaNum(event)
{
//var key = (evt.which) ? evt.which :evt.KeyCode;
if ((event.keyCode > 64 && event.keyCode < 91) 
		|| (event.keyCode > 96 && event.keyCode < 123) 
		|| (event.keyCode == 32)||(event.keyCode > 47 && event.keyCode < 58))
 {
return true;
}
else{
alert("Please Enter Only Valid Characters");
return false;
}
}  
function maintenance_submit_fn(e){	
	var empSelector = $(".maintResourceName");
	$(".maintResourceName,.empIdFieldCheck,.fieldCheckToFill").removeClass("redAlert");
	var validateFields = checkValIsEmpty(empSelector);
	console.log(checkValIsEmpty(empSelector));
	if(validateFields.empField || validateFields.toFillField || validateFields.toFillCheck || validateFields.vDate ||validateFields.startdate )
		{
			if(validateFields.empField)
				{					
					$("#maintenance_error_alert").html("Please fill Resource name");
				}
			else if(validateFields.toFillField)
				{
					$(".fieldCheckToFill").addClass("redAlert");
					$("#maintenance_error_alert").html("Please fill the mandatory fields");
				}
			else if(validateFields.toFillCheck)
				{
					$("#maintenance_error_alert").html("Please fill the mandatory fields");
				}
			else if(validateFields.vDate)
				{
					$("#maintenance_error_alert").html("Please provide valid date(s)");		
				}
			else if(validateFields.startdate)
			{
				$("#maintenance_error_alert").html("Please provide valid bill start and end date(s)");		
			}
			$('html, body').animate({scrollTop: 0}, "slow");
			e.preventDefault();
		}	
}

function checkValIsEmpty(empSelector)
{
	var checkFlg = {"empField" : false, "toFillField" : true, "toFillCheck" : false,  "vDate" : false, "startdate" : false};
		
		if($(empSelector).val() == "")
			{
				checkFlg.empField = true;
				$(empSelector).addClass("redAlert");				
			}
		else
			{
				$(".fieldCheckToFill").each(function(index, elem){
						
					if($(elem).val() != "")
						{					
							checkFlg.toFillField = false;								
							var getToFillElements = $(elem).parents(".panel-body").find(".fieldCheckToFill");
							getToFillElements.each(function(i,v){				
								if($(v).val() == "")
								{
									checkFlg.toFillCheck = true;
									$(v).removeClass("redAlert").addClass("redAlert");
								}
								else if($(v).hasClass("fillDate") && !isValidDate($(v).val()))
								{
									$(v).addClass("redAlert");
									checkFlg.vDate = true;
								}	
								else if ($(this).attr("id") == "startDate" || $(this).attr("id") == "endDate")
								{
									if (isValidDate($("#startDate").val()) && isValidDate($("#endDate").val()))
									{
										if(!dateCompare($("#startDate").val(),$("#endDate").val()))
											{
												$(this).removeClass("redAlert").addClass("redAlert");
												checkFlg.startdate=true;
											}
										
									}
								}	
							
							});	
						}
							
				});
			}
	
	return checkFlg;	
}

function offboard_submit_fnc(e)
{
	
	if($(".offboardRollOff").val() == "" && !$(".offboardRollcheck").is(":checked"))
		{		
			$(".offboardRollOff,.offboardRollcheck").removeClass("redAlert").addClass("redAlert");
			$("#offboard_error_alert").html("Please fill the mandatory fields");
			$('html, body').animate({scrollTop: 0}, "slow");
			e.preventDefault();		
		}
	//!dateCompare($("#requestdate").val(),$("#grantdate").val())
	else if($(".offboardRollOff").val() != "" && !$(".offboardRollcheck").is(":checked"))
		{
			if(!dateCompare($("#rollonDate").val(),$("#roffDate").val()))
				{
					$(".offboardRollOff,.offboardRollcheck").removeClass("redAlert").addClass("redAlert");
					$("#offboard_error_alert").html("Please provide valid start and end date(s)");
					$('html, body').animate({scrollTop: 0}, "slow");
					e.preventDefault();
				}
		}
	
}


/* common functions */


function validateEmail(email) { 
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
} 

function isValidDate(subject){
	  if (subject.match(/^(?:(0[1-9]|1[012])[\- \/.](0[1-9]|[12][0-9]|3[01])[\- \/.](19|20)[0-9]{2})$/))
	  {
	    return true;
	  }
	  else
	  {
	    return false;
	  }
}

function dateCompare(date1, date2){
    return new Date(date2) > new Date(date1);
}
$.fn.save_change_call_update = function()
{	
	
	checkFields();	
	
	if(!checkFields().inpFld && !checkFields().emlFld && !checkFields().Vdate && !checkFields().RODate)
		{
			$.ajax({
				 type:'POST',
			     url:'hardwareUpdate?page=rsa',			     
			     data: $("#basicBootstrapFormUpdateRsa").serializeArray(),
			     success: function (data) {
			            alert("Details Saved successfully");
			            $("#basicBootstrapFormUpdateRsa").submit();			           
			           

			    }
			});
		}
	else
		{
			$("#myModalUpdate").on("hide.bs.modal",function(e){				
				e.preventDefault();
				$(this).off("hide.bs.modal");
				});				
		}
};

$.fn.save_change_call_update_Mob = function()
{	
	
	checkFields();	
	
	if(!checkFields().inpFld && !checkFields().emlFld && !checkFields().Vdate && !checkFields().RODate  && !checkFields().AOdate)
		{
			$.ajax({
				 type:'POST',
			     url:'hardwareUpdate?page=mob',			     
			     data: $("#basicBootstrapFormUpdateMob").serializeArray(),
			     success: function (data) {
			            alert("Details Saved successfully");
			            $("#basicBootstrapFormUpdateMob").submit();
			    }
			});
		}
	else
		{
			$("#myModalUpdateMob").on("hide.bs.modal",function(e){				
				e.preventDefault();
				$(this).off("hide.bs.modal");
				});				
		}
};

$.fn.save_change_call_update_Lap = function()
{	
	
	checkFields();	
	
	if(!checkFields().inpFld && !checkFields().emlFld && !checkFields().Vdate && !checkFields().RODate)
		{
			$.ajax({
				 type:'POST',
			     url:'hardwareUpdate?page=lap',			     
			     data: $("#basicBootstrapFormUpdateLap").serializeArray(),
			     success: function (data) {
			            alert("Details Saved successfully");
			            $("#basicBootstrapFormUpdateLap").submit();
			    }
			});
		}
	else
		{
			$("#myModalUpdateLap").on("hide.bs.modal",function(e){				
				e.preventDefault();
				$(this).off("hide.bs.modal");
				});				
		}
};
$.fn.populateDialogBoxUpdate = function()
{
	
	var getListDatasUpdate = $(this).parents("tr").children("td");	
	$.each(getListDatasUpdate,function(i,v){			
		$("#myModalUpdate").find(".form-control").eq(i).val($(v).text());			
	});
	
};



/*$.fn.populateDialogBoxRewards = function()
{
	
	var getListDatasUpdate = $(this).parents("tr").children("td");	
	$.each(getListDatasUpdate,function(i,v){			
		$("#myModalRewards").find(".form-control").eq(i).val($(v).text());			
	});
	
};*/




$.fn.populateDialogBoxUpdateMob = function()
{
	
	var getListDatasUpdateMob = $(this).parents("tr").children("td");	
	$.each(getListDatasUpdateMob,function(i,v){			
		$("#myModalUpdateMob").find(".form-control").eq(i).val($(v).text());			
	});
	
};

$.fn.populateDialogBoxUpdateLap = function()
{
	
	var getListDatasUpdateLap = $(this).parents("tr").children("td");	
	$.each(getListDatasUpdateLap,function(i,v){			
		$("#myModalUpdateLap").find(".form-control").eq(i).val($(v).text());			
	});
	
};
function lettersOnly(evt) {
	var charCode = (evt.which) ? evt.which : event.keyCode;
	 if (charCode != 46 && charCode > 31 
				&& (charCode < 48 || charCode > 57)){
		  return true;
	}
    else
   alert("please enter only aplabets") ;	
return false;
	}

function isNumb(evt)
{
	 var iKeyCode =(evt.which) ? evt.which :evt.KeyCode;
	 if (!(iKeyCode == 8 || iKeyCode == 13) && (iKeyCode > 48 || iKeyCode < 57)) {
		 alert("Please Enter valid input");
		 return false;
	 }
}

$.fn.delete_HardwareDetails_fn_cost = function(){	
	var CurHardwareId = $("#basicBootstrapFormUpdatecost").find("#empId").val();
	var month = $("#basicBootstrapFormUpdatecost").find("#month").val();
	var application = $("#basicBootstrapFormUpdatecost").find("#application").val();

	$.ajax({
		 type:'GET',
	     url:'hardwareDelete?page=cost&hardware_id='+CurHardwareId+'&month='+month+'&application='+application,	    
	     success: function (data) {	 
	           location.reload();
	           alert("details deleted succesfully");
	            
	    }
	});
	
};

$.fn.populateDialogBoxUpdatecost = function()
{
	
	var getListDatasUpdatecost = $(this).parents("tr").children("td");	
	$.each(getListDatasUpdatecost,function(i,v){			
		$("#myModalUpdatecost").find(".form-control").eq(i).val($(v).text());			
	});
	
};

$.fn.populateHardwaresReportDialog = function()
{
	var getListDatasUpdateLap = $(this).parents("tr").children("td");
	$.each(getListDatasUpdateLap,function(i,v){			
		$("#myModalUpdateHardware").find(".form-control").eq(i).val($(v).text());			
	});
	
};

$.fn.delete_HardwareDetails_fn = function(){	
	alert("delete")
	var CurHardwareId = $("#basicBootstrapFormUpdateHardware").find("#rsaupdate").val();
	 
	$.ajax({
		 type:'GET',
	     url:'hardwareDelete?page=rsa&hardware_id='+CurHardwareId,	    
	     success: function (data) {	          
	            alert("Details Deleted successfully");
	           
	           $("#basicBootstrapFormUpdateHardware").submit();
	            
	    }
	});
	
};
/*window.onbeforeunload = function() { return "You work will be lost."; };*/
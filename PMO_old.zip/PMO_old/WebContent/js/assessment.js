//var jsonContent = ${jss};

$(function()
{
		/*$.ajax({
			type:'GET',
		   	url:'assessSave?action=fetchassess&technology=Unix&difflevel=Proficient',			     
		   	data: $("#assessSave").serializeArray(),
		   	success: function (data) {
		   		console.log(data);
		   		jsonContent = data;
		  	},error:function(){
			   console.log('error at ajax');
		  	}
			});*/
});
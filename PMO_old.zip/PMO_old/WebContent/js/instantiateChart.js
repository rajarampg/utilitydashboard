function generateColumnChart(CHART_DETAILS){
	columnDataGeneratin(CHART_DETAILS);
    highColumnChart(CHART_DETAILS);
}


function generatePieChart(CHART_DETAILS){
	pieDataGeneratin(CHART_DETAILS);
	highPieChart(CHART_DETAILS);
}


function columnDataGeneratin(CHART_DETAILS){
	CHART_DETAILS['jsonContent'] = $('#'+CHART_DETAILS.sourceTable).bootstrapTable('getData');
	console.log(CHART_DETAILS['jsonContent']);
	var entities = [];
	var xAxisFields = [];
	$.each(CHART_DETAILS.jsonContent,function(){
		var index = entities.indexOf(this[CHART_DETAILS.entityField]);
		if(index <0  && this[CHART_DETAILS.entityField] != undefined) {
			entities.push(this[CHART_DETAILS.entityField])
		}
	});
	
	CHART_DETAILS['entities'] = entities;
	
	
	var chart = {};
	chart['type'] = 'column';
	chart['name'] = CHART_DETAILS.xAxisScale;
	

	var data = [];
	$.each(CHART_DETAILS.entities, function(){
		data.push(0);
	});
		
	$.each(CHART_DETAILS.jsonContent,function(){
		var index = CHART_DETAILS.entities.indexOf(this[CHART_DETAILS.entityField]);
		if(CHART_DETAILS.yAxisFieldCount){
			data[index] += 1;
		}else{
			data[index] += parseInt(this[CHART_DETAILS.yAxisField]);
		}
	});
	
	var dataBind = [];
	$.each(data, function(k, value){
		var content = {};
		content['y'] = value;
		getNextColor(CHART_DETAILS);
		content['color'] = CHART_DETAILS.colors[CHART_DETAILS.currentColor]; 
		dataBind.push(content);
	});
	chart['data'] = dataBind;
	if(isExport){
		var dataLabels = {
            enabled: true,
            format: '{point.y} ',
            style: {
                color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
            }
        };
		chart['dataLabels'] = dataLabels;
	}
	CHART_DETAILS.data = [];
	
	
	
	CHART_DETAILS.data.push(chart);
}


function pieDataGeneratin(CHART_DETAILS){
	CHART_DETAILS['jsonContent'] = $('#'+CHART_DETAILS.sourceTable).bootstrapTable('getData');
	console.log(CHART_DETAILS['jsonContent']);
	var entities = [];
	var xAxisFields = [];
	$.each(CHART_DETAILS.jsonContent,function(){
		var index = entities.indexOf(this[CHART_DETAILS.entityField]);
		if(index <0  && this[CHART_DETAILS.entityField] != undefined) {
			entities.push(this[CHART_DETAILS.entityField])
		}
	});
	
	CHART_DETAILS['entities'] = entities;
	
	var chart = {};
	chart['type'] = 'pie';
	chart['name'] = CHART_DETAILS.pieName;
	chart['center'] = [50,40];
	chart['size'] = 150;
	chart['showInLegend'] = false;
	chart['dataLabels'] = {
							enabled: false
        					};
	
	var data = [];
	var totals = [];
	$.each(CHART_DETAILS.entities, function(){
		totals.push(0);
	});
		
	$.each(CHART_DETAILS.jsonContent,function(){
		var index = CHART_DETAILS.entities.indexOf(this[CHART_DETAILS.entityField]);
		if(CHART_DETAILS.yAxisFieldCount){
			totals[index] += 1;
		}else{
			totals[index] += parseInt(this[CHART_DETAILS.yAxisField]);
		}
	});
		
	$.each(CHART_DETAILS.entities, function(i, val){
		var pie = {};
		getNextColor(CHART_DETAILS);
		pie['color'] = CHART_DETAILS.colors[CHART_DETAILS.currentColor];
		pie['name'] = val;
		pie['y'] = totals[i];
		data.push(pie);
	});
		
	CHART_DETAILS.data = data;
}


function getNextColor(CHART_DETAILS){
	
	if(CHART_DETAILS.colors.length > CHART_DETAILS.currentColor+1 ){
		CHART_DETAILS.currentColor+=1;
	}else{
		CHART_DETAILS.currentColor = 0;
	}
}

function highColumnChart(CHART_DETAILS){
	    $('#'+CHART_DETAILS.target).highcharts({
	        chart: {
	            type: 'column',
	            width : CHART_DETAILS.width,
	            height : CHART_DETAILS.height
	        },
	        title: {
	            text: CHART_DETAILS.title
	        },
	        xAxis: {
	            categories: 
	                        CHART_DETAILS.entities
	            ,
	            crosshair: true
	        },
	        yAxis: {
	            min: 0,
	            title: {
	                text: CHART_DETAILS.yAxisScale
	            }
	        },
	        tooltip: {
	            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
	            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
	                '<td style="padding:0"><b>{point.y} '+CHART_DETAILS.yAxisScale+'</b></td></tr>',
	            footerFormat: '</table>',
	            shared: true,
	            useHTML: true
	        },
	        plotOptions: {
	            column: {
	                pointPadding: 0.2,
	                borderWidth: 0,
	                
	            }
	        },
	         credits: {
	             enabled: false
	         },
	         series : CHART_DETAILS.data
	    });
	}	
  
  
  function highPieChart(CHART_DETAILS){
	  
	    $('#'+CHART_DETAILS.target).highcharts({
	    	
	    	chart: {
	            plotBackgroundColor: null,
	            plotBorderWidth: null,
	            plotShadow: false,
	            type: 'pie',
	            width : CHART_DETAILS.width,
	            height : CHART_DETAILS.height
	        },
	        title: {
	            text: CHART_DETAILS.title
	        },
	        
	        tooltip: {
	            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
	            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
	                '<td style="padding:0"><b>{point.y} '+CHART_DETAILS.yAxisScale+'</b></td></tr>',
	            footerFormat: '</table>',
	            shared: true,
	            useHTML: true
	        },
	        plotOptions: {
	            pie: {
	                allowPointSelect: true,
	                cursor: 'pointer',
	                dataLabels: {
	                    enabled: true,
	                    format: '<b>{point.name}</b>: {point.y}',
	                    style: {
	                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
	                    }
	                }
	            }
	        },
	        
	        series: [{
	        	name: CHART_DETAILS.xAxisScale,
	            colorByPoint: true,
	            data: CHART_DETAILS.data}],
	            exporting: {
	                enabled: true
	            }
	        
	    });
	}


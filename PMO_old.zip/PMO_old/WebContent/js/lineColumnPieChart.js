

function dataGenerationLCP(CHART_DETAILS){
	
	CHART_DETAILS['jsonContent'] = $('#'+CHART_DETAILS.sourceTable).bootstrapTable('getData');
	console.log(CHART_DETAILS['jsonContent']);
	var entities = [];
	var xAxisFields = [];
	$.each(CHART_DETAILS.jsonContent,function(){
		var index = entities.indexOf(this[CHART_DETAILS.entityField]);
		if(index <0  && this[CHART_DETAILS.entityField] != undefined) {
			entities.push(this[CHART_DETAILS.entityField])
		}
		index = xAxisFields.indexOf(this[CHART_DETAILS.xAxisField]);
		if(index <0 && this[CHART_DETAILS.xAxisField] != undefined){
			xAxisFields.push(this[CHART_DETAILS.xAxisField])
		}
	});
	
	CHART_DETAILS['entities'] = entities;
	CHART_DETAILS['xAxisEntities'] = xAxisFields;
	var series = [];
//	generate column chart	
	
	if(CHART_DETAILS.column){
		var columnData = generateColumnChartData(CHART_DETAILS);
		$.each(columnData, function(){
			series.push(this);
		});
	}

	
//	generate spline chart

	if(CHART_DETAILS.spline){
	series.push(generateSplineChartData(CHART_DETAILS));
	}
	
	

		
//	generate bar stack chart
	if(CHART_DETAILS.stackBar){
		CHART_DETAILS.stackFields = [];
		$.each(CHART_DETAILS.jsonContent,function(){
			if(this[CHART_DETAILS.stackField] != undefined && CHART_DETAILS.stackFields.indexOf(this[CHART_DETAILS.stackField]) < 0){
				CHART_DETAILS.stackFields.push(this[CHART_DETAILS.stackField]);
				}
			});
		var stackData = generateBarStackData(CHART_DETAILS);
		$.each(stackData, function(){
			series.push(this);	
		});
		
		if(CHART_DETAILS.pie){
//			clone object
			var PIE_CHART = jQuery.extend({}, CHART_DETAILS);
			PIE_CHART.entities = CHART_DETAILS.stackFields;
			PIE_CHART.entityField = CHART_DETAILS.stackField;
			series.push(generatePieChartData(PIE_CHART));
		}
		CHART_DETAILS.data = series;
		return;
	}
	
	
	
//	generate column stack chart
	if(CHART_DETAILS.stackColumn){
		CHART_DETAILS.stackFields = [];
		$.each(CHART_DETAILS.jsonContent,function(){
			if(CHART_DETAILS.stackFields.indexOf(this[CHART_DETAILS.stackField]) < 0){
				CHART_DETAILS.stackFields.push(this[CHART_DETAILS.stackField]);
				}
			});
		var stackData = generateColumnStackData(CHART_DETAILS);
		$.each(stackData, function(){
			series.push(this);	
		});
		
		if(CHART_DETAILS.pie){
			CHART_DETAILS.entities = CHART_DETAILS.stackFields;
			CHART_DETAILS.entityField = CHART_DETAILS.stackField;
			series.push(generatePieChartData(CHART_DETAILS));
		}
		CHART_DETAILS.data = series;
		return;
	}
	
	
//	generate pie chart
	
	if(CHART_DETAILS.pie){
		series.push(generatePieChartData(CHART_DETAILS));
	}
	
	
	CHART_DETAILS.data = series;
	 
	console.log(series);
}



function dataGenerationHardware(CHART_DETAILS){
	CHART_DETAILS['jsonContent'] = $('#'+CHART_DETAILS.sourceTable).bootstrapTable('getData');
	console.log(CHART_DETAILS['jsonContent']);
	var entities = [];
	var xAxisFields = [];
	$.each(CHART_DETAILS.jsonContent,function(){
		var index = xAxisFields.indexOf(this[CHART_DETAILS.xAxisField]);
		if(index <0 && this[CHART_DETAILS.xAxisField] != undefined){
			xAxisFields.push(this[CHART_DETAILS.xAxisField])
		}
	});
	
	CHART_DETAILS['xAxisEntities'] = xAxisFields;
	
	
	var series = [];
	for(i=0;i<CHART_DETAILS.entities.length;i++){
		var chart = {};
		chart['type'] = 'column';
		chart['name'] = CHART_DETAILS.entities[i];
		getNextColor(CHART_DETAILS);
		chart['color'] = CHART_DETAILS.colors[CHART_DETAILS.currentColor];
		var data = [];
		$.each(CHART_DETAILS.xAxisEntities, function(){
			data.push(0);
		});
		
		$.each(CHART_DETAILS.jsonContent,function(){
			if(this[CHART_DETAILS.entityField[i]]){
				var index = CHART_DETAILS.xAxisEntities.indexOf(this[CHART_DETAILS.xAxisField]);
				if(CHART_DETAILS.yAxisFieldCount){
					data[index] += 1;
				}else{
					data[index] += parseInt(this[CHART_DETAILS.yAxisField]);
				}
			}
		});	
		chart['data'] = data;
		series.push(chart);
	}
	CHART_DETAILS.data = series;
	
	
	// pie data
	
	var chart = {};
	chart['type'] = 'pie';
	chart['name'] = CHART_DETAILS.pieName;
	chart['size'] = 150;
	chart['showInLegend'] = false;
	if(isExport){
	chart['dataLabels'] = {
							enabled: true
        					};
	chart['center'] = CHART_DETAILS.center;
	}else{
		chart['dataLabels'] = {
				enabled: false
				};
		chart['center'] = [50,40];
	}
	var pieData = [];
	$.each(series, function(){
		var total = 0;
		$.each(this.data, function(){
			total+=this;
			});
		pieData.push(total);
		});
	console.log(pieData);
	
	var data = [];
			
	$.each(CHART_DETAILS.entities, function(i, val){
		var pie = {};
		getNextColor(CHART_DETAILS);
		pie['color'] = CHART_DETAILS.colors[CHART_DETAILS.currentColor];
		pie['name'] = val;
		pie['y'] = pieData[i];
		data.push(pie);
	});
		
	chart['data'] = data;
	CHART_DETAILS.data.push(chart);
	
	
}

function generateColumnChartData(CHART_DETAILS){
	var series = [];
	for(i=0;i<CHART_DETAILS.entities.length;i++){
		var chart = {};
		chart['type'] = 'column';
		chart['name'] = CHART_DETAILS.entities[i];
		getNextColor(CHART_DETAILS);
		chart['color'] = CHART_DETAILS.colors[CHART_DETAILS.currentColor];
		var data = [];
		$.each(CHART_DETAILS.xAxisEntities, function(){
			data.push(0);
		});
		
		$.each(CHART_DETAILS.jsonContent,function(){
			if(CHART_DETAILS.entities[i] == this[CHART_DETAILS.entityField]){
				var index = CHART_DETAILS.xAxisEntities.indexOf(this[CHART_DETAILS.xAxisField]);
				if(CHART_DETAILS.entityFilter){
					var filterCondition = CHART_DETAILS.entityFilterValues.indexOf(this[CHART_DETAILS.entityFilterField]);
					if(filterCondition<0){
						return;
					}
				}
				if(CHART_DETAILS.yAxisFieldCount){
					data[index] += 1;
				}else{
					data[index] += parseInt(this[CHART_DETAILS.yAxisField]);
				}
			}
		});	
		chart['data'] = data;
		
		if(isExport){
			var dataLabels = {
	            enabled: true,
	            format: '{point.y} ',
	            /*format: '<b>{point.name}</b>: {point.y} '+    (CHART_DETAILS.yAxisScaleTip === undefined ? CHART_DETAILS.yAxisScale : '₹'),*/
	            style: {
	                color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
	            }
	        };
			chart['dataLabels'] = dataLabels;
		}
		
		series.push(chart);
	}
	return series;
}



function generateBarStackData(CHART_DETAILS){
	var series = [];
	
	$.each(CHART_DETAILS.stackFields,function(key, stackCategory){
		var chart = {};
		chart['name'] = stackCategory;
		getNextColor(CHART_DETAILS);
		chart['color'] = CHART_DETAILS.colors[CHART_DETAILS.currentColor];
		var data = [];
		$.each(CHART_DETAILS.xAxisEntities, function(){
			data.push(0);
		});
		
		for(i=0;i<CHART_DETAILS.entities.length;i++){
			$.each(CHART_DETAILS.jsonContent,function(){
				if(stackCategory == this[CHART_DETAILS.stackField] && CHART_DETAILS.entities[i] == this[CHART_DETAILS.xAxisField]){
					var index = CHART_DETAILS.xAxisEntities.indexOf(this[CHART_DETAILS.xAxisField]);
					if(CHART_DETAILS.yAxisFieldCount){
						data[index] += 1;
					}else{
						data[index] += parseInt(this[CHART_DETAILS.yAxisField]);
					}	
				}
			});
		}
		chart['data'] = data;
		series.push(chart);
		
	});
	
	return series;
}


function generateColumnStackData(CHART_DETAILS){
	var series = [];
	for(i=0;i<CHART_DETAILS.entities.length;i++){
		$.each(CHART_DETAILS.stackFields,function(key, stackCategory){
			
		var chart = {};
		chart['name'] = CHART_DETAILS.entities[i];
		getNextColor(CHART_DETAILS);
		chart['color'] = CHART_DETAILS.colors[CHART_DETAILS.currentColor];
		var data = [];
		$.each(CHART_DETAILS.xAxisEntities, function(){
			data.push(0);
		});
		
			$.each(CHART_DETAILS.jsonContent,function(){
				if(CHART_DETAILS.entities[i] == this[CHART_DETAILS.entityField]){
					if(stackCategory == this[CHART_DETAILS.stackField]){
						var index = CHART_DETAILS.xAxisEntities.indexOf(this[CHART_DETAILS.xAxisField]);
						if(CHART_DETAILS.yAxisFieldCount){
							data[index] += 1;
						}else{
							data[index] += parseInt(this[CHART_DETAILS.yAxisField]);
						}	
					}
				}
					
			});
		chart['data'] = data;
		chart['stack'] = stackCategory;
		series.push(chart);	
		});	
		
	}
	return series;
}


function generateSplineChartData(CHART_DETAILS){
	var chart = {};
	chart['type'] = 'spline';
	chart['name'] = CHART_DETAILS.splineName;
	marker = {};
	getNextColor(CHART_DETAILS);
	marker['lineColor'] = CHART_DETAILS.colors[CHART_DETAILS.currentColor];
	marker['fillColor'] = 'white';
	marker['lineWidth'] = 2;
	
	chart['marker'] = marker;
	var data = [];
	$.each(CHART_DETAILS.xAxisEntities, function(){
		data.push(0);
	});
	
	$.each(CHART_DETAILS.xAxisEntities, function(i, entity){
		var totalForAxis = 0;
		$.each(CHART_DETAILS.jsonContent,function(){
			if(CHART_DETAILS.entityFilter){
				var filterCondition = CHART_DETAILS.entityFilterValues.indexOf(this[CHART_DETAILS.entityFilterField]);
				if(filterCondition<0){
					return;
				}
			}
			if(entity == this[CHART_DETAILS.xAxisField]){
				if(CHART_DETAILS.yAxisFieldCount){
					totalForAxis += 1;
				}else{
					totalForAxis += parseInt(this[CHART_DETAILS.yAxisField]);
				}
			}
		});
		data[i] = totalForAxis / CHART_DETAILS.xAxisEntities.length;
	});
		
	chart['data'] = data;
	return chart;
}


function generatePieChartData(CHART_DETAILS){
	var chart = {};
	chart['type'] = 'pie';
	chart['name'] = CHART_DETAILS.pieName;
	if(CHART_DETAILS['center'] === undefined){
		chart['center'] = [50,40];
	}
	else{
		chart['center'] = CHART_DETAILS['center'];
	}
	chart['size'] = 150;
	chart['showInLegend'] = false;
	chart['dataLabels'] = {
							enabled: false
        					};
	
	var data = [];
	var totals = [];
	$.each(CHART_DETAILS.entities, function(){
		totals.push(0);
	});
		
	$.each(CHART_DETAILS.jsonContent,function(){
		var index = CHART_DETAILS.entities.indexOf(this[CHART_DETAILS.entityField]);
		if(CHART_DETAILS.entityFilter){
			var filterCondition = CHART_DETAILS.entityFilterValues.indexOf(this[CHART_DETAILS.entityFilterField]);
			if(filterCondition<0){
				return;
			}
		}
		if(CHART_DETAILS.yAxisFieldCount){
			totals[index] += 1;
		}else{
			totals[index] += parseInt(this[CHART_DETAILS.yAxisField]);
		}
	});
		
	$.each(CHART_DETAILS.entities, function(i, val){
		var pie = {};
		getNextColor(CHART_DETAILS);
		pie['color'] = CHART_DETAILS.colors[CHART_DETAILS.currentColor];
		pie['name'] = val;
		pie['y'] = totals[i];
		data.push(pie);
	});
		
	chart['data'] = data;
	if(isExport){
		var dataLabels = {
            enabled: true,
            format: '<b>{point.name}</b>: {point.y} '+CHART_DETAILS.yAxisScale,
            style: {
                color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
            }
        };
		chart['dataLabels'] = dataLabels;
	}
	
	return chart;
	}


function getNextColor(CHART_DETAILS){
	if(CHART_DETAILS.colors.length > CHART_DETAILS.currentColor+1 ){
		CHART_DETAILS.currentColor+=1;
	}else{
		CHART_DETAILS.currentColor = 0;
	}
}



function attritionChartChanges(CHART_DETAILS){
	console.log(JSON.stringify(CHART_DETAILS.data));
	$('#'+CHART_DETAILS.target).highcharts({
		
		chart: {
            type: 'column',
            width : CHART_DETAILS.width,
            height : CHART_DETAILS.height
        },
        title: {
        	text: CHART_DETAILS.title
        },
        xAxis: {
        	title: {
                text: CHART_DETAILS.xAxisScale
            },
        	categories: CHART_DETAILS.xAxisEntities
        },
        yAxis: {
            min: 0,
            title: {
                text: CHART_DETAILS.yAxisScale
            },
            stackLabels: {
                enabled: true,
                style: {
                    fontWeight: 'bold',
                }
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                /*'<td style="padding:0"><b>{point.y:.1f}'+CHART_DETAILS.yAxisScale+' </b></td></tr>',*/
            	'<td style="padding:0"><b>{point.y}'+CHART_DETAILS.yAxisScale+' </b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        
        plotOptions: {
            column: {
                stacking: 'normal',
            }
        },
        
        
        series: [{
            name: 'John',
            data: [5, 3, 4, 7, 2],
            stack: 'QA'
        }, {
            name: 'Joe',
            data: [3, 4, 4, 2, 5],
            stack: 'DEV'
        }, {
            name: 'Jane',
            data: [2, 5, 6, 2, 1],
            stack: 'OPS'
        }, {
            name: 'Janet',
            data: [3, 0, 4, 4, 3],
            stack: 'female'
        }] 
    });
}	
	



function attritionChart(CHART_DETAILS){
	console.log(JSON.stringify(CHART_DETAILS.data));
	$('#'+CHART_DETAILS.target).highcharts({
		
		chart: {
            type: 'column',
            width : CHART_DETAILS.width,
            height : CHART_DETAILS.height
        },
        title: {
        	text: CHART_DETAILS.title
        },
        xAxis: {
        	title: {
                text: CHART_DETAILS.xAxisScale
            },
        	categories: CHART_DETAILS.xAxisEntities
        },
        yAxis: {
            min: 0,
            title: {
                text: CHART_DETAILS.yAxisScale
            },
            stackLabels: {
                enabled: true,
                style: {
                    fontWeight: 'bold',
                }
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y}&nbsp'+CHART_DETAILS.yAxisScale+' </b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        
        plotOptions: {
            column: {
                stacking: 'normal',
            }
        },
        series: CHART_DETAILS.data 
    });
}	
		
		


function lineColumnPieChart(CHART_DETAILS){
	
	
	var chartOptions = {
	    chart:{
	    	width : CHART_DETAILS.width,
	    	height : CHART_DETAILS.height
	    },
        title: {
            text: CHART_DETAILS.title
        },
        xAxis: {
            categories: CHART_DETAILS.xAxisEntities,
            title: {
                text: CHART_DETAILS.xAxisScale
            }
        },
        yAxis: {
            allowDecimals: false,
            title: {
                text: CHART_DETAILS.yAxisScale
            }
        },
        series : CHART_DETAILS.data,
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y}'+CHART_DETAILS.yAxisScale+' </b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        }
        
    };
	
	if(isExport){
		var dataLabels = {
				series: {
	                dataLabels: {
	                    enabled: true
	                }
				}
        };
		chartOptions['plotOptions'] = dataLabels;
		console.log('shittyExportisOn');
	}
	
	console.log(chartOptions);
	console.log(JSON.stringify(chartOptions));
	
	    $('#'+CHART_DETAILS.target).highcharts(chartOptions);
	    
}


function dataGenerationRewards(CHART_DETAILS){
	CHART_DETAILS['jsonContent'] = $('#'+CHART_DETAILS.sourceTable).bootstrapTable('getData');
	console.log(CHART_DETAILS['jsonContent']);
	var entities = [];
	var xAxisFields = [];
	$.each(CHART_DETAILS.jsonContent,function(){
		if(CHART_DETAILS.entityFilter){
			var filterCondition = CHART_DETAILS.entityFilterValues.indexOf(this[CHART_DETAILS.entityFilterField]);
			if(filterCondition<0){
				return;
			}
		}
		var index = entities.indexOf(this[CHART_DETAILS.entityField]);
		if(index <0  && this[CHART_DETAILS.entityField] != undefined) {
			entities.push(this[CHART_DETAILS.entityField])
		}
		index = xAxisFields.indexOf(this[CHART_DETAILS.xAxisField]);
		if(index <0 && this[CHART_DETAILS.xAxisField] != undefined){
			xAxisFields.push(this[CHART_DETAILS.xAxisField])
		}
	});
	
	CHART_DETAILS['entities'] = entities;
	CHART_DETAILS['xAxisEntities'] = xAxisFields;
	var series = [];
	
	
	for(i=0;i<CHART_DETAILS.entities.length;i++){
		var chart = {};
		chart['type'] = 'column';
		chart['name'] = CHART_DETAILS.entities[i];
		getNextColor(CHART_DETAILS);
		chart['color'] = CHART_DETAILS.colors[CHART_DETAILS.currentColor];
		var data = [];
		$.each(CHART_DETAILS.xAxisEntities, function(){
			data.push(0);
		});
		var existingAwards = [];
		$.each(CHART_DETAILS.jsonContent,function(){
			if(CHART_DETAILS.entities[i] == this[CHART_DETAILS.entityField]){
				if(CHART_DETAILS.entityFilter){
					var filterCondition = CHART_DETAILS.entityFilterValues.indexOf(this[CHART_DETAILS.entityFilterField]);
					if(filterCondition<0){
						return;
					}
				}
				var index = CHART_DETAILS.xAxisEntities.indexOf(this[CHART_DETAILS.xAxisField]);
				var existingIndex = existingAwards.indexOf(this['rewardId']);
				if(existingIndex<0){
					existingAwards.push(this['rewardId']);
					data[index] += 1;	
				}
			}
		});	
		chart['data'] = data;
		series.push(chart);
	}
	
	CHART_DETAILS.data = series;
	
	
}

var myApp = angular.module('app', ['ngAnimate','ui.bootstrap','xeditable','dndLists','angular-loading-bar','tableSort']);


//controller for SingleUserView Screen

myApp.controller("SingleViewCtrl", function ($scope,$window,$http) {
	
	$scope.singleemp = {};
	$scope.singleemp.renew = 'false';
	$scope.submitted = false ;
	$scope.list = [];
	$scope.success_status = 'null' ;
	$scope.new_data=[];
	$scope.new_data_role={};
	$scope.new_data_contract={};
	$scope.skillkey={};
	$scope.new_data_skill={};
	
	$scope.getDataFromServer = function(){
			
		var response = $http({method : 'GET',url : 'OnBoardingSingle', contentType: 'application/json'});
	    response.success(function(data, status, headers, config) {
		$scope.new_data = angular.fromJson(data.manager) ;
		$scope.new_data_role = angular.fromJson(data.role);
		$scope.new_data_skill=angular.fromJson(data.skillpair);
		$scope.skillkey = Object.keys($scope.new_data_skill);
		$scope.new_data_contract =angular.fromJson(data.contract);
		//alert(" Data : "+JSON.stringify($scope.new_data_skill));	
	
		if(localStorage.getItem("emp_id")!=null)
		{
		//	$scope.singleemp.portfolio = localStorage.getItem("portfolio");
			$scope.singleemp.enterpriseId = localStorage.getItem("emp_id");
		}
		localStorage.clear();
		});
		response.error(function(data, status, headers, config) {
		//alert("error in loading get request");	
		});
		
		
	}
	
	$scope.fetchpredetails = function()
	{
	
		url =  'staticTable?action=singleviewresmgr&id='+$scope.singleemp.portfolio;
		var response = $http({method : 'GET',url : url, contentType: 'application/json'});
	    response.success(function(data, status, headers, config) {
	   	console.log("type",typeof(data),"data",data);
	   //	alert(JSON.stringify(angular.fromJson(data)));
	   	
	   	$scope.new_data = angular.fromJson(data.manager) ;
	   	$scope.new_data_contract =angular.fromJson(data.contract);
	   	
	   	//$scope.singleemp.director=data[0].directorId;
	   	//$scope.singleemp.vp=data[0].vpUserId;   	
	    	
	    	//$scope.singleemp.employeeId = angular.fromJson(data) ;
	    });
	
		
	}

	
	$scope.fetchdata = function()
	{
		url =  'staticTable?action=singleview&id='+$scope.singleemp.resourceManager;
		var response = $http({method : 'GET',url : url, contentType: 'application/json'});
	    response.success(function(data, status, headers, config) {
	    	console.log("type",typeof(data),"data",data);
	    	$scope.singleemp.director=data[0].directorId;
	    	$scope.singleemp.vp=data[0].vpUserId;   	
	    	
	    	//$scope.singleemp.employeeId = angular.fromJson(data) ;
	    });
		
	};
	
	
	
	$scope.ok = function(form) {
					
		$scope.submitted = true ;
					
					if(form.$invalid){
					return false;	
					}
					else
					{	
//					alert(JSON.stringify($scope.singleemp));
				
					var response = $http({
				        method : 'POST',
				        url : 'OnBoardingSingle',
				        contentType: 'application/json',
				        data : JSON.stringify($scope.singleemp)});
				    
					
					response.success(function(data, status, headers, config) {
//					alert(data +' '+ status +' '+ headers+' '+config);
					if (data=='empnotfound')
						alert("Employee Details not found. Please enter valid Enterprise id !!");
					else
					$scope.success_status = 'true' ;
//					alert( "response: " + $scope.success_status);
						
					});
					response.error(function(data, status, headers, config) {
//						alert(data +' '+ status +' '+ headers+' '+config);
						$scope.success_status = 'false' ;
//						alert( "response " + $scope.success_status);
					});
					}
					
			
			}
	});




// controller for multiUserView screen

myApp.controller("MultiViewCtrl", function ($scope,$window,$http) {

$scope.Employees = [];
$scope.emp={};
$scope.emp.renew = 'false';
$scope.success_status_multiple = 'null'

$scope.addRow = function() {
	
	$scope.Employees.push($scope.emp);
	$scope.emp = {};
	$scope.emp.renew = 'false';
	 
};

$scope.removeEmp = function(index) {
    $scope.Employees.splice(index, 1);
  };

// for tab control
  $scope.tabs = [
                 { title:'Individual Details' , active: true, disabled: false},
                 { title:'Common Details',  active: false , disabled: false }
               ];
 
  $scope.next = function() {
		//to enable tab2 and disable tab1
	  	$scope.tabs[1].active=true;
		//$scope.tabs[1].disabled=false;
		
		$scope.tabs[0].active=false;
		//$scope.tabs[0].disabled=true;
		 
	};  

  $scope.back = function() {
		//to enable tab2 and disable tab1
	  	$scope.tabs[0].active=true;
		//$scope.tabs[0].disabled=false;
		
		$scope.tabs[1].active=false;
		//$scope.tabs[1].disabled=true;
		 
	};  

	
	$scope.commondetail = {};
	$scope.detail = [];
	
	$scope.new_data=[];
	$scope.new_data_role={};
	$scope.new_data_contract={};
	$scope.skillkey={};
	$scope.new_data_skill={};
	
	$scope.getDataFromServer = function(){
		var response = $http({method : 'GET',url : 'OnBoardingMultiple', contentType: 'application/json'});
	    response.success(function(data, status, headers, config) {
		$scope.new_data = angular.fromJson(data.manager) ;
		$scope.new_data_role = angular.fromJson(data.role);
		$scope.new_data_skill=angular.fromJson(data.skillpair);
		$scope.skillkey = Object.keys($scope.new_data_skill);
		$scope.new_data_contract =angular.fromJson(data.contract);
		//alert(" Data : "+JSON.stringify($scope.new_data_skill));		
		});
		response.error(function(data, status, headers, config) {
		//alert("error in loading get request");	
		});
	}
	
	
	
	$scope.submit = function() {
				
		var json1 = $scope.Employees;
	    var json2 = $scope.commondetail;
	    
	    //alert(json1+' '+json2);
	    for(var i=0;i<json1.length;i++)
	    {	
	    var json3 = angular.extend({},json1[i],json2);
	    $scope.detail.push(json3);
	    }
	    //alert($scope.detail);
		
	    
	    //alert(JSON.stringify($scope.detail));
		var response = $http({
	        method : 'POST',
	        url : 'OnBoardingMultiple',
	        contentType: 'application/json',
	        data : JSON.stringify($scope.detail)});
	    
		response.success(function(data, status, headers, config) {
		$scope.success_status_multiple = 'true' ;
		//alert( "response: " + $scope.success_status_multiple);
			
		});
		response.error(function(data, status, headers, config) {
			$scope.success_status_multiple = 'false' ;
		//	alert( "response " + $scope.success_status_multiple);
		});
		
	
	};
  
});


//controller for Onboarding selection screen

myApp.controller('CollapseDemoCtrl', function ($scope,$window,$uibModal) {
  
  $scope.isCollapsed = true;
  
  $scope.launch = function (value) {
            $scope.selectedVal = value;
   		
		switch ($scope.selectedVal) {

		case 'single':
		//to replace with redirect part to single user view
		$scope.isCollapsed = true;
		var url = $window.location.protocol +"//"+ $window.location.host + "/PMO/SingleUserViewNew1.jsp"
		$window.location.href = url;
		break;
		
		case 'multiple' :
		$scope.isCollapsed = false;
		$scope.todisable = true;
		break;
		
		case 'yes':
			
			var url = $window.location.protocol +"//"+ $window.location.host + "/PMO/MultiUserView.jsp"
			$window.location.href = url;	
		
		//to replace with redirect part to multi user view1
		break;
}
};


$scope.open = function (size) {

    var modalInstance = $uibModal.open({
      animation: $scope.animationsEnabled,
      templateUrl: 'myModalContent.html',
      controller: 'ModalInstanceCtrl',
      size: size,
      resolve: {
        selectedVal: function () {
          return $scope.selectedVal;
        }
      }
    });};
});

// Controllor for Error Window dialog box 

myApp.controller('ModalInstanceCtrl', function ($scope, $uibModalInstance, $window) {
  
  $scope.ok = function () {
    	
    	var url = $window.location.protocol +"//"+ $window.location.host + "/PMO/SingleUserViewNew1.jsp"
		$window.location.href = url;
	
  };

  $scope.cancel = function () {
	  var url = $window.location.protocol +"//"+ $window.location.host + "/PMO/NewROselect.jsp";	
	$window.location.href = url;
  };
});


//controller with New Login jsp page: 

myApp.controller('PostController',  function($scope, $http, $window) {
	
	$scope.errorMsg ='';
	$scope.inputData= {};
	$scope.loading=false;
	this.postForm = function() {
		
		$scope.inputData={"Username" : encodeURIComponent(this.inputData.username),"Password" :encodeURIComponent(this.inputData.password) };
		$scope.loading=true;
		//alert("data : "+JSON.stringify($scope.inputData));	
		
		var response = $http({method: 'POST',url: 'NewLoginServlet',data: JSON.stringify($scope.inputData),	
			contentType: 'application/json'
		});
		
		response.success(function(data, status, headers, config){
			$scope.loading=false;
			switch(data){
			case 'Reset':
				var url = $window.location.protocol +"//"+ $window.location.host + "/PMO/passwordreset.jsp"
				$window.location.href = url;
				break;
				
			case 'Main' :
				var url = $window.location.protocol +"//"+ $window.location.host + "/PMO/main.jsp"
				$window.location.href = url;
				break;
			}
			
			console.log(data+' success message');
			$scope.loading=false;	
	});
		
		response.error(function(data, status, headers, config) {
			$scope.errorMsg = 'Unable to Submit Form';
			$scope.loading=false;
		});
	}
	
});


myApp.controller('resetController',  function($scope, $http, $window) {
	
	$scope.msg ='';
	$scope.currentpassword='';
	$scope.newpassword='';
	$scope.confirmpassword='';
	
	this.postForm = function() {
		
		
	
		var response = $http({
			method: 'POST',
			url: 'PasswordResetServlet',
			data: JSON.stringify({"currentpassword":$scope.currentpassword,"newpassword":$scope.newpassword,"confirmpassword":$scope.confirmpassword }),
			contentType: 'application/json'
		});
		
		response.success(function(data, status, headers, config) {
			console.log( data+' success message resetcontroller ');
			
			$window.alert("Password changed Successfully !!");
			var url = $window.location.protocol +"//"+ $window.location.host + "/PMO/editResourceDetails.action"
			$window.location.href = url;
			
		});
		
		resoponse.error(function(data, status, headers, config) {
			console.log( data+' Error message resetcontroller ');
		});
	}
	
});

myApp.controller('ViewStatusCtrl', function ($scope, $window , $http) {

    $scope.datakey = ["taskName","taskDescription","assignedDate","endDate","status","assignedBy","daysElapsed"];
    //$scope.data=[];
    
    $scope.getdata = function()
    {
    
    var response = $http({method: 'GET',url: '/PMO/taskSave?select=taskstatus', contentType: 'application/json'});
    
    response.success(function(data, status, headers, config) {
    	if(data!='')
    	{	
    	console.log( data +' success message ViewTaskController ');  
    	$scope.data=angular.fromJson(data);
    	}
    	else
    	{
    		console.log( 'No data from servlet for the user');  
    	}	
    });
           
    response.error(function(data, status, headers, config) {
           console.log( data+' Error message ViewTaskController ');
    });    
    }
    
    });


myApp.controller("DemandRequestCtrl", function ($scope,$window,$http) {
	
	

	$scope.popup0 = {   opened: false   };
	$scope.popup1 = {   opened: false   };
    $scope.popup2 = {   opened: false  };
    
	$scope.edfulfilldate = new Date();  
		
	 // open min-cal
	 $scope.open0 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup0.opened = true; };
	 $scope.open1 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup1.opened = true; };
	 $scope.open2 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup2.opened = true; };


	// for tab control
	$scope.tabs = [{ title:'Demand Details' , active: true, disabled: false},{ title:'Other Details',  active: false , disabled: false}];


	
	$scope.getDataFromServer = function(){
		var response = $http({method : 'GET',url : 'ResourceRequestServlet', contentType: 'application/json'});
	    response.success(function(data, status, headers, config) {
		$scope.new_data_portfolio = angular.fromJson(data.portfolio) ;
		$scope.new_data_priskill = angular.fromJson(data.priskill);
		//alert(" Data : "+JSON.stringify($scope.new_data_skill));		
		});
		response.error(function(data, status, headers, config) {
		//alert("error in loading get request");	
		});
	}
	
				
 	$scope.next = function() {
	//to enable tab2 and disable tab1
	$scope.tabs[1].active=true;
	//$scope.tabs[1].disabled=false;
	$scope.tabs[0].active=false;
	//$scope.tabs[0].disabled=true;
	};
	
	$scope.back = function() {
	//to enable tab2 and disable tab1
	$scope.tabs[0].active=true;
	//$scope.tabs[0].disabled=false;
	$scope.tabs[1].active=false;
	//$scope.tabs[1].disabled=true;
	};


	$scope.dmd={ 
	
	};
	//defalut settings of value for the form 
	
	$scope.setdefaultvalue = function()
	{
		if ($scope.dmd.onsitecomponent=='true')
			{
			$scope.dmd.visatype='USA - H1B' ; 
		    $scope.dmd.visaready='true' ;
			$scope.dmd.wrklocation='Client Onsite - Out of India';
			}
		else if ($scope.dmd.onsitecomponent=='false')
			{
			$scope.dmd.visatype='' ; 
		    $scope.dmd.visaready='' ;
		    $scope.dmd.wrklocation='CDC2C - SEZ';
			}
	}
	
	
	$scope.setterm = function()
	{
		if($scope.dmd.careerlevel=='13-Associate Software Engineer' || $scope.dmd.careerlevel=='12-Associate Software Engineer')
		{
			$scope.dmd.lockduration='long term';
		}	
	}
	
	
	$scope.settermwbseffentity = function()
	{
		
		if ($scope.dmd.portfolio=='Application Operation')
		{
		$scope.dmd.lockduration='long term';	
		} 
		else
		{ 
		$scope.dmd.lockduration='short term'; 
		} 	
		
		
		if ($scope.dmd.priskill=='Microsoft- .NET Architecture' || $scope.dmd.priskill =='ASP.NET')
		{
			$scope.dmd.ffentity='Avanade';
			if($scope.dmd.portfolio=='Application Stores Program')  
			{
				$scope.dmd.wbsecode = 'AGMTK004' ;//DEV Avanade WBS
				
			} else if ($scope.dmd.portfolio=='Application Operation')			
			{
				$scope.dmd.wbsecode = 'Z000DF20' ;	//OPS Avanade WBS
			}
			else 
			
			$scope.dmd.wbsecode = '' ;
	
		}
		else 
		{
		
			$scope.dmd.ffentity='IDC'
			if($scope.dmd.portfolio=='Application Stores Program')  
			{
				$scope.dmd.wbsecode = 'AGMTK002' ; //DEV Non Avanade WBS
				
			} else if ($scope.dmd.portfolio=='Application Operation')			
			{
				$scope.dmd.wbsecode = 'AGXP9002' ; //OPS Non Avanade WBS
			} else 
			
			$scope.dmd.wbsecode = '' ;
				
			
		}
							
	}
	
/*	$scope.dmd.demandsegment = "Existing Client";
	$scope.dmd.clientiview = 'Yes';
	$scope.dmd.ishlready = 'Yes' ;
	$scope.dmd.demandpriority = "High";
	$scope.dmd.srclocation = "Chennai";*/

	
	$scope.success_status_demand='null';
	
	$scope.submit = function(form) {
		$scope.submitted = true ;
		
		if(form.$invalid){
			alert("Details required for the mandatory fields are not provided. Kindly fill the remaining details as well ");
			console.log("all columns not filled ");
		return false;	
		}
		else
		{	
//		alert(JSON.stringify($scope.dmd));
	
		var response = $http({
	        method : 'POST',
	        url : 'ResourceRequestServlet',
	        contentType: 'application/json',
	        data : JSON.stringify($scope.dmd)});
	    
		
		response.success(function(data, status, headers, config) {
//		alert(data +' '+ status +' '+ headers+' '+config);
			$scope.success_status_demand = 'true' ;
//		alert( "response: " + $scope.success_status);
		});
		
		response.error(function(data, status, headers, config) {
//			alert(data +' '+ status +' '+ headers+' '+config);
			$scope.success_status_demand = 'false' ;
//			alert( "response " + $scope.success_status);
		});
		}
		
		}
 
	});


myApp.controller("rrdViewController", function ($scope,$window,$http,$timeout) {


	$scope.startdata = function()
	{
		$scope.dmd = JSON.parse(localStorage.getItem("dmdinput"));
		$scope.inputs = JSON.parse(localStorage.getItem("rrdinputs"));
		$scope.success_status_rrd = localStorage.getItem("success_status_rrd");
		$scope.success_status_did= localStorage.getItem("success_status_did");
		$scope.searchDemandId = localStorage.getItem("searchDemandId");	
	}

	//searching particular demand id and mapping returned object  to model

	

	$scope.searchDemandId='';

	$scope.dmd={};

	$scope.inputs=[];

	$scope.success_status_rrd='null';

	$scope.success_status_did='null';

	//$scope.inputs=[{id:'1',rrdid: 'Arun' },{id:'2',rrdid: 'Ram'}];


	$scope.searchfromtask = function(demand)
	{
		$scope.searchDemandId=demand;
		$scope.search()
	 $timeout(function(){
		  var url = $window.location.protocol +"//"+ $window.location.host + "/PMO/rrdentry.jsp"
			$window.location.href = url;
	 },1000)
		  console.log("myres", $scope.dmd,"my res2", $scope.inputs);
}
	
	
	
	
	
	$scope.search = function(){
		$scope.inputs=[];
		$scope.dmd={};
		
		if($scope.searchDemandId!='' && $scope.searchDemandId!=null)
			{
					var url = "ResourceRequestServlet?id="+$scope.searchDemandId;					
					var url2 = "RRDMapperServlet?id="+$scope.searchDemandId;										 
					localStorage.clear();		
	var response = $http({method : 'GET',url : url, contentType: 'application/json'}); 

	response.success(function(data, status, headers, config) {
			$scope.dmd = angular.fromJson(data);
			localStorage.setItem("searchDemandId",$scope.searchDemandId);
			localStorage.setItem("dmdinput",JSON.stringify($scope.dmd));
		   if(localStorage.getItem("dmdinput")=='undefined') {
			   localStorage.setItem("dmdinput",JSON.stringify($scope.dmd));
		   } else{
		   $scope.dmd=JSON.parse(localStorage.getItem("dmdinput"));
	   		}
		   
		   console.log("final set",  $scope.dmd )
		   $scope.success_status_did='true';
	  
		   localStorage.setItem("success_status_did",$scope.success_status_did);
	   	   localStorage.setItem("dmdinput",JSON.stringify($scope.dmd));
	   	   

	   

	   var response_rrd = $http({method : 'GET',url : url2 , contentType: 'application/json'});

 

	   response_rrd.success(function(data, status, headers, config) {
	   $scope.inputs = angular.fromJson(data);
	   localStorage.setItem("rrdinputs",JSON.stringify($scope.inputs));
	   $scope.success_status_rrd='true';
	   localStorage.setItem("success_status_rrd",$scope.success_status_rrd);
	   }).then(function(){
		   
	   });

	   response_rrd.error(function(data, status, headers, config) {

	   $scope.success_status_rrd='false';

	   });

	});

	response.error(function(data, status, headers, config) {

	$scope.success_status_did='false';
	
	//alert("error in loading get request");

	});
	
	}
		else 
	{
			alert("Please enter the demand ID to be searched and try again");
	}		

	}



	$scope.getRows=function(){

	   var a = new Array();

	   for(var i=1; i <= $scope.dmd.rescount; i++)

	a.push(i);

	   return a;
	   

	};

	 

	$scope.saveInput = function(data, id) {

	   //$scope.user not updated yet

	   angular.extend(data, {id: id, searchDemandId: $scope.searchDemandId});

	  // alert(JSON.stringify(angular.extend(data, {id: id, searchDemandId: $scope.searchDemandId})));

	  // return $http.post('/RRDMapperServlet', data);
	   
	   var response = $http({
	        method : 'POST',
	        url : 'RRDMapperServlet',
	        contentType: 'application/json',
	        data : JSON.stringify(data)});
	    
		
		response.success(function(data, status, headers, config) {
//		alert(data +' '+ status +' '+ headers+' '+config);
			console.log("success updated");
//		alert( "response: " + $scope.success_status);
		});
		
		response.error(function(data, status, headers, config) {
//			alert(data +' '+ status +' '+ headers+' '+config);
			$scope.success_status_demand = 'false' ;
//					alert( "response " + $scope.success_status);
			console.log("error");
		});
	   

	 };




	 // remove user

	 $scope.removeInput = function(index) {

	   $scope.inputs.splice(index, 1);

	 };

	 

	$scope.addRRD = function() {

	if($scope.inputs.length+1<=$scope.dmd.rescount)

	{


	$scope.inserted = { id: $scope.inputs.length+1, name: '' };

	   $scope.inputs.push($scope.inserted);

	}

	else

	alert("RRD limit reached for the current request");

	};

	 



	});


//----------------------------------------------------------------------------------------------




myApp.controller("EditableTableCtrl", function ($scope,$window,$http,$filter,$modal) {
	
	//for datepicker
	$scope.dmd={};
	 $scope.demands=[];
	
	
	$scope.popup0 = {   opened: false   };
	$scope.popup1 = {   opened: false   };
    $scope.popup2 = {   opened: false  };
    
	 $scope.open0 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup0.opened = true; };
	 $scope.open1 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup1.opened = true; };
	 $scope.open2 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup2.opened = true; };
	
	
	 	$scope.opened = {};

		$scope.open = function($event, elementOpened) {
			$event.preventDefault();
			$event.stopPropagation();
			$scope.opened[elementOpened] = true;
		};
	 
	 
	 $scope.setshowhidevisa = function()
		{
			if ($scope.dmd.onsitecomponent=='true')
				{
				$scope.dmd.visatype='USA - H1B' ; 
			    $scope.dmd.visaready='true' ;
				$scope.dmd.wrklocation='Client Onsite - Out of India';
				}
			else if ($scope.dmd.onsitecomponent=='false')
				{
				$scope.dmd.visatype='' ; 
			    $scope.dmd.visaready='' ;
			    $scope.dmd.wrklocation='CDC2C - SEZ';
				}
		}
	 
	 $scope.setterm = function(self,user)
		{
		//alert(self.$data);
		//alert(JSON.stringify(user));
		if( self.$data=='12-Associate Software Engineer' || self.$data=='13-Associate Software Engineer' || $scope.dmd.portfolio=='Application Operation')
			user.lockduration='long term';
		else
			user.lockduration='short term';
		}

		$scope.setffentity = function(self,user)
		{
		//alert(self.$data);
		//alert(JSON.stringify(user));
		if( self.$data=='Microsoft- .NET Architecture' || self.$data=='ASP.NET')
			user.ffentity='Avanade';
		else
			user.ffentity='IDC';
		}
	

	 $scope.settermwbseffentity_priskill = function(self,user)
		{
			if ($scope.dmd.portfolio=='Application Operation')
			{
			user.lockduration='long term';	
			} 
			else
			{ 
			user.lockduration='short term'; 
			} 	
			
			if (self.$data=='Microsoft- .NET Architecture' || self.$data =='ASP.NET')
			{
				user.ffentity='Avanade';
				if($scope.dmd.portfolio=='Application Stores Program')  
				{
					user.wbsecode = 'AGMTK004' ;//DEV Avanade WBS
				} else if ($scope.dmd.portfolio=='Application Operation')			
				{
					user.wbsecode = 'Z000DF20' ;	//OPS Avanade WBS
				}
				else 
				$scope.dmd.wbsecode = '' ;
			}
			else 
			{
				user.ffentity='IDC';
				if($scope.dmd.portfolio=='Application Stores Program')  
				{
					user.wbsecode = 'AGMTK002' ; //DEV Non Avanade WBS
					
				} else if ($scope.dmd.portfolio=='Application Operation')			
				{
					user.wbsecode = 'AGXP9002' ; //OPS Non Avanade WBS
				} else 
				user.wbsecode = '' ;
			}
								
		}

	 
		$scope.settermwbseffentity_portfolio = function(users)
		{
		for( i=0; i<users.length; i++ )
		{
			if ($scope.dmd.portfolio=='Application Operation' || users[i].careerlevel=='13-Associate Software Engineer' || users[i].careerlevel=='12-Associate Software Engineer')
			{
			users[i].lockduration='long term';	
			} 
			else
			{ 
			users[i].lockduration='short term'; 
			}
			
			if (users[i].priskill=='Microsoft- .NET Architecture' || users[i].priskill =='ASP.NET')
			{
				users[i].ffentity='Avanade';
				if($scope.dmd.portfolio=='Application Stores Program')  
				{
					users[i].wbsecode = 'AGMTK004' ;//DEV Avanade WBS
					
				} else if ($scope.dmd.portfolio=='Application Operation')			
				{
					users[i].wbsecode = 'Z000DF20' ;	//OPS Avanade WBS
				}
				else 
				users[i].wbsecode = '' ;
			}
			else 
			{
				users[i].ffentity='IDC'
				if($scope.dmd.portfolio=='Application Stores Program')  
				{
					users[i].wbsecode = 'AGMTK002' ; //DEV Non Avanade WBS
					
				} else if ($scope.dmd.portfolio=='Application Operation')			
				{
					users[i].wbsecode = 'AGXP9002' ; //OPS Non Avanade WBS
				} else 
				users[i].wbsecode = '' ;
			}
		}						
		}
	 
	 
	
	$scope.users = [ ]; 
   /* $scope.statuses = [{value: 1, text: 'status1'},{value: 2, text: 'status2'},
	               {value: 3, text: 'status3'},{value: 4, text: 'status4'}];*/ 

    
    $scope.primaryskilllist = [
          {value: 'C++ (UNIX)', text: 'C++ (UNIX)'},
          {value: 'Java Enterprise Edition', text: 'Java Enterprise Edition'},
          {value: 'Mainframe', text: 'Mainframe'},
          {value: 'Microsoft- .NET Architecture', text: 'Microsoft- .NET Architecture'},
          {value: 'ASP.NET', text: 'ASP.NET'},
          {value: 'COBOL', text: 'COBOL'},
          {value: 'J2EE Architecture', text: 'J2EE Architecture'},
          {value: 'HTML 5', text: 'HTML 5'},
          {value: 'AngularJS', text: 'AngularJS'},
          {value: 'Java Platform Language and Class Libraries', text: 'Java Platform Language and Class Libraries'},
          {value: 'Java Standard Edition', text: 'Java Standard Edition'},
          {value: 'C (UNIX)', text: 'C (UNIX)'}
          ]; 

	$scope.showprimarySkill = function(user) {
            var selected = [];
             if(user.priskill) {
                selected = $filter('filter')($scope.primaryskilllist, {value: user.priskill});
               }
              return selected.length ? selected[0].text : 'Not set';
             }

    $scope.careerlevellist = [
         {value: 'Accenture Leadership', text: 'Accenture Leadership'},
         {value: '5-Senior Manager', text: '5-Senior Manager'},
         {value: '6-Senior Manager', text: '6-Senior Manager'},
         {value: '7-Manager', text: '7-Manager'},
         {value: '8-Associate Manager', text: '8-Associate Manager'},
         {value: '9-Team Lead', text: '9-Team Lead'},
         {value: '10-Senior Software Engineer', text: '10-Senior Software Engineer'},
         {value: '11-Software Engineer', text: '11-Software Engineer'},
         {value: '12-Associate Software Engineer', text: '12-Associate Software Engineer'},
         {value: '13-Associate Software Engineer', text: '13-Associate Software Engineerr'},
         {value: 'Intern ASE', text: 'Intern ASE'}
         ]; 

    $scope.showcareerLevel = function(user) {
             var selected = [];
               if(user.careerlevel) {
                 selected = $filter('filter')($scope.careerlevellist, {value: user.careerlevel});
               }
              return selected.length ? selected[0].text : 'Not set';
             }

    $scope.ffentitylist = [
          {value: 'ASE Trainee', text: 'ASE Trainee'},
          {value: 'ASW', text: 'ASW'},
          {value: 'ASW CD', text: 'ASW CD'},
          {value: 'ASW PE', text: 'ASW PE'},
          {value: 'Avanade', text: 'Avanade'},
          {value: 'Avanade Pembroke', text: 'Avanade Pembroke'},
          {value: 'IDC', text: 'IDC'},
          {value: 'BTG-IDC', text: 'BTG-IDC'},
          {value: 'Capacity Services', text: 'Capacity Services'},
          {value: 'DCN-ISU', text: 'DCN-ISU'},
          {value: 'Expat', text: 'Expat'},
          {value: 'Graduate Associate', text: 'Graduate Associate'},
          {value: 'Graduate Associate ISIS', text: 'Graduate Associate ISIS'},
          {value: 'IDC Pembroke', text: 'IDC Pembroke'},
          {value: 'IO-DC', text: 'IO-DC'},
          {value: 'IO-DC - NON IDC', text: 'IO-DC - NON IDC'},
          {value: 'IS- Implementation Services', text: 'IS- Implementation Services'},
          {value: 'PG Associates', text: 'PG Associates'},
          {value: 'Services in IDC', text: 'Services in IDC'},
          {value: 'SI Specialist', text: 'SI Specialist'}
          ]; 
	   
	     $scope.showffEntity = function(user) {
            var selected = [];
               if(user.ffentity) {
                 selected = $filter('filter')($scope.ffentitylist, {value: user.ffentity});
               }
               return selected.length ? selected[0].text : 'Not set';
           }

	     $scope.rhl = [{value: 'true', text: 'Yes'},{value: 'false', text: 'No'}]; 
	   
	     $scope.showrhl = function(user) {
            var selected = [];
               if(user.ishlready) {
                  selected = $filter('filter')($scope.rhl, {value: user.ishlready});
                 }
                 return selected.length ? selected[0].text : 'Not set';
             }
	   
	     $scope.termlist = [{value: 'short term', text: 'short term'},{value: 'long term', text: 'long term'}]; 
	   
	     $scope.showterm = function(user) {
	                 var selected = [];
	                 if(user.lockduration) {
	                   selected = $filter('filter')($scope.termlist, {value: user.lockduration});
	                 }
	                 return selected.length ? selected[0].text : 'Not set';
	             }

	             

	   
	     /*$scope.loadGroups = function() {
	               return $scope.groups.length ? null : $http.get('/groups').success(function(data) {
	                 $scope.groups = data;
	               });
	             };
	*/

	              // filter users to show
	             $scope.filterUser = function(user) {
	               return user.isDeleted !== true;
	             };

	             // mark user as deleted
	             $scope.deleteUser = function(id) {
	               var filtered = $filter('filter')($scope.users, {id: id});
	               if (filtered.length) {
	                 filtered[0].isDeleted = true;
	               }
	             };

	             // add user
	             $scope.addUser = function() {
	               $scope.users.push({
	                 id: $scope.users.length+1,
	                 priskill: null,
	                 rrstartdate: new Date(),
	                 opened: false,
	                 careerlevel: null,
	                 ffentity: null,
	                 ishlready: "false",
	                 lockduration : $scope.dmd.portfolio=='Application Operation' ? "long term" : "short term",
	                 wbsecode: null,
	                 rescount: 1,
	                 isNew: true
	               });

	             };




	             // cancel all changes

	             $scope.cancel = function() {
	               for (var i = $scope.users.length; i--;) {
	                 var user = $scope.users[i];    
	                 // undelete
	                 if (user.isDeleted) {
	                   delete user.isDeleted;
	                 }
	                 // remove new 
	                 if (user.isNew) {
	                   $scope.users.splice(i, 1);
	                 }      
	               };
	             };

	             

     $scope.saveTable = function() {
	   var results = [];
	   for (var i = $scope.users.length; i--;) {
       var user = $scope.users[i];
	     // actually delete user
	     if (user.isDeleted) {
	       $scope.users.splice(i, 1);
	     }
	     // mark as not new 
	     if (user.isNew) {
	       user.isNew = false;
	     }
	     // send on server
//	     results.push($http.post('/saveUser', user));      
	   }
//	   return $q.all(results);
	           
	 };

	 $scope.combinesubmit = function ()
	 {
		 
		 var json1 = $scope.dmd;
		 var json2 = $scope.users;
		    
		    //alert(json1+' '+json2);
		    for(var i=0;i<json2.length;i++)
		    {	
		    var json3 = angular.extend({},json1,json2[i]);
		    $scope.demands.push(json3);
		    }
		    
			
		    console.log(JSON.stringify($scope.demands));
		   // alert(JSON.stringify($scope.demands));
		    
			var response = $http({
		        method : 'POST',
		        url : 'ResourceMultipleRequestServlet',
		        contentType: 'application/json',
		        data : JSON.stringify($scope.demands)});
		    
			response.success(function(data, status, headers, config) {
				 	
			alert("Demand Request successfully created !!!");
			$scope.demands=[];
			$scope.users=[];
			$scope.dmd={};
			});
			response.error(function(data, status, headers, config) {
								
			alert("Oh Snap!! Something went wrong, please try again after some time!!!");
			$scope.demands=[];
			$scope.users=[];
			$scope.dmd={};
			});
			 
	 };
	 
	 
	});



myApp.controller("checklistTableCtrl", function ($scope,$window,$http,$filter) {
	
	
	 $scope.getresourcedata = function()
	 {
		 var response = $http({method : 'GET',url : 'staticTable?action=rollOffChk', contentType: 'application/json'});
		 response.success(function(data, status, headers, config) {
			 //alert(JSON.stringify(data));
			$scope.new_data = angular.fromJson(data) ;
			});
		 
		 if(localStorage.getItem("rolloffresourcename")!='undefined') 
		 {
		 	$scope.resourceName=localStorage.getItem("rolloffresourcename");		  
		 	$scope.getchecklistdata();
		 	localStorage.clear();
		 }
	 }
	 
	 
	 $scope.getchecklistdata = function()
	 {
		 var response = $http({method : 'GET',url : 'RollOffCheckListServlet?id='+$scope.resourceName , contentType: 'application/json'});
		 response.success(function(data, status, headers, config) {
			 //alert(JSON.stringify(data));
			 //alert(angular.fromJson(data.checklist1));
			 $scope.checklist1 = angular.fromJson(data.checklist1);$scope.checklist2 = angular.fromJson(data.checklist2);
			 $scope.checklist3 = angular.fromJson(data.checklist3);$scope.checklist4 = angular.fromJson(data.checklist4);
			 $scope.checklist5 = angular.fromJson(data.checklist5);$scope.checklist6 = angular.fromJson(data.checklist6);
			 $scope.checklist7 = angular.fromJson(data.checklist7);$scope.checklist8 = angular.fromJson(data.checklist8);
			 $scope.checklist9 = angular.fromJson(data.checklist9);$scope.checklist10 = angular.fromJson(data.checklist10);
			 $scope.checklist11 = angular.fromJson(data.checklist11);$scope.checklist12 = angular.fromJson(data.checklist12);
			 $scope.checklist13 = angular.fromJson(data.checklist13);$scope.checklist14 = angular.fromJson(data.checklist14);
			 $scope.checklist15 = angular.fromJson(data.checklist15);$scope.checklist16 = angular.fromJson(data.checklist16);
			 $scope.checklist17 = angular.fromJson(data.checklist17);$scope.checklist18 = angular.fromJson(data.checklist18);
			 $scope.checklist19 = angular.fromJson(data.checklist19);$scope.checklist20 = angular.fromJson(data.checklist20);
			});
		 response.error(function(data, status, headers, config) {
			 $scope.checklist1={}; $scope.checklist11={};
			 $scope.checklist2={}; $scope.checklist12={};
			 $scope.checklist3={}; $scope.checklist13={};
			 $scope.checklist4={}; $scope.checklist14={};
			 $scope.checklist5={}; $scope.checklist15={};
			 $scope.checklist6={}; $scope.checklist16={};
			 $scope.checklist7={}; $scope.checklist17={};
			 $scope.checklist8={}; $scope.checklist18={};
			 $scope.checklist9={}; $scope.checklist19={};
			 $scope.checklist10={}; $scope.checklist20={};
			 
		 });
	 }
	 
	 
	 $scope.checklistfinal = {};
	 
	 $scope.checklist1={}; $scope.checklist11={};
	 $scope.checklist2={}; $scope.checklist12={};
	 $scope.checklist3={}; $scope.checklist13={};
	 $scope.checklist4={}; $scope.checklist14={};
	 $scope.checklist5={}; $scope.checklist15={};
	 $scope.checklist6={}; $scope.checklist16={};
	 $scope.checklist7={}; $scope.checklist17={};
	 $scope.checklist8={}; $scope.checklist18={};
	 $scope.checklist9={}; $scope.checklist19={};
	 $scope.checklist10={}; $scope.checklist20={};
	
	 $scope.chkListData = 
	{"checklist1":$scope.checklist1,"checklist2":$scope.checklist2,
	"checklist3":$scope.checklist3,"checklist4":$scope.checklist4,
	"checklist5":$scope.checklist5,"checklist6":$scope.checklist6,
	"checklist7":$scope.checklist7,"checklist8":$scope.checklist8,
	"checklist9":$scope.checklist9,"checklist10":$scope.checklist10,
	"checklist11":$scope.checklist11,"checklist12":$scope.checklist12,
	"checklist13":$scope.checklist13,"checklist14":$scope.checklist14,
	"checklist15":$scope.checklist15,"checklist16":$scope.checklist16,
	"checklist17":$scope.checklist17,"checklist18":$scope.checklist18,
	"checklist19":$scope.checklist19,"checklist20":$scope.checklist20}
	;
	 
	 
	 
	 $scope.popup0 = {   opened: false   };$scope.popup10 = {   opened: false   };
	 $scope.popup1 = {   opened: false   };$scope.popup11 = {   opened: false   };
	 $scope.popup2 = {   opened: false   };$scope.popup12 = {   opened: false   };
	 $scope.popup3 = {   opened: false   };$scope.popup13 = {   opened: false   };
	 $scope.popup4 = {   opened: false   };$scope.popup14 = {   opened: false   };
	 $scope.popup5 = {   opened: false   };$scope.popup15 = {   opened: false   };
	 $scope.popup6 = {   opened: false   };$scope.popup16 = {   opened: false   };
	 $scope.popup7 = {   opened: false   };$scope.popup17 = {   opened: false   };
	 $scope.popup8 = {   opened: false   };$scope.popup18 = {   opened: false   };
	 $scope.popup9 = {   opened: false   };$scope.popup19 = {   opened: false   };
	  
	 
	 $scope.open0 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup0.opened = true; };
	 $scope.open1 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup1.opened = true; };
	 $scope.open2 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup2.opened = true; };
	 $scope.open3 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup3.opened = true; };
	 $scope.open4 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup4.opened = true; };
	 $scope.open5 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup5.opened = true; };
	 $scope.open6 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup6.opened = true; };
	 $scope.open7 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup7.opened = true; };
	 $scope.open8 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup8.opened = true; };
	 $scope.open9 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup9.opened = true; };
	 $scope.open10 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup10.opened = true; };
	 $scope.open11 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup11.opened = true; };
	 $scope.open12 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup12.opened = true; };
	 $scope.open13 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup13.opened = true; };
	 $scope.open14 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup14.opened = true; };
	 $scope.open15 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup15.opened = true; };
	 $scope.open16 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup16.opened = true; };
	 $scope.open17 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup17.opened = true; };
	 $scope.open18 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup18.opened = true; };
	 $scope.open19 = function($event) {  $event.preventDefault(); $event.stopPropagation();  $scope.popup19.opened = true; };



	 $scope.submit = function()
	 {
		 $scope.checklistfinal={};
		 
		 
		 if($scope.checklist1.status=='Completed' || $scope.checklist1.status=='Not Applicable' || $scope.checklist2.status=='Completed' || $scope.checklist2.status=='Not Applicable' ||
					$scope.checklist3.status=='Completed' || $scope.checklist3.status=='Not Applicable' || $scope.checklist4.status=='Completed' || $scope.checklist4.status=='Not Applicable' ||
					$scope.checklist5.status=='Completed' || $scope.checklist5.status=='Not Applicable' || $scope.checklist6.status=='Completed' || $scope.checklist6.status=='Not Applicable' ||
					$scope.checklist7.status=='Completed' || $scope.checklist7.status=='Not Applicable' || $scope.checklist8.status=='Completed' || $scope.checklist8.status=='Not Applicable' ||
					$scope.checklist9.status=='Completed' || $scope.checklist9.status=='Not Applicable' || $scope.checklist10.status=='Completed' || $scope.checklist10.status=='Not Applicable' ||
					$scope.checklist11.status=='Completed' || $scope.checklist11.status=='Not Applicable' || $scope.checklist12.status=='Completed' || $scope.checklist12.status=='Not Applicable' ||
					$scope.checklist13.status=='Completed' || $scope.checklist13.status=='Not Applicable' || $scope.checklist14.status=='Completed' || $scope.checklist14.status=='Not Applicable' ||
					$scope.checklist15.status=='Completed' || $scope.checklist15.status=='Not Applicable' || $scope.checklist16.status=='Completed' || $scope.checklist16.status=='Not Applicable' ||
					$scope.checklist17.status=='Completed' || $scope.checklist17.status=='Not Applicable' || $scope.checklist18.status=='Completed' || $scope.checklist18.status=='Not Applicable' ||
					$scope.checklist19.status=='Completed' || $scope.checklist19.status=='Not Applicable' || $scope.checklist20.status=='Completed' || $scope.checklist20.status=='Not Applicable')
			 
		 var finalstatus = 'Inactive';
		
		 else	 var finalstatus = 'Active'
		
		 $scope.checklistfinal=
				{"empNum":$scope.resourceName,"checklist1":$scope.checklist1,"checklist2":$scope.checklist2,
					"checklist3":$scope.checklist3,"checklist4":$scope.checklist4,
					"checklist5":$scope.checklist5,"checklist6":$scope.checklist6,
					"checklist7":$scope.checklist7,"checklist8":$scope.checklist8,
					"checklist9":$scope.checklist9,"checklist10":$scope.checklist10,
					"checklist11":$scope.checklist11,"checklist12":$scope.checklist12,
					"checklist13":$scope.checklist13,"checklist14":$scope.checklist14,
					"checklist15":$scope.checklist15,"checklist16":$scope.checklist16,
					"checklist17":$scope.checklist17,"checklist18":$scope.checklist18,
					"checklist19":$scope.checklist19,"checklist20":$scope.checklist20,"status":finalstatus};
		 console.log(JSON.stringify($scope.checklistfinal));
		 console.log($scope.checklistfinal);
		//alert(JSON.stringify($scope.checklistfinal));
		
		
		var response = $http({method :'POST',url : 'RollOffCheckListServlet', contentType: 'application/json',
	    data : JSON.stringify($scope.checklistfinal)});

		 
		 
		response.success(function(data, status, headers, config) {
			console.log("success updated");
			alert("Details Updated successfully !!!!");
		});
		response.error(function(data, status, headers, config) {
			console.log("error");
		});
			 
	 };



});


myApp.controller("dynamicreportcontroller", function ($scope,$window,$http,$parse) {
	
	$scope.loading = true;
	$scope.filtering = false;
	$scope.isDisabled = false;
	$scope.buttonName = 'Get Report';
	$scope.reportName = 'Generated Report';
	$scope.sortReverse  = false;
	
	
	$scope.models = [
	                 {listName: "Available Columns", items: [], dragging: false},
	                 {listName: "Selected for Report", items: [], dragging: false}
	               ];
	
	var list_columns = [
	["EnterpriseID","Resource Name","Project Name","Portfolio","Status"],
	["Portfolio","Expected Demand Fulfillment Date","Requested Resource Start Date","Demand End Date","Demand Segmentation","Client Interview Required"
	 ,"Primary Skill","Ready to Hard Lock","Fulfillment Entity","Lock Duration","WBSe","Priority","Source Location","Work Location","Career Level",
	 "Onsite Component Present","Visa Type","Visa Ready resource","Demand ID","Created By","Updated By","Created TS","Updated TS","Status"],
	 ["Employee Id","Resource Name","Portfolio","Certification Type","Certification Name","Certification Date","Completion Status","Score"],
	["Task Name","Task Description","Start Date","Estimated/End Date","status","Created By","Open Days"]
	];
	
	var list_columns_id = [
	["empId","rname","projName","stream","status"],	                       
    ["portfolio","edfulfilldate","rrstartdate","demandenddate","demandsegment","clientiview","priskill","ishlready","ffentity","lockduration",
     "wbsecode","demandpriority","srclocation","wrklocation","careerlevel","onsitecomponent","visatype","visaready","demandid","createdby","updatedby",
     "createdts","updatedts","status"],
     ["empId","rname","stream","certificationType","certificationName","certificationDate","certificationStatus","score"],
    ["taskName","taskDescription","assignedDate","endDate","status","assignedBy","daysElapsed"]
 	];
	
	$scope.searchfilter = {};
	
	$scope.togglefilter = function()
	{
		$scope.filtering = !$scope.filtering;
		
		if(!$scope.filtering)
		{
			for (var i in $scope.searchfilter)
			{
				delete $scope.searchfilter[i] ;
				//alert(i+' and '+$scope.searchfilter[i]);
			}
			$scope.searchfilter = {};
		}	else
		{	
			for (var i in $scope.searchfilter)
			{
				$scope.searchfilter[i] = '';
				//alert(i+' and '+$scope.searchfilter[i]);
			}	
		}	
		
	}
	
	$scope.togglesort = function(value)
	{
		//alert(value);
		$scope.sortType = value; 
		$scope.sortReverse = !$scope.sortReverse;
		//alert($scope.sortReverse);
		
	}
	
	$scope.reportdata = [];
	
	
	$scope.getreport = function()
	{
		$scope.isDisabled = true;
		$scope.buttonName = 'Loading data..';
		$scope.sortType     = $scope.models[1].items[0].id; //default first field sorted
						
		var url;
		switch($scope.tableview)
		{
		case '0' : //employee details path to change
			url = 'reports?action=resourceDetails';
			$scope.reportName = 'Employee Details';
			break;
			
		case '1' : //RRD Details
			url = 'reports?action=rrddetails';
			$scope.reportName = 'RRD Details';
			break;
			
		case '2' : //certification
			url = 'reports?action=certificationMasterReport';
			$scope.reportName = 'Certification Details';
			break;
			
		case '3' : //Task details
			url = 'reports?action=tasksMasterReport';
			$scope.reportName = 'Task Details';
			break;
		}
		//alert(url+" "+$scope.tableview);
		var response = $http({method : 'GET',url : url, contentType: 'application/json'});
	    response.success(function(data, status, headers, config) {	    	
	    	//alert(data);
	    	//alert(angular.fromJson(data));
	    	//alert(JSON.stringify(angular.fromJson(data)));
	    	for (var i = 0; i < $scope.models[1].items.length ; i++) {
				var idvalue = 'searchfilter.'+$scope.models[1].items[i].id;
				var model = $parse(idvalue);
				model.assign($scope,"");
			}
	    	
	    	$scope.reportdata = angular.fromJson(data);
	    	$scope.loading = false;
	    	$scope.buttonName = 'Get Report';
	    	$scope.isDisabled = false;
	    });
		response.error(function(data, status, headers, config) {
			
			alert("Oh Snap!! Something went wrong, please try again after some time!!!");
			$scope.loading = true;
	    	$scope.buttonName = 'Get Report';
	    	$scope.isDisabled = false;
		});
	};
	
		
	$scope.viewselect = function()
	{
		$scope.loading = true;
		
		//incase filtering options were not removed to clear the fields and toggle for the next dynamic report
		$scope.filtering = false;
		for (var i in $scope.searchfilter)
		{
			delete $scope.searchfilter[i] ;
		
		}
		$scope.searchfilter = {};
		
		var list_data = list_columns[$scope.tableview];
		var list_id = list_columns_id[$scope.tableview];
		$scope.models[0].items = [];
		$scope.models[1].items = [];
		
		 for (var i = 0; i < list_data.length ; i++) {
			 $scope.models[0].items.push({label: list_data[i],id : list_id[i] });
		 }
	}
	               /**
	                * dnd-dragging determines what data gets serialized and send to the receiver
	                * of the drop. While we usually just send a single object, we send the array
	                * of all selected items here.
	                */
	               $scope.getSelectedItemsIncluding = function(list, item) {
	                 item.selected = true;
	                 return list.items.filter(function(item) { return item.selected; });
	               };

	               /**
	                * We set the list into dragging state, meaning the items that are being
	                * dragged are hidden. We also use the HTML5 API directly to set a custom
	                * image, since otherwise only the one item that the user actually dragged
	                * would be shown as drag image.
	                */
	               $scope.onDragstart = function(list, event) {
	                  list.dragging = true;
	                  if (event.dataTransfer.setDragImage) {
	                    var img = new Image();
	                    //img.src = 'framework/vendor/ic_content_copy_black_24dp_2x.png';
	                    event.dataTransfer.setDragImage(img, 0, 0);
	                  }
	               };

	               /**
	                * In the dnd-drop callback, we now have to handle the data array that we
	                * sent above. We handle the insertion into the list ourselves. By returning
	                * true, the dnd-list directive won't do the insertion itself.
	                */
	               $scope.onDrop = function(list, items, index) {
	                 angular.forEach(items, function(item) { item.selected = false; });
	                 list.items = list.items.slice(0, index)
	                             .concat(items)
	                             .concat(list.items.slice(index));
	                 return true;
	               }

	               /**
	                * Last but not least, we have to remove the previously dragged items in the
	                * dnd-moved callback.
	                */
	               $scope.onMoved = function(list) {
	                 list.items = list.items.filter(function(item) { return !item.selected; });
	               };

	               // Generate the initial model
	               /*angular.forEach($scope.models, function(list) {
	                 for (var i = 1; i <= 4; ++i) {
	                     list.items.push({label: "Item " + list.listName + i});
	                 }
	               });*/

	               // Model to JSON for demo purpose
	               $scope.$watch('models', function(model) {
	                   $scope.modelAsJson = angular.toJson(model, true);
	               }, true);

	
	
	}); 










function individualdrop() {

	$("#employeeName").hide();
	$("#empId").hide();
}
function hidedrop() {
	$("#ddlMon").hide();
	$("#ddlQua").hide();
	$("#month").hide();
	$("#Quarter").hide();
}
function monthlydetail() {
	hidedrop();
	$("#ddlMon").show();
	$("#month").show();
}
function Quarterlydetail() {
	hidedrop();
	$("#ddlQua").show();
	$("#Quarter").show();
}
$.fn.save_change_call_update_Tasks = function() {
	$.ajax({
		type : 'POST',
		url : 'taskSave?action=update',
		data : $("#basicBootstrapFormUpdateTask").serializeArray(),
		success : function(data) {
			alert("Details updated successfully");
			location.reload();
		}
	});
};

$.fn.delete_TaskDetails_fn_Task = function() {
	$.ajax({
		type : 'POST',
		url : 'taskDelete?action=update',
		data : $("#basicBootstrapFormUpdateTask").serializeArray(),
		success : function(data) {
			alert("Details deleted successfully");
			location.reload();
		}
	});
};

$.fn.populateDialogBox = function() {

	var getListDatas = $(this).parents("tr").children("td");
	$.each(getListDatas, function(i, v) {
		$("#myModalUpdateTask").find(".form-control").eq(i).val($(v).text());
	});

};

function populateDialogRewards() {

	var selected = $("#myModalRewards option:selected").val();
	if (selected == "Team") {
		individualdrop();
		var getListDatas = $(this).parents("tr").children("td");
		$.each(getListDatas, function(i, v) {
			$("#myModal").find(".form-control").eq(i).val($(v).text());
		});

		$('#myModal').modal('show');
	} else {
		$("#employeeName").show();
		$("#empId").show();
	}
}

function dateCompare(date1, date2) {
	return new Date(date2) > new Date(date1);
}

function task_submit_fnc(e) {
	var startdate = $("#assignedDate").val();
	var enddate = $("#endDate").val();

	checkFields();

	if (checkFields().inpFld) {
		$("#main_error_alert").html("Please fill the mandatory fields");
		
	}
	
	if (dateCompare(enddate, startdate)) {

		$("#main_error_alert")
				.html(
						"Tentative Deadline Date shouldn't lesser than Task Created on Date");	
	}
else{
		
		$("#taskSave").submit();
		
	}
	e.preventDefault();
	/*e.preventDefault();
	location.reload();*/
};

function onTeamSubmit(e) {

	var costJson = {};
	$(".checkbox1").each(function(i, obj) {
		if (obj.checked == true) {

			costJson[obj.id] = obj.name;
		}

	});
	var json = JSON.stringify(costJson);
	var urlString = getUrl();
	alert("Details saved successfully");
	location.reload();
	$.ajax({
		url : 'rewSave',
		type : 'POST',
		dataType : 'json',
		data : urlString + '&json=' + json,
		success : function(result) {
			alert("hi")
			
			
		}
	
	
	});

	/*checkFields();
	if(checkFields().inpFld || checkFields().emlFld)
	{	
		
		$("#main_error_alert").html("Please fill the mandatory fields");
	}*/
	

	
	
}

function getUrl() {
	var selected = '&awardReceiver='
			+ $("#myModalRewards option:selected").val();
	var empName = '&employeename=' + $('#empName').val();
	var empId = '&employeeId=' + $('#empNbr').val();
	var radio = '&monthly='
			+ $("input[type='radio'][name='awardtype']:checked").val();
	var monthperiod = '&monthlyperiod=' + $('#month').val();
	var monthaward = '&monthlyaward=' + $('#ddlMon').val();
	var quarterperiod = '&quarterlyperiod=' + $('#Quarter').val();
	var quarteraward = '&quarterlyaward=' + $('#ddlQua').val();
	var reason = '&reason=' + $('#reason').val();
	var stream = '&stream=' + $("#stream option:selected").val();
	var Url = 'page=updateTeam' + selected + empName + empId + radio
			+ monthperiod + monthaward + quarterperiod + quarteraward + reason
			+ stream;
	return Url;

}

function onChangeStream() {

	var stream = $("#stream option:selected").val();

}

function rewards_submit_fnc(e) {

	var reason = $("#reason").val();
	var empId = $("");
	if (reason == null) {

		$("#main_error_alert").html("Reason Shouldn't be empty");

	}
	$('html, body').animate({
		scrollTop : 0
	}, "slow");

};

$(function() {
	$('#configreset').click(function() {
		$('#devForm')[0].reset();
		$('html, body').animate({
			scrollTop : 0
		}, "slow");
	});
});


/*function populateDialogAssessment() {

//	var selected = $("#diffID option:selected").val();
//	if(selected){
		$('#myModalAssessment').modal('show');
	//}
	//else
	//	$('#myModalAssessment').modal('hide');
	//}
	
}*/


package com.pmo.main;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pmo.connection.DatabaseConnection;

/**
 * Servlet implementation class TaskDeleteServlet
 */

public class TaskDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TaskDeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }



	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		DatabaseConnection dbConn = new DatabaseConnection();
        Connection con = dbConn.mySqlConnection(); 
        PreparedStatement pst = null;
       // String operation = request.getParameter("page");
		String taskDescription=(String)request.getParameter("taskDescModal");
		//HttpSession session = request.getSession(true);
		String operation = (String) request.getParameter("action");
        if (operation.equals("update")) 
		{
		
			String deleteTasks = "Delete from tasks WHERE task_desc=?";
			try {
				pst = con.prepareStatement(deleteTasks);
				pst.setString(1,taskDescription);
				pst.executeUpdate();
				con.commit();
				//pst.close();
				//con.close();
			} catch (SQLException e) {				
				e.printStackTrace();
			}finally 
			{
				// DatabaseConnection.closeRs(rs);
				DatabaseConnection.closePst(pst);
				DatabaseConnection.closeCon(con);
        }
        
        
		}
	}

}

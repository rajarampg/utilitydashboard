package com.pmo.main;

import java.io.IOException;  
import java.io.PrintWriter;  
  
import javax.servlet.ServletException;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
//import javax.servlet.http.HttpSession;  
public class logoutServlet extends HttpServlet {  
        /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		protected void doGet(HttpServletRequest request, HttpServletResponse response)  
                                throws ServletException, IOException {  
            response.setContentType("text/html");  
            PrintWriter out=response.getWriter();  
            request.setAttribute("loginError", "You are successfully logged out!");  
            request.getRequestDispatcher("index.jsp").include(request, response);  
//            request.getRequestDispatcher("newlogin.jsp").include(request, response);  
           // HttpSession session=request.getSession();  
          //  session.invalidate();  
              
            //out.println("<span class='alert'>You are successfully logged out!</span>");     
              
            out.close();  
    }  
}  

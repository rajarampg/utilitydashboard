package com.pmo.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.pmo.commons.EventNotification;
import com.pmo.dboperation.ResourceRequestDemandDAO;
import com.pmo.login.AccessDao;
import com.pmo.model.ResourceRequestDemandDetails;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

/**
 * Servlet implementation class ResourceRequestServlet
 */
//@WebServlet("/ResourceRequestServlet")
public class ResourceRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResourceRequestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		String demandId = request.getParameter("id");
		boolean demandStat= false;
		ResourceRequestDemandDetails rrdFormFetch;
		try {
			demandStat = ResourceRequestDemandDAO.isDemandIdPresent(demandId);
			if(demandStat){
				rrdFormFetch= ResourceRequestDemandDAO.rrdFetch(demandId);
				response.setContentType("application/json");
				System.out.println(new Gson().toJson(rrdFormFetch));
				response.getWriter().write(new Gson().toJson(rrdFormFetch));
			} else {
				response.sendError(0, "rrdentry.jsp");
			}
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		Gson rrdForm = new Gson();
		ResourceRequestDemandDetails rrdDetails = rrdForm.fromJson(request.getReader(), ResourceRequestDemandDetails.class); 
		System.out.println("Resource Request Demand details: " + rrdDetails.toString());
		String userName = (String) request.getSession().getAttribute("name");
		int rrdFormResponse;
		try {
			rrdFormResponse = ResourceRequestDemandDAO.rrdInsert(rrdDetails, userName);
			List<String> toMailId = new ArrayList<String>() ;
			
			List<String> ccMailId = new ArrayList<String>() ;
			
			Configuration cfg = new Configuration();
			cfg.setServletContextForTemplateLoading(this.getServletContext(), "WEB-INF");
	        	Template template = cfg.getTemplate("demandtemplate.ftl");
	        
	        Writer out = new StringWriter();
	        try {
	        	Map<String, Object> rootMap = new HashMap<String, Object>();
	            	rootMap.put("obj",rrdDetails);
	        	template.process(rootMap,out);
	        	
				} 
	        catch (TemplateException e)
	        	{
				// TODO Auto-generated catch block
				e.printStackTrace();
	        	} 
			
			
			try {
				//PMO to TO MAIL ID
//				toMailId= AccessDao.getPmoUserID();
				toMailId.add("walmart.idc.pmo");
				
				//Supervisor and user to CC MAIL ID
				ccMailId.add(AccessDao.getSupervisorID(userName));
				ccMailId.add(userName);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			
			
			System.out.println("Email Content: "+ out.toString());
			
			if(rrdFormResponse != 0){
				EventNotification.sendSimpleEmailNotification(toMailId, ccMailId ," New Demand Request! ", out.toString());
				
				System.out.println("Successfully inserted values into DB!");
				response.sendRedirect("demandrequestview.jsp");
			} else{
				System.out.println("Failed to insert RRD details!");
				response.sendError(0, "demandrequestview.jsp");
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			response.sendError(0, "demandrequestview.jsp");
			e.printStackTrace();
			e.printStackTrace();
		} catch (AddressException e) {
			response.sendError(0, "demandrequestview.jsp");
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.printStackTrace();
		} catch (MessagingException e) {
			response.sendError(0, "demandrequestview.jsp");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}

package com.pmo.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pmo.connection.DatabaseConnection;

/**
 * Servlet implementation class HardwareDeleteServlet
 */

public class HardwareDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private String employeeId;
	Connection connection;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		DatabaseConnection dbConn = new DatabaseConnection();
		connection = dbConn.mySqlConnection(); 
		PreparedStatement pst;


		employeeId =(String)request.getParameter("employeeId");	

		String operation = request.getParameter("page");

		if(operation!=null && operation.equals("deleteHardwares")){
			try{
				connection.setAutoCommit(false);
				if(deleteLaptopDetails() && deleteMobileDetails() && deleteRsaDetails()){
					connection.commit();
				}else{

				}
			}
			catch(Exception e){
				e.printStackTrace();
				try{
					connection.rollback();
				}catch(Exception ex){
					ex.printStackTrace();
				}
			}finally{
				dbConn.closeConnection(connection, null, null);	
			}
	}else if (operation!=null && operation.equals("cost")) {
			PrintWriter pw = response.getWriter();
			String deletecost = "Delete from communication WHERE employeenumbr=? and month = ?";
			try {
				String month=(String)request.getParameter("month");
				pst = connection.prepareStatement(deletecost);
				pst.setInt(1,Integer.parseInt(employeeId));
				pst.setString(2,month);
				
				int deletedRecords = pst.executeUpdate();
				pst.close();
				connection.close();
		
				if(deletedRecords==1){
					pw.println("Detail deleted Successfully!!");
				}
				else {
					pw.println("Error deleting details!!");
				}
				
			} catch (SQLException e) {				
				e.printStackTrace();
			}
        }

	}
	
	
	boolean deleteLaptopDetails(){
		PreparedStatement pst = null;
		String deleteLap = "Delete from laptopdetails WHERE employeenumber = ";
		try {
			deleteLap+=employeeId;
			pst = connection.prepareStatement(deleteLap);
			pst.executeUpdate();
			pst.close();
			return true;
		} catch (SQLException e) {				
			e.printStackTrace();
			return false;
		}
	}
	
	
	boolean deleteMobileDetails(){
		PreparedStatement pst = null;
		String deleteMob = "Delete from mobiledetails WHERE employeenumber = ";
		try {
			deleteMob+=employeeId;
			pst = connection.prepareStatement(deleteMob);
			pst.executeUpdate();
			pst.close();
			return true;
		} catch (SQLException e) {				
			e.printStackTrace();
			return false;
		}
	}
	

	boolean deleteRsaDetails(){
		PreparedStatement pst = null;
		String deleteRsa = "Delete from rsadetails WHERE employeenumber = ";
		try {
			deleteRsa+=employeeId;
			pst = connection.prepareStatement(deleteRsa);
			pst.executeUpdate();
			pst.close();
			return true;
		} catch (SQLException e) {				
			e.printStackTrace();
			return false;
		}
	}


	
	
}

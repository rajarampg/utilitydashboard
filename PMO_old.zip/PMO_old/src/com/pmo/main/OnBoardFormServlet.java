package com.pmo.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.pmo.commons.EmailMessager;
import com.pmo.commons.EventNotification;
import com.pmo.commons.Util;
import com.pmo.connection.DatabaseConnection;
import com.pmo.connection.PmoProperties;
import com.pmo.dboperation.InsertOnboardingDetails;
import com.pmo.dboperation.RollOffCheckListDAO;
import com.pmo.login.AccessDao;
import com.pmo.login.TableDetail;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

public class OnBoardFormServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private final String selectQuery = "select resourcemanager  from approvaldetails";
	private final String selectSupervisorQuery = "select distinct supervisor_name from employeedetails where supervisor_name is not null";
	private final String selectChangeQuery = "select employeenumber, resourcename, manager_id, supervisor_name, projectname from employeedetails where employeenumber = ?";
	private final String updateQuery = "UPDATE employeedetails SET manager_id = ?, supervisor_name=? , projectname=? where employeenumber = ? ";

	private final String updateOffBoard = "UPDATE employeedetails SET rolloffdate = ?, rolloffreason=?, employee_status = ?, isexit = ? where employeenumber = ? "; 
		
	DatabaseConnection dbConn = new DatabaseConnection();	

	@SuppressWarnings("static-access")
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		String page = request.getParameter("page");
		String action = request.getParameter("action");
		Connection con = null;
		PreparedStatement statement = null;
		HttpSession session = request.getSession(false);
		String userName = (String) request.getSession().getAttribute("name");
		
		if(page!=null && page.equals("onboard")){
			if(action!=null && action.equals("insert")){
				String insertOrUpdate = request.getParameter("resname");
					response.setContentType("text/html");
					String prevResourceName = request.getParameter("resname");
					if(page!=null && page.equals("onboard")){
						if(action!=null && action.equals("insert")){
							InsertOnboardingDetails insert = new InsertOnboardingDetails();
							boolean status = false;
							if(insertOrUpdate!=null && insertOrUpdate.equals("New"))
								status = insert.insertEvent(request);
							else
								status = insert.updateOnBoardingDetails(request, prevResourceName);
							
							if(status)
							{	
								Util.setResponseStatus(response, "40OK");
								String isEmailNotRequired = PmoProperties.getProperty("ISEMAILREQ");
								if(isEmailNotRequired.equalsIgnoreCase("TRUE"))
								{
								if(insertOrUpdate!=null && insertOrUpdate.equals("New"))
								{
									
									String user = (String)session.getAttribute("enterpriseId");
									String onboardMailSubject= "Onboard Request";
									String onboardMailContent="";
									try {
										onboardMailContent=EmailMessager.generateEmailMessage(this.getServletContext(),request,"emailtemplateold.ftl");
										System.out.println("STR : "+onboardMailContent);
									} catch (TemplateException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}									
									//String onboardMailContent= "Onboard request has been raised by manager userid."+user;
									
									List<String> toMailId = new ArrayList<String>() ;
									List<String> ccMailId = new ArrayList<String>() ;
									try {
										toMailId.add("walmart.idc.pmo");
										
										ccMailId.add(AccessDao.getSupervisorID(userName));
										ccMailId.add(userName);
										
									} catch (SQLException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
									
									
									try {
										EventNotification.sendSimpleEmailNotification(toMailId,ccMailId, onboardMailSubject, onboardMailContent);
										
									} catch (AddressException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									} catch (MessagingException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}
							}
							}
							else
								Util.setResponseStatus(response, "Oops! Something went wrong!", "onboardingForm.jsp");
						}
					}	
			}
			
			
				
		}else if (page!=null && page.equals("changeRequest")){
			if (action!=null && action.equals("updateDetails")){
				String manager = request.getParameter("newman");
				String supervisor = request.getParameter("newSuper");
				String projectName = request.getParameter("newProjectName");
				String resourceName = request.getParameter("resourceName");
				String empId = resourceName.split("- ")[1];
				int recordsInserted = 0;
				
				try{
				con = dbConn.mySqlConnection();
				statement = con.prepareStatement(updateQuery);
				statement.setString(1, manager);
				statement.setString(2, supervisor);
				statement.setString(3, projectName);
				statement.setInt(4, Integer.parseInt(empId));
				recordsInserted = statement.executeUpdate();
				if(recordsInserted ==1 )
					con.commit();
				PrintWriter pw = response.getWriter();
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Details Got Saved Successfully');");
				pw.println("location='changeRequest.jsp';");
				pw.println("</script>");
				}catch(Exception e){
					e.printStackTrace();
				}finally{
					dbConn.closeConnection(con, statement, null);
				}
			}
		}else if (page!=null && page.equals("offBoard")){
			//String offboardingForm = "offboardingForm.jsp";
			String offboardingForm = "newrolloffchecklist.jsp";
			String responseMessage = "";
			String resourceName = request.getParameter("ResourceName");
			String isExit = request.getParameter("rolloffExitDate");
			boolean exit = (isExit != null && isExit.equals("roffExitDate"))? true: false; 
			String rollOffDate = request.getParameter("rollOffDate");
			String rollOffReason = request.getParameter("rolloffReason");
			String empId = resourceName.split("- ")[1];
			int recordsUpdated = 0;

			try{

				con = dbConn.mySqlConnection();
				con.setAutoCommit(false);
				statement = con.prepareStatement(updateOffBoard);
				statement.setString(1, rollOffDate);
				statement.setString(2, rollOffReason);
				statement.setInt(3, Util.OFFBOARDED);
				statement.setBoolean(4, exit);
				statement.setInt(5, Integer.parseInt(empId));
				recordsUpdated = statement.executeUpdate();
				InsertOnboardingDetails insert = new InsertOnboardingDetails();
				RollOffCheckListDAO rOffInsert = new RollOffCheckListDAO(); 
				//String userName = (String)request.getSession().getAttribute("name");
				if(recordsUpdated==1 && insert.insertTaskDetailsForRollOff("Roll Off Request",resourceName, userName, "rollOff",rollOffDate) && rOffInsert.insertRollOffCheckListDetails(empId,userName)){
					con.commit();
					responseMessage = "Off boarding request submitted successfully. Please fill in the Roll-Off checklist details as well";
					
					String isEmailNotRequired = PmoProperties.getProperty("ISEMAILREQ");
					if(isEmailNotRequired.equalsIgnoreCase("TRUE"))
					{					
						TableDetail empFetch = new TableDetail();
						List<String> toMailId = new ArrayList<String>() ;
						List<String> ccMailId = new ArrayList<String>() ;
						try {
							empFetch= AccessDao.getResourceDetails(resourceName);
							toMailId.add("walmart.idc.pmo");
							//Supervisor and user to CC MAIL ID
							ccMailId.add(AccessDao.getSupervisorID(userName));
							ccMailId.add(userName);
							String offboardMailSubject= "Offboard Request for "+empFetch.getEnterpriseId();		
							Configuration cfg = new Configuration();
							cfg.setServletContextForTemplateLoading(this.getServletContext(), "WEB-INF");
					        Template template = cfg.getTemplate("rollofftemplate.ftl");
					        
					        Writer out = new StringWriter();
					        try {
					        	Map<String, Object> rootMap = new HashMap<String, Object>();
					            rootMap.put("obj",empFetch);
					        	template.process(rootMap,out);
					        	
								} 
					        catch (TemplateException e)
					        	{
								// TODO Auto-generated catch block
								e.printStackTrace();
					        	}
					        try {
					        	System.out.println("EMail ROLL OFF : "+out.toString());
								EventNotification.sendSimpleEmailNotification(toMailId, ccMailId,offboardMailSubject, out.toString());
							} catch (AddressException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (MessagingException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
								
						
					
				}
					
				}
				else{
					con.rollback();
					responseMessage = "Error processing request";
				}

				
			}catch(Exception e){
				e.printStackTrace();
				responseMessage = "Error processing request";
			}finally{
				dbConn.closeConnection(con, statement, null);
			}
			Util.setResponseStatus(response, responseMessage, offboardingForm);
			
		}
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String page = request.getParameter("page");
		String action = request.getParameter("action");
		if(page!=null & page.equals("onBoarding")){
			RequestDispatcher rd = null;
			request.setAttribute("elementContent", "''");
    		rd= request.getRequestDispatcher("onboardingForm.jsp");
    		rd.forward(request, response);
		}else if(page!=null & page.equals("getEmployeeDetails")){
			String empId = request.getParameter("empId");
			InsertOnboardingDetails insert = new InsertOnboardingDetails();
			insert.getEmployeeDetails(response, Integer.parseInt(empId.trim()));	
		}else if(page!=null & page.equals("loadEmployeeDetails")){
			RequestDispatcher rd = null;
			request.setAttribute("elementContent", new InsertOnboardingDetails().getEmployeeDetailsJson(11097113));
    		rd= request.getRequestDispatcher("onboardingForm.jsp");
    		rd.forward(request, response);
		}else if(page!=null & page.equals("changeRequest")){
			PreparedStatement statement = null;
			
			Connection con = dbConn.mySqlConnection();
			ResultSet rs = null;
			
			if(action!=null && action.equals("loadManagerDetails")){
				List<String> empNameList = new ArrayList<String>();
				try {
					statement = con.prepareStatement(selectQuery);
					rs = statement.executeQuery();
					while (rs.next()) {
						String newManagerID = rs.getString("resourcemanager");
						empNameList.add(newManagerID);
					}
					String json = null;
					json = new Gson().toJson(empNameList);
					System.out.println("New manager: " +json.toString());
					response.setContentType("application/json");
					response.getWriter().write(json);

				} catch (SQLException e) {
					e.printStackTrace();
				}	
			}
			else if(action!=null && action.equals("loadNewSupervisorDetails")){
				List<String> empNameList = new ArrayList<String>();
				try {
					statement = con.prepareStatement(selectSupervisorQuery);
					rs = statement.executeQuery();
					while (rs.next()) {
						String newSuperID = rs.getString("supervisor_name");
						empNameList.add(newSuperID);
					}
					String json = null;
					json = new Gson().toJson(empNameList);
					System.out.println("New Supervisor: " +json.toString());
					response.setContentType("application/json");
					response.getWriter().write(json);

				} catch (SQLException e) {
					e.printStackTrace();
				}	
			}else if(action!=null && action.equals("populateDetails")){
				List<String> empNameList = null;
				try {
				String empName = request.getParameter("empName");
				String empId = empName.split("- ")[1];
				statement = con.prepareStatement(selectChangeQuery);
				statement.setInt(1, Integer.parseInt(empId.trim()));
				rs = statement.executeQuery();
				if(rs.next()) {
					empNameList = new ArrayList<String>();
					empNameList.add(rs.getString("manager_id"));
					empNameList.add(rs.getString("supervisor_name"));
					empNameList.add(rs.getString("projectname"));
				}
				String json = null;
				json = new Gson().toJson(empNameList);
				response.setContentType("application/json");
				response.getWriter().write(json);
				}catch(SQLException e){
					e.printStackTrace();
				}
			
			}
			
		}
	}
	
	
	
	
}

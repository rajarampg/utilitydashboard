package com.pmo.main;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class SessionHelper extends LoginServlet{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//public static String USER_NAME= "userName";
	//private static String PASSWORD = "password";
	
	
	public static boolean isUserLoggedIn(HttpServletRequest req)
	{
		boolean userLoggedIn = false;		
		HttpSession session = req.getSession(false);
		session.getAttribute("name");
		session.getAttribute("pass");
		
		if(session!=null)
		{
			String userName = (String)session.getAttribute("name");
			String passWord = (String)session.getAttribute("pass");
			if(userName!=null && passWord !=null)
			{
				userLoggedIn = true;
			}			
		}					
		return userLoggedIn;
	}

}

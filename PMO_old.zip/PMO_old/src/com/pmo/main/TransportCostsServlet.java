package com.pmo.main;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.pmo.commons.Util;
import com.pmo.connection.DatabaseConnection;
  
public class TransportCostsServlet extends HttpServlet{   
  
    private static final long serialVersionUID = 1L;
    private final String COLUMN_WBS_ELEMENT = "WBS_ELEMENT"; 
    private final String COLUMN_PERIOD ="period";
    private final String COLUMN_ADHOC_AMOUNT = "adhoc_amount";
    private final String COLUMN_REGULAR_AMOUNT = "regular_amount";
    private final String COLUMN_FINAL_AMOUNT = "final_amount";
    private final String COLUMN_STREAM = "stream";
    private final String COLUMN_TIMESTAMP = "transport_timestamp";
    private final String insertQuery = "INSERT INTO transport_cost (WBS_ELEMENT, period, adhoc_amount, regular_amount, final_amount, stream) values (?,?,?,?,?,?)";
    private final String selectQuery = "SELECT * FROM transport_cost WHERE upper(WBS_ELEMENT) = upper(?) AND period = ? AND stream = ?";
    private final String REPORT_SELECT_QUERY = "SELECT * FROM transport_cost ORDER BY transport_timestamp DESC";
    private final String deleteQuery = "DELETE FROM transport_cost WHERE upper(WBS_ELEMENT) = upper(?) AND period = ? AND stream = ?";
    final String VALIDATION_SAVE_SUCCESS = "Save successful!";
    final String VALIDATION_DELETE_SUCCESS = "Delete successful!";
    final String VALIDATION_DELETE_FAILED = "Delete failed!";
    final String VALIDATION_SAVE_FAILED = "Save failed!";
    final String VALIDATION_SAVE_ABORTED_AS_MULTIPLE_ENTRIES_FOUND = "Save aborted as multiple entries exists!";
    private String jspTransportsCost = "transportCosts.jsp";
    private String jspTransportsCostReport = "transportCostsReport.jsp";
    
    public void doGet(HttpServletRequest request, HttpServletResponse response)     
    		throws ServletException, IOException {    

    	RequestDispatcher rd=null;
    	DatabaseConnection dbConn = new DatabaseConnection();
    	Connection con = dbConn.mySqlConnection();
    	PreparedStatement statement = null;
    	String action=(String)request.getParameter("action");
    	String wbs=(String)request.getParameter("wbs");
    	String period=(String)request.getParameter("period");
    	String stream=(String)request.getParameter("stream");
    	String export=(String)request.getParameter("export");
    	ResultSet result = null;	

    	if(action!=null && action.equalsIgnoreCase("fetch")){
    		try{
    			statement = con.prepareStatement(selectQuery);
    			statement.setString(1, wbs);
    			statement.setString(2, period);
    			statement.setString(3, stream);
    			result = statement.executeQuery();
    			if(result.next()){
    				String adhocAmount=result.getString(COLUMN_ADHOC_AMOUNT);
    				String regularAmount=result.getString(COLUMN_REGULAR_AMOUNT);
    				String finalAmount=result.getString(COLUMN_FINAL_AMOUNT);
    				response.setContentType("application/json");
    				String jsonOutput = "{";
    				jsonOutput+="\"responseAvailable\":\"true\",";
    				jsonOutput+="\"adhocAmount\":\""+adhocAmount+"\",";
    				jsonOutput+="\"regularAmount\":\""+regularAmount+"\",";
    				jsonOutput+="\"finalAmount\":\""+finalAmount+"\"";
    				jsonOutput+="}";
    				response.getWriter().write(jsonOutput);
    			}

    		}catch(Exception e){
    			e.printStackTrace();
    		}finally{
    			DatabaseConnection.closeConnection(con, statement, result);
    		}
    	}else if(action!=null && action.equalsIgnoreCase("fetchReport")){
    		List<TransportDetails> list = new ArrayList<TransportDetails>();
    		TransportDetails transportCostDetails = null;
    		try{
    			statement = con.prepareStatement(REPORT_SELECT_QUERY);
    			result = statement.executeQuery();
    			while(result.next()){
    				transportCostDetails = new TransportDetails();
    				transportCostDetails.setWbsElement(result.getString(COLUMN_WBS_ELEMENT));
    				transportCostDetails.setPeriod(result.getString(COLUMN_PERIOD));
    				transportCostDetails.setStream(result.getString(COLUMN_STREAM));
    				transportCostDetails.setAdhocAmount(result.getDouble(COLUMN_ADHOC_AMOUNT));
    				transportCostDetails.setRegularAmount(result.getDouble(COLUMN_REGULAR_AMOUNT));
    				transportCostDetails.setFinalAmount(result.getDouble(COLUMN_FINAL_AMOUNT));
    			//	transportCostDetails.setTimeStamp(result.getString(COLUMN_TIMESTAMP));
    				list.add(transportCostDetails);
    			}
    		}catch(Exception e){
    			e.printStackTrace();
    		}finally{
    			DatabaseConnection.closeConnection(con, statement, result);
    		}
    		if(export!=null && export.equals("true")){
    			request.setAttribute("list", list);
        		rd= request.getRequestDispatcher("exportTransportCosts.jsp");
        		rd.forward(request, response);	
    		}else{
    		request.setAttribute("list", list);
    		rd= request.getRequestDispatcher("transportCostsReport.jsp");
    		rd.forward(request, response);
    		}
    		
    	}
    	
    	
    	else if(action!=null && action.equalsIgnoreCase("deleteTransportCost")){
    		try{
    			con.setAutoCommit(false);
    			statement = con.prepareStatement(deleteQuery);
    			statement.setString(1, wbs);
    			statement.setString(2, period);
    			statement.setString(3, stream);
    			int deletedEntries = statement.executeUpdate();
    			if(deletedEntries==1){
    				con.commit();
    				Util.setResponseStatus(response, VALIDATION_DELETE_SUCCESS, jspTransportsCostReport);
    				return;
    			} else if(deletedEntries>1){
    				con.rollback();
    				Util.setResponseStatus(response, VALIDATION_SAVE_ABORTED_AS_MULTIPLE_ENTRIES_FOUND, jspTransportsCostReport);
    				return;
    			}else{
    				con.rollback();
    				Util.setResponseStatus(response, VALIDATION_DELETE_FAILED, jspTransportsCostReport);
    				return;
    			}
    			
    		}catch(Exception e){
    			e.printStackTrace();
    		}finally{
    			DatabaseConnection.closeConnection(con, statement, result);
    		}
    	}
    }
    
    public void doPost(HttpServletRequest request, HttpServletResponse response)     
    		throws ServletException, IOException {

    	DatabaseConnection dbConn = new DatabaseConnection();
    	Connection con = dbConn.mySqlConnection();
    	PreparedStatement statement = null;      
    	String wbsNumber=(String)request.getParameter("wbs");
    	String period=(String)request.getParameter("period");
    	double adhocAmount= Double.parseDouble(request.getParameter("adhocAmount"));
    	double regularAmount= Double.parseDouble(request.getParameter("regularAmount"));
    	String stream=(String)request.getParameter("stream");
    	SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
    	int recordsInserted = 0;
    	try{
    		dateFormat.parse(period);	
    	}catch(ParseException e){
    		System.out.println("has to be handled");
    	}
    	try{
    		con.setAutoCommit(false);
    		statement = con.prepareStatement(deleteQuery);
    		statement.setString(1, wbsNumber);
    		statement.setString(2, period);
    		statement.setString(3, stream);
    		int deletedEntries = statement.executeUpdate();
    		if(deletedEntries>1){
    			con.rollback();
    			Util.setResponseStatus(response, VALIDATION_SAVE_ABORTED_AS_MULTIPLE_ENTRIES_FOUND, jspTransportsCost);
    			return;
    		}
    		statement.close();
    		statement = con.prepareStatement(insertQuery);
    		statement.setString(1, wbsNumber.toUpperCase());
    		statement.setString(2, period);
    		statement.setDouble(3, adhocAmount);
    		statement.setDouble(4, regularAmount);
    		statement.setDouble(5, adhocAmount+regularAmount);
    	     statement.setString(6, stream);
    		recordsInserted = statement.executeUpdate();
    		if(recordsInserted<1){
    			System.out.println("*****check");
    		}else if (recordsInserted == 1){
    			System.out.println("success");
    			con.commit();
    			Util.setResponseStatus(response, VALIDATION_SAVE_SUCCESS, jspTransportsCost);
    		}
    	}
    	catch(Exception e){
    		e.printStackTrace();
    		Util.setResponseStatus(response, VALIDATION_SAVE_FAILED, jspTransportsCost);
    		try{
    			con.rollback();
    		}catch(Exception ex){
    			e.printStackTrace();
    			Util.setResponseStatus(response, VALIDATION_SAVE_FAILED, jspTransportsCost);
    		}
    		return;
    	}finally{
    		DatabaseConnection.closeConnection(con, statement, null);
    	}

    }
    
    
    
   /* public void setResponseStatusEdit(HttpServletResponse response, String responseMessage){
    	try{
    	PrintWriter writer = response.getWriter();
    		String reply= "<script type=\"text/javascript\">"
    						+"alert('"+responseMessage+"');"
    						+"location='"+jspTransportsCostReport+"';"
    						+"</script>";
    	writer.write(reply);
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }*/
    
    
    public class TransportDetails{
    	
    	private String wbsElement;
    	
    	private String stream;
    	
    	private String period;
    	
    	private double adhocAmount;
    	
    	private double regularAmount;
    	
    	private double finalAmount;
    	
    	private String timeStamp;

		public String getWbsElement() {
			return wbsElement;
		}

		public void setWbsElement(String wbsElement) {
			this.wbsElement = wbsElement;
		}

		public String getStream() {
			return stream;
		}

		public void setStream(String stream) {
			this.stream = stream;
		}

		public String getPeriod() {
			return period;
		}

		public void setPeriod(String period) {
			this.period = period;
		}

		public double getAdhocAmount() {
			return adhocAmount;
		}

		public void setAdhocAmount(double adhocAmount) {
			this.adhocAmount = adhocAmount;
		}

		public double getRegularAmount() {
			return regularAmount;
		}

		public void setRegularAmount(double regularAmount) {
			this.regularAmount = regularAmount;
		}

		public double getFinalAmount() {
			return finalAmount;
		}

		public void setFinalAmount(double finalAmount) {
			this.finalAmount = finalAmount;
		}

		public String getTimeStamp() {
			return timeStamp;
		}

		public void setTimeStamp(String timeStamp) {
			this.timeStamp = timeStamp;
		}
    	
    }
    
	   
}   

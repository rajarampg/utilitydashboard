package com.pmo.main;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.pmo.dboperation.ResourceRequestDemandDAO;
import com.pmo.model.RRDMapper;

/**
 * Servlet implementation class RRDMapperServlet
 */
//@WebServlet("/RRDMapperServlet")
public class RRDMapperServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RRDMapperServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		

		String searchDemandId = request.getParameter("id");
		ArrayList<RRDMapper> rrdMapper;
		try {
			rrdMapper= ResourceRequestDemandDAO.rrdNumberFetch(searchDemandId);
			response.setContentType("application/json");
			System.out.println(new Gson().toJson(rrdMapper));
			response.getWriter().write(new Gson().toJson(rrdMapper));
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);

		Gson rrdMapperJson = new Gson();
		RRDMapper rrdmap = rrdMapperJson.fromJson(request.getReader(), RRDMapper.class);
		System.out.println("RRD Mapped Details: " + rrdmap.toString());
		
		boolean rrdResponse;
		try {
			rrdResponse=ResourceRequestDemandDAO.isRrdMappedValuePresent(rrdmap);
			if(rrdResponse){
				boolean updateStat= ResourceRequestDemandDAO.updateRrdMapValues(rrdmap);
				if(updateStat){
					System.out.println("Updated successfully!");
				} else {
					System.out.println("Failed during update!");
				}
			} else {
				boolean insertStat =ResourceRequestDemandDAO.insertRrdMapValues(rrdmap);
				if(insertStat){
					System.out.println("Inserted successfully");
				} else {
					System.out.println("Failed during insert!");
				}
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}

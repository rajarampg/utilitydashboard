package com.pmo.main;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pmo.dboperation.InsertHardwareDetails;
import com.pmo.login.HardwareMaintenance;

/**
 * Servlet implementation class HardwareUpdate
 */
//@WebServlet("/HardwareUpdate")
public class HardwareUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HardwareUpdateServlet() {
        super();        
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException ,NullPointerException{    	
		
		res.setContentType("text/html");		
		HardwareMaintenance rd=null;
		
		InsertHardwareDetails i=null;	
	    
	    HttpSession session = req.getSession(true);
		String page = (String) session.getAttribute("page");
	   
			if(page!=null && page.equals("hardware")){
				rd = new HardwareMaintenance();
				rd.setEmployeeNumber(Integer.parseInt(req.getParameter("employeeNumberModal").trim()));
				rd.setEmployeeName(req.getParameter("employeeNameModal"));
				rd.setStream(req.getParameter("stream"));
				rd.setRsaToken(Integer.parseInt(req.getParameter("rsaToken")));
				rd.setValidDate(req.getParameter("rsaValidUpto"));
				rd.setLaptopNo(req.getParameter("laptopNumber"));
				if(rd.getLaptopNo()!=null && !rd.getLaptopNo().trim().equals("")){
					rd.setAssetTag(req.getParameter("assetTag"));
					rd.setMake(req.getParameter("make"));	
				}
				rd.setMobileNo(Long.parseLong(req.getParameter("mobileNumber")));
				if(rd.getMobileNo()!=0){
					rd.setServiceProvider(req.getParameter("serviceProvider"));
					String billCycleStartDate = req.getParameter("billCycleStart");
					rd.setBillCycle(billCycleStartDate+"-"+req.getParameter("billCycleEnd"));
				}
				
				InsertHardwareDetails update = new InsertHardwareDetails();
//				Update functionality is revoked as of now at reports page
//				String status = update.updateHardwareDetails(rd);
				
			 }
				
		}
}

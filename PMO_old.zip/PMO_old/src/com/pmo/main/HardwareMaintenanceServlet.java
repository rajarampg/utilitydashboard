package com.pmo.main;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.codehaus.jackson.map.ObjectMapper;
import com.pmo.dboperation.InsertHardwareDetails;
import com.pmo.login.HardwareMaintenance;


public class HardwareMaintenanceServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException ,NullPointerException{
		System.out.println("in");
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException ,NullPointerException{
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");		
		InsertHardwareDetails i=null;
		boolean rsastatus = true,mobstatus = true,lapstatus = true, dataCardStatus = true;
		String operation = req.getParameter("empDetails");
		HardwareMaintenance  hardwareDetails = null;
		if(operation==null || (operation!=null && operation.trim().equals("\"\""))){
			hardwareDetails = new HardwareMaintenance();
			hardwareDetails.setRsa(false);
			hardwareDetails.setMobile(false);
			hardwareDetails.setLaptop(false);
			hardwareDetails.setDataCard(false);
		}else{
			ObjectMapper mapper = new ObjectMapper();
			hardwareDetails = mapper.readValue(operation, HardwareMaintenance.class);
		}
		
		i = new InsertHardwareDetails();
		boolean insert = false, update = false;
		
//		rsa
		Integer rsaToken=null;
		String rsatokenstring = req.getParameter("rsatoken");
		if(rsatokenstring!=null && !rsatokenstring.equals("")){
		rsaToken = Integer.parseInt(req.getParameter("rsatoken"));
			hardwareDetails.setRsaToken(rsaToken);
			hardwareDetails.setEmployeeNumber(Integer.parseInt(req
					.getParameter("employeenumber")));
			hardwareDetails.setEmployeeName(req.getParameter("employeename"));
			
			hardwareDetails.setValidDate(req.getParameter("validdate"));
		
		}
		
//		laptop
		String laptopnostring = req.getParameter("laptopno");
		if(laptopnostring!=null && !laptopnostring.equals("")) {

			hardwareDetails.setLaptopNo(req.getParameter("laptopno"));
			hardwareDetails.setEmployeeNumber(Integer.parseInt(req
					.getParameter("employeenumber")));
			hardwareDetails.setEmployeeName(req.getParameter("employeename"));				
			hardwareDetails.setAssetTag(req.getParameter("assettag"));
			hardwareDetails.setMake(req.getParameter("make"));
		}
//		mobile
		
		Long mobileNo =null;
		String mobilenostring = req.getParameter("mobileno");
		
		if(mobilenostring!=null && !mobilenostring.equals(""))
		{ 
			mobileNo = Long.parseLong(req.getParameter("mobileno"));


			String startdate=req.getParameter("billcycle");
			String enddate=req.getParameter("billcycleend");
			String billcycle=startdate.concat("-").concat(enddate);

			hardwareDetails.setMobileNo(Long.parseLong(req.getParameter("mobileno")));
			hardwareDetails.setEmployeeNumber(Integer.parseInt(req
					.getParameter("employeenumber")));
			hardwareDetails.setEmployeeName(req.getParameter("employeename"));
			hardwareDetails.setStream(req.getParameter("stream"));
			hardwareDetails.setBillCycle(billcycle);
			hardwareDetails.setServiceProvider(req.getParameter("serviceprovidername"));

		}
		
		
//		datacard
		
		String dataCardNumber =null;
		dataCardNumber = req.getParameter("dataCardNumber");
		
		
		if (dataCardNumber != null && !dataCardNumber.trim().equals("")) {

			String startdate=req.getParameter("dataCardBillStart");
			String enddate=req.getParameter("dataCardBillEnd");
			String billcycle=startdate.concat("-").concat(enddate);
			
			hardwareDetails.setDataCardNumber(Long.parseLong(dataCardNumber));
			hardwareDetails.setEmployeeNumber(Integer.parseInt(req.getParameter("employeenumber")));
			hardwareDetails.setDataCardBillCycle(billcycle);
			hardwareDetails.setDataCardServiceProvider(req.getParameter("dataCardServiceProvider"));
		}
		
		res.getWriter().write(i.saveHardwareDetails(hardwareDetails));
		}
	}



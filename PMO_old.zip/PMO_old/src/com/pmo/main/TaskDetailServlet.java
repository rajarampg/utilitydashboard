package com.pmo.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.pmo.commons.Util;
import com.pmo.connection.DatabaseConnection;
import com.pmo.dboperation.InsertTaskDetails;
import com.pmo.login.TableDetail;

/**
 * Servlet implementation class TaskDetailServlet
 */

public class TaskDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TaskDetailServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Statement st;
    	DatabaseConnection dbConn = new DatabaseConnection();

    	
    	Connection con = dbConn.mySqlConnection();
      //  HttpSession session= request.getSession(true);
		String operation=(String) request.getParameter("select");
	
		TableDetail td=new TableDetail();
		if (operation.equals("taskstatus")) 
		{
			 List<TableDetail> taskslist = new ArrayList<TableDetail>();   
			 
			try {
				Util daysElapFn = new Util();
				int noOfDays = 0;
				PreparedStatement ps=con.prepareStatement("select * from tasks where assignedby=? order by task_timestamp desc");
				ps.setString(1, (String) request.getSession().getAttribute("name"));
	        	ResultSet rs=ps.executeQuery();
	        	
	        	
	        	while (rs.next())
	        	{
	        		td = new TableDetail();
	        		td.setAssignedDate(rs.getString("assigned_date"));
	        		td.setTaskDescription(rs.getString("task_desc"));
	        		td.setEndDate(rs.getString("complete_date"));
	        		td.setStatus(rs.getString("status"));
	        		
	        		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	        		Date date = new Date();
	        		Date endDate = new Date(date.getTime());
	        		if(td.getStatus().equalsIgnoreCase("Completed")){
	        			noOfDays=daysElapFn.printDifference(td.getAssignedDate(), td.getEndDate());
	        		} else {
	        			noOfDays=daysElapFn.printDifference(td.getAssignedDate(), dateFormat.format(endDate).toString());
	        		}
	        		td.setDaysElapsed(noOfDays);
	        		
	        		
	        		td.setAssignedBy(rs.getString("assignedby"));	
	        		td.setTimestamp(rs.getTimestamp("task_timestamp"));
	        		td.setTaskName(rs.getString("task_name"));
	        		taskslist.add(td);
	        	}	
	        	response.setContentType("application/json");
	    		
	    		response.getWriter().write(new Gson().toJson(taskslist));
			}
		 catch (SQLException e) {				
			e.printStackTrace();
		} 
		}
	        		
		else if (operation.equals("tasks")) 
		{
			 List<TableDetail> taskslist = new ArrayList<TableDetail>();   
			 Util daysElapFn = new Util();
			 int noOfDays = 0;
			try {
	        	st=con.createStatement();
	        	ResultSet rs=st.executeQuery("select * from tasks where  status in('Progress','Pending') order by task_timestamp desc");
	        	boolean hasRollOn = false;
	        	while (rs.next())
	        	{
	        		td = new TableDetail();
	        		td.setAssignedDate(rs.getString("assigned_date"));
	        		td.setTaskDescription(rs.getString("task_desc"));
	        		td.setEndDate(rs.getString("complete_date"));
	        		td.setStatus(rs.getString("status"));
	        		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	        		Date date = new Date();
	        		Date endDate = new Date(date.getTime());
	        		if(!(td.getStatus().equalsIgnoreCase("Completed"))){
	        			noOfDays=daysElapFn.printDifference(td.getAssignedDate(), dateFormat.format(endDate).toString());
	        		} else {
	        			noOfDays=daysElapFn.printDifference(td.getAssignedDate(), td.getEndDate());
	        		}
	        		td.setDaysElapsed(noOfDays);
	        		td.setAssignedBy(rs.getString("assignedby"));	
	        		td.setTimestamp(rs.getTimestamp("task_timestamp"));
	        		td.setTaskName(rs.getString("task_name"));
	        		td.setRequestType(rs.getString("isRequest"));
//	        		 || td.getRequestType() !="demandReq") rollOn rollOff
	        		
	        		if(td.getRequestType() != null && (td.getRequestType().equalsIgnoreCase("rollOn")|| td.getRequestType().equalsIgnoreCase("rollOff"))){
	        			td.setEmpId(Integer.parseInt(td.getTaskDescription().split("- ")[1]));
	        			if(td.getRequestType().equals("rollOn"))
	        				hasRollOn = true;
	        		}
	        		taskslist.add(td);
	        		
	        	}
	        	request.setAttribute("list",taskslist);
	        	if(hasRollOn)
	        		request.setAttribute("isExportExists",hasRollOn);
	        	RequestDispatcher rd= request.getRequestDispatcher("taskdetail.jsp");
	        	rd.forward(request, response);
			} catch (SQLException e) {				
				e.printStackTrace();
			} 
		
		}
//		request.setAttribute("select", "tasks");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,NullPointerException {
	
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		TableDetail td=new TableDetail() ;
		InsertTaskDetails i  = new InsertTaskDetails();	
		HttpSession session = request.getSession(true);
		String operation = (String) request.getParameter("action");	
		String userName = (String) request.getSession().getAttribute("name");

		if(operation.equals("insert")) {
			td.setTaskName(request.getParameter("taskName"));
			td.setAssignedDate(request.getParameter("assignedDate"));
			String taskDescription =request.getParameter("taskDesc"); 
			td.setTaskDescription(taskDescription);
			td.setEndDate(request.getParameter("endDate"));
			td.setStatus(request.getParameter("status"));
			td.setAssignedBy(request.getParameter("assigned"));
			td.setTaskCompletedBy(userName);
			String status1=i.insertTaskDetails(td);
			
			if(status1.equals("true"))
			{			
			pw.println("<script type=\"text/javascript\">");
			pw.println("alert('Details Got Saved Successfully');");
			pw.println("location='tasks.jsp';");
			pw.println("</script>");
			}
			
			else
			{
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('DB Problem in Inserting the data');");
				pw.println("location='tasks.jsp';");
				pw.println("</script>");
			}
			
		}
		else if(operation.equals("update")) {	
			SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date date = new Date();
			td.setTaskName(request.getParameter("taskName"));
			td.setAssignedDate(request.getParameter("assignDateModal"));
			td.setTaskDescription(request.getParameter("taskDescModal"));
			td.setStatus(request.getParameter("statustypeModal"));
			if(td.getStatus().equalsIgnoreCase("Completed")){
				Date endDate = new Date(date.getTime());
				td.setEndDate(dateFormat.format(endDate).toString());
			} else {
				td.setEndDate(request.getParameter("endDateModal"));
			}
			td.setAssignedBy(request.getParameter("assignedByModal"));
			td.setTaskCompletedBy(userName);
			i.updateTaskDetails(td);
			
			
		}
			
		}
	}
			
	
package com.pmo.main;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pmo.dboperation.InsertTaskDetails;
import com.pmo.login.TableDetail;

/**
 * Servlet implementation class TaskUpdateServlet
 */

public class TaskUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TaskUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	//	PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		TableDetail td=new TableDetail() ;
		InsertTaskDetails i  = new InsertTaskDetails();		
		  String operation = request.getParameter("page");
		  String userName = (String) request.getSession().getAttribute("name");
		//String operation = (String) session.getAttribute("operation");	
			if(operation.equals("tasks")) {
				
				td.setAssignedDate(request.getParameter("assignDateModal"));
				td.setTaskDescription(request.getParameter("taskDescModal"));
				td.setEndDate(request.getParameter("endDateModal"));
				td.setStatus(request.getParameter("statustypeModal"));
				td.setAssignedBy(request.getParameter("assignedByModal"));
				td.setTaskCompletedBy(userName);
				i.updateTaskDetails(td);
				RequestDispatcher rd= request.getRequestDispatcher("taskdetail.jsp");
	        	rd.forward(request, response);
//	        	i.updateTaskDetails(td);
				
			}
			
			}
		}
	



/**
 * @author sankar.arumugam
 * @modifed valarmathi : 24/06/2015
 */
package com.pmo.main;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.pmo.commons.Util;
import com.pmo.dboperation.NewLoginDAO;
import com.pmo.login.AccessDao;
import com.pmo.login.LoginDao;

public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@SuppressWarnings("static-access")
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		//PrintWriter out = response.getWriter();
		SessionHelper sessionhelper = new SessionHelper();
		String user = request.getParameter("username");
		String password = request.getParameter("userpass");
		String role = request.getParameter("role");
		String responseMessage = "";
		int status = 0;
		String access="0";
		String enterpriseId = "";
		//HttpSession session = request.getSession(true);

		HttpSession session = request.getSession(false);

		/*
		 * if (session == null || session.getAttribute("name") == null ||
		 * session.getAttribute("pass") == null)
		 * 
		 * { request.getRequestDispatcher("/sessionError.jsp").forward(request,
		 * response);
		 * 
		 * }
		 */

		if(role !=null && role.equalsIgnoreCase("guest"))
		{
			
			if (user !=null && !user.trim().equalsIgnoreCase("guest"))
			{	
							role="employee";
			}
		}
		
		if (session != null) {
			
			session.setAttribute("name", user);
			
			//session.setMaxInactiveInterval(60);
          //  Cookie userName = new Cookie("name", user);
            
          //  response.addCookie(userName);
            //response.sendRedirect("index.jsp");
			session.setAttribute("pass", password);
			session.setAttribute("role", role);
			sessionhelper.isUserLoggedIn(request);
			String loginForm = "index.jsp";
			boolean firstTimeUser;
			NewLoginDAO loginDao = new NewLoginDAO();
			try {
				firstTimeUser = loginDao.getLoginStatus(user);
				if (firstTimeUser) {
					int loginChk=loginDao.validateFirstLogin(user, password,role);
					if(loginChk==1){
						access=AccessDao.getAccess(role);
						enterpriseId = LoginDao.getEnterprizeId(user);
						session.setAttribute("enterpriseId",enterpriseId);					
						ArrayList<String> list = AccessDao.uiFormRights();
						String json = new Gson().toJson(list);
						request.setAttribute("elementContent", "''");
						session.setAttribute("accessrights",access);
						session.setAttribute("uiForm",json);
						RequestDispatcher rd = request
								.getRequestDispatcher("passwordreset.jsp");
						rd.forward(request, response);
					} else {
						if (loginChk == 0) {
							responseMessage = "Sorry username or password error";
							request.setAttribute("loginError",
									"Sorry username or password error");
						} else if (loginChk == 2) {
							responseMessage = "Invalid User Type";
							request.setAttribute("UserError", "Invalid User Type");
						}
						RequestDispatcher rd = request
								.getRequestDispatcher("index.jsp");
						rd.include(request, response);
						Util.setResponseStatus(response, responseMessage, loginForm);
					}
					
				} else {
					status = LoginDao.validate(user, password, role);
					if (status == 1) {
						access=AccessDao.getAccess(role);
						enterpriseId = LoginDao.getEnterprizeId(user);
						session.setAttribute("enterpriseId",enterpriseId);					
						ArrayList<String> list = AccessDao.uiFormRights();
						String json = new Gson().toJson(list);
						request.setAttribute("elementContent", "''");
						session.setAttribute("accessrights",access);
						session.setAttribute("uiForm",json);
						RequestDispatcher rd = request
								.getRequestDispatcher("main.jsp");
						rd.forward(request, response);
						/*
						 * RequestDispatcher rd = request
						 * .getRequestDispatcher("onboard.jsp"); rd.forward(request,
						 * response);
						 */
					} else {

						if (status == 0) {
							responseMessage = "Sorry username or password error";
							request.setAttribute("loginError",
									"Sorry username or password error");
						} else if (status == 2) {
							responseMessage = "Invalid User Type";
							request.setAttribute("UserError", "Invalid User Type");
						}

						RequestDispatcher rd = request
								.getRequestDispatcher("index.jsp");
						rd.include(request, response);
						Util.setResponseStatus(response, responseMessage, loginForm);
					}

				}
				
				
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
//			response.sendRedirect("index.html"); // No logged-in user found, so redirect to login page.
	         response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
	         response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
	         response.setDateHeader("Expires", 0);
			request.getRequestDispatcher("/sessionError.jsp").forward(request,
					response);
		}

	}
}

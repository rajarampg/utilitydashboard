package com.pmo.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.pmo.commons.EventNotification;
import com.pmo.connection.DatabaseConnection;
import com.pmo.dboperation.OnBoardingDetailsCreate;
import com.pmo.login.AccessDao;
import com.pmo.login.OnBoardingFormDetails;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

/**
 * Servlet implementation class OnBoardingSingleEntry
 */
//@WebServlet("/OnBoardingSingleEntry")
public class OnBoardingSingleEntry extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OnBoardingSingleEntry() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		PreparedStatement pst1 = null;
		ResultSet rs1 = null;
		PreparedStatement pst2 = null;
		ResultSet rs2 = null;
		PreparedStatement pst3 = null;
		ResultSet rs3 = null;
		
		con = DatabaseConnection.getRAWConnection();
		 Map<String, Object> outMap = new HashMap<String, Object>();
		 ArrayList<String> managerlist = new ArrayList<String>();
		 ArrayList<String> rolelist = new ArrayList<String>();
		 Map<String, Object> skilllist = new HashMap<String, Object>();
		 ArrayList<String> contractlist = new ArrayList<String>();
		 
		try {
			pst = con.prepareStatement("select distinct resourcemanager from approvaldetails");
			rs = pst.executeQuery();
			while (rs.next()) {
			managerlist.add(rs.getString("resourcemanager"));
			}
			System.out.println(managerlist);
			outMap.put("manager", managerlist);
			
			pst1 = con.prepareStatement("select distinct role from roledetails where role !=''");
			rs1 = pst1.executeQuery();
			while (rs1.next()) {
			rolelist.add(rs1.getString("role"));
			}
			System.out.println(rolelist);
			outMap.put("role", rolelist);
			
			pst2 = con.prepareStatement("select distinct skillname,patternafter from skillcontent where skillname!='' and patternafter!='';");
			rs2 = pst2.executeQuery();
			while (rs2.next()) {
				skilllist.put(rs2.getString("skillname"),rs2.getString("patternafter"));
			}
			outMap.put("skillpair", skilllist);
			
			pst3 = con.prepareStatement("select distinct contractid from contract;");
			rs3 = pst3.executeQuery();
			while (rs3.next()) {
				contractlist.add(rs3.getString("contractid"));
			}
			outMap.put("contract", contractlist);
			
		} catch (SQLException e) {
			System.out.println("SQl Exception occured while fetching the access rights"+ e.getMessage());
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);DatabaseConnection.closePst(pst);
			DatabaseConnection.closeRs(rs1);DatabaseConnection.closePst(pst1);
			DatabaseConnection.closeRs(rs2);DatabaseConnection.closePst(pst2);
			DatabaseConnection.closeRs(rs3);DatabaseConnection.closePst(pst3);
			DatabaseConnection.closeCon(con);
		}
		response.setContentType("application/json");
		System.out.println(new Gson().toJson(outMap));
		response.getWriter().write(new Gson().toJson(outMap));
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Gson obFormClient = new Gson();
		OnBoardingFormDetails obForm = obFormClient.fromJson(request.getReader(), OnBoardingFormDetails.class);
		System.out.println("Form Details: " + obForm.toString());
		String userName = (String) request.getSession().getAttribute("name");
		OnBoardingDetailsCreate obDetails = new OnBoardingDetailsCreate();
		boolean isEmpPresent=obDetails.fetchEmployeeDetails(obForm);
		if(isEmpPresent){
			obDetails.fetchRateDetails(obForm);
			obDetails.fetchManagementDetails(obForm);
			obDetails.fetchPatternAfterValues(obForm);
			obDetails.fetchJustificationDetails(obForm);
			System.out.println("Form Details: " + obForm.toString());
//			int obfResponse = OnBoardingDetailsCreate.onBoardingMemberDetailsInsert(obForm,userName);
			int obfResponse = OnBoardingDetailsCreate.onBoardingMemberDetailsUpdate(obForm,userName);
			
			//int obfResponse=1;
			
			//setting up email details by template matching 
			Configuration cfg = new Configuration();
			cfg.setServletContextForTemplateLoading(this.getServletContext(), "WEB-INF");
	        Template template = cfg.getTemplate("emailtemplate.ftl");
	        
	        Writer out = new StringWriter();
	        try {
	        	Map<String, Object> rootMap = new HashMap<String, Object>();
	            rootMap.put("obj",obForm);
	        	template.process(rootMap,out);
	        	
				} 
	        catch (TemplateException e)
	        	{
				// TODO Auto-generated catch block
				e.printStackTrace();
	        	}
	                		
			if(obfResponse != 0)
			{	
				
				System.out.println("Successfully inserted into DB");
				System.out.println("Inside try OUT : "+out);
				List<String> toMailId = new ArrayList<String>() ;
				
				List<String> ccMailId = new ArrayList<String>() ;
				
				try {
					//PMO to TO MAIL ID
//					toMailId= AccessDao.getPmoUserID();
					toMailId.add("walmart.idc.pmo");
					
					//Supervisor and user to CC MAIL ID
					ccMailId.add(AccessDao.getSupervisorID(userName));
					ccMailId.add(userName);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				
				System.out.println("TO MAILID: "+toMailId);
				System.out.println("CC MAILID: "+ccMailId);
				
				try {
				// if DB insertion success send email notification	
				EventNotification.sendSimpleEmailNotification(toMailId, ccMailId ," Onboard Request ", out.toString());
				response.sendRedirect("SingleUserViewNew.jsp");
				} catch (AddressException e) {
				e.printStackTrace();
				response.sendError(obfResponse);
				} catch (MessagingException e) {
				e.printStackTrace();
				response.sendError(obfResponse);
				}
					
			}
			else
			{
				response.sendError(obfResponse);
			}
		} else {
			response.getWriter().write("empnotfound");
			
		}
		
		
	}

}

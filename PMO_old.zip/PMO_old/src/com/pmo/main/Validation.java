package com.pmo.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Validation {

	public boolean validateDate(String rollonDate, String rolloffDate) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		
		if (!(rollonDate.equalsIgnoreCase(""))) {
		   Date startDate=sdf.parse(rollonDate);
		     if (!(rolloffDate.equalsIgnoreCase("")))
		     {
		    	 Date endDate=sdf.parse(rolloffDate);
		    	 if (!endDate.after(startDate)) {
		    		 return true;
		    	 	}
		     }
		
			}
		return false;
		}
}

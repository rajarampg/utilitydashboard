package com.pmo.main;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pmo.commons.EventNotification;
import com.pmo.commons.Util;
import com.pmo.connection.PmoProperties;
import com.pmo.dboperation.InsertOnboardingDetails;
import com.pmo.dboperation.RollOffCheckListDAO;
import com.pmo.login.AccessDao;
import com.pmo.login.TableDetail;

/**
 * Servlet implementation class DEVServlet
 */
public class OffShoreServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		res.setContentType("text/html");		
		TableDetail td=null;
		Integer employeeId=Integer.parseInt(req.getParameter("empid"));
		String resName= req.getParameter("rname");
		String isExit = req.getParameter("rolloffExitDate");
		String rollOffDate = req.getParameter("rolloffDate");
		String rollOffReason = req.getParameter("rolloffreason");
		String empEnterpriseId = req.getParameter("enterpriseId");
		String userName = (String) req.getSession().getAttribute("name");
		HttpSession session = req.getSession(true);

		td= new TableDetail();
		if(isExit != null && isExit.equals("roffExitDate")){
			td.setExit(true);
		}else{
			td.setExit(false);
		}
		td.setEmpId(employeeId);
		td.setRolloffDate(rollOffDate);
		td.setRolloffReason(rollOffReason);
		td.setRname(resName);
		String rOffStat = RollOffCheckListDAO.getRollOffCheckListStatus(employeeId);
		if(rOffStat.equalsIgnoreCase("Inactive")){
			td.setEmployeeStatus(Util.ROLLEDOFF);
			td.setTaskCompletedBy(userName);
			InsertOnboardingDetails insertDetails = new InsertOnboardingDetails();
			if(insertDetails.updateRollOff(td))
			{
				Util.setResponseStatus(res, "Employee "+employeeId+" rolled off successfully", "offboard.jsp");
				String isEmailNotRequired = PmoProperties.getProperty("ISEMAILREQ");
				if(isEmailNotRequired.equalsIgnoreCase("TRUE"))
				{					
					String user = (String)session.getAttribute("enterpriseId");
					String rollOffMailSubject= "Roll-Off completion update";
					String rollOffMailContent= "Roll-off for the resource: " + resName +  "is completed by PMO userid:" + user;
					
					List<String> toMailId = new ArrayList<String>() ;
					List<String> ccMailId = new ArrayList<String>() ;
					try {
						String superID= AccessDao.getSupervisorID(empEnterpriseId);
						toMailId.add(superID);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					ccMailId.add("walmart.idc.pmo");
					
					try {
						EventNotification.sendSimpleEmailNotification(toMailId, ccMailId ,rollOffMailSubject, rollOffMailContent);
					} catch (AddressException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (MessagingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
			}
				
			}
			else
			{
				Util.setResponseStatus(res, "Oops! An error has occured while processing the request", "offboard.jsp");
			}
		} else {
			td.setEmployeeStatus(Util.OFFBOARDED);
			Util.setResponseStatus(res, "Oops! Complete the roll off checklist process for the resource!", "newrolloffchecklist.jsp");
		}
		
	}	


	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String page = request.getParameter("page");
		if(page!=null && page.equals("loadRollOff")){
			String resourceName = request.getParameter("resourceName");
			RequestDispatcher rd = null;
			request.setAttribute("resName", resourceName);
			rd= request.getRequestDispatcher("offboard.jsp");
			rd.forward(request, response);
		}
	}



} 

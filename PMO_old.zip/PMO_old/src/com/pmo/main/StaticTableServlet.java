package com.pmo.main;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.pmo.commons.Util;
import com.pmo.connection.DatabaseConnection;
import com.pmo.login.OnBoardingFormDetails;
import com.pmo.login.TableDetail;

public class StaticTableServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	Statement st;
	DatabaseConnection dbConn = new DatabaseConnection();
	Connection con;
	ResultSet rs = null;
	PreparedStatement pst;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		String action = request.getParameter("action");
		String page = request.getParameter("page");
		PreparedStatement pst = null;
		RequestDispatcher rd = null;
		HttpSession session = request.getSession();
		if (action.equals("empName")) {
			String filter = request.getParameter("filter");
			String query = Util.getResourceListQuery(filter, (String)session.getAttribute("name"));
			List<String> empNameList = new ArrayList<String>();
			try {
				con = dbConn.mySqlConnection();
				st = con.createStatement();
				rs = st.executeQuery(query);
				while (rs.next()) {
					String empName = rs.getString("resourcename")+"@@"+rs.getString("specificstream");
					empNameList.add(empName);
				}
				String json = null;
				json = new Gson().toJson(empNameList);
				response.setContentType("application/json");
				response.getWriter().write(json);

			} catch (SQLException e) {
				e.printStackTrace();
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			finally{
				DatabaseConnection.closeRs(rs);
				DatabaseConnection.closeStmt(st);
				DatabaseConnection.closeCon(con);
			}
			
		} 
		
		else if(action !=null && action.equals("supervisorName")){
			
			List<String> supNameList = new ArrayList<String>();
			
			try {
				con = dbConn.mySqlConnection();
				st = con.createStatement();
				rs = st.executeQuery("select enterpriseid,specificstream from employeedetails where careerlevel in('9-Team Lead','8-Associate Manager','7-Manager','6-Senior Manager','5-Senior Manager','Accenture Leadership')");
				while (rs.next()) {
					String supName = rs.getString("enterpriseid")+"@@"+rs.getString("specificstream");
					supNameList.add(supName);
				}
				String json = null;
				json = new Gson().toJson(supNameList);
				response.setContentType("application/json");
				response.getWriter().write(json);

			} catch (SQLException e) {
				e.printStackTrace();
			}catch (Exception e) {
				e.printStackTrace();
			}finally{
				DatabaseConnection.closeRs(rs);
				DatabaseConnection.closeStmt(st);
				DatabaseConnection.closeCon(con);
			}
			
		} else if(action !=null && action.equals("rollOffChk")){
			
			List<String> rOffChkList = new ArrayList<String>();
			
			try {
				con = dbConn.mySqlConnection();
				st = con.createStatement();
				rs = st.executeQuery("select resourcename from employeedetails where employee_status = 4");
				while (rs.next()) {
					String resName = rs.getString("resourcename");
					rOffChkList.add(resName);
				}
				String json = null;
				json = new Gson().toJson(rOffChkList);
				response.setContentType("application/json");
				response.getWriter().write(json);

			} catch (SQLException e) {
				e.printStackTrace();
			}catch (Exception e) {
				e.printStackTrace();
			}finally{
				DatabaseConnection.closeRs(rs);
				DatabaseConnection.closeStmt(st);
				DatabaseConnection.closeCon(con);
			}
			
		} else if (action.equals("singleview") && action !=null) {
			String entID = request.getParameter("id");
			TableDetail td=new TableDetail();
			List<TableDetail> list = new ArrayList<TableDetail>(); 
			
			try {
				String findempId = "select director,vp from approvaldetails  where resourcemanager=?";
				con = dbConn.mySqlConnection();
				pst = con.prepareStatement(findempId);
				pst.setString(1, entID);
				
				rs = pst.executeQuery();

				while (rs.next()) {
					td.setDirectorId(rs.getString("director"));
					td.setVpUserId(rs.getString("vp"));
					
					list.add(td);
				}
				String json = null;
				json = new Gson().toJson(list);
				response.setContentType("application/json");
				response.getWriter().write(json);
			} catch (SQLException e) {
				e.printStackTrace();
			}catch (Exception e) {
				e.printStackTrace();
			}
			finally
			{
				dbConn.closeConnection(con, pst, rs);
			}
						
		} else if (action.equals("singleviewresmgr") && action !=null) {
			String portfolio = request.getParameter("id");
			Connection con = null;
			PreparedStatement pst1 = null;
			ResultSet rs = null;
			PreparedStatement pst3 = null;
			ResultSet rs3 = null;
			
			con = DatabaseConnection.getRAWConnection();
			 Map<String, Object> outMap = new HashMap<String, Object>();
			 ArrayList<String> managerlist = new ArrayList<String>();
			  ArrayList<String> contractlist = new ArrayList<String>();
			 
			try {
				pst1 = con.prepareStatement("select resourcemanager from onboardpreload  where portfolio=?");
				pst1.setString(1, portfolio);
				rs = pst1.executeQuery();
				while (rs.next()) {
				managerlist.add(rs.getString("resourcemanager"));
				}
				System.out.println(managerlist);
				outMap.put("manager", managerlist);
				
				
				pst3 = con.prepareStatement("select distinct contractid from onboardpreload where portfolio=? and contractid is not null");
				pst3.setString(1, portfolio);
				rs3 = pst3.executeQuery();
				while (rs3.next()) {
					contractlist.add(rs3.getString("contractid"));
				}
				outMap.put("contract", contractlist);
				
			} catch (SQLException e) {
				System.out.println("SQl Exception occured while fetching the access rights"+ e.getMessage());
				e.printStackTrace();
			} finally {
				DatabaseConnection.closeRs(rs);DatabaseConnection.closePst(pst1);
				DatabaseConnection.closeRs(rs3);DatabaseConnection.closePst(pst3);
				DatabaseConnection.closeCon(con);
			}
			response.setContentType("application/json");
			System.out.println(new Gson().toJson(outMap));
			response.getWriter().write(new Gson().toJson(outMap));
		} 
		
		else if (action.equals("offshoredetails")) {
			List<TableDetail> list = new ArrayList<TableDetail>();

			try {
				con = dbConn.mySqlConnection();
				st = con.createStatement();
				rs = st.executeQuery("select * from employeedetails where employee_status = 5");
				while (rs.next()) {
					TableDetail td = new TableDetail();
					td.setEmpId(rs.getInt("EmployeeNumber"));
					td.setRname(rs.getString("ResourceName"));
					td.setEnterpriseId(rs.getString("EnterpriseId"));
					td.setGender(rs.getString("gender"));
					td.setRollonDate(rs.getString("RollOnDate"));
					td.setRolloffDate(rs.getString("RollOffDate"));
					td.setExit(rs.getBoolean("isexit"));
					td.setRolloffReason(rs.getString("rolloffreason"));
					td.setStream(rs.getString("SpecificStream"));
					td.setCapability(rs.getString("Capability"));
					td.setClevel(rs.getString("CareerLevel"));
					td.setLockType(rs.getString("locktype"));
					td.setPhoneNo(rs.getLong("phone_no"));
					td.setSiteLocation(rs.getString("delivery_centre"));
					td.setCurrLocation(rs.getString("currentlocation"));
					td.setVisaType(rs.getString("visa_type"));
					td.setDuration(rs.getString("duration_stay"));
					td.setWmtid(rs.getString("wmt_userid"));
					td.setRequestdate(rs.getString("wmt_accessdate"));
					td.setGrantdate(rs.getString("wmt_grantdate"));
					td.setBayNumber(rs.getInt("bayno"));
					td.setFloor(rs.getString("floor"));
					td.setWorkstationNumber(rs.getString("workstation"));
					td.setPrimarySkill(rs.getString("primary_skill"));
					td.setSecondarySkill(rs.getString("secondary_skill"));
					td.setProficiency(rs.getString("proficiency_level"));
					list.add(td);

				}
				String countQA="select (substring(rolloffdate,0,3)||'/'||substring(rolloffdate,7,4)), count(rollondate)  from offboarddetails where rolloffdate != 'Exit' group by (substring(rolloffdate,0,3)||'/'||substring(rolloffdate,7,4))" ;
				pst=con.prepareStatement(countQA);
				rs=pst.executeQuery();
				ArrayList<Integer> reportData = new ArrayList<Integer>();
				for(int i=1;i<=12;i++){
					reportData.add(0);
				}
				while(rs.next())
				{
					int key = Integer.parseInt(rs.getString(1).substring(0,2));
					int countQADept=rs.getInt(2);				
					reportData.set(key-1, countQADept);
				}	
				
				String reportFormat = getMappableFormat(reportData);
				request.setAttribute("reportData", reportFormat);
				
				if (page != null && page.equalsIgnoreCase("export")) {
					request.setAttribute("list", list);
					rd = request.getRequestDispatcher("excelOffboard.jsp");
				} else {
					request.setAttribute("list", list);
					rd = request.getRequestDispatcher("offboardReport.jsp");
				}
				rd.forward(request, response);
			} catch (SQLException e) {
				e.printStackTrace();
			}catch (Exception e) {
				e.printStackTrace();
			}
			finally
			{
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closeStmt(st);
			DatabaseConnection.closeCon(con);
			}
		} else {
			String empName = request.getParameter("employee_Name");
			//String stream=request.getParameter("specificstream");
		//	List<String> List = new ArrayList<String>();
			TableDetail td=new TableDetail();
			List<TableDetail> list = new ArrayList<TableDetail>(); 
			
			try {
				String findempId = "select employeenumber,specificstream  from EmployeeDetails  where resourcename=?";
				con = dbConn.mySqlConnection();
				pst = con.prepareStatement(findempId);
				pst.setString(1, empName);
				
				rs = pst.executeQuery();

				while (rs.next()) {
					td.setEmpId(rs.getInt("employeenumber"));
					td.setStream(rs.getString("specificstream"));
					list.add(td);
				}
				String json = null;
				json = new Gson().toJson(list);
				response.setContentType("application/json");
				response.getWriter().write(json);
			} catch (SQLException e) {
				e.printStackTrace();
			}catch (Exception e) {
				e.printStackTrace();
			}
			finally
			{
				dbConn.closeConnection(con, pst, rs);
			}

		}
	}

	String getMappableFormat(ArrayList<Integer> list){
		String months[] ={"January", "February","March", "April","May", "June","July", "August","September", "October","November","December"}; 
		String report = "[";
		for(int i=0;i<12;i++){
			if(i!=0)
				report+=",";
			report+=("['"+months[i]+"',"+list.get(i)+"]");
		}
		report+="]";
		return report;
	}
	
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		String page = req.getParameter("page");
		int check = 0;

		if (page.equals("validEmpId")) {
			String empId = (String) req.getParameter("employee_Id");
			if (!empId.equals("")) {

				String countEmpId = "select count(*) from employeedetails  where employeenumber=?";

				try {
					con = dbConn.mySqlConnection();
					pst = con.prepareStatement(countEmpId);
					pst.setInt(1, Integer.parseInt(empId));
					rs = pst.executeQuery();
					while (rs.next()) {
						check = rs.getInt(1);
					}

				} catch (SQLException e) {
					e.printStackTrace();
				}catch (Exception e) {
					e.printStackTrace();
				}
				finally
				{
					dbConn.closeConnection(con, pst, rs);
				}
			}
			} 
		
		else {
				String employeeName = (String) req
						.getParameter("employee_Name");
				String countEmp = "select count(*) from employeedetails  where resourcename=?";
				if (!employeeName.equals(""))
				{
					try {
						con = dbConn.mySqlConnection();
						pst = con.prepareStatement(countEmp);
						pst.setString(1, employeeName);
						rs = pst.executeQuery();
						while (rs.next()) {
							check = rs.getInt(1);
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}catch (Exception e) {
						e.printStackTrace();
					}
					finally
					{
						dbConn.closeConnection(con, pst, rs);
					}
			}

		}
		if ((check > 0)) {
			String json = null;
			json = new Gson().toJson("failure");
			res.setContentType("application/json");
			res.getWriter().write(json);
		}
	}

}

package com.pmo.main;

import java.awt.List;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.map.ObjectMapper;

import com.pmo.dboperation.InsertCertificationAndRewardDetails;
import com.pmo.login.TableDetail;

/**
 * Servlet implementation class RewardsServlet
 */

public class RewardsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RewardsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		InsertCertificationAndRewardDetails ic=new InsertCertificationAndRewardDetails();
		ArrayList<TableDetail> list=new ArrayList<TableDetail>();
		TableDetail td= null;
		String awardReceiver=request.getParameter("awardReceiver");
		if(awardReceiver!=null && awardReceiver.equals("Team")){
		HashMap<String,Object> result = null;
		String page=request.getParameter("page");
		if (page!=null && page.equals("updateTeam")) {
			String json=request.getParameter("json");	
			 result = new ObjectMapper().readValue(json, HashMap.class);
			 
			 for( @SuppressWarnings("unused") Entry<String, Object> entry :result.entrySet()){
				 td =new TableDetail() ;
				 td.setEmpId(Integer.parseInt(entry.getKey()));
				 td.setRname((String)entry.getValue());
				 setProperties(request, td);
				 list.add(td);
			 }
		}
		}else{
			td =new TableDetail();
			String employeeName=request.getParameter("employeename");
			String employeeId=request.getParameter("employeeId");	
			td.setEmpId(Integer.parseInt(employeeId));
			 td.setRname(employeeName);
			 setProperties(request, td);
			 list.add(td);
		}
		

		int recordsInserted = 0;
		if((recordsInserted=ic.insertRewards(list))>0){
			pw.println("<script type=\"text/javascript\">");
			pw.println("alert('Details Got Saved Successfully');");
			//pw.println("alert('"+recordsInserted+" Award(s) added');");
			pw.println("location='rewards.jsp';");
			pw.println("</script>");
			System.out.println("inserted successfully");
		}else{
			pw.println("Error saving award details!!");	
		}
		
	}
	
	private void setProperties(HttpServletRequest request, TableDetail td){
		String awardType=request.getParameter("monthly");
		if(awardType.equals("Monthly")){
			String award= request.getParameter("monthlyaward");
			String awardPeriod = request.getParameter("monthlyperiod");
			td.setAward(award);
			td.setAward_period(awardPeriod);		
		}
		else{
			String award=request.getParameter("quarterlyaward");
			String awardPeriod= request.getParameter("quarterlyperiod");
			td.setAward(award);
			td.setAward_period(awardPeriod);
			}
		String  reason=request.getParameter("reason");
		String awardReceiver=request.getParameter("awardReceiver");
		String specificStream=request.getParameter("stream");
		td.setStream(specificStream);
		td.setAwardType(awardType);
		td.setReason(reason);
		td.setAward_receiver(awardReceiver);
	}
	

}

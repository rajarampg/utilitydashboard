package com.pmo.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.pmo.commons.EventNotification;
import com.pmo.commons.Util;
import com.pmo.connection.DatabaseConnection;
import com.pmo.connection.PmoProperties;
import com.pmo.dboperation.InsertEventDetails;
import com.pmo.login.AccessDao;
import com.pmo.login.EventDetails;

public class EventsServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	private final String COLUMN_INITIATOR = "initiator";
	private final String COLUMN_EVENT_NAME = "eventname";
	private final String COLUMN_EVENT_DESC = "describeevent";
	private final String COLUMN_EVENT_TIME = "evettime";
	

	@SuppressWarnings("static-access")
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		SessionHelper sessionhelper = new SessionHelper();
		String initiator = request.getParameter("initiativeFrom");
		String eventName = request.getParameter("eventName");
		String eventDesc = request.getParameter("eventDesc");
		String eventStartTime = request.getParameter("eventStartTime");
		String eventorg = request.getParameter("eventorg");
		String eventAud = request.getParameter("eventAud");
		int noHrs = Integer.parseInt(request.getParameter("durationHrs"));
		int noMins = Integer.parseInt(request.getParameter("durationMins"));

		HttpSession session = request.getSession(false);
		InsertEventDetails insert = new InsertEventDetails();
		EventDetails eventDetailsDTO = new EventDetails();
		eventDetailsDTO.setTitle(eventName);
		eventDetailsDTO.setInitiator(initiator);
		eventDetailsDTO.setEventDesc(eventDesc);
		eventDetailsDTO.setStartTime(eventStartTime);
		eventDetailsDTO.setHrs(noHrs);
		eventDetailsDTO.setMins(noMins);
		
		if(insert.insertEvent(eventDetailsDTO)){
			Util.setResponseStatus(response, "Event Scheduled Successfully!");
			String isEmailNotRequired = PmoProperties.getProperty("ISEMAILREQ");
			if(isEmailNotRequired.equalsIgnoreCase("TRUE"))
			{					
				String user = (String)session.getAttribute("enterpriseId");
				String eventMailSubject= "Offboard Request";
				String eventMailContent= "offboard request has been raised by userid."+user;
				
				List<String> toMailId = new ArrayList<String>() ;
				List<String> ccMailId = new ArrayList<String>() ;
				try {
					toMailId= AccessDao.getPmoUserID();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				for (String aud: eventAud.split(";"))
				{
					ccMailId.add(aud);
				}
				
				
				try {
					EventNotification.sendSimpleEmailNotification(toMailId, ccMailId,eventMailSubject, eventMailContent);
				} catch (AddressException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (MessagingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
		}else{
			Util.setResponseStatus(response, "Oops! Something went wrong");
		}

	}
	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)     
			throws ServletException, IOException {
		
		String action=(String)request.getParameter("action");
		
		if(action!=null && action.equals("fetchAllEvents")){
		List<EventDetails> eventsList = new InsertEventDetails().getAllEvents();
		response.setContentType("application/json");
		response.getWriter().write("[");
		if(eventsList!=null && eventsList.size()>0){
			response.getWriter().write(eventsList.get(0).toString());
			for(int i=1;i<eventsList.size();i++){
				response.getWriter().write(","+eventsList.get(i).toString());
			}
		}
		response.getWriter().write("]");
		}
		
		else if(action!=null && action.equalsIgnoreCase("populateEventDetails")){
    		String eventId=(String)request.getParameter("eventId");
    		RequestDispatcher rd=null;
    		
    		EventDetails eventsDetails = new InsertEventDetails().getEventDetails(eventId);
    		request.setAttribute("id", eventsDetails.getId());
    		request.setAttribute("eventTitle", eventsDetails.getTitle());
    		request.setAttribute("eventDescription", eventsDetails.getEventDesc());
    		request.setAttribute("startTime", eventsDetails.getStartTime());
    		long timeDifference = eventsDetails.getStart()-System.currentTimeMillis();
    		if(timeDifference >=0){
    			if(timeDifference > 86400000)
    				eventsDetails.setEventColorCode("Blue");
    			else
    				eventsDetails.setEventColorCode("Green");
    		}else
    			eventsDetails.setEventColorCode("Red");
    		request.setAttribute("colorCode", eventsDetails.getEventColorCode());
    		request.setAttribute("duration", eventsDetails.getDuration());
    		request.setAttribute("initiator", eventsDetails.getInitiator());
        	rd= request.getRequestDispatcher("eventDescription.jsp");
        	rd.forward(request, response);	
    	}
		
	}
	
	
	
	
}

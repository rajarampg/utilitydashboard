package com.pmo.main;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.pmo.commons.EventNotification;
import com.pmo.connection.DatabaseConnection;
import com.pmo.dboperation.OnBoardingDetailsCreate;
import com.pmo.login.AccessDao;
import com.pmo.login.OnBoardingFormDetails;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

/**
 * Servlet implementation class OnBoardingMultipleEntry
 */
//@WebServlet("/OnBoardingSingle")
public class OnBoardingMultipleEntry extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OnBoardingMultipleEntry() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		PreparedStatement pst1 = null;
		ResultSet rs1 = null;
		PreparedStatement pst2 = null;
		ResultSet rs2 = null;
		PreparedStatement pst3 = null;
		ResultSet rs3 = null;
		
		con = DatabaseConnection.getRAWConnection();
		 Map<String, Object> outMap = new HashMap<String, Object>();
		 ArrayList<String> managerlist = new ArrayList<String>();
		 ArrayList<String> rolelist = new ArrayList<String>();
		 Map<String, Object> skilllist = new HashMap<String, Object>();
		 ArrayList<String> contractlist = new ArrayList<String>();
		 
		try {
			pst = con.prepareStatement("select distinct resourcemanager from approvaldetails");
			rs = pst.executeQuery();
			while (rs.next()) {
			managerlist.add(rs.getString("resourcemanager"));
			}
			System.out.println(managerlist);
			outMap.put("manager", managerlist);
			
			pst1 = con.prepareStatement("select distinct role from roledetails where role !=''");
			rs1 = pst1.executeQuery();
			while (rs1.next()) {
			rolelist.add(rs1.getString("role"));
			}
			System.out.println(rolelist);
			outMap.put("role", rolelist);
			
			pst2 = con.prepareStatement("select distinct skillname,patternafter from skillcontent where skillname!='' and patternafter!='';");
			rs2 = pst2.executeQuery();
			while (rs2.next()) {
				skilllist.put(rs2.getString("skillname"),rs2.getString("patternafter"));
			}
			outMap.put("skillpair", skilllist);
			pst3 = con.prepareStatement("select distinct contractid from contract;");
			rs3 = pst3.executeQuery();
			while (rs3.next()) {
				contractlist.add(rs3.getString("contractid"));
			}
			outMap.put("contract", contractlist);
			
		} catch (SQLException e) {
			System.out.println("SQl Exception occured while fetching the access rights"+ e.getMessage());
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);DatabaseConnection.closePst(pst);
			DatabaseConnection.closeRs(rs1);DatabaseConnection.closePst(pst1);
			DatabaseConnection.closeRs(rs2);DatabaseConnection.closePst(pst2);
			DatabaseConnection.closeRs(rs3);DatabaseConnection.closePst(pst3);
			DatabaseConnection.closeCon(con);
		}
		response.setContentType("application/json");
		System.out.println(new Gson().toJson(outMap));
		response.getWriter().write(new Gson().toJson(outMap));
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Gson obFormClient = new Gson();
		OnBoardingFormDetails[] obForm = obFormClient.fromJson(request.getReader(), OnBoardingFormDetails[].class);
		String userName = (String) request.getSession().getAttribute("name");
		OnBoardingDetailsCreate obDetails = new OnBoardingDetailsCreate();
		for(OnBoardingFormDetails obf:obForm){
			obDetails.fetchRateDetails(obf);
			obDetails.fetchManagementDetails(obf);
			obDetails.fetchPatternAfterValues(obf);
			obDetails.fetchJustificationDetails(obf);
		}
		int obfResponse = obDetails.onBoardingMultipleMembersDetailsInsert(obForm,userName);
		
		//setting up email details by template matching 
		Configuration cfg = new Configuration();
		cfg.setServletContextForTemplateLoading(this.getServletContext(), "WEB-INF");
		Template template = cfg.getTemplate("emailtemplate.ftl");
		

		if(obfResponse != 0)
		{	
	    	System.out.println("Successfully inserted into DB");
	    	List<String> toMailId = new ArrayList<String>() ;
	    	List<String> ccMailId = new ArrayList<String>() ;
			try {
//			toMailId= AccessDao.getPmoUserID();
			toMailId.add("walmart.idc.pmo");

			ccMailId.add(AccessDao.getSupervisorID(userName));
			ccMailId.add(userName);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}	
			
			
			System.out.println("To mail ID : "+toMailId);	
			System.out.println("CC mail ID : "+ccMailId);	
			
		for(int i=0;i<obForm.length;i++)
		{  
						
		
		 Writer out = new StringWriter();
		 try {
		 Map<String, Object> rootMap = new HashMap<String, Object>();
		 rootMap.put("obj",obForm[i]);
		 template.process(rootMap,out);
		  System.out.println("Inside try OUT : "+out);
		 } 
		 catch (TemplateException e)
		 {
		 e.printStackTrace();
		 }
			
		try {
		EventNotification.sendSimpleEmailNotification(toMailId, ccMailId ," Onboard Request ", out.toString());
		
		} catch (AddressException e) {
		e.printStackTrace();
		response.sendError(obfResponse);
		} catch (MessagingException e) {
		e.printStackTrace();	
		response.sendError(obfResponse);
		}
		}
		response.sendRedirect("MultiUserView.jsp");
		   
		}
		else
		{
			response.sendError(obfResponse);
		}
		
		
	}

}

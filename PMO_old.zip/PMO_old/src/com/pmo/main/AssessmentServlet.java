package com.pmo.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.map.ObjectMapper;
import org.postgresql.util.PGobject;

import com.google.gson.Gson;
import com.pmo.commons.Util;
import com.pmo.connection.DatabaseConnection;
import com.pmo.dboperation.InsertAssessmentDetails;
import com.pmo.login.Assessment;
import com.pmo.login.TableDetail;

/**
 * Servlet implementation class AssessmentServlet
 */

public class AssessmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AssessmentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		ObjectMapper objectMapper=null;
		String action = (String) request.getParameter("action");
		if (action != null && action.equals("fetchassess")) {
			int empId = Integer.parseInt((String) request.getParameter("empid"));
			String technology = (String) request.getParameter("technology");
			String difflevel = (String) request.getParameter("difflevel");
			String stream = (String) request.getParameter("stream");
			Assessment assesment = new Assessment();
			assesment.setEmpId(empId);
			assesment.setStream(stream);
			assesment.setTechnology(technology);
			assesment.setDifficultyLevel(difflevel);
			if (new InsertAssessmentDetails().getAssessment(assesment)) {
				String json = new Gson().toJson(assesment);
				response.setContentType("application/json");
				response.getWriter().write(json);
			} else {
				response.setContentType("application/json");
				response.getWriter().write("{'error':'error'");
			}
		}
		else if(action !=null && action.equals("writeassessment")){
			
			String json = request.getParameter("json");
			objectMapper = new ObjectMapper();
			Assessment assessment = objectMapper.readValue(json, Assessment.class);
			assessment.setAssessmentStatus(3);
			assessment.setMarks(0);
			if (new InsertAssessmentDetails().updateAssessment(assessment)) {
				response.setContentType("application/json");
				response.getWriter().write("{\"status\":\"success\"}");
			} else {
				response.getWriter().write("{\"status\":\"failed\"}");
			}	
		}
		
		else if (action != null && action.equals("postquest")) {
			String technology = (String) request.getParameter("technology");
			String difflevel = (String) request.getParameter("difflevel");
			String postQuestion = (String) request.getParameter("postques");
			String insertQuestions = new InsertAssessmentDetails().postquestion(postQuestion, technology, difflevel);
		} 
		
		else if (action != null && action.equals("smeAssessmentList")) {
			ArrayList<String> resourceList = new InsertAssessmentDetails().getAssessmentList();
			String json = null;
			json = new Gson().toJson(resourceList);
			response.setContentType("application/json");
			response.getWriter().write(json);
		} 
		else if (action != null && action.equals("smeAssessmentDetails")) {
			String candidateDetail = (String) request.getParameter("candidateDetail");
			Assessment assessment = new Assessment();
			assessment.setEmpId(Integer.parseInt(candidateDetail.split(" - ")[0]));
			assessment.setExamId(Integer.parseInt(candidateDetail.split(" - ")[1]));
			new InsertAssessmentDetails().getAssessmentDetails(assessment);
			String json = new Gson().toJson(assessment);
			response.setContentType("application/json");
			response.getWriter().write(json);
		}
		else if(action !=null && action.equals("smeAssessed")){
			String json = request.getParameter("json");
			objectMapper = new ObjectMapper();
			Assessment assessment = objectMapper.readValue(json, Assessment.class);
			assessment.setAssessmentStatus(4);
			assessment.setMarks(Integer.parseInt(request.getParameter("marks")));
			if (new InsertAssessmentDetails().updateAssessment(assessment)) {
				response.setContentType("application/json");
				response.getWriter().write("{\"status\":\"success\"}");
			} else {
				response.getWriter().write("{\"status\":\"failed\"}");
			}	
			/*
			new InsertAssessmentDetails().updateAssessment(assessment);
			String json =new Gson().toJson(assessment);
			response.setContentType("application/json");
			response.getWriter().write("{\"status\":\"success\"}");
			response.getWriter().write(json);*/
		}	
	}

}

package com.pmo.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.TypeFactory;
import com.google.gson.Gson;
import com.pmo.commons.Util;
import com.pmo.connection.DatabaseConnection;
import com.pmo.dboperation.InsertCommunicationDetails;
import com.pmo.dboperation.PMODAO;
import com.pmo.login.HardwareMaintenance;
  
public class HardwareDetailServlet extends HttpServlet{   
  
    private static final long serialVersionUID = 1L;   
//    private final String selectQuery = "select mobiledetails.employeenumber, mobiledetails.employeename, mobiledetails.stream, mobiledetails.billcycle,mobiledetails.servicepro, mobiledetails.mobileno, mobiledetails.mobiletimestamp , communication.cost FROM mobiledetails left outer join communication on mobiledetails.employeenumber=communication.employeenumbr and communication.month=? ";
    
    
    
    


    public void doGet(HttpServletRequest request, HttpServletResponse response)     
            throws ServletException, IOException {     
    	Statement st;
    	PreparedStatement pstmt = null;
        Connection con = null;
		String operation=request.getParameter("page");
		String rsahidden=request.getParameter("rsahidden");
		String laphidden=request.getParameter("laphidden");
		String mobilehidden=request.getParameter("mobilehidden");
      
		if(operation!=null)
		{
			operation=request.getParameter("page");
		}
		else
		{
			operation="dummy";
		}
		if(rsahidden!=null)
		{
			rsahidden=request.getParameter("rsahidden");
		}
		else
		{
			rsahidden="dummy";
		}
		if(laphidden!=null)
		{
			laphidden=request.getParameter("laphidden");
		}
		else
		{
			laphidden="dummy";
		}
		if(mobilehidden!=null)
		{
			mobilehidden=request.getParameter("mobilehidden");
		}
		else
		{
			mobilehidden="dummy";
		}
		if (operation.equals("rsa") || (rsahidden.equals("rsahidden"))) 
		{
			 List<HardwareMaintenance> rsalist = new ArrayList<HardwareMaintenance>();    
			try {
	        	st=con.createStatement();
	        	ResultSet rs=st.executeQuery("select * from rsadetails order by rsatimestamp desc");
	        	while (rs.next())
	        	{
	        		HardwareMaintenance td=new HardwareMaintenance();
	        		td.setRsaToken(rs.getInt("rsatoken"));
	        		td.setEmployeeNumber(rs.getInt("employeenumber"));
	        		td.setEmployeeName(rs.getString("employeename"));	        		
	        		td.setValidDate(rs.getString("validdate"));        		
	        		td.setTimestamp(rs.getTimestamp("rsatimestamp"));
	        		rsalist.add(td);
	        		
	        	}
	        	request.setAttribute("list",rsalist);	
	        	RequestDispatcher rd= request.getRequestDispatcher("rsa.jsp");
	        	rd.forward(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		
		}

	else if(operation.equals("mob") || (mobilehidden.equals("mobilehidden"))) 
		{
			List<HardwareMaintenance> moblist = new ArrayList<HardwareMaintenance>();
			try {
				st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from mobiledetails order by mobiletimestamp desc");
				while (rs.next())
				{
			   		HardwareMaintenance td=new HardwareMaintenance();
			   		td.setMobileNo(rs.getLong("mobileno"));
			   		td.setEmployeeNumber(rs.getInt("employeenumber"));
			   		td.setEmployeeName(rs.getString("employeename"));	        		
			   		td.setStream(rs.getString("stream")); 
			   		td.setBillCycle(rs.getString("billcycle"));
			   		td.setServiceProvider(rs.getString("servicepro"));
			   		td.setTimestamp(rs.getTimestamp("mobiletimestamp"));
			   		moblist.add(td);
   		
				}
		   	request.setAttribute("list",moblist);	
		   	RequestDispatcher rd= request.getRequestDispatcher("mobile.jsp");
		   	rd.forward(request, response);
			} catch (SQLException e) {		
		e.printStackTrace();
		} 
		
    }
		
	else if(operation.equals("com") ){
		
	   	RequestDispatcher rd= request.getRequestDispatcher("communication.jsp");
	   	rd.forward(request, response);
	}

	else if(operation.equals("maintenance")){
		request.setAttribute("resourceList",Util.getResourcesList("inRoll"));
		RequestDispatcher rd= request.getRequestDispatcher("maintenance.jsp");
		rd.forward(request, response);
	}	else if(operation.equals("hardwareDetails")){
		String resourceName = request.getParameter("resName");
		PMODAO dao = new PMODAO();
		List<HardwareMaintenance> hardwareDetails = dao.getHardwareDetails(" and resourcename = '"+resourceName+"'");
		response.setContentType("application/json");
		String json ="";
		if(hardwareDetails.size()>0)
			json = new Gson().toJson(hardwareDetails.get(0));
		else
			json ="no data available";
		response.getWriter().write(json);
	}
		
	else if(operation.equals("comFetch") ) 
		{
			ResultSet rs = null;
			String filter = "";
			String filterCondition = request.getParameter("stream");
			if(filterCondition!=null && !filterCondition.trim().equals("")){
				if(!filterCondition.equals("All"))
					filter += (" and employeedetails.specificstream = '"+filterCondition+"'");
				
			}
			filterCondition = request.getParameter("project");
			if(filterCondition!=null && !filterCondition.trim().equals("")){
				if(!filterCondition.equals("All"))
					filter += (" and employeedetails.projectname = '"+filterCondition+"'");
				
			}
			List<HardwareMaintenance> moblist = new ArrayList<HardwareMaintenance>();
			try {
				con = DatabaseConnection.getRAWConnection();
				StringBuilder selectQuery = new StringBuilder("");
				selectQuery.append("select commtable.assettype , commtable.employeenumber, commtable.assetnumber, commtable.billcycle, employeedetails.resourcename, employeedetails.specificstream, communication.cost, employeedetails.projectname from (select 1 assettype , employeenumber, mobileno assetnumber, billcycle");
				selectQuery.append(" from mobiledetails union select 2 assettype , employeenumber, datacardnumber assetnumber, billcycle from datacarddetails) as commtable left outer join employeedetails on commtable.employeenumber = employeedetails.employeenumber");
				selectQuery.append(" left outer join communication on communication.employeenumber = commtable.employeenumber and commtable.assettype = communication.assettype and commtable.assetnumber = communication.assetnumber and communication.month = ? where employeedetails.employee_status <= 3");
				selectQuery.append(filter);
				pstmt=con.prepareStatement(selectQuery.toString());
				String month=request.getParameter("month");
				pstmt.setString(1, month);
	            rs=pstmt.executeQuery();

				while (rs.next())
				{
			   		HardwareMaintenance td=new HardwareMaintenance();
			   		td.setStream(rs.getString("specificstream"));
			   		td.setEmployeeNumber(rs.getInt("employeenumber"));
			   		td.setAssetType(rs.getInt("assettype"));
			   		if(td.getAssetType()==1 )
			   			td.setMobileNo(rs.getLong("assetnumber"));
			   		else if(td.getAssetType() == 2)
			   			td.setDataCardNumber(rs.getLong("assetnumber"));
			   		td.setBillCycle(rs.getString("billcycle"));
			   		td.setEmployeeName(rs.getString("resourcename"));
			   		td.setProjectName(rs.getString("projectname"));
			   		String cost = rs.getString("cost");
			   		td.setCost(cost==null? 0 :Double.parseDouble(cost));
			   		moblist.add(td);
				}
				String json = null; 	        		
	    		json = new Gson().toJson(moblist); 
	    		response.setContentType("application/json");  
	    		response.getWriter().write(json);
			} catch (SQLException e) {		
		e.printStackTrace();
		} finally{
			DatabaseConnection.closeConnection(con, pstmt, rs);
		}
		
    }
	else if(operation!=null && operation.trim().equals("projectList")){
		PMODAO dao = new PMODAO();
		List<String> projectList = dao.getProjectList();
		String json = new Gson().toJson(projectList);
		response.setContentType("application/json");  
		response.getWriter().write(json);
	}
		else if(operation.equals("lap") || (laphidden.equals("laphidden"))) 
		{
		
			List<HardwareMaintenance> laplist = new ArrayList<HardwareMaintenance>();    
			try {
					st=con.createStatement();
					ResultSet rs=st.executeQuery("select * from laptopdetails order by laptoptimestamp desc");
					while (rs.next())
					{
						HardwareMaintenance td=new HardwareMaintenance();
						td.setLaptopNo(rs.getString("laptopno"));
						td.setEmployeeNumber(rs.getInt("employeenumber"));
						td.setEmployeeName(rs.getString("employeename"));	        		
						td.setAssetTag(rs.getString("assettag"));    
						td.setMake(rs.getString("make"));  
						td.setTimestamp(rs.getTimestamp("laptoptimestamp"));
						laplist.add(td);
						
					}
					request.setAttribute("list",laplist);	
					RequestDispatcher rd= request.getRequestDispatcher("lap.jsp");
					rd.forward(request, response);
				} catch (SQLException e) {				
					e.printStackTrace();
				} 
		}
		
		else if(operation.equals("cost"))
		{
			List<HardwareMaintenance> cost = new ArrayList<HardwareMaintenance>();  
			try{
				st=con.createStatement();
				ResultSet rs=st.executeQuery(" select communication.employeenumbr,communication.application ,communication.month ,communication.cost,mobiledetails.employeename from communication left outer join mobiledetails on communication.employeenumbr=mobiledetails.employeenumber");
				while(rs.next())
				{
					HardwareMaintenance td=new HardwareMaintenance();
					td.setEmployeeNumber(rs.getInt("employeenumbr"));
					td.setApplication(rs.getString("application"));
					td.setMonth(rs.getString("month"));
					td.setCost(rs.getInt("cost"));
					td.setEmployeeName(rs.getString("employeename"));
					cost.add(td);
					
					
				}
				request.setAttribute("list",cost);	
				RequestDispatcher rd= request.getRequestDispatcher("cost.jsp");
				rd.forward(request, response);
				
			}catch (SQLException e) {				
				e.printStackTrace();
			} 
		}
		
    }
    public String getMonthYear(String month){
        String req[] = month.split(" ");
        String[] months = new DateFormatSymbols().getMonths();
        for(int i=0;i<12;i++){
               if(months[i].equals(req[0])){
                      if(i<9)
                            return "0"+(i+1)+" "+req[1];
                      else
                            return (i+1)+" "+req[1];
               }
        }
        return "";
     }
     
     
     public String getMonth(String month){
         String req[] = month.split(" ");
         String[] months = new DateFormatSymbols().getMonths();
         for(int i=0;i<12;i++){
                if(months[i].equals(req[0])){
                       if(i<9)
                             return "0"+(i+1);
                       else
                             return (i+1)+"";
                }
         }
         return "";
      }
         
     static int  calls = 0;
     public void doPost(HttpServletRequest request, HttpServletResponse response)     
     		throws ServletException, IOException {
     	calls++;
     	System.out.println(calls);
     	String json = request.getParameter("json");
     	/*String application = request.getParameter("project");*/
     	String month= request.getParameter("month");
     	response.setContentType("application/json");
     	if(json!=null){
     		PrintWriter pw = response.getWriter();
     		
     		ObjectMapper parser = new ObjectMapper();
     		ArrayList<HardwareMaintenance> list = parser.readValue(json, TypeFactory.collectionType(List.class, HardwareMaintenance.class));
     		for(HardwareMaintenance hm : list){
     			hm.setMonth(month);
     		}
     		InsertCommunicationDetails t=new InsertCommunicationDetails();
     		boolean status= t.insertIntoCommunication(list);
     		response.setContentType("application/text");
     		if(status){
     			pw.print("{statusMessage:'Details updated successfully!!'}");
     		}
     		else{
     			pw.print("{statusMessage:'Error saving data!!'}");
     		}
     	}
     }

     int getEmployeeNumber(String input){
     	if(input==null || input.trim().equals(""))
     		return 0;
     	try{
     		return Integer.parseInt(input.trim().replaceAll("\"", ""));
     	}catch(Exception e){
     		e.printStackTrace();
     		return 0;
     	}
     }
     
     double getCost(String input){
     	if(input==null || input.trim().equals(""))
     		return 0;
     	try{
     		return Double.parseDouble(input.trim().replaceAll("\"", ""));
     	}catch(Exception e){
     		e.printStackTrace();
     		return 0;
     	}
     }
  
    
    
    
}



        
        
    

package com.pmo.main;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.map.ObjectMapper;

import com.pmo.dboperation.RollOffCheckListDAO;
import com.pmo.model.RollOffCheckList;

/**
 * Servlet implementation class RollOffCheckListServlet
 */
//@WebServlet("/RollOffCheckListServlet")
public class RollOffCheckListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RollOffCheckListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		String empId = request.getParameter("id");
		String empNum = empId.split("- ")[1];
		int empNo = Integer.parseInt(empNum);
		String rollOffData;
		try {
			rollOffData = RollOffCheckListDAO.rollOfDataFetch(empNo);
			response.setContentType("application/json");
			System.out.println(rollOffData);
			response.getWriter().write(rollOffData);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		String jsonFromUi =request.getReader().readLine();
		ObjectMapper objectMapper = new ObjectMapper();
		RollOffCheckList rOffList = objectMapper.readValue(jsonFromUi, RollOffCheckList.class);
		System.out.println("Roll-Off CheckList Details: " + rOffList.toString());
		String userName = (String) request.getSession().getAttribute("name");
		String resName = rOffList.getEmpNum();
		String empNum = resName.split("- ")[1];
		int empId = Integer.parseInt(empNum);
		RollOffCheckListDAO rollOffDao = new  RollOffCheckListDAO();
		boolean empChk = rollOffDao.isEmployeePresent(empId);
		if(empChk){
			int updResponse = RollOffCheckListDAO.rollOffCheckListUpdate(rOffList, userName);
			if(updResponse != 0){
				response.sendRedirect("newrolloffchecklist.jsp");
			} else {
				response.sendError(updResponse);
			}
		} else {
			response.sendError(400, "Invalid request!!");
		}
		
	}

}

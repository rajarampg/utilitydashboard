package com.pmo.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pmo.commons.EmailMessager;
import com.pmo.commons.EventNotification;
import com.pmo.commons.Util;
import com.pmo.connection.PmoProperties;
import com.pmo.dboperation.InsertResourceDetails;
import com.pmo.login.AccessDao;
import com.pmo.login.TableDetail;

import freemarker.template.TemplateException;

/**
 * Servlet implementation class DEVServlet
 */
public class DEVServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");		
		TableDetail td=null;
		String Client="Walmart";
		InsertResourceDetails i  = new InsertResourceDetails();		
		HttpSession session = req.getSession(true);
		String resource = req.getParameter("resourcename");
		String operation = (String) session.getAttribute("operation");
		String userName = (String) req.getSession().getAttribute("name");
		if(resource!=null && resource.equals("New"))
			operation = "insert";
		else
			operation = "updateRollOn";
		if (operation.equals("insert")) {			
			td= new TableDetail();
			/*td.setEmpId(Integer.parseInt(req.getParameter("empid")));*/
//			 Changed for update roll-on 's new employee insert
			td.setEmpId(Integer.parseInt(req.getParameter("employeeId")));
			td.setFirstName(req.getParameter("firstName"));
			td.setLastName(req.getParameter("lastName"));
			td.setRname(td.getFirstName()+" - "+td.getEmpId());
			td.setEnterpriseId(req.getParameter("enterpriseId"));
			td.setRollonDate(req.getParameter("rollonDate"));			
			td.setStream(req.getParameter("stream"));
			td.setCapability(req.getParameter("capability"));
			td.setClevel((req.getParameter("clevel")));
			td.setProjName(req.getParameter("projName"));
			td.setClient(Client);
			if((req.getParameter("sitelocation")).equals("Offshore")){
				td.setVisaType("");
				td.setDuration("");
			}
			else{
			td.setVisaType(req.getParameter("visa"));
			td.setDuration(req.getParameter("duration"));
			}
			td.setCurrLocation(req.getParameter(getLocationFieldName(req.getParameter("sitelocation"))));  
			td.setProjDetails(req.getParameter("projDetails"));			
			td.setGender(req.getParameter("gender"));
			td.setWmtid(req.getParameter("wmtid"));
			td.setRequestdate(req.getParameter("requestdate"));
			td.setGrantdate(req.getParameter("grantdate"));
			td.setWorkstationNumber(req.getParameter("workstationNumber"));
			td.setBayNumber(Integer.parseInt(req.getParameter("BayNumber")));
			td.setFloor(req.getParameter("floor"));
			td.setLockType(req.getParameter("locktype"));
			td.setSiteLocation(req.getParameter("sitelocation"));
			td.setSupervisorName(req.getParameter("Supervisor"));
			td.setPhoneNo(Long.parseLong(req.getParameter("phoneNo")));
			td.setPrimarySkill(req.getParameter("primaryskill"));
			td.setSecondarySkill(req.getParameter("secondaryskill"));
			td.setProficiency(req.getParameter("proficiency"));
			td.setRolloffDate(req.getParameter("lockEndDate"));
			td.setRolledOnBy((String) session.getAttribute("enterpriseId"));
			td.setEmployeeStatus(Util.ONBOARDED);
			td.setRrdId(req.getParameter("rrdId"));
			String status=i.insertDetails(td);
		/*	try {
				  i.sendmail();
				} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			if(status.equals("true"))
			{			
			pw.print("Details Got Saved Successfully!!");
			
			String isEmailNotRequired = PmoProperties.getProperty("ISEMAILREQ");
			if(isEmailNotRequired.equalsIgnoreCase("TRUE"))
			{					
				String user = (String)session.getAttribute("enterpriseId");
				String rollOnMailSubject= "Roll On details for employee:" + req.getParameter("enterpriseId") + "RRD ID:" + req.getParameter("rrdId");
				//String rollOnMailContent= "Accenture roll on completed successfully by userid."+user + "Kindly login to portal to raise Walmart On-boarding request.";
				String rollOnMailContent=null;
				try {
					rollOnMailContent=EmailMessager.generateEmailMessage(this.getServletContext(),req,"newresourcetemplate.ftl");
					System.out.println("STR : "+rollOnMailContent);
				} catch (TemplateException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				List<String> toMailId = new ArrayList<String>() ;
				List<String> ccMailId = new ArrayList<String>() ;
				ccMailId.add(req.getParameter("Supervisor"));
				toMailId.add(req.getParameter("enterpriseId"));
				
				
				try {
					EventNotification.sendSimpleEmailNotification(toMailId, ccMailId,rollOnMailSubject, rollOnMailContent);
				} catch (AddressException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (MessagingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
		
			
			}else if(status.equals("duplicate")){
				pw.print("Already Employee is existing in the DB");
			}else{
				pw.print("DB Problem in Inserting the data");
			}
		}
		else if (operation!=null && operation.equals("updateRollOn")){			
			td= new TableDetail();
			td.setEmpId(Integer.parseInt(req.getParameter("employeeId")));
			td.setRname(req.getParameter("resourcename"));
			td.setEnterpriseId(req.getParameter("enterpriseId"));
			td.setRollonDate(req.getParameter("rollonDate"));			
			td.setStream(req.getParameter("stream"));
			td.setCapability(req.getParameter("capability"));
			td.setProjName(req.getParameter("projName"));
			td.setClient(Client);
			td.setSiteLocation(req.getParameter("sitelocation"));
			td.setCurrLocation(req.getParameter(getLocationFieldName(req.getParameter("sitelocation"))));
			td.setVisaType(req.getParameter("visa"));
			td.setDuration(req.getParameter("duration"));
			td.setClevel((req.getParameter("clevel")));
			td.setPhoneNo(Long.parseLong(req.getParameter("phoneNo")));
			td.setProjDetails(req.getParameter("projDetails"));			
			td.setGender(req.getParameter("gender"));
			td.setWmtid(req.getParameter("wmtid"));
			td.setRequestdate(req.getParameter("requestdate"));
			td.setGrantdate(req.getParameter("grantdate"));
			td.setWorkstationNumber(req.getParameter("workstationNumber"));
			td.setBayNumber(Integer.parseInt(req.getParameter("BayNumber")));
			td.setFloor(req.getParameter("floor"));
			td.setLockType(req.getParameter("locktype"));
			td.setSiteLocation(req.getParameter("sitelocation"));
			td.setSupervisorName(req.getParameter("Supervisor"));
			td.setManagerId(req.getParameter("manager"));
			td.setPrimarySkill(req.getParameter("primaryskill"));
			td.setSecondarySkill(req.getParameter("secondaryskill"));
			td.setProficiency(req.getParameter("proficiency"));
			td.setRolloffDate(req.getParameter("lockEndDate"));
			td.setRolledOnBy((String) session.getAttribute("enterpriseId"));
			td.setEmployeeStatus(Util.ROLLEDON);
			td.setRrdId(req.getParameter("rrdId"));
			td.setTaskCompletedBy(userName);
			if(i.updateEmployeeDetails(td))
				pw.print("Details Got Saved Successfully!!");
			else
				pw.print("Error rolling on "+td.getEmpId()+"!! Enter a valid Walmart ID!");

			 
		
		}

	}

	private String getLocationFieldName(String siteLocation){
		String currentLocation = "";
		if(siteLocation!=null && !siteLocation.trim().equals("")){
			if(siteLocation.equals("Onshore"))
				currentLocation = "onshorecurrLocation";
			else if(siteLocation.equals("IDC"))
				currentLocation = "offshoreLocation";
			else
				currentLocation = "pdclocation"; 
		}
		return currentLocation;
		
	}
	
	
}

package com.pmo.main;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.Gson;
import com.pmo.connection.DatabaseConnection;
import com.pmo.dboperation.InsertCertificationAndRewardDetails;
import com.pmo.login.TableDetail;

/**
 * Servlet implementation class CertificationDetailServlet
 */

public class CertificationDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//private  final String selectQuery="select emp.employeenumber, emp.specificstream ,rew.award_receiver from employeedetails as emp left join rewards_recognition as rew on emp.employeenumber=rew.employeenumber where rew.award_receiver=?";
	
	String stFlag;
	String acFlag;

       
    /**
     * 
     * @see HttpServlet#HttpServlet()
     */
    public CertificationDetailServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException ,NullPointerException{	
		Statement st;
    	DatabaseConnection dbConn = new DatabaseConnection();
    	 String exQuery;
        Connection con = dbConn.mySqlConnection();
		String operation=request.getParameter("page");
		String award_receiver= request.getParameter("stream");
		stFlag=request.getParameter("stFlag");
		acFlag=request.getParameter("acFlag");
		PreparedStatement pst;
		
		if (operation.equals("certi") ) 
		{
			 List<TableDetail> certilist = new ArrayList<TableDetail>();    
			try {
	        	st=con.createStatement();
	        	ResultSet rs=st.executeQuery("select * from certification order by certtimestamp desc");
	        	while (rs.next())
	        	{
	        		TableDetail td=new TableDetail();
	        		td.setRname(rs.getString("employeeName"));
	        		td.setEmpId(rs.getInt("employeeNumber"));
	        		td.setStream(rs.getString("stream"));
	        		td.setCertificationType(rs.getString("certificationtype"));
	        		td.setCertificationName(rs.getString("certificationname"));
	        		td.setCertificationDate(rs.getString("certificationdate"));
	        		td.setScore(rs.getInt("score"));
	        		td.setTimestamp(rs.getTimestamp("certtimestamp"));
	        		td.setCertificationStatus(rs.getString("status"));
	        		certilist.add(td);
	        		
	        	}
	        	String countjava="select count(*)  from certification WHERE certificationname =?" ;
				pst=con.prepareStatement(countjava);
				pst.setString(1, "java");
				rs=pst.executeQuery();
				while(rs.next())
				{
					
					int countQADept=rs.getInt(1);				
					request.setAttribute("countQADept",countQADept);
				}
				String counthtml="select count(*)  from certification WHERE certificationname =?" ;
				pst=con.prepareStatement(counthtml);
				pst.setString(1, "html");
				rs=pst.executeQuery();
				while(rs.next())
				{
					
					int countDevDep =rs.getInt(1);
					request.setAttribute("countDevDep",countDevDep);
				}
				String coundotnet="select count(*)  from certification WHERE certificationname =?" ;
				pst=con.prepareStatement(coundotnet);
				pst.setString(1, "dotnet");
				rs=pst.executeQuery();
				while(rs.next())
				{
					
					int countOpsDep =rs.getInt(1);
					request.setAttribute("countDevDep",countOpsDep);
				}
	        	request.setAttribute("list",certilist);	
	        	RequestDispatcher rd= request.getRequestDispatcher("certificationdetail.jsp");
	        	rd.forward(request, response);
			} catch (SQLException e) {				
				e.printStackTrace();
			} 
		
		}
		else if (operation.equals("rewards") ) 
		{
			 List<TableDetail> rewardslist = new ArrayList<TableDetail>();    
			try {
	        	st=con.createStatement();
	        	ResultSet rs=st.executeQuery("select * from rewards_recognition order by rewardtimestamp desc");
	        	while (rs.next())
	        	{
	        		TableDetail td=new TableDetail();
	        		td.setRname(rs.getString("employeename"));
	        		td.setEmpId(rs.getInt("employeenumber"));
	        		td.setStream(rs.getString("stream"));
	        		td.setAwardType(rs.getString("awardtype"));
	        		td.setAward_receiver(rs.getString("award_receiver"));
	        		td.setAward_period(rs.getString("award_period"));
	        		td.setAward(rs.getString("award"));
	        		td.setReason(rs.getString("awardreason"));
	        		td.setTimestamp(rs.getTimestamp("rewardtimestamp"));		
	        		rewardslist.add(td);
	        		
	        	}
	        	String countQA="select count(*)  from rewards_recognition WHERE stream =?" ;
				pst=con.prepareStatement(countQA);
				pst.setString(1, "QA");
				rs=pst.executeQuery();
				while(rs.next())
				{
					
					int countQADept=rs.getInt(1);				
					request.setAttribute("countQADept",countQADept);
				}
				String countDev="select count(*)  from rewards_recognition WHERE stream =?" ;
				pst=con.prepareStatement(countDev);
				pst.setString(1, "DEV");
				rs=pst.executeQuery();
				while(rs.next())
				{
					
					int countDevDep =rs.getInt(1);
					request.setAttribute("countDevDep",countDevDep);
				}
				String countOps="select count(*)  from rewards_recognition WHERE stream =?" ;
				pst=con.prepareStatement(countOps);
				pst.setString(1, "OPS");
				rs=pst.executeQuery();
				while(rs.next())
				{					
					int countOpsDep =rs.getInt(1);
					request.setAttribute("countOpsDep",countOpsDep);
				}
			
				
	        	request.setAttribute("list",rewardslist);	
	        	RequestDispatcher rd= request.getRequestDispatcher("rewardsdetail.jsp");
	        	rd.forward(request, response);
			} catch (SQLException e) {			
				e.printStackTrace();
			} 
		
		}
		
		else if (operation.equals("team") ) {
		List<TableDetail> list1 = new ArrayList<TableDetail>(); 
		try{
			
		//	String temp=stFlag;
			
			exQuery=Getquery();
			
        	st=con.createStatement();
        	TableDetail td=new TableDetail();
        	ResultSet rs=st.executeQuery(exQuery);
			
			while(rs.next())
			{
				 td=new TableDetail();
				td.setRname(rs.getString("resourcename"));
        		td.setEmpId(rs.getInt("employeenumber"));
        		td.setStream(rs.getString("specificstream"));
        		list1.add(td);
        		   		
			}	
			String json = null; 	        		
    		json = new Gson().toJson(list1); 
    		response.setContentType("application/json");  
    		response.getWriter().write(json);
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		}
			}

	
	public String Getquery()
	{
		
		String sql;
		
		if(stFlag.equalsIgnoreCase("all"))
		{			
		
			 sql ="select resourcename,employeenumber,specificstream from employeedetails  group by employeenumber,resourcename,specificstream";
			
		}

		/*else if(stFlag.equalsIgnoreCase("all"))
		{
			
			 sql ="select emp.resourcename,emp.employeenumber,emp.specificstream from employeedetails as emp inner join rewards_recognition as rew on emp.employeenumber=rew.employeenumber where rew.award_receiver='"+acFlag+"'group by emp.employeenumber" ;
					 
		}*/
		else 
		{
		 sql ="select resourcename,employeenumber,specificstream from employeedetails where specificstream ='"+stFlag+"' group by resourcename,employeenumber,specificstream";
		}
			
	
		return sql;
		
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		InsertCertificationAndRewardDetails ic=new InsertCertificationAndRewardDetails();
		TableDetail td=new TableDetail() ;
		
		String employeeName=request.getParameter("employeename");
		String employeeId=request.getParameter("employeenumber");
		String specificStream=request.getParameter("stream");
		String certificationType=request.getParameter("certificationtype");
		String certificationName= request.getParameter("capability");
		if(certificationName.equalsIgnoreCase("others"))
			certificationName=request.getParameter("capabilityOthers");
		String currentStatus= request.getParameter("status");
		String  certificationDate=request.getParameter("certificationDate");
		String score = request.getParameter("score");
		td.setRname(employeeName);
		td.setEmpId(Integer.parseInt(employeeId));
		td.setStream(specificStream);
		td.setCertificationType(certificationType);
		td.setCertificationName(certificationName);
		td.setCertificationStatus(currentStatus);
		if(currentStatus.equalsIgnoreCase("certification")){
			td.setCertificationDate(certificationDate);
			if(score.equalsIgnoreCase("")){
				td.setScore(0);
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Input Score details!! ');");
				pw.println("location='certification.jsp';");
				pw.println("</script>");
			} else{
				td.setScore(Integer.parseInt(score));
			}
			
		}else {
			td.setCertificationDate(null);
			td.setScore(0);
			
		}
		
		
		try {
				boolean chkTrainingDtls= false;
				int desVal= ic.checkCertiDtls(td);
				if(desVal==1){
					chkTrainingDtls=ic.updateTrainingDetails(td);
				} else if (desVal == 2) {
					chkTrainingDtls=ic.updateCertificationDetails(td);
				} else if (desVal == 3) {
					chkTrainingDtls=ic.updateCertificationDetailsFrmCerti(td);
				} else if (desVal == 4) {
					chkTrainingDtls=ic.insertCertificationDetails(td);
				}
				
				if(chkTrainingDtls){
					pw.println("<script type=\"text/javascript\">");
					pw.println("alert('Details Got Saved Successfully');");
					pw.println("location='certification.jsp';");
					pw.println("</script>");
					System.out.println("inserted successfully");
				}else{
					pw.println("<script type=\"text/javascript\">");
					pw.println("alert('Error saving details!!');");
					pw.println("location='certification.jsp';");
					pw.println("</script>");
				}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			pw.println("<script type=\"text/javascript\">");
			pw.println("alert('Error saving details!!');");
			pw.println("location='certification.jsp';");
			pw.println("</script>");
			e.printStackTrace();
		}
		
		
		
	
	}
	
	
	
	
}

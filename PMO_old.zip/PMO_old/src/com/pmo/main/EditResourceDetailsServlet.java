package com.pmo.main;

import java.io.IOException;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.codehaus.jackson.map.ObjectMapper;
import com.google.gson.Gson;
import com.pmo.commons.NavigationProperties;
import com.pmo.connection.DatabaseConnection;
import com.pmo.dboperation.InsertResourceDetails;
import com.pmo.login.TableDetail;
  
public class EditResourceDetailsServlet extends HttpServlet{   
  
    private static final long serialVersionUID = 1L;
    DatabaseConnection dbConn;
  
    public void doPost(HttpServletRequest request, HttpServletResponse response)     
    		throws ServletException, IOException {

    	HashMap<String, String> responseStatus = new HashMap<String, String>();
    	String action = request.getParameter("page");
    	if(action == null){
    		InsertResourceDetails dao = new InsertResourceDetails();
    		String enterpriseId = (String)request.getSession().getAttribute("enterpriseId");
    		TableDetail tableDetail = dao.getEmployeeDetails(enterpriseId);
    		String responseJsp = "";
    		if(tableDetail!=null){
    			request.setAttribute("employeeDetail", new Gson().toJson(tableDetail));
    			responseJsp = NavigationProperties.getProperty(request.getServletPath().substring(1)+".success");
    			request.getRequestDispatcher(responseJsp).forward(request, response);
    		}else{
    			responseJsp = NavigationProperties.getProperty(request.getServletPath().substring(1)+".failure");
    			request.getRequestDispatcher(responseJsp).forward(request, response);
    		}
    	}else if(action!= null && action.trim().equals("updateDetails")){
    		String employeeDetail = request.getParameter("employeeDetail");
    		ObjectMapper objectMapper = new ObjectMapper();
    		InsertResourceDetails dao = new InsertResourceDetails();
    		TableDetail dto = objectMapper.readValue(employeeDetail, TableDetail.class);
    		response.setContentType("application/json");
    		if(dao.modifyEmployeeDetails(dto)){
    			responseStatus.put("status", "Resource details updated successfully!");
    			response.getWriter().write(new Gson().toJson(responseStatus));
    		}
    		else{
    			responseStatus.put("status", "Oops! Error updating Resource details!");
    			response.getWriter().write(new Gson().toJson(responseStatus));
    		}
    	}
    	/*else if(action!= null && action.trim().equals("updateRollOn")){
    		String checkList = request.getParameter("checkListDetails");
    		ObjectMapper objectMapper = new ObjectMapper();
    		CheckListDAO dao = new CheckListDAO();
    		response.setContentType("application/json");
    		if(dao.updateCheckListDetails(objectMapper.readValue(checkList, CheckList.class))){
    			responseStatus.put("status", "Checklist updated successfully!");
    			response.getWriter().write(new Gson().toJson(responseStatus));
    		}
    		else{
    			responseStatus.put("status", "Oops! Error updating checklist!");
    			response.getWriter().write(new Gson().toJson(responseStatus));
    		}
    	}else if(action!= null && action.trim().equals("getRollOffChecklist")){
    		CheckListDAO dao = new CheckListDAO();
    		String enterpriseId = (String)request.getSession().getAttribute("enterpriseId");
    		HashMap<String, String> checkList = dao.getRollOffCheckListDetails(enterpriseId);
    		if(checkList == null){
//    			Employee is not rolled on / roll on check list is not complete
    			System.out.println("return main jsp");
    		}
    		request.setAttribute("checkListDetails", new Gson().toJson(checkList));
    		String responseJsp = NavigationProperties.getProperty(request.getServletPath().substring(1)+".success");
    		request.getRequestDispatcher(responseJsp).forward(request, response);
    	}else if(action!= null && action.trim().equals("updateRollOff")){
    		String checkList = request.getParameter("checkListDetails");
    		ObjectMapper objectMapper = new ObjectMapper();
    		TypeReference<HashMap<String, String>> typeRef = new TypeReference<HashMap<String, String>>() {};
    		HashMap<String, String> checkListDetails = objectMapper.readValue(checkList, typeRef); 
    		CheckListDAO dao = new CheckListDAO();
    		response.setContentType("application/json");
    		if(dao.updateRollOffCheckListDetails(Integer.parseInt(checkListDetails.get("employeeNumber")))){
    			responseStatus.put("status", "Checklist updated successfully!");
    			response.getWriter().write(new Gson().toJson(responseStatus));
    		}
    		else{
    			responseStatus.put("status", "Oops! Error updating checklist!");
    			response.getWriter().write(new Gson().toJson(responseStatus));
    		}*/
    }
    
	   
}   

package com.pmo.main;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.pmo.dboperation.NewLoginDAO;
import com.pmo.login.AccessDao;
import com.pmo.login.LoginDao;
import com.pmo.login.NewLoginDetails;

/**
 * Servlet implementation class NewLoginServlet
 */
//@WebServlet("/NewLoginServlet")
public class NewLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("static-access")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		SessionHelper sessionhelper = new SessionHelper();
		HttpSession session = request.getSession(false);
		String access="0";
		String enterpriseId = "";
		
		Gson newLoginClient = new Gson();
		NewLoginDetails newLoginForm = newLoginClient.fromJson(request.getReader(), NewLoginDetails.class);
		String user = newLoginForm.getUsername();
		String password = newLoginForm.getPassword();
		System.out.println("Username entry: " +user);
		
		if(session != null){
			session.setAttribute("name", user);
			session.setAttribute("pass", password);
			sessionhelper.isUserLoggedIn(request);
		
		boolean firstTimeUser;
		NewLoginDAO loginDao = new NewLoginDAO();
		try {
			firstTimeUser = loginDao.getLoginStatus(user);
			String userRole = loginDao.getUserRole(user);
			if(firstTimeUser){
				if(loginDao.validateFirstLogin(user, password,userRole)==1){
					access=AccessDao.getAccess(userRole);
					enterpriseId = LoginDao.getEnterprizeId(user);
					session.setAttribute("enterpriseId",enterpriseId);					
					ArrayList<String> list = AccessDao.uiFormRights();
					String json = new Gson().toJson(list);
					request.setAttribute("elementContent", "''");
					session.setAttribute("accessrights",access);
					session.setAttribute("uiForm",json);
					response.setContentType("application/text");
					response.getWriter().write("Reset");
				} else {
					response.sendError(1);
					System.out.println("Invalid credentials try again!");
				}
				
			} else {
				if(loginDao.validateLogin(user,password)){
					access=AccessDao.getAccess(userRole);
					enterpriseId = LoginDao.getEnterprizeId(user);
					session.setAttribute("enterpriseId",enterpriseId);					
					ArrayList<String> list = AccessDao.uiFormRights();
					String json = new Gson().toJson(list);
					request.setAttribute("elementContent", "''");
					session.setAttribute("accessrights",access);
					session.setAttribute("uiForm",json);
					response.setContentType("application/text");
					response.getWriter().write("Main");
				} else {
					System.out.println("Invalid login credentials!");
					response.sendError(1);
				}
				
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		} else {
			request.getRequestDispatcher("/sessionError.jsp").forward(request,
					response);
		}
	}

}

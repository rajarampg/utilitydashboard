package com.pmo.main;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.pmo.dboperation.NewLoginDAO;
import com.pmo.login.NewLoginDetails;
import com.pmo.login.ResetPasswordDetails;

/**
 * Servlet implementation class PasswordResetServlet
 */
//@WebServlet("/PasswordResetServlet")
public class PasswordResetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PasswordResetServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Gson passRestForm = new Gson();
		ResetPasswordDetails resetPassForm = passRestForm.fromJson(request.getReader(), ResetPasswordDetails.class);
		String currentPassword = resetPassForm.getCurrentpassword();
		String newpassword = resetPassForm.getNewpassword();
		String userName = (String) request.getSession().getAttribute("name");
		System.out.println("Username:"+ userName +"Current pass:" + currentPassword + "New password:" + newpassword);
		NewLoginDAO loginDao = new NewLoginDAO();
		try {
			int updRes=loginDao.updatePasswordAfterInitialLogin(userName,currentPassword,newpassword);
			if(updRes == 1){
				response.sendRedirect("passwordreset.jsp");
//				response.setContentType("application/text");
//				System.out.println("Main!!!");
//				response.getWriter().write("Main");
			} else {
				System.out.println("Password not reset! Please try again!");
				response.sendError(1);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}

}

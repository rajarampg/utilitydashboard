package com.pmo.main;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.pmo.commons.Util;
import com.pmo.connection.DatabaseConnection;
import com.pmo.dboperation.PMODAO;
import com.pmo.login.HardwareMaintenance;
import com.pmo.login.TableDetail;
import com.pmo.model.RollOnCheckList;
  
public class ReportsServlet extends HttpServlet{   
  
    private static final long serialVersionUID = 1L;
    
    
    DatabaseConnection dbConn = new DatabaseConnection();
    PMODAO dao = new PMODAO();
  
    public void doGet(HttpServletRequest request, HttpServletResponse response)     
    		throws ServletException, IOException {
    	String jsonContent = null;
    	String action=(String)request.getParameter("action");

    	if(action!=null){

    		if(action.equalsIgnoreCase("onboard")){
    			Object data = dao.getDetails(Util.ONBOARD_EMPLOYEE_DETAILS);
    			if(data!=null){
    			List<TableDetail> tableDetails = (List<TableDetail>)data;
    			if(tableDetails.size()>0)
    				jsonContent = new Gson().toJson(tableDetails);
    			}
    		} else if(action.equalsIgnoreCase("transportCosts")){
    			Object data = dao.getDetails(Util.TRANSPORT_COSTS_REPORT);
    			if(data!=null){
    			ArrayList<HashMap<String, String>> transportDetails = (ArrayList<HashMap<String, String>>)data;
    			if(transportDetails.size()>0)
    				jsonContent = new Gson().toJson(transportDetails);
    			}
    		} else if(action.equalsIgnoreCase("gender")){
    			Object data = dao.getDetails(Util.GENDER_REPORT);
    			if(data!=null){
    			List<TableDetail> genderDetails = (List<TableDetail>)data;
    			if(genderDetails.size()>0)
    				jsonContent = new Gson().toJson(genderDetails);
    			}
    		} else if(action.equalsIgnoreCase("hardware")){
    			Object data = dao.getDetails(Util.HARDWARE_REPORT);
    			if(data!=null){
    			List<HardwareMaintenance> hardwareDetails = (List<HardwareMaintenance>)data;
    			if(hardwareDetails.size()>0)
    				jsonContent = new Gson().toJson(hardwareDetails);
    			}
    		} else if(action.equalsIgnoreCase("communications")){
    			Object data = dao.getDetails(Util.COMMUNICATION_COSTS_REPORT);
    			if(data!=null){
    			List<HardwareMaintenance> communicationDetails = (List<HardwareMaintenance>)data;
    			if(communicationDetails.size()>0)
    				jsonContent = new Gson().toJson(communicationDetails);
    			}
    		} else if(action.equalsIgnoreCase("rewards")){
    			Object data = dao.getDetails(Util.REWARDS_REPORT);
    			if(data!=null){
    			List<TableDetail> rewardDetails = (List<TableDetail>)data;
    			if(rewardDetails.size()>0)
    				jsonContent = new Gson().toJson(rewardDetails);
    			}
    		} else if(action.equalsIgnoreCase("certifications")){
    			Object data = dao.getDetails(Util.CERTIFCATION_REPORT);
    			if(data!=null){
    			List<TableDetail> certificationDetails = (List<TableDetail>)data;
    			if(certificationDetails.size()>0)
    				jsonContent = new Gson().toJson(certificationDetails);
    			}
    		} 
    		else if(action.equalsIgnoreCase("certificationMasterReport")){
    			Object data = dao.getDetails(Util.CERTIFICATION_MASTER_REPORT);
    			if(data!=null){
    			List<TableDetail> certificationMasDetails = (List<TableDetail>)data;
    			if(certificationMasDetails.size()>0)
    				jsonContent = new Gson().toJson(certificationMasDetails);
    			}
    		}
    		else if(action.equalsIgnoreCase("tasksMasterReport")){
    			Object data = dao.getDetails(Util.TASKS_MASTER_REPORT);
    			if(data!=null){
    			List<TableDetail> tasksMasDetails = (List<TableDetail>)data;
    			if(tasksMasDetails.size()>0)
    				jsonContent = new Gson().toJson(tasksMasDetails);
    			}
    		}
    		else if(action.equalsIgnoreCase("trainings")){
    			Object data = dao.getDetails(Util.TRAINING_REPORT);
    			if(data!=null){
    			List<TableDetail> trainingDetails = (List<TableDetail>)data;
    			if(trainingDetails.size()>0)
    				jsonContent = new Gson().toJson(trainingDetails);
    			}
    		} else if(action.equalsIgnoreCase("offboard")){
    			Object data = dao.getDetails(Util.OFFBOARD_EMPLOYEE_DETAILS);
    			if(data!=null){
    			List<TableDetail> tableDetails = (List<TableDetail>)data;
    			if(tableDetails.size()>0)
    				jsonContent = new Gson().toJson(tableDetails);
    			}
    		} else if(action.equalsIgnoreCase("resourceDetails")){
    			Object data = dao.getDetails(Util.RESOURCE_DETAILS);
    			if(data!=null){
    			List<TableDetail> tableDetails = (List<TableDetail>)data;
    			if(tableDetails.size()>0)
    				jsonContent = new Gson().toJson(tableDetails);
    			}
    		} else if(action.equalsIgnoreCase("rrddetails")){
    			Object data = dao.getDetails(Util.RRD_REPORT);
    			if(data!=null){
    			List<TableDetail> rrdDetails = (List<TableDetail>)data;
    			if(rrdDetails.size()>0)
    				jsonContent = new Gson().toJson(rrdDetails);
    			}
    		}
    		else if(action.equalsIgnoreCase("aclreport")){
    			Object data = dao.getDetails(Util.ACL_REPORT);
    			if(data!=null){
    			List<TableDetail> aclDetails = (List<TableDetail>)data;
    			if(aclDetails.size()>0)
    				jsonContent = new Gson().toJson(aclDetails);
    			}
    		}
    		else if(action.equalsIgnoreCase("rollonCheckListReport")){
    			Object data = dao.getDetails(Util.ROLLON_CHECKLIST_REPORT);
    			if(data!=null){
    			List<RollOnCheckList> rOnChkListDetails = (List<RollOnCheckList>)data;
    			if(rOnChkListDetails.size()>0)
    				jsonContent = new Gson().toJson(rOnChkListDetails);
    			}
    		}
    	}
    	if(jsonContent!=null){
    		response.setContentType("application/json");  
    		response.getWriter().write(jsonContent);
    	}
    }
	   
}   

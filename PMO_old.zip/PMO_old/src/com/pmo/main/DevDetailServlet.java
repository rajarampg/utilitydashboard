package com.pmo.main;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.Gson;
import com.pmo.commons.Util;
import com.pmo.connection.DatabaseConnection;
import com.pmo.dboperation.InsertResourceDetails;
import com.pmo.dboperation.PMODAO;
import com.pmo.login.TableDetail;
  
public class DevDetailServlet extends HttpServlet{   
  
    private static final long serialVersionUID = 1L;
    DatabaseConnection dbConn = new DatabaseConnection();
  
    public void doGet(HttpServletRequest request, HttpServletResponse response)     
    		throws ServletException, IOException {    

    	Statement st;

    	Connection con = dbConn.mySqlConnection();
    	PreparedStatement pst;      
    	String action=(String)request.getParameter("action");
    	String empId=(String)request.getParameter("employee_id");
    	String ename=(String)request.getParameter("employee_Name");		
    	RequestDispatcher rd=null;     
    	ResultSet rs=null;	

    	if(action!=null && action.equalsIgnoreCase("delete"))
    	{

    		InsertResourceDetails i  = new InsertResourceDetails();
    		String countStatus=i.checkCountHardware(Integer.parseInt(empId));
    		if (countStatus.equals("true"))
    		{
    			String deleteEmployee = "Delete from EmployeeDetails WHERE EmployeeNumber=?";
    			try {
    				pst = con.prepareStatement(deleteEmployee);
    				pst.setInt(1,Integer.parseInt(empId));
    				pst.executeUpdate();
    				pst.close();
    				con.close();				
    			} catch (SQLException e) {				
    				e.printStackTrace();
    			}
    		}
    		else
    		{

    			if (countStatus.equals("rsafalse"))
    			{

    				String deleteEmployeeRsa = "Delete from rsaDetails WHERE EmployeeNumber=?";
    				try {
    					pst = con.prepareStatement(deleteEmployeeRsa);
    					pst.setInt(1,Integer.parseInt(empId));
    					pst.executeUpdate();
    					pst.close();

    				} catch (SQLException e) {				
    					e.printStackTrace();
    				}
    			}


    			String mobStatus=i.checkCountHardware(Integer.parseInt(empId));
    			if (mobStatus.equals("mobfalse"))
    			{

    				String deleteEmployeeMob = "Delete from mobileDetails WHERE EmployeeNumber=?";
    				try {
    					pst = con.prepareStatement(deleteEmployeeMob);
    					pst.setInt(1,Integer.parseInt(empId));
    					pst.executeUpdate();
    					pst.close();

    				} catch (SQLException e) {				
    					e.printStackTrace();
    				}

    			}
    			String lapStatus=i.checkCountHardware(Integer.parseInt(empId));
    			if (lapStatus.equals("lapfalse"))
    			{
    				String deleteEmployeeLap = "Delete from laptopDetails WHERE EmployeeNumber=?";
    				try {
    					pst = con.prepareStatement(deleteEmployeeLap);
    					pst.setInt(1,Integer.parseInt(empId));
    					pst.executeUpdate();
    					pst.close();

    				} catch (SQLException e) {				
    					e.printStackTrace();
    				}

    			}
    			String certStatus=i.checkCountHardware(Integer.parseInt(empId));
    			if (certStatus.equals("certfalse"))
    			{
    				String deleteEmployeeCert = "Delete from certification WHERE EmployeeNumber=?";
    				try {
    					pst = con.prepareStatement(deleteEmployeeCert);
    					pst.setInt(1,Integer.parseInt(empId));
    					pst.executeUpdate();
    					pst.close();

    				} catch (SQLException e) {				
    					e.printStackTrace();
    				}

    			}
    			String rewardStatus=i.checkCountHardware(Integer.parseInt(empId));
    			if (rewardStatus.equals("rewardfalse"))
    			{
    				String deleteEmployeereward = "Delete from rewards_recognition WHERE EmployeeNumber=?";
    				try {
    					pst = con.prepareStatement(deleteEmployeereward);
    					pst.setInt(1,Integer.parseInt(empId));
    					pst.executeUpdate();
    					pst.close();

    				} catch (SQLException e) {				
    					e.printStackTrace();
    				}

    			}						
    			String deleteEmployee = "Delete from EmployeeDetails WHERE EmployeeNumber=?";
    			try {
    				pst = con.prepareStatement(deleteEmployee);
    				pst.setInt(1,Integer.parseInt(empId));
    				pst.executeUpdate();
    				pst.close();
    				con.close();				
    			} catch (SQLException e) {				
    				e.printStackTrace();
    			}

    		}		
    	}
    	else if(action!=null && action.equals("getRollonForm")){
    		request.setAttribute("elementContent","''");
    		request.setAttribute("resourceList",Util.getResourcesList("rollOn"));
    		rd= request.getRequestDispatcher("onboard.jsp");
    		rd.forward(request, response);
    	}
    	else if(action!=null && action.equals("employeeDetail")){
    		empId=(String)request.getParameter("employeeId");
    		TableDetail tableDetail = new PMODAO().getEmployeeDetails(empId);
    		String json = null; 	        		
    		json = new Gson().toJson(tableDetail);
    		request.setAttribute("elementContent",json);
    		request.setAttribute("resourceList", Util.getResourcesList("rollOn"));
    		rd= request.getRequestDispatcher("onboard.jsp");
    		rd.forward(request, response);
    	/*}else if(action!=null && action.equals("rollOnDetails")){*/
    	}else if(action!=null && action.equals("employeeDetailsJson")){
    		empId = (String)request.getParameter("employeeId");
    		TableDetail tableDetail = new PMODAO().getEmployeeDetails(empId);
    		String json = null; 	        		
    		json = new Gson().toJson(tableDetail);
    		response.setContentType("application/json");  
			response.getWriter().write(json);
    	}else if(action!=null && action.equals("empId")){
    		List<TableDetail> emplist = new ArrayList<TableDetail>();

    		try {
    			String countRSA="select * from EmployeeDetails  where ResourceName=? and employee_status = 4";					          

    			pst=con.prepareStatement(countRSA);
    			pst.setString(1,ename);
    			rs=pst.executeQuery();

    			while (rs.next())
    			{
    				TableDetail td=new TableDetail();
    				td.setEmpId(rs.getInt("employeenumber"));
    				td.setRname(rs.getString("resourcename"));
    				td.setEnterpriseId(rs.getString("EnterpriseId"));
    				td.setGender(rs.getString("gender"));
    				td.setSiteLocation(rs.getString("delivery_centre"));
    				td.setCurrLocation(rs.getString("CurrentLocation"));
    				td.setVisaType(rs.getString("visa_type"));
    				td.setDuration(rs.getString("duration_stay"));
    				td.setRollonDate(rs.getString("RollOnDate"));	        		
    				td.setStream(rs.getString("SpecificStream"));      
    				td.setCapability(rs.getString("Capability"));
    				td.setClevel(rs.getString("CareerLevel"));
    				td.setWmtid(rs.getString("wmt_userid"));
    				td.setRequestdate(rs.getString("wmt_accessdate"));
    				td.setGrantdate(rs.getString("wmt_grantdate"));
    				td.setWorkstationNumber(rs.getString("workstation"));
    				td.setBayNumber(rs.getInt("bayno"));
    				td.setFloor(rs.getString("floor"));
    				td.setProjName(rs.getString("ProjectName"));
    				td.setClient(rs.getString("Client"));
    				td.setProjDetails(rs.getString("ProjectDetails"));	 
    				td.setLockType(rs.getString("locktype"));
    				td.setPrimarySkill(rs.getString("primary_skill"));
    				td.setSecondarySkill(rs.getString("secondary_skill"));
    				td.setProficiency(rs.getString("proficiency_level"));
    				td.setPhoneNo(rs.getLong("phone_no"));
    				td.setRolloffDate(rs.getString("rolloffdate"));
    				td.setRolloffReason(rs.getString("rolloffreason"));
    				td.setExit(rs.getBoolean("isexit"));
    				emplist.add(td);
    				String json = null; 	        		
    				json = new Gson().toJson(emplist); 
    				response.setContentType("application/json");  
    				response.getWriter().write(json);

    			}
    		}
    		catch (SQLException e) {			
    			e.printStackTrace();
    		} 
    	}else if(action!=null && action.equalsIgnoreCase("exportRollOnDetails")){
    		int employeeId = Integer.parseInt((String) request.getParameter("employeeId"));
    		List<TableDetail> list = getEmployeeOnboardDetails(true , employeeId );
    		request.setAttribute("fileName", employeeId+".xls");
    		request.setAttribute("list", list);	
    		rd= request.getRequestDispatcher("excelExport.jsp");
    		rd.forward(request, response);
    	}


    }
    
    


public List<TableDetail> getEmployeeOnboardDetails(boolean forEmpId, int empId){
	Connection con = dbConn.mySqlConnection();
	PreparedStatement pst = null;
	ResultSet rs = null;
	TableDetail td= null;
	List<TableDetail> list = new ArrayList<TableDetail>();
	try{
		list = new ArrayList<TableDetail>();
		String selectStatement = "select * from EmployeeDetails order by onboardtimestamp desc";
		
		if(forEmpId){
			selectStatement = "select * from EmployeeDetails where employeenumber = ?";
			pst = con.prepareStatement(selectStatement);
			pst.setInt(1, empId);
		}else{
			pst = con.prepareStatement(selectStatement);	
		}
		rs=pst.executeQuery();
		while (rs.next())
		{
			td=new TableDetail();

			td.setRname(rs.getString("ResourceName"));

			td.setFirstName(rs.getString("first_name"));
			td.setLastName(rs.getString("last_name"));
			td.setEmpId(rs.getInt("employeenumber"));
			td.setEnterpriseId(rs.getString("enterpriseid"));
			//		td.setrs.getString("resourcename"));
			td.setIdentifierType(rs.getString("identifier_type"));
			td.setIdentifierNumber(rs.getString("identifier_number"));
			td.setStream(rs.getString("specificstream"));
			td.setDeptNumber(rs.getString("department_number"));
			td.setCountry(rs.getString("country"));
			td.setDeliveryCentre(rs.getString("delivery_centre"));
			td.setCurrLocation(rs.getString("currentlocation"));
			td.setRoleDesc(rs.getString("role_desc"));
			td.setContractType(rs.getString("contract_type"));
			td.setRate(rs.getDouble("rate"));
			td.setRollonDate(rs.getString("onboard_start_date"));
			td.setManagerId(rs.getString("manager_id"));
			td.setDirectorId(rs.getString("director_id"));
			td.setVpUserId(rs.getString("vp_user_id"));
			td.setComments(rs.getString("comments"));
			td.setContractorHostPattern(rs.getString("contractor_host_pattern"));
			td.setContractorUnixPattern(rs.getString("contractor_unix_pattern"));
			td.setUnixBoxes(rs.getString("unix_boxes"));
			String remedyPattern = rs.getString("remedy_pattern");
			try{
				if(remedyPattern!=null)
					remedyPattern = remedyPattern.replaceAll("\\^", ", ");
			}catch(Exception e){
				e.printStackTrace();
			}
			td.setContractorRemedyPattern(remedyPattern);
			td.setContractorADPattern(rs.getString("contractor_ad_pattern"));
			td.setADGroupShared(rs.getString("ad_groups_shared"));
			td.setContractorTDPattern(rs.getString("contractor_td_pattern"));
			td.setTeraApplication(rs.getString("teradata_application"));
			td.setBusinessJustification(rs.getString("business_justification"));
			td.setEmployeeStatus(rs.getInt("employee_status"));
			list.add(td);
		}
	}catch(Exception e){
		e.printStackTrace();
	}finally{

	}
	return list;
}

    public TableDetail getTableDetailDTO(String employeeNumber){
    	Connection con = dbConn.mySqlConnection();
        PreparedStatement pst;
        ResultSet rs = null;
			
			try {
				String countRSA="select * from employeedetails  where employeenumber=?";					          
		         
				pst=con.prepareStatement(countRSA);
				pst.setInt(1,Integer.parseInt(employeeNumber));
				rs=pst.executeQuery();
	        	
	        	if (rs.next())
	        	{
	        		TableDetail td=new TableDetail();
	        		td.setEmpId(rs.getInt("employeenumber"));	        	
	        		td.setEnterpriseId(rs.getString("EnterpriseId"));
	        		td.setRname(rs.getString("resourcename"));
	        		td.setFirstName(rs.getString("first_name"));
					td.setLastName(rs.getString("last_name"));
	        		td.setGender(rs.getString("gender"));
	        		td.setSiteLocation(rs.getString("delivery_centre"));
	        		td.setCurrLocation(rs.getString("currentlocation"));
	        		td.setVisaType(rs.getString("visa_type"));
	        		td.setDuration(rs.getString("duration_stay"));
	        		td.setRollonDate(rs.getString("RollOnDate"));	        		
	        		td.setStream(rs.getString("SpecificStream"));      
	        		td.setCapability(rs.getString("Capability"));
	        		td.setClevel(rs.getString("CareerLevel"));
	        		td.setWmtid(rs.getString("wmt_userid"));
	        		td.setRequestdate(rs.getString("wmt_accessdate"));
	        		td.setGrantdate(rs.getString("wmt_grantdate"));
	        		td.setWorkstationNumber(rs.getString("workstation"));
	        		td.setBayNumber(rs.getInt("bayno"));
	        		td.setFloor(rs.getString("floor"));
	        		td.setProjName(rs.getString("ProjectName"));
	        		td.setClient(rs.getString("Client"));
	        		td.setProjDetails(rs.getString("ProjectDetails"));	 
	        		td.setLockType(rs.getString("locktype"));
	        		td.setPrimarySkill(rs.getString("primary_skill"));
	        		td.setSecondarySkill(rs.getString("secondary_skill"));
	        		td.setProficiency(rs.getString("proficiency_level"));
	        		td.setPhoneNo(rs.getLong("phone_no"));
	        		td.setManagerId(rs.getString("manager_id"));
	        		return td;
	        	}
			}
			catch (SQLException e) {			
				e.printStackTrace();
			} 
			return null;
    }
	   
}   

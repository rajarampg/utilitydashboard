package com.pmo.main;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pmo.dboperation.InsertTaskDetails;
import com.pmo.login.TableDetail;

/**
 * Servlet implementation class TaskMaintenanceServlet
 */

public class TaskMaintenanceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TaskMaintenanceServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		TableDetail td=new TableDetail() ;
		InsertTaskDetails i  = new InsertTaskDetails();		
		//HttpSession session = request.getSession(true);
		String operation = (String) request.getParameter("page");	
		String userName = (String) request.getSession().getAttribute("name");

		if(operation.equals("tasks")) {
			
			td.setAssignedDate(request.getParameter("assignedDate"));
			td.setTaskDescription(request.getParameter("taskDesc"));
			td.setEndDate(request.getParameter("endDate"));
			td.setStatus(request.getParameter("status"));
			td.setAssignedBy(request.getParameter("assigned"));
			td.setTaskCompletedBy(userName);
			String status1=i.insertTaskDetails(td);
			
			if(status1.equals("true"))
			{			
			pw.println("<script type=\"text/javascript\">");
			pw.println("alert('Details Got Saved Successfully');");
			pw.println("location='tasks.jsp';");
			pw.println("</script>");
			}
			else if(status1.equals("duplicate"))
				{
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Already Employee is existing in the DB');");
				pw.println("location='tasks.jsp';");
				pw.println("</script>");
				}
			else
			{
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('DB Problem in Inserting the data');");
				pw.println("location='tasks.jsp';");
				pw.println("</script>");
			}
			
	}

	}}

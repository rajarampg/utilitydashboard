/**
 * 
 */
package com.pmo.dboperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.pmo.commons.Util;
import com.pmo.connection.DatabaseConnection;
import com.pmo.login.TableDetail;

public class InsertOnboardingDetails {

	// DatabaseConnection dbConn = new DatabaseConnection();
	Connection con = null;
	PreparedStatement pst = null;
	Statement st = null;
	ResultSet rs = null;
	private final String selectQuery = "select count(employeenumber) from employeedetails where employeenumber = ?";
	private final String pageParams[] = { "firstname", "lastname", "employeeId", "enterpriseId", "resname", "idType",
			"identNumb", "deptType", "deptNumb", "country", "sitelocation", "pdclocation", "roleDescription",
			"contractType", "rate", "startDate", "mangID", "dirId", "vpId", "comments", "contHost", "contUnix",
			"unixBoxes", "remedyaccess", "ADaccess", "grpshared", "TeraAccess", "teraBoxes", "busJust","patternAfter", "contractId", "onboarded_by" };
	private final String tableParams[] = { "first_name", "last_name", "employeenumber", "enterpriseid", "resourcename",
			"identifier_type", "identifier_number", "specificstream", "department_number", "country", "delivery_centre",
			"currentlocation", "role_desc", "contract_type", "rate", "onboard_start_date", "manager_id", "director_id",
			"vp_user_id", "comments", "contractor_host_pattern", "contractor_unix_pattern", "unix_boxes",
			"remedy_pattern", "contractor_ad_pattern", "ad_groups_shared", "contractor_td_pattern",
			"teradata_application", "business_justification","pattern_after","contract_id","onboarded_by", "employee_status","firsttimeuser","employee_type" };
	private final String pageRemedyParams[] = { "hostPattern", "unixPattern", "remedybox", "ADpattern", "Terapattern" };
	private final String updateQuery = "update employeedetails set rolloffdate = ?, rolloffreason = ?, isexit = ?, employee_status = ? where employeenumber = ?";
	// handles integer datatypes
	private final int ints[] = { 2, 14 };
	// Handles remedy types with option yes / no
	private final int intsRemedyType[] = { 20, 21, 23, 24, 26 };

	public boolean insertEvent(HttpServletRequest request) {
		String insertQuery = "INSERT INTO employeedetails (" + tableParams[0];
		String insertQueryParams = ") values (?";
		for (int i = 1; i < tableParams.length; i++) {
			insertQuery += (", " + tableParams[i]);
			insertQueryParams += (", ?");
		}
		// DatabaseConnection dbConn = new DatabaseConnection();
		Connection con = null;
		PreparedStatement statement = null;
		int recordsInserted = 0;
		int remedyWildCards = 0;
		String resource = "";
		boolean status = false;
		String userName = (String) request.getSession().getAttribute("name");
		if (userName == null || userName.trim().equals(""))
			userName = "unKnown";
		
		try {
			// con.setAutoCommit(false);
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement(insertQuery + insertQueryParams + ")");
			int i = 0;
			for (; i < tableParams.length - 4; i++) {
				if (isTypeInt(i))
					statement.setInt(i + 1, Integer.parseInt(request.getParameter(pageParams[i])));
				else if (isRemedyType(i)) {

					if (request.getParameter(pageParams[i]).equals("Yes"))
						statement.setString(i + 1, request.getParameter(pageRemedyParams[remedyWildCards]));
					else
						statement.setString(i + 1, null);
					remedyWildCards++;
				} else if (i == 4) {
					resource = request.getParameter(pageParams[0]) + " - " + request.getParameter(pageParams[2]);
					statement.setString(i + 1, resource);
				} else if (i == 11)
					statement.setString(i + 1,
							request.getParameter(getLocationFieldName(request.getParameter(pageParams[10]))));
				else if(i == 31)
					statement.setString(i + 1, userName);
				else
					statement.setString(i + 1, request.getParameter(pageParams[i]));
			}
			statement.setString(++i, (String) request.getSession().getAttribute("enterpriseId"));
			statement.setInt(++i, Util.ONBOARDED);
			statement.setBoolean(++i, true);
			statement.setString(++i, "employee");
			recordsInserted = statement.executeUpdate();


			if (recordsInserted == 1 && insertTaskDetails("Roll On Request", resource, userName, "rollOn")) {
				con.commit();
				status = true;
			} else {
				con.rollback();
				status = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		} finally {
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}
		return status;
	}

	public boolean updateOnBoardingDetails(HttpServletRequest request, String prevResourceName) {
		// DatabaseConnection dbConn = new DatabaseConnection();
		Connection con = null;
		PreparedStatement statement = null;
		int recordsUpdated = 0;
		String resource = "";
		int remedyWildCards = 0;
		boolean status = false;
		
		try {
			// con.setAutoCommit(false);
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement(getUpdateQuery());
			String userName = (String) request.getSession().getAttribute("name");
			if (userName == null || userName.trim().equals(""))
				userName = "unKnown";
			int i = 0;
			for (; i < tableParams.length - 4; i++) {
				if (isTypeInt(i))
					statement.setInt(i + 1, Integer.parseInt(request.getParameter(pageParams[i])));
				else if (isRemedyType(i)) {

					if (request.getParameter(pageParams[i]).equals("Yes"))
						statement.setString(i + 1, request.getParameter(pageRemedyParams[remedyWildCards]));
					else
						statement.setString(i + 1, null);
					remedyWildCards++;
				} else if (i == 4) {
					resource = request.getParameter(pageParams[0]) + " - " + request.getParameter(pageParams[2]);
					statement.setString(i + 1, resource);
				} else if (i == 11)
					statement.setString(i + 1,
							request.getParameter(getLocationFieldName(request.getParameter(pageParams[10]))));
				else
					statement.setString(i + 1, request.getParameter(pageParams[i]));
			}
			statement.setString(++i, (String) request.getSession().getAttribute("enterpriseId"));
			statement.setInt(++i, Util.ONBOARDED);
			statement.setInt(++i, Integer.parseInt(request.getParameter(pageParams[2])));
			recordsUpdated = statement.executeUpdate();
			System.out.println("STMT: " + statement.toString());
			if (recordsUpdated == 1
					&& updateTaskDetails("Roll On Request", resource, userName, "rollOn", prevResourceName)) {
				con.commit();
				status = true;
			} else {
				con.rollback();
				status = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		} finally {
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}
		return status;
	}

	public boolean updateRollOff(TableDetail td) {
		// DatabaseConnection dbConn = new DatabaseConnection();
		Connection connection = null;
		PreparedStatement statement = null;
		int recordsUpdated = 0;
		boolean status = false;
		try {
			// connection = dbConn.mySqlConnection();
			// connection.setAutoCommit(false);
			connection = DatabaseConnection.getRAWConnection();
			statement = connection.prepareStatement(updateQuery);
			statement.setString(1, td.getRolloffDate());
			statement.setString(2, td.getRolloffReason());
			statement.setBoolean(3, td.isExit());
			statement.setInt(4, td.getEmployeeStatus());
			statement.setInt(5, td.getEmpId());
			recordsUpdated = statement.executeUpdate();
			if (recordsUpdated == 1 && updateTaskDetailsRollOff(td.getRname(),td.getTaskCompletedBy())) {
				connection.commit();
				status = true;
			} else {
				connection.rollback();
				status = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		} finally {
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}
		return status;
	}

	public boolean insertTaskDetails(String taskName, String resource, String requestor, String requestType) {
		TableDetail td = new TableDetail();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		td.setTaskName(taskName);
		Date date = new Date();
		Date endDate = null;
		td.setAssignedDate(dateFormat.format(date).toString());
		td.setTaskDescription(resource);
		//Setting default task deadlines as per task type!
		if(requestType.equalsIgnoreCase("rollOn")) {
			endDate = new Date(date.getTime() + 1210000000);
		} else {
			endDate = new Date(date.getTime() + 172800000);
			
		}
		td.setEndDate(dateFormat.format(endDate).toString());
		td.setStatus("Pending");
		td.setAssignedBy(requestor);
		td.setRequestType(requestType);
		td.setTaskCompletedBy(requestor);
		InsertTaskDetails i = new InsertTaskDetails();
		if (i.insertTaskDetails(td).equals("true"))
			return true;
		else
			return false;

	}
	
	
	
	public boolean insertTaskDetailsForRollOff(String taskName, String resource, String requestor, String requestType,String taskEndDate) {
		TableDetail td = new TableDetail();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		long endDate = Date.parse(taskEndDate);
		Date eDate1 = new Date(endDate);
		td.setTaskName(taskName);
		td.setAssignedDate(dateFormat.format(date).toString());
		td.setTaskDescription(resource);
		td.setEndDate(dateFormat.format(eDate1).toString());
		td.setStatus("Pending");
		td.setAssignedBy(requestor);
		td.setRequestType(requestType);
		td.setTaskCompletedBy(requestor);
		InsertTaskDetails i = new InsertTaskDetails();
		if (i.insertTaskDetails(td).equals("true"))
			return true;
		else
			return false;

	}
	
	
	

	public boolean updateTaskDetailsRollOff(String resource,String taskCompletedby) {
		TableDetail td = new TableDetail();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		td.setTaskName("Roll Off Request");
		Date date = new Date();
		td.setTaskDescription(resource);
		Date endDate = new Date(date.getTime());
		td.setEndDate(dateFormat.format(endDate).toString());
		td.setTaskCompletedBy(taskCompletedby);
		InsertTaskDetails updateTask = new InsertTaskDetails();
		if (updateTask.updateRequestTasks(td))
			return true;
		else
			return false;

	}

	public boolean updateTaskDetails(String taskName, String resource, String requestor, String requestType,
			String prevTaskDesc) {
		TableDetail td = new TableDetail();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		td.setTaskName(taskName);
		Date date = new Date();
		td.setAssignedDate(dateFormat.format(date).toString());
		td.setTaskDescription(resource);
		Date endDate = new Date(date.getTime() + 172800000);
		td.setEndDate(dateFormat.format(endDate).toString());
		td.setStatus("Pending");
		td.setAssignedBy(requestor);
		td.setRequestType(requestType);
		td.setTaskCompletedBy(requestor);
		InsertTaskDetails i = new InsertTaskDetails();
		if (i.updateTaskDetails(td, prevTaskDesc))
			return true;
		else
			return false;

	}

	private String getLocationFieldName(String siteLocation) {
		String currentLocation = "";
		if (siteLocation != null && !siteLocation.trim().equals("")) {
			if (siteLocation.equals("Onshore"))
				currentLocation = "onshorecurrLocation";
			else if (siteLocation.equals("IDC"))
				currentLocation = "offshoreLocation";
			else
				currentLocation = "pdclocation";
		}
		return currentLocation;

	}

	boolean isTypeInt(int i) {
		for (int j = 0; j < ints.length; j++) {
			if (i == ints[j]) {
				return true;
			}
		}
		return false;
	}

	boolean isRemedyType(int i) {
		for (int j = 0; j < intsRemedyType.length; j++) {
			if (i == intsRemedyType[j]) {
				return true;
			}
		}
		return false;
	}

	boolean isEmployeeExisting(int employeeId) {

		// DatabaseConnection dbConn = new DatabaseConnection();
		// Connection con = dbConn.mySqlConnection();
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		int recordCount = 0;
		boolean status = false;
		try {
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement(selectQuery);
			statement.setInt(1, employeeId);
			rs = statement.executeQuery();
			if (rs.next())
				recordCount = rs.getInt(1);
			if (recordCount >= 1)
				status = true;
			else
				status = false;
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}

		return status;

	}

	public void getEmployeeDetails(HttpServletResponse response, int employeeId) {
		// PreparedStatement statement = null;
		try {
			String employeeDetails = getEmployeeDetailsJson(employeeId);
			response.setContentType("application/json");
			response.getWriter().write(employeeDetails);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// dbConn.closeConnection(con, statement, null);
		}

	}

	public String getEmployeeDetailsJson(int employeeId) {
		// DatabaseConnection dbConn = new DatabaseConnection();
		// Connection con = dbConn.mySqlConnection();
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		HashMap<String, String> employeeDetail = new HashMap<String, String>();
		try {
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement(getSelectQuery());
			statement.setInt(1, employeeId);
			rs = statement.executeQuery();
			if (rs.next()) {
				employeeDetail.put(pageParams[0], rs.getString(tableParams[0]));
				int remedyWildCards = 0;
				for (int i = 1; i < pageParams.length; i++) {
					if (isRemedyType(i)) {
						if (remedyWildCards == 2) {
							String pattern = Util.checkForNull(rs.getString(tableParams[i]));
							String data[] = {};
							if (pattern != null && !pattern.trim().equals("")) {
								employeeDetail.put(pageParams[i], "Yes");
								data = pattern.split("\\^");
							} else
								employeeDetail.put(pageParams[i], "No");
							ArrayList<String> parameters = new ArrayList<String>();

							for (int j = 0; j < data.length; j++) {
								parameters.add(data[j]);
							}
							employeeDetail.put(pageRemedyParams[remedyWildCards], parameters.toString());
						} else {
							String pattern = Util.checkForNull(rs.getString(tableParams[i]));
							if (pattern != null && !pattern.trim().equals("")) {
								employeeDetail.put(pageParams[i], "Yes");
								employeeDetail.put(pageRemedyParams[remedyWildCards], pattern);
							} else {
								employeeDetail.put(pageParams[i], "No");
								employeeDetail.put(pageRemedyParams[remedyWildCards], "");
							}
						}

						remedyWildCards++;
					} 
					else {
						employeeDetail.put(pageParams[i], Util.checkForNull(rs.getString(tableParams[i])));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeConnection(con, statement, rs);
		}
		return new Gson().toJson(employeeDetail);
	}

	private String getSelectQuery() {
		String selectQuery = "select " + tableParams[0];
		for (int i = 1; i < tableParams.length; i++) {
			selectQuery += (", " + tableParams[i]);
		}
		selectQuery += " from employeedetails where employeenumber = ?";
		return selectQuery;
	}

	private String getUpdateQuery() {
		StringBuilder updateQuery = new StringBuilder("update employeedetails set ");
		updateQuery.append(tableParams[0] + " = ?");
		for (int i = 1; i < tableParams.length-2; i++) {
			updateQuery.append(", " + tableParams[i] + " = ?");
		}
		updateQuery.append(" where employeenumber = ?");
		return updateQuery.toString();
	}

}

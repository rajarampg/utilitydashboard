package com.pmo.dboperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.pmo.commons.AESencrp;
import com.pmo.connection.DatabaseConnection;

public class NewLoginDAO {
	
	public int validateFirstLogin(String name, String pass, String role)
			throws Exception {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String usertype = null;
		int val = 0;

		con = DatabaseConnection.getRAWConnection();
		try {

			pst = con.prepareStatement("select * from employeedetails where enterpriseid=? and employeenumber=?");
			pst.setString(1, name);
			pst.setString(2, pass);

			rs = pst.executeQuery();
			if (rs.next()) {
				usertype = rs.getString("employee_type");
				if (usertype != null
						&& usertype.trim().equalsIgnoreCase(role.trim())){
					val = 1;
					if((insertDetailsIntoLogin(name,pass,usertype)) == 1){
						System.out.println("Successfully inserted values into login table!");
					} else {
						System.out.println("Error while inserting values into login table!");
					}
				} else {
					val = 2;
					System.out.println("Invalid user type!!");
				}
				
			} else {
				val = 0;
				System.out.println("Unable to fetch employee type from employeedetails table!");
			}
				
			

		} catch (SQLException e) {
			System.out
					.println("SQl Exception occured while validation login user"
							+ e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Exception occured while validation login user"
					+ e.getMessage());
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}

		return val;
	}
	
	
	
	public boolean getLoginStatus(String entID) throws SQLException {

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		boolean userid = false;

		con = DatabaseConnection.getRAWConnection();

		try {

			pst = con.prepareStatement("select firsttimeuser from employeedetails where enterpriseid=?");
//			pst.setInt(1, Integer.parseInt(password));
			pst.setString(1, entID);

			rs = pst.executeQuery();
			if (rs.next()) {
				userid = rs.getBoolean("firsttimeuser");
			}else{
				System.out.println("Not a first time user!!");
			}
		} catch (SQLException e) {
			System.out
					.println("SQl Exception occured while fetching user type"
							+ e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Exception occured while fetching user type"
					+ e.getMessage());
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}

		return userid;
	}
	
	
	public int updateFirstTimeUserInDb(String password) throws SQLException {

		Connection con = null;
		PreparedStatement pst = null;
		int rs=0;

		con = DatabaseConnection.getRAWConnection();

		try {

			pst = con.prepareStatement("update employeedetails set firsttimeuser='false' where employeenumber=?");
			pst.setString(1, password);
			

			rs = pst.executeUpdate();
			con.commit();
		} catch (SQLException e) {
			System.out
					.println("SQl Exception occured while updating first time login"
							+ e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Exception occured while updating first time login"
					+ e.getMessage());
			e.printStackTrace();
		} finally {
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return rs;
	}

	public int insertDetailsIntoLogin(String enterpriseId,String password,String userType) throws Exception {

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int retVal =0;

		con = DatabaseConnection.getRAWConnection();
		AESencrp encryDecry = new AESencrp();
		password = encryDecry.encrypt(password);

		try {

			pst = con.prepareStatement("insert into login(username,password,usertype,enterpriseid) values (?,?,?,?)");
			pst.setString(1, enterpriseId);
			pst.setString(2, password);
			pst.setString(3, userType);
			pst.setString(4, enterpriseId);
			retVal = pst.executeUpdate();
			con.commit();
		} catch (SQLException e) {
			System.out
					.println("SQl Exception occured while inserting values into login table"
							+ e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Exception occured while inserting values into login table"
					+ e.getMessage());
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return retVal;
	}
	
	public boolean validateLogin(String name, String pass)
			throws Exception {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		boolean val= false;

		con = DatabaseConnection.getRAWConnection();
		AESencrp encryDecry = new AESencrp();
		pass = encryDecry.encrypt(pass);

		try {

			pst = con.prepareStatement("select * from login where enterpriseid=? and password=?");
			pst.setString(1, name);
			pst.setString(2, pass);

			rs = pst.executeQuery();
			val= rs.next();
			

		} catch (SQLException e) {
			System.out
					.println("SQl Exception occured while validation login user"
							+ e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Exception occured while validation login user"
					+ e.getMessage());
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return val;

	}
	
	
	public int updatePasswordAfterInitialLogin(String userName,String currentPassword, String newPassword)
			throws Exception {
		Connection con = null;
		PreparedStatement pst = null;
		int rs = 0;

		con = DatabaseConnection.getRAWConnection();
		AESencrp encryDecry = new AESencrp();
		newPassword = encryDecry.encrypt(newPassword);

		try {

			pst = con.prepareStatement("update login set password =? where username =?");
			pst.setString(1, newPassword);
			pst.setString(2, userName);

			rs = pst.executeUpdate();
			con.commit();
			if(rs == 1){
				if(getLoginStatus(userName)){
					int firstUserflag= updateFirstTimeUserInDb(currentPassword);
					if(firstUserflag==1){
						System.out.println("First time login user flag is modified!");
					} else {
						System.out.println("Error updating first time login user flag!");
					}
				} else {
					System.out.println("Updating password!!");
				}
				
			} else {
				System.out.println("Unable to update the password! No resultset returned!!");
			}

		} catch (SQLException e) {
			System.out
					.println("SQl Exception occured while resetting password"
							+ e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Exception occured while resetting password"
					+ e.getMessage());
			e.printStackTrace();
		} finally {
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return rs;
	}
	
	public String getUserRole(String entID) throws SQLException {

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String userid = null;

		con = DatabaseConnection.getRAWConnection();

		try {

			pst = con.prepareStatement("select employee_type from employeedetails where enterpriseid=?");
//			pst.setInt(1, Integer.parseInt(password));
			pst.setString(1, entID);

			rs = pst.executeQuery();
			if (rs.next()) {
				userid = rs.getString("employee_type");
			}else{
				System.out.println("No employee type found!!");
			}
		} catch (SQLException e) {
			System.out
					.println("SQl Exception occured while fetching user type"
							+ e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Exception occured while fetching user type"
					+ e.getMessage());
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}

		return userid;
	}
	
}

/**
 * @author s.ghouse.mohideen
 */
package com.pmo.dboperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.postgresql.util.PGobject;

import com.google.gson.Gson;
import com.pmo.connection.DatabaseConnection;
import com.pmo.login.Assessment;
import com.pmo.login.AssessmentJson;

/**
 * @author s.ghouse.mohideen
 *
 */
public class InsertAssessmentDetails {

	boolean status  = false;
	Date date = new Date();
	Timestamp timestamp = new Timestamp(date.getTime());
	private final String selectQuery = "select * from assessment_qa_pool  where technology=? and difficulty_level=? order by random() limit 20";
	private final String startAssessmentQuery = "insert into assessment_answer_pool(employeeid,stream,answers,technology, difficulty_level, status, exam_id , date)values(?,?,?,?,?,?,currval('AWARD_ID'),current_timestamp)";
	private final String updateAssessmentQuery = "update assessment_answer_pool set answers =? ,status = ?, date = current_timestamp,marks_secured=? where employeeid = ? and exam_id = ?";
	private final String insertQuery="insert into assessment_qa_pool(questions,technology,difficulty_level,date) values(?,?,?,?)";
	private final String evaluateList = "select  employeeid +' - '+exam_id+'  '+ stream from assessment_answer_pool where status = 3";
	private final String smeEvaluateDetails = "select * from assessment_answer_pool where employeeid = ? and exam_id = ? ";
	
	public boolean getAssessment(Assessment assessment) {
		Connection con = null;
		PreparedStatement statement = null;
		boolean status = false;
		ResultSet rs = null;
		HashMap<String, String> hm = new HashMap<String, String>();
		ArrayList<AssessmentJson> questionsList = null;
		try {
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement(selectQuery);
			statement.setString(1, assessment.getTechnology());
			statement.setString(2, assessment.getDifficultyLevel());
			rs = statement.executeQuery();
			hm = new HashMap<String, String>();
			questionsList = new ArrayList<AssessmentJson>();  
			while (rs.next()) {
				AssessmentJson json = new AssessmentJson();
				json.setQuestionId(rs.getInt("question_id"));
				json.setQuestion(rs.getString("questions"));
				questionsList.add(json);
			}
			PGobject pgObject = new PGobject();
			pgObject.setType("json");
			pgObject.setValue(new Gson().toJson(hm));
			assessment.setAnswers(pgObject);
			assessment.setJsonAnswers(questionsList);
			assessment.setAssessmentStatus(1);
			if(insertAssessmentDetails(assessment))
				status = true;
			else
				status = false;
		} catch (SQLException e) {
			e.printStackTrace();
			status = false;
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}
		return status;
	}
	
	public ArrayList<String> getAssessmentList(){
	Connection con = null;
	PreparedStatement statement = null;
	ResultSet rs = null;
	ArrayList<String> resourceList = null;
	try {
		con = DatabaseConnection.getRAWConnection();
		statement = con.prepareStatement(evaluateList);
		rs = statement.executeQuery();
		resourceList = new ArrayList<String>();
		while (rs.next()) {
			resourceList.add(rs.getString(1));
		}
	} catch (SQLException e) {
		e.printStackTrace();
		resourceList = null;
	} catch (Exception e) {
		e.printStackTrace();
		resourceList = null;
	} finally {
		DatabaseConnection.closeRs(rs);
		DatabaseConnection.closePst(statement);
		DatabaseConnection.closeCon(con);
	}
	return resourceList;
	}
	
	
	

	public Assessment getAssessmentDetails(Assessment assessment){
	Connection con = null;
	PreparedStatement statement = null;
	ResultSet rs = null;
	ArrayList<AssessmentJson> answersList = null;
	try {
		con = DatabaseConnection.getRAWConnection();
		statement = con.prepareStatement(smeEvaluateDetails);
		statement.setInt(1, assessment.getEmpId());
		statement.setInt(2, assessment.getExamId());
		rs = statement.executeQuery();
		if (rs.next()) {
			assessment.setStream(rs.getString("stream"));
			assessment.setAnswers((PGobject)rs.getObject("answers"));
			assessment.setTechnology(rs.getString("technology"));
			assessment.setDifficultyLevel(rs.getString("difficulty_level"));
			assessment.setAssessmentStatus(rs.getInt("status"));
		}
		ObjectMapper objectMapper = new ObjectMapper();
		answersList = objectMapper.readValue(assessment.getAnswers().toString(), new TypeReference<List<AssessmentJson>>() {});
		assessment.setJsonAnswers(answersList);
	} catch (SQLException e) {
		e.printStackTrace();
		return null;
	} catch (Exception e) {
		e.printStackTrace();
		return null;
	} finally {
		DatabaseConnection.closeRs(rs);
		DatabaseConnection.closePst(statement);
		DatabaseConnection.closeCon(con);
	}
	return assessment;
}

	

	public boolean insertAssessmentDetails(Assessment assessment) {
		Connection con = null;
		PreparedStatement statement = null;
		PGobject pgObject = null;
		boolean status = false;
		try {
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement(startAssessmentQuery);
			statement.setInt(1, assessment.getEmpId());
			statement.setString(2,assessment.getStream());
			statement.setObject(3, assessment.getAnswers());
			statement.setString(4,assessment.getTechnology());
			statement.setString(5,assessment.getDifficultyLevel());
			int examId = updateRewardId(con); 
			if(examId == -1)
				throw new Exception("Error generating reward id");
			assessment.setExamId(examId);
			statement.setInt(6, assessment.getAssessmentStatus());
			int recordsInserted = statement.executeUpdate();
			if (recordsInserted == 1){
				con.commit();
				status = true;
			}
			else{
				con.rollback();
				status = false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			status = false;
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		} finally {
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);

		}
		return status;

	}
	
	
	public boolean updateAssessment(Assessment assessment) {
		Connection con = null;
		PreparedStatement statement = null;
		PGobject pgObject = null;
		try {
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement(updateAssessmentQuery);
			statement.setString(2,assessment.getStream());
			String json = new Gson().toJson(assessment.getJsonAnswers());
			pgObject = new PGobject();
			pgObject.setType("json");
			pgObject.setValue(json);
			statement.setObject(1, pgObject);
			statement.setInt(2, assessment.getAssessmentStatus());
			statement.setInt(3,assessment.getMarks());
			statement.setInt(4, assessment.getEmpId());
			statement.setInt(5, assessment.getExamId());
			int recordsUpdated = statement.executeUpdate();
			if (recordsUpdated == 1){
				con.commit();
				status = true;
			}
			else{
				con.rollback();
				status = false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			status = false;
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		} finally {
			DatabaseConnection.closePst(statement);
			
			DatabaseConnection.closeCon(con);
		}
		return status;

	}
	
/*public boolean	updateSmeAssessment(Assessment assessment){
	Connection con = null;
	PreparedStatement statement = null;
	PGobject pgObject = null;
		
	try {
		con = DatabaseConnection.getRAWConnection();
		statement = con.prepareStatement(updateAssessmentQuery);
		statement.setString(2,assessment.getStream());
		String json = new Gson().toJson(assessment.getJsonAnswers());
		pgObject = new PGobject();
		pgObject.setType("json");
		pgObject.setValue(json);
		statement.setObject(1, pgObject);
		statement.setInt(2, assessment.getAssessmentStatus());
		statement.setInt(3,assessment.getMarks());
		statement.setInt(4, assessment.getEmpId());
		statement.setInt(5, assessment.getExamId());
		int recordsUpdated = statement.executeUpdate();
		if (recordsUpdated == 1){
			con.commit();
			status = true;
		}
		
		else{
			con.rollback();
			status = false;
		}
	}
	catch (Exception e) {
		// TODO: handle exception
	}
		return status;
	}
	*/
	
public String postquestion(String questions,String technology,String difficulty){
	String status = "false";
	Connection con = null;
	PreparedStatement statement = null;
	try {
		con = DatabaseConnection.getRAWConnection();
		statement = con.prepareStatement(insertQuery);
		statement.setString(1,questions);
		statement.setString(2,technology);
		statement.setString(3,difficulty);
	//	statement.setTimestamp(4,timestamp);
		int recordsInserted=statement.executeUpdate();
		if(recordsInserted ==1){
			status="true";
			con.commit();
		}
		else{
			status = "false";
			con.rollback();
		}
	} catch (SQLException e) {
		status = "false";
		e.printStackTrace();
	}
	catch (Exception e) {
		status = "false";
		e.printStackTrace();
	}
	finally{
		DatabaseConnection.closePst(statement);
		DatabaseConnection.closeCon(con);
	}
		return status;
		
	}	



public int updateRewardId(Connection con) {
	int examId = -1;
	PreparedStatement pst = null;
	ResultSet rs = null;
	try {

		String generateId = "SELECT nextval('AWARD_ID')";
		pst = con.prepareStatement(generateId);
		rs = pst.executeQuery();
		if(rs.next())
			examId = rs.getInt(1);
	}

	catch (SQLException e) {
		e.printStackTrace();

	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		DatabaseConnection.closePst(pst);
	}
	return examId;

}

}

/**
 * 
 */
package com.pmo.dboperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.pmo.connection.DatabaseConnection;
import com.pmo.login.EventDetails;

public class InsertEventDetails {

	// DatabaseConnection dbConn = new DatabaseConnection();
	Connection con = null;
	PreparedStatement pst = null;
	Statement st = null;
	ResultSet rs = null;
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
	Date date;

	private final String selectQuery = "select * from events order by event_start_time";
	private final String selectEventQuery = "select * from events where event_id = ?";
	private final String insertQuery = "INSERT INTO events (event_name,initiator,event_description,event_start_time,hrs,mins) VALUES (?,?,?,?,?,?)";
	private final String COLUMN_EVENT_ID = "event_id";
	private final String COLUMN_EVENT_NAME = "event_name";
	private final String COLUMN_INITIATOR = "initiator";
	private final String COLUMN_DESCRIBE_EVENT = "event_description";
	private final String COLUMN_EVENT_START = "event_start_time";
	private final String COLUMN_EVENT_HRS = "hrs";
	private final String COLUMN_EVENT_MINS = "mins";

	/*
	 * public static void main(String args[]){ SimpleDateFormat dateFormat = new
	 * SimpleDateFormat("MM/dd/yyyy hh:mm a"); try { // 06/16/2015 8:13 PM //
	 * 24/12/2011 18:54:23 long qu = dateFormat.parse("06/16/2015 8:13 PM"
	 * ).getTime(); Timestamp ts = new Timestamp(qu); System.out.println(ts);
	 * Date date = new Date(qu); System.out.println(dateFormat.format(date)); }
	 * catch (ParseException e) { e.printStackTrace(); } }
	 */

	public boolean insertEvent(EventDetails eventDetails) {
		// DatabaseConnection dbConn = new DatabaseConnection();
		Connection con = null;
		PreparedStatement statement = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		boolean status = false;
		try {
			// con.setAutoCommit(false);
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement(insertQuery);
			statement.setString(1, eventDetails.getTitle());
			statement.setString(2, eventDetails.getInitiator());
			statement.setString(3, eventDetails.getEventDesc());
			long startTimeInMillis = dateFormat.parse(eventDetails.getStartTime()).getTime();
			Timestamp startTime = new Timestamp(startTimeInMillis);
			statement.setTimestamp(4, startTime);
			statement.setInt(5, eventDetails.getHrs());
			statement.setInt(6, eventDetails.getMins());
			int recordsInserted = statement.executeUpdate();
			if (recordsInserted == 1) {
				status = true;
				con.commit();
			} else {
				status = false;
				con.rollback();
			}

		} catch (SQLException e) {
			e.printStackTrace();
			status = false;
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		} finally {
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}

		return status;

	}

	public List<EventDetails> getAllEvents() {
		// DatabaseConnection dbConn = new DatabaseConnection();
		// Connection con = dbConn.mySqlConnection();
		Connection con = null;
		PreparedStatement statement = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
		ResultSet rs = null;
		EventDetails eventDetails = null;
		List<EventDetails> eventsList = new ArrayList<EventDetails>();
		try {
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement(selectQuery);
			rs = statement.executeQuery();
			while (rs.next()) {
				eventDetails = new EventDetails();
				eventsList.add(eventDetails);
				eventDetails.setId(rs.getInt(COLUMN_EVENT_ID));
				eventDetails.setTitle(rs.getString(COLUMN_EVENT_NAME));
				eventDetails.setInitiator(rs.getString(COLUMN_INITIATOR));
				String description = rs.getString(COLUMN_DESCRIBE_EVENT);
				description = description.replaceAll("\\\"", "\\\\\"");
				eventDetails.setEventDesc(description);
				int hrs = rs.getInt(COLUMN_EVENT_HRS);
				int mins = rs.getInt(COLUMN_EVENT_MINS);
				eventDetails.setHrs(hrs);
				eventDetails.setMins(mins);
				Timestamp startTime = rs.getTimestamp(COLUMN_EVENT_START);
				eventDetails.setStart(startTime.getTime());
				long endTime = eventDetails.getStart() + (hrs * 60 * 60 * 1000) + (mins * 60 * 1000);
				eventDetails.setEnd(endTime);
				Date startDate = new Date(eventDetails.getStart());
				eventDetails.setStartTime(dateFormat.format(startDate));
				eventDetails.setDuration(hrs + " hrs " + mins + " mins");
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}
		return eventsList;
	}

	public EventDetails getEventDetails(String eventId) {
		// DatabaseConnection dbConn = new DatabaseConnection();
		// Connection con = dbConn.mySqlConnection();
		Connection con = null;
		PreparedStatement statement = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
		ResultSet rs = null;
		EventDetails eventDetails = null;
		try {
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement(selectEventQuery);
			statement.setInt(1, Integer.parseInt(eventId.trim()));
			rs = statement.executeQuery();
			while (rs.next()) {
				eventDetails = new EventDetails();
				eventDetails.setId(rs.getInt(COLUMN_EVENT_ID));
				eventDetails.setTitle(rs.getString(COLUMN_EVENT_NAME));
				eventDetails.setInitiator(rs.getString(COLUMN_INITIATOR));
				String description = rs.getString(COLUMN_DESCRIBE_EVENT);
				description = description.replaceAll("\\\"", "\\\\\"");
				eventDetails.setEventDesc(description);
				int hrs = rs.getInt(COLUMN_EVENT_HRS);
				int mins = rs.getInt(COLUMN_EVENT_MINS);
				eventDetails.setHrs(hrs);
				eventDetails.setMins(mins);
				Timestamp startTime = rs.getTimestamp(COLUMN_EVENT_START);
				eventDetails.setStart(startTime.getTime());
				long endTime = eventDetails.getStart() + (hrs * 60 * 60 * 1000) + (mins * 60 * 1000);
				eventDetails.setEnd(endTime);
				Date startDate = new Date(eventDetails.getStart());
				eventDetails.setStartTime(dateFormat.format(startDate));
				eventDetails.setDuration(hrs + " hrs " + mins + " mins");
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}
		return eventDetails;
	}

}

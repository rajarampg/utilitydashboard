package com.pmo.dboperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;

import org.codehaus.jackson.map.ObjectMapper;
import org.postgresql.util.PGobject;

import com.google.gson.Gson;
import com.pmo.connection.DatabaseConnection;
import com.pmo.login.CheckList;

public class CheckListDAO {

	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	Date date;
    Timestamp timestamp;
    
    

	public boolean insertCheckListDetails(CheckList checkList){
		String insertTableSQL = "insert into rollon_checklist (employeenumber, checklist_details, status, acknowledge_time) VALUES(?,?,?,CURRENT_TIMESTAMP)";
		try {
			checkList.setStatus(1);
			con = DatabaseConnection.getRAWConnection();
			pst = con.prepareStatement(insertTableSQL);
			pst.setInt(1, checkList.getEmployeeId());
			pst.setString(2, new Gson().toJson(checkList).toString());
//			PGobject pgObject = new PGobject();
//			pgObject.setType("json");
//			pgObject.setValue(new Gson().toJson(checkList));
//			pst.setObject(2, pgObject);
			pst.setInt(3, checkList.getStatus());
			date= new java.util.Date();
			timestamp=new Timestamp(date.getTime());
			//pst.setTimestamp(4, timestamp);
			if(pst.executeUpdate() == 1){
				con.commit();
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DatabaseConnection.closeConnection(con, pst, null);
		}
		return false;
	}



	public boolean updateCheckListDetails(CheckList checkList)
	{
		String updateTableSQL = "UPDATE rollon_checklist SET CHECKLIST_DETAILS=?,status = ?,acknowledge_time=CURRENT_TIMESTAMP WHERE employeenumber=?";
		try {
			con = DatabaseConnection.getRAWConnection();
			checkList.setStatus(1);
			pst = con.prepareStatement(updateTableSQL);
			pst.setString(1, new Gson().toJson(checkList).toString());
//			PGobject pgObject = new PGobject();
//			pgObject.setType("json");
//			pgObject.setValue(new Gson().toJson(checkList));
//			pst.setObject(1, pgObject);
			pst.setInt(2, checkList.getStatus());
			date= new java.util.Date();
			timestamp=new Timestamp(date.getTime());
			//pst.setTimestamp(3, timestamp);
			pst.setInt(3, checkList.getEmployeeId());
			int updateCount = pst.executeUpdate();

			if(updateCount==1){
				con.commit();
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DatabaseConnection.closeConnection(con, pst, null);
		}
		return false;
	}

	
	public CheckList getCheckListDetails(String enterpriseId){
		
		String selectQuery = "select employeetable.employeenumber, employeetable.enterpriseid, employeetable.resourcename, employeetable.rollondate, employeetable.projectname,"
				+" employeetable.fullname, rollon_checklist.checklist_details, rollon_checklist.status from rollon_checklist right outer join"
				+" (select employeenumber, enterpriseid, resourcename, rollondate, projectname, concat(last_name,first_name) as  fullname from employeedetails where enterpriseid = ?)"
				+" employeetable on employeetable.employeenumber = rollon_checklist.employeenumber";

		CheckList checkList = null;
		try {
			con = DatabaseConnection.getRAWConnection();
			pst = con.prepareStatement(selectQuery);
			pst.setString(1, enterpriseId);
			rs = pst.executeQuery();
			if(rs.next()){
				ObjectMapper objectMapper = new ObjectMapper();
				String checkListDetails = rs.getString("checklist_details");
				if(checkListDetails!=null && !checkListDetails.trim().equals("")){
					checkList = objectMapper.readValue(checkListDetails, CheckList.class);
					checkList.setDataExisting(true);
				}else{
					checkList = new CheckList();
					checkList.setDataExisting(false);
					checkList.setProjectName(rs.getString("projectname"));
				}
				checkList.setEnterpriseId(enterpriseId);
				checkList.setFullName(rs.getString("fullname"));
				checkList.setStartDate(rs.getString("rollondate"));
				checkList.setResourceName(rs.getString("resourcename"));
				checkList.setEmployeeId(rs.getInt("employeenumber"));
				checkList.setStatus(rs.getInt("status"));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DatabaseConnection.closeConnection(con, pst, rs);
		}
		return checkList;
	}

	public boolean updateRollOffCheckListDetails(int employeeId)
	{
		String updateTableSQL = "UPDATE rollon_checklist SET status = ?,acknowledge_time=CURRENT_TIMESTAMP WHERE employeenumber=?";
		try {
			con = DatabaseConnection.getRAWConnection();
			pst = con.prepareStatement(updateTableSQL);
			pst.setInt(1, 2);
			date= new java.util.Date();
			timestamp=new Timestamp(date.getTime());
			//pst.setTimestamp(2, timestamp);
			pst.setInt(2, employeeId);
			int updateCount = pst.executeUpdate();
			if(updateCount==1){
				con.commit();
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DatabaseConnection.closeConnection(con, pst, null);
		}
		return false;
	}
	
	
	public HashMap<String, String> getRollOffCheckListDetails(String enterpriseId){
		
		String selectQuery = "select employeedetails.employeenumber, employeedetails.rolloffdate, employeedetails.resourcename, rollon_checklist.status"
								+" from employeedetails join rollon_checklist on rollon_checklist.employeenumber = employeedetails.employeenumber"
								+" where employeedetails.enterpriseid = ?";

		HashMap<String, String> rollOffDetails = null; 
		try {
			rollOffDetails = new HashMap<String, String>();
			con = DatabaseConnection.getRAWConnection();
			pst = con.prepareStatement(selectQuery);
			pst.setString(1, enterpriseId);
			rs = pst.executeQuery();
			if(rs.next()){
				rollOffDetails.put("employeeNumber", rs.getString("employeenumber"));
				rollOffDetails.put("resourceName", rs.getString("resourcename"));
				rollOffDetails.put("rollOffDate", rs.getString("rolloffdate"));
				rollOffDetails.put("status", rs.getString("status"));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DatabaseConnection.closeConnection(con, pst, rs);
		}
		return rollOffDetails;
	}

}
	




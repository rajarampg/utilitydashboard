package com.pmo.dboperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.pmo.connection.DatabaseConnection;
import com.pmo.login.OnBoardingFormDetails;

public class OnBoardingDetailsCreate {
	
	private  static final int employeeStatus = 1;
	private  static final int  employeeStatusUpd =2;
	private static final String employeeType ="employee";
	private static final boolean firstTimeUser = true;
	
	
	public static int onBoardingMemberDetailsUpdate(OnBoardingFormDetails obfDetails, String userLoggedIn){
		int responseCode=0;
		String resource = null;
		Date dNow = new Date( );
	    SimpleDateFormat ft = new SimpleDateFormat ("MM/dd/yyyy");
	    String currentDate=ft.format(dNow).toString();
		try {
			InsertOnboardingDetails insertIntoTask = new InsertOnboardingDetails();
			Connection con = DatabaseConnection.getRAWConnection();
			PreparedStatement ps=con.prepareStatement("update employeedetails set role_desc=?,delivery_centre=?,identifier_number=?,primary_skill=?,pattern_after=?,manager_id=?,contract_id=?,isrenew=?,resourcename=?,employee_status=?,employee_type=?,firsttimeuser=?,specificstream=?,onboarded_by=?,rate=?,director_id=?,vp_user_id=?,contractor_host_pattern=?,contractor_unix_pattern=?,unix_boxes=?,remedy_pattern=?,contractor_ad_pattern=?,ad_groups_shared=?,contractor_td_pattern=?,teradata_application=?,business_justification=?,onboard_start_date=? where employeenumber=?");
			resource = obfDetails.getFirstName()+ " - " +obfDetails.getEmployeeId();
			ps.setString(1, obfDetails.getRole());
			ps.setString(2, obfDetails.getLocation());
			ps.setString(3, obfDetails.getUniqueUserID());
			ps.setString(4, obfDetails.getSkill());
			ps.setString(5, obfDetails.getPatterAfter());
			ps.setString(6, obfDetails.getResourceManager());
			ps.setString(7, obfDetails.getContactId());
			ps.setString(8, obfDetails.getRenew());
			ps.setString(9, resource);
			ps.setLong(10, employeeStatusUpd);
			ps.setString(11, employeeType);
			ps.setBoolean(12, firstTimeUser);
			ps.setString(13, obfDetails.getPortfolio());
			ps.setString(14, userLoggedIn);
			ps.setDouble(15, obfDetails.getRate());
			ps.setString(16, obfDetails.getDirectorId());
			ps.setString(17, obfDetails.getVicePresId());
			ps.setString(18, obfDetails.getPatterAfter());
			ps.setString(19, obfDetails.getPatterAfter());
			ps.setString(20, obfDetails.getUnixBox());
			ps.setString(21, obfDetails.getPatterAfter());
			ps.setString(22, obfDetails.getPatterAfter());
			ps.setString(23, obfDetails.getAdAccess());
			ps.setString(24, obfDetails.getPatterAfter());
			ps.setString(25, obfDetails.getTeraDataBox());
			ps.setString(26, obfDetails.getBusinessJust());
			ps.setString(27, currentDate);
			ps.setLong(28, obfDetails.getEmployeeId());
			
			responseCode = ps.executeUpdate();
			if(responseCode == 1  && insertIntoTask.insertTaskDetails("WMT Onboard", resource, userLoggedIn, "rollOn")){
				con.commit();
			}else {
				con.rollback();
			}
			
			System.out.println("Response Code:" + responseCode);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return responseCode;
	}
	
	
	
	
    
	public static int onBoardingMemberDetailsInsert(OnBoardingFormDetails obfDetails, String userLoggedIn){
		int responseCode=0;
		String resource = null;
		Date dNow = new Date( );
	    SimpleDateFormat ft = new SimpleDateFormat ("MM/dd/yyyy");
	    String currentDate=ft.format(dNow).toString();
		try {
			InsertOnboardingDetails insertIntoTask = new InsertOnboardingDetails();
			Connection con = DatabaseConnection.getRAWConnection();
			PreparedStatement ps=con.prepareStatement("insert into employeedetails(employeenumber,enterpriseid,first_name,last_name,role_desc,delivery_centre,identifier_number,primary_skill,pattern_after,manager_id,contract_id,isrenew,resourcename,employee_status,employee_type,firsttimeuser,specificstream,onboarded_by,rate,director_id,vp_user_id,contractor_host_pattern,contractor_unix_pattern,unix_boxes,remedy_pattern,contractor_ad_pattern,ad_groups_shared,contractor_td_pattern,teradata_application,business_justification,onboard_start_date) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			resource = obfDetails.getFirstName()+ " - " +obfDetails.getEmployeeId();
			ps.setLong(1, obfDetails.getEmployeeId());
			ps.setString(2, obfDetails.getEnterpriseId());
			ps.setString(3, obfDetails.getFirstName());
			ps.setString(4, obfDetails.getLastName());
			ps.setString(5, obfDetails.getRole());
			ps.setString(6, obfDetails.getLocation());
			ps.setString(7, obfDetails.getUniqueUserID());
			ps.setString(8, obfDetails.getSkill());
			ps.setString(9, obfDetails.getPatterAfter());
			ps.setString(10, obfDetails.getResourceManager());
			ps.setString(11, obfDetails.getContactId());
			ps.setString(12, obfDetails.getRenew());
			ps.setString(13, resource);
			ps.setLong(14, employeeStatus);
			ps.setString(15, employeeType);
			ps.setBoolean(16, firstTimeUser);
			ps.setString(17, obfDetails.getPortfolio());
			ps.setString(18, userLoggedIn);
			ps.setDouble(19, obfDetails.getRate());
			ps.setString(20, obfDetails.getDirectorId());
			ps.setString(21, obfDetails.getVicePresId());
			ps.setString(22, obfDetails.getPatterAfter());
			ps.setString(23, obfDetails.getPatterAfter());
			ps.setString(24, obfDetails.getUnixBox());
			ps.setString(25, obfDetails.getPatterAfter());
			ps.setString(26, obfDetails.getPatterAfter());
			ps.setString(27, obfDetails.getAdAccess());
			ps.setString(28, obfDetails.getPatterAfter());
			ps.setString(29, obfDetails.getTeraDataBox());
			ps.setString(30, obfDetails.getBusinessJust());
			ps.setString(31, currentDate);
			
			responseCode = ps.executeUpdate();
			if(responseCode == 1 && insertIntoTask.insertTaskDetails("Roll On Request", resource, userLoggedIn, "rollOn")){
				con.commit();
			}else {
				con.rollback();
			}
			
			System.out.println("Response Code:" + responseCode);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return responseCode;
	}

	Connection con;
	PreparedStatement ps;
	public int onBoardingMultipleMembersDetailsInsert(OnBoardingFormDetails[] obfDetails, String userLoggedIn){
		int responseCode=0;
		String resource = null;
		Date dNow = new Date( );
	    SimpleDateFormat ft = new SimpleDateFormat ("MM/dd/yyyy");
	    String currentDate=ft.format(dNow).toString();
		InsertOnboardingDetails insertIntoTask = new InsertOnboardingDetails();
		try {
			con = DatabaseConnection.getRAWConnection();
			con.setAutoCommit(false);
			ps =con.prepareStatement("insert into employeedetails(employeenumber,enterpriseid,first_name,last_name,role_desc,delivery_centre,identifier_number,primary_skill,pattern_after,manager_id,contract_id,isrenew,resourcename,employee_status,employee_type,firsttimeuser,specificstream,onboarded_by,rate,director_id,vp_user_id,contractor_host_pattern,contractor_unix_pattern,unix_boxes,remedy_pattern,contractor_ad_pattern,ad_groups_shared,contractor_td_pattern,teradata_application,business_justification,onboard_start_date) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			for(OnBoardingFormDetails obf:obfDetails){
				resource = obf.getFirstName()+ " - " +obf.getEmployeeId();
				ps.setLong(1, obf.getEmployeeId());
				ps.setString(2, obf.getEnterpriseId());
				ps.setString(3, obf.getFirstName());
				ps.setString(4, obf.getLastName());
				ps.setString(5, obf.getRole());
				ps.setString(6, obf.getLocation());
				ps.setString(7, obf.getUniqueUserID());
				ps.setString(8, obf.getSkill());
				ps.setString(9, obf.getPatterAfter());
				ps.setString(10, obf.getResourceManager());
				ps.setString(11, obf.getContactId());
				ps.setString(12, obf.getRenew());
				ps.setString(13, resource);
				ps.setLong(14, employeeStatus);
				ps.setString(15, employeeType);
				ps.setBoolean(16, firstTimeUser);
				ps.setString(17, obf.getPortfolio());
				ps.setString(18, userLoggedIn);
				ps.setDouble(19, obf.getRate());
				ps.setString(20, obf.getDirectorId());
				ps.setString(21, obf.getVicePresId());
				ps.setString(22, obf.getPatterAfter());
				ps.setString(23, obf.getPatterAfter());
				ps.setString(24, obf.getUnixBox());
				ps.setString(25, obf.getPatterAfter());
				ps.setString(26, obf.getPatterAfter());
				ps.setString(27, obf.getAdAccess());
				ps.setString(28, obf.getPatterAfter());
				ps.setString(29, obf.getTeraDataBox());
				ps.setString(30, obf.getBusinessJust());
				ps.setString(31, currentDate);
				ps.addBatch();
				System.out.println("Added insert stmts to batch");
			}
			int[] count = ps.executeBatch();
			boolean dbInsertionState= checkAllRowsInsertion(count);
			if(dbInsertionState){
				System.out.println("Commiting to DB");
				con.commit();
				responseCode = 1;
				for(OnBoardingFormDetails obf:obfDetails){
					resource = obf.getFirstName()+ " - " +obf.getEmployeeId();
					if(responseCode == 1 && insertIntoTask.insertTaskDetails("Roll On Request", resource, userLoggedIn, "rollOn")){
						System.out.println("Committed to tasks table!");
					} else{
						System.out.println("Error committing multiple values into tasks table!");
					}
				}
			} else {
				System.out.println("Not commiting to DB");
				con.rollback();
				responseCode = 0;
			}
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	
		
		return responseCode;
	}
	
	private boolean checkAllRowsInsertion(int[] batchArray){
		boolean success = false;
		for(int arrayVal:batchArray){
			if(arrayVal == 1){
				success = true;
			}else {
				success = false;
				break;
			}
		}
		return success;
	}
	
	public boolean fetchPatternAfterValues(OnBoardingFormDetails obfDetails){
		boolean retVal = false;
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		try {
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement("select * from patterndetails where skill=?");
			statement.setString(1, obfDetails.getSkill());
			rs = statement.executeQuery();
			if (rs.next()){
				obfDetails.setRequestFor(rs.getString("request_for"));
				obfDetails.setSpecificAccessRequests(rs.getString("specific_access_request"));
				obfDetails.setUnixBox(rs.getString("unix_boxes"));
				obfDetails.setTeraDataBox(rs.getString("teradata_box"));
				obfDetails.setClarityAccess(rs.getString("clarity_access"));
				obfDetails.setAdAccess(rs.getString("ad_access"));
				obfDetails.setAdditionalDetailsAction(rs.getString("additionaldetails_action"));
				System.out.println("Pattern details set successfully!");
				retVal= true;
			} else {
				System.out.println("Error: no resultset found!!");
			}
				
			
		} catch (Exception e) {
			e.printStackTrace();
			retVal = false;
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}
		
		
		return retVal;
	}
	
	public boolean fetchRateDetails(OnBoardingFormDetails obfDetails){
		boolean retVal = false;
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		try {
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement("select * from roledetails where role=? and location=?");
			statement.setString(1, obfDetails.getRole());
			statement.setString(2, obfDetails.getLocation());
			rs = statement.executeQuery();
			if (rs.next()){
				obfDetails.setRate(rs.getDouble("rate"));;
				System.out.println("Rate details set successfully!");
				retVal= true;
			} else {
				System.out.println("Error: no resultset found!!");
			}
				
			
		} catch (Exception e) {
			e.printStackTrace();
			retVal = false;
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}
		
		
		return retVal;
	}
	
	public boolean fetchManagementDetails(OnBoardingFormDetails obfDetails){
		boolean retVal = false;
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		try {
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement("select * from approvaldetails where resourcemanager=?");
			statement.setString(1, obfDetails.getResourceManager());
			rs = statement.executeQuery();
			if (rs.next()){
				obfDetails.setDirectorId(rs.getString("director"));
				obfDetails.setVicePresId(rs.getString("vp"));
				System.out.println("Management details set successfully!");
				retVal= true;
			} else {
				System.out.println("Error: no resultset found!!");
			}
				
			
		} catch (Exception e) {
			e.printStackTrace();
			retVal = false;
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}
		
		
		return retVal;
	}
	
	public boolean fetchJustificationDetails(OnBoardingFormDetails obfDetails){
		boolean retVal = false;
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		try {
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement("select business_justification from skillcontent where skillname=?");
			statement.setString(1, obfDetails.getSkill());
			rs = statement.executeQuery();
			if (rs.next()){
				obfDetails.setBusinessJust(rs.getString("business_justification"));
				System.out.println("Business justification set successfully!");
				retVal= true;
			} else {
				System.out.println("Error: no resultset found!!");
			}
				
			
		} catch (Exception e) {
			e.printStackTrace();
			retVal = false;
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}
		
		
		return retVal;
	}
	
	public boolean fetchEmployeeDetails(OnBoardingFormDetails obfDetails){
		boolean retVal = false;
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		try {
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement("select first_name,last_name,employeenumber from employeedetails where enterpriseid=?");
			statement.setString(1, obfDetails.getEnterpriseId());
			rs = statement.executeQuery();
			if (rs.next()){
				obfDetails.setEnterpriseId(obfDetails.getEnterpriseId());
				obfDetails.setEmployeeId(rs.getLong("employeenumber"));
				obfDetails.setFirstName(rs.getString("first_name"));
				obfDetails.setLastName(rs.getString("last_name"));
				String idenNum =Long.toString(rs.getLong("employeenumber"));
				String numbers = idenNum.substring(idenNum.length() - 4, idenNum.length());
//				String myString = (idenNum.length() > 3)? idenNum.substring(idenNum.length() - 4, 4): idenNum;
				obfDetails.setUniqueUserID(numbers);
				System.out.println("Employee details set successfully!");
				retVal= true;
			} else {
				System.out.println("Error: no resultset found!!");
			}
				
			
		} catch (Exception e) {
			e.printStackTrace();
			retVal = false;
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}
		
		
		return retVal;
	}
	
}

package com.pmo.dboperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.pmo.commons.Util;
import com.pmo.connection.DatabaseConnection;
import com.pmo.login.HardwareMaintenance;
import com.pmo.login.TableDetail;
import com.pmo.model.AclReport;
import com.pmo.model.ResourceRequestDemandDetails;
import com.pmo.model.RollOnCheckList;

public class PMODAO {

	// DatabaseConnection dbConn = new DatabaseConnection();
	Connection con = null;
	PreparedStatement pst = null;
	Statement stmt = null;
	ResultSet rs = null;

	public Object getDetails(int request) {
		switch (request) {
		case Util.ONBOARD_EMPLOYEE_DETAILS:
			List<TableDetail> onboardDetails = getEmployeeOnboardDetails();
			if (onboardDetails != null && onboardDetails.size() > 0) {
				return onboardDetails;
			}
			break;
		case Util.TRANSPORT_COSTS_REPORT:
			ArrayList<HashMap<String, String>> transportCosts = getTransportReport();
			if (transportCosts != null && transportCosts.size() > 0) {
				return transportCosts;
			}
			break;
		case Util.GENDER_REPORT:
			List<TableDetail> genderDetails = getGenderReport();
			if (genderDetails != null && genderDetails.size() > 0) {
				return genderDetails;
			}
			break;
		case Util.HARDWARE_REPORT:
			List<HardwareMaintenance> hardwareDetails = getHardwareDetails("");
			if (hardwareDetails != null && hardwareDetails.size() > 0) {
				return hardwareDetails;
			}
			break;
		case Util.COMMUNICATION_COSTS_REPORT:
			List<HardwareMaintenance> communicationDetails = getCommunicationReport();
			if (communicationDetails != null && communicationDetails.size() > 0) {
				return communicationDetails;
			}
			break;
		case Util.CERTIFCATION_REPORT:
			List<TableDetail> certificationDetails = getCertificationReport();
			if (certificationDetails != null && certificationDetails.size() > 0) {
				return certificationDetails;
			}
			break;
		case Util.TRAINING_REPORT:
			List<TableDetail> trainingDetails = getTrainingReport();
			if (trainingDetails != null && trainingDetails.size() > 0) {
				return trainingDetails;
			}
			break;
		case Util.CERTIFICATION_MASTER_REPORT:
			List<TableDetail> certificationMasterDetails = getCertificationMasterReport();
			if (certificationMasterDetails != null && certificationMasterDetails.size() > 0) {
				return certificationMasterDetails;
			}
			break;
		case Util.TASKS_MASTER_REPORT:
			List<TableDetail> tasksMasterDetails = getTasksMasterReport();
			if (tasksMasterDetails != null && tasksMasterDetails.size() > 0) {
				return tasksMasterDetails;
			}
			
		case Util.REWARDS_REPORT:
			List<TableDetail> awardsDetails = getRewardsReport();
			if (awardsDetails != null && awardsDetails.size() > 0) {
				return awardsDetails;
			}
			break;
		case Util.OFFBOARD_EMPLOYEE_DETAILS:
			List<TableDetail> offboardDetails = getEmployeeOffboardDetails();
			if (offboardDetails != null && offboardDetails.size() > 0) {
				return offboardDetails;
			}
			break;
		case Util.RESOURCE_DETAILS:
			List<TableDetail> resourceDetails = getResourceDetails();
			if (resourceDetails != null && resourceDetails.size() > 0) {
				return resourceDetails;
			}
			break;
		case Util.RRD_REPORT:
			List<ResourceRequestDemandDetails> rrdDetails = getRrdDetails();
			if (rrdDetails != null && rrdDetails.size() > 0) {
				return rrdDetails;
			}
			break;	
		case Util.ACL_REPORT:
			List<AclReport> aclDetails = getAclDetails();
			if (aclDetails != null && aclDetails.size() > 0) {
				return aclDetails;
			}
			break;
		case Util.ROLLON_CHECKLIST_REPORT:
			List<RollOnCheckList> rollOnChkListDetails = getRollOnChkListDetails();
			if (rollOnChkListDetails != null && rollOnChkListDetails.size() > 0) {
				return rollOnChkListDetails;
			}
			break;	
		}
		return null;

	}

	List<TableDetail> getEmployeeOnboardDetails() {
		ResultSet rs = null;
		TableDetail td = null;
		List<TableDetail> list = new ArrayList<TableDetail>();
		try {
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			list = new ArrayList<TableDetail>();
			String selectStatement = "select * from EmployeeDetails where employee_status = 3 order by onboardtimestamp desc";
			pst = con.prepareStatement(selectStatement);
			rs = pst.executeQuery();
			while (rs.next()) {
				td = new TableDetail();
				td.setEmpId(rs.getInt("employeenumber"));
				td.setEnterpriseId(rs.getString("enterpriseid"));
				td.setFirstName(rs.getString("first_name"));
				td.setLastName(rs.getString("last_name"));
				td.setStream(rs.getString("specificstream"));
				td.setGender(rs.getString("gender"));
				td.setRollonDate(rs.getString("onboard_start_date"));
				td.setDeliveryCentre(rs.getString("delivery_centre"));
				td.setCurrLocation(rs.getString("currentlocation"));
				td.setCapability(rs.getString("capability"));
				td.setClevel(rs.getString("careerlevel"));
				td.setPhoneNo(rs.getLong("phone_no"));
				td.setPrimarySkill(rs.getString("primary_skill"));
				td.setSecondarySkill(rs.getString("secondary_skill"));
				td.setProficiency(rs.getString("proficiency_level"));
				td.setWmtid(rs.getString("wmt_userid"));
				td.setProjName(rs.getString("projectname"));
				td.setSupervisorName(rs.getString("supervisor_name"));
				td.setManagerId(rs.getString("manager_id"));
				td.setRoleDesc(rs.getString("role_desc"));

				list.add(td);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return list;
	}
	
	
	List<TableDetail> getResourceDetails() {
		ResultSet rs = null;
		TableDetail td = null;
		List<TableDetail> list = new ArrayList<TableDetail>();
		try {
			con = DatabaseConnection.getRAWConnection();
			list = new ArrayList<TableDetail>();
			String selectStatement = "select employeenumber, concat(first_name,' ',last_name) as employeename, specificstream, projectname, employee_status from EmployeeDetails order by rollondate, employeenumber";
			pst = con.prepareStatement(selectStatement);
			rs = pst.executeQuery();
			while (rs.next()) {
				td = new TableDetail();
				td.setEmpId(rs.getInt("employeenumber"));
				td.setRname(rs.getString("employeename"));
				td.setStream(rs.getString("specificstream"));
				td.setProjName(rs.getString("projectname"));
				td.setStatus(Util.getEmployeeStatusDesc(rs.getInt("employee_status")));
				list.add(td);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeConnection(con, pst, rs);
		}
		return list;
	}

	

	List<TableDetail> getEmployeeOffboardDetails() {
		ResultSet rs = null;
		TableDetail td = null;
		List<TableDetail> list = new ArrayList<TableDetail>();
		try {
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			list = new ArrayList<TableDetail>();
			String selectStatement = "select CONVERT(VARCHAR(20),rolloffdate,101)as Period, * from employeedetails WHERE EMPLOYEE_STATUS > 3 order by Period";
			pst = con.prepareStatement(selectStatement);
			rs = pst.executeQuery();
			while (rs.next()) {
				td = new TableDetail();
				td.setEmpId(rs.getInt("employeenumber"));
				td.setEnterpriseId(rs.getString("enterpriseid"));
				td.setFirstName(rs.getString("first_name"));
				td.setLastName(rs.getString("last_name"));
				td.setStream(rs.getString("specificstream"));
				td.setGender(rs.getString("gender"));
				td.setRollonDate(rs.getString("onboard_start_date"));
				td.setDeliveryCentre(rs.getString("delivery_centre"));
				td.setCurrLocation(rs.getString("currentlocation"));
				td.setCapability(rs.getString("capability"));
				td.setClevel(rs.getString("careerlevel"));
				td.setPhoneNo(rs.getLong("phone_no"));
				td.setPrimarySkill(rs.getString("primary_skill"));
				td.setSecondarySkill(rs.getString("secondary_skill"));
				td.setProficiency(rs.getString("proficiency_level"));
				td.setWmtid(rs.getString("wmt_userid"));
				td.setProjName(rs.getString("projectname"));
				td.setSupervisorName(rs.getString("supervisor_name"));
				td.setManagerId(rs.getString("manager_id"));
				td.setRolloffDate(rs.getString("rolloffdate"));
				td.setRolloffReason(rs.getString("rolloffreason"));
				td.setExit(rs.getBoolean("isexit"));
				if(td.isExit())
					td.setStatus("Exit");
				else
					td.setStatus("Roll Off");
				td.setReportPeriod(rs.getString("period"));
				list.add(td);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return list;
	}

	private final String TRANSPORT_COSTS_QUERY = "SELECT * FROM transport_cost ORDER BY cast(period as datetime)";
	private final String COLUMN_WBS_CODE = "wbs_code";
	private final String COLUMN_PERIOD = "period";
	private final String COLUMN_ADHOC_AMOUNT = "adhoc_amount";
	private final String COLUMN_REGULAR_AMOUNT = "regular_amount";
	private final String COLUMN_FINAL_AMOUNT = "final_amount";
	private final String COLUMN_STREAM = "stream";
	private final String COLUMN_WBS_ELEMENT ="WBS_Element";

	ArrayList<HashMap<String, String>> getTransportReport() {
		ArrayList<HashMap<String, String>> list = null;
		HashMap<String, String> transportCostDetails = null;
		PreparedStatement statement = null;
		Connection con = null;
		ResultSet result = null;
		try {

			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			list = new ArrayList<HashMap<String, String>>();
			statement = con.prepareStatement(TRANSPORT_COSTS_QUERY);
			result = statement.executeQuery();
			while (result.next()) {
				transportCostDetails = new HashMap<String, String>();
				transportCostDetails.put("WBS_Element", result.getString(COLUMN_WBS_ELEMENT ));
				transportCostDetails.put("period", result.getString(COLUMN_PERIOD));
				transportCostDetails.put("stream", result.getString(COLUMN_STREAM));
				transportCostDetails.put("adhoc_amount", result.getString(COLUMN_ADHOC_AMOUNT));
				transportCostDetails.put("regular_amount", result.getString(COLUMN_REGULAR_AMOUNT));
				transportCostDetails.put("final_amount", result.getString(COLUMN_FINAL_AMOUNT));
				list.add(transportCostDetails);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(result);
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}
		return null;
	}

	List<TableDetail> getGenderReport() {
		List<TableDetail> gender = new ArrayList<TableDetail>();
		Statement st = null;
		try {
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			st = con.createStatement();
			ResultSet rs = st.executeQuery(
					"select employeenumber,resourcename,specificstream,careerlevel,gender from employeedetails where employee_status = 3 ");
			while (rs.next()) {
				TableDetail td = new TableDetail();
				td.setEmpId(rs.getInt("employeenumber"));
				td.setRname(rs.getString("resourcename"));
				td.setStream(rs.getString("specificstream"));
				td.setClevel(rs.getString("careerlevel"));
				td.setGender(rs.getString("gender"));
				gender.add(td);
			}
			return gender;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closeStmt(st);
			DatabaseConnection.closeCon(con);
		}
		return null;
	}



	private final String HARDWARE_DETAILS_QUERY = "select rsa.employeenumber, emp.specificstream, rsa.employeename, rsa.rsatoken,"
			+ " rsa.validdate, mob.mobileno, mob.stream, mob.billcycle, mob.servicepro, lap.laptopno, lap.assettag, lap.make,"
			+ " dat.datacardnumber, dat.serviceprovider, dat.billcycle databillcycle from rsadetails rsa left outer "
			+ " join mobiledetails mob on rsa.employeenumber = mob.employeenumber left outer"
			+ " join laptopdetails lap on rsa.employeenumber = lap.employeenumber left outer join datacarddetails dat "
			+ " on dat.employeenumber = rsa.employeenumber join employeedetails emp on rsa.employeenumber = emp.employeenumber where emp.employee_status =3";

	private final String COLUMN_EMP_NUMBER = "employeenumber";
	private final String COLUMN_EMP_NAME = "employeename";
	private final String COLUMN_SPECIFIC_STREAM = "specificstream";
	private final String COLUMN_RSA_TOKEN = "rsatoken";
	private final String COLUMN_VALID_UPTO = "validdate";
	private final String COLUMN_MOBILE = "mobileno";
	private final String COLUMN_BILL_CYCLE = "billcycle";
	private final String COLUMN_SERVICE_PRO = "servicepro";
	private final String COLUMN_LAP_NUMBER = "laptopno";
	private final String COLUMN_ASSETTAG = "assettag";
	private final String COLUMN_MAKE = "make";
	private final String COLUMN_DATA_CARD_NUMBER = "datacardnumber";
	private final String COLUMN_DATA_BILL_CYCLE = "databillcycle";
	private final String COLUMN_DATA_SERVICE_PROVIDER = "serviceprovider";

	public List<HardwareMaintenance> getHardwareDetails(String filter) {
		List<HardwareMaintenance> maintenanceList = new ArrayList<HardwareMaintenance>();
		HardwareMaintenance hardwareMaintenance = null;
		Statement st = null;
		try {
			//con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			st = con.createStatement();
			ResultSet rs = st.executeQuery(HARDWARE_DETAILS_QUERY + filter);
			while (rs.next()) {
				hardwareMaintenance = new HardwareMaintenance();
				hardwareMaintenance.setEmployeeNumber(rs.getInt(COLUMN_EMP_NUMBER));
				hardwareMaintenance.setEmployeeName(rs.getString(COLUMN_EMP_NAME));

				hardwareMaintenance.setStream(rs.getString(COLUMN_SPECIFIC_STREAM));

				int rsaToken = rs.getInt(COLUMN_RSA_TOKEN);
				if (rsaToken != 0)
					hardwareMaintenance.setRsa(true);
				hardwareMaintenance.setRsaToken(rsaToken);
				hardwareMaintenance.setValidDate(rs.getString(COLUMN_VALID_UPTO));

				hardwareMaintenance.setMobileNo(rs.getLong(COLUMN_MOBILE));
				if (hardwareMaintenance.getMobileNo() != 0) {
					hardwareMaintenance.setMobile(true);
				}
				String billCycle = rs.getString(COLUMN_BILL_CYCLE);
				String billOrdinates[] = { "", "" };
				if (billCycle != null && !billCycle.trim().equals("")) {
					billOrdinates = billCycle.split("-");
				}
				hardwareMaintenance.setBillStartDate(billOrdinates[0]);
				hardwareMaintenance.setBillEndDate(billOrdinates[1]);
				hardwareMaintenance.setServiceProvider(rs.getString(COLUMN_SERVICE_PRO));

				hardwareMaintenance.setAssetTag(rs.getString(COLUMN_ASSETTAG));
				hardwareMaintenance.setLaptopNo(rs.getString(COLUMN_LAP_NUMBER));
				if (hardwareMaintenance.getLaptopNo() != null && !hardwareMaintenance.getLaptopNo().trim().equals("")) {
					hardwareMaintenance.setLaptop(true);
				}
				hardwareMaintenance.setMake(rs.getString(COLUMN_MAKE));

				hardwareMaintenance.setDataCardNumber(rs.getLong(COLUMN_DATA_CARD_NUMBER));
				if (hardwareMaintenance.getDataCardNumber() != 0) {
					hardwareMaintenance.setDataCard(true);
					String dataCardbillCycle = rs.getString(COLUMN_DATA_BILL_CYCLE);
					String dataCardbillOrdinates[] = { "", "" };
					if (dataCardbillCycle != null && !dataCardbillCycle.trim().equals(""))
						dataCardbillOrdinates = dataCardbillCycle.split("-");
					hardwareMaintenance.setDataCardBillStartDate(dataCardbillOrdinates[0]);
					hardwareMaintenance.setDataCardBillEndDate(dataCardbillOrdinates[1]);
					hardwareMaintenance.setDataCardServiceProvider(rs.getString(COLUMN_DATA_SERVICE_PROVIDER));
				}

				maintenanceList.add(hardwareMaintenance);

			}
			return maintenanceList;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closeStmt(st);
			DatabaseConnection.closeCon(con);
		}
		return null;
	}

	List<HardwareMaintenance> getCommunicationReport() {
		List<HardwareMaintenance> cost = new ArrayList<HardwareMaintenance>();
		Statement st = null;
		try {
			String selectQuery = "select communication.*, employeedetails.resourcename from communication, employeedetails where employeedetails.employeenumber = communication.employeenumber"
					+" and communication.project = employeedetails.projectname ORDER BY cast(communication.month as datetime)";
			con = DatabaseConnection.getRAWConnection();
			st = con.createStatement();
			ResultSet rs = st.executeQuery(selectQuery);
			while (rs.next()) {
				HardwareMaintenance td = new HardwareMaintenance();
				td.setEmployeeNumber(rs.getInt("employeenumber"));
				td.setApplication(rs.getString("project"));
				td.setMonth(rs.getString("month"));
				td.setCost(rs.getInt("cost"));
				td.setEmployeeName(rs.getString("resourcename"));
				td.setAssetType(rs.getInt("assettype"));
				cost.add(td);
			}
			return cost;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closeStmt(st);
			DatabaseConnection.closeCon(con);
		}
		return null;
	}

	List<TableDetail> getCertificationReport() {
		List<TableDetail> certilist = new ArrayList<TableDetail>();
		Statement st = null;
		try {
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from certification where status='certification' order by certtimestamp desc");
			while (rs.next()) {
				TableDetail td = new TableDetail();
				td.setRname(rs.getString("employeeName"));
				td.setEmpId(rs.getInt("employeeNumber"));
				td.setStream(rs.getString("stream"));
				td.setCertificationType(rs.getString("certificationtype"));
				td.setCertificationName(rs.getString("certificationname"));
				td.setCertificationDate(rs.getString("certificationdate"));
				td.setScore(rs.getInt("score"));
				td.setTimestamp(rs.getTimestamp("certtimestamp"));
				td.setCertificationStatus(rs.getString("status"));
				certilist.add(td);
			}
			return certilist;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closeStmt(st);
			DatabaseConnection.closeCon(con);
		}
		return null;
	}

	List<TableDetail> getTrainingReport() {
		List<TableDetail> trainlist = new ArrayList<TableDetail>();
		Statement st = null;
		try {
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from certification where status='training' order by certtimestamp desc");
			while (rs.next()) {
				TableDetail td = new TableDetail();
				td.setRname(rs.getString("employeeName"));
				td.setEmpId(rs.getInt("employeeNumber"));
				td.setStream(rs.getString("stream"));
				td.setCertificationType(rs.getString("certificationtype"));
				td.setCertificationName(rs.getString("certificationname"));
				td.setCertificationDate(rs.getString("certificationdate"));
				td.setScore(rs.getInt("score"));
				td.setTimestamp(rs.getTimestamp("certtimestamp"));
				td.setCertificationStatus(rs.getString("status"));
				trainlist.add(td);
			}
			return trainlist;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closeStmt(st);
			DatabaseConnection.closeCon(con);
		}
		return null;
	}
	
	
	List<TableDetail> getCertificationMasterReport() {
		List<TableDetail> certilist = new ArrayList<TableDetail>();
		Statement st = null;
		try {
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from certification order by certtimestamp desc");
			while (rs.next()) {
				TableDetail td = new TableDetail();
				td.setRname(rs.getString("employeeName"));
				td.setEmpId(rs.getInt("employeeNumber"));
				td.setStream(rs.getString("stream"));
				td.setCertificationType(rs.getString("certificationtype"));
				td.setCertificationName(rs.getString("certificationname"));
				td.setCertificationDate(rs.getString("certificationdate"));
				td.setScore(rs.getInt("score"));
				td.setTimestamp(rs.getTimestamp("certtimestamp"));
				td.setCertificationStatus(rs.getString("status"));
				certilist.add(td);
			}
			return certilist;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closeStmt(st);
			DatabaseConnection.closeCon(con);
		}
		return null;
	}
	
	List<TableDetail> getTasksMasterReport() {
		List<TableDetail> taskslist = new ArrayList<TableDetail>();
		Statement st = null;
		try {
			// con = dbConn.mySqlConnection();
			Util daysElapFn = new Util();
			int noOfDays = 0;
			con = DatabaseConnection.getRAWConnection();
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from tasks order by task_timestamp desc");
			
			while (rs.next()) {
				TableDetail td = new TableDetail();
        		td.setAssignedDate(rs.getString("assigned_date"));
        		td.setTaskDescription(rs.getString("task_desc"));
        		td.setEndDate(rs.getString("complete_date"));
        		td.setStatus(rs.getString("status"));
        		
        		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        		Date date = new Date();
        		Date endDate = new Date(date.getTime());
        		if(td.getStatus().equalsIgnoreCase("Completed")){
        			noOfDays=daysElapFn.printDifference(td.getAssignedDate(), td.getEndDate());
        		} else {
        			noOfDays=daysElapFn.printDifference(td.getAssignedDate(), dateFormat.format(endDate).toString());
        		}
        		td.setDaysElapsed(noOfDays);
        		td.setAssignedBy(rs.getString("assignedby"));	
        		td.setTimestamp(rs.getTimestamp("task_timestamp"));
        		td.setTaskName(rs.getString("task_name"));
        		taskslist.add(td);
			}
			return taskslist;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closeStmt(st);
			DatabaseConnection.closeCon(con);
		}
		return null;
	}
	
	
	List<ResourceRequestDemandDetails> getRrdDetails() {
		List<ResourceRequestDemandDetails> rrdList = new ArrayList<ResourceRequestDemandDetails>();
		Statement st = null;
		try {
			
//			portfolio, edfulfilldate, rrstartdate, demandenddate, demandsegment, clientiview, priskill, ishlready, ffentity,
//			lockduration, wbsecode, demandpriority, srclocation,
//					wrklocation, careerlevel, onsitecomponent, visatype, visaready, demandid, createdby, updatedby, createdts, updatedts,status) 
//			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			st = con.createStatement();
			//Change the query as per rrdTable
			ResultSet rs = st.executeQuery("select * from resourcerequestdetails order by updatedts desc;");
			while (rs.next()) {
				ResourceRequestDemandDetails rrd = new ResourceRequestDemandDetails();
				rrd.setPortfolio(rs.getString("portfolio"));
				rrd.setEdfulfilldate(rs.getString("edfulfilldate"));
				rrd.setRrstartdate(rs.getString("rrstartdate"));
				rrd.setDemandenddate(rs.getString("demandenddate"));
//				rrd.setEdfulfilldate(rs.getTimestamp("edfulfilldate"));
//				rrd.setRrstartdate(rs.getTimestamp("rrstartdate"));
//				rrd.setDemandenddate(rs.getTimestamp("demandenddate"));
//				rrd.setEdfulfilldate(rs.getDate("edfulfilldate"));
//				rrd.setRrstartdate(rs.getDate("rrstartdate"));
//				rrd.setDemandenddate(rs.getDate("demandenddate"));
				rrd.setDemandsegment(rs.getString("demandsegment"));
				rrd.setClientiview(rs.getBoolean("clientiview"));
				rrd.setPriskill(rs.getString("priskill"));
				rrd.setIshlready(rs.getBoolean("ishlready"));
				rrd.setFfentity(rs.getString("ffentity"));
				rrd.setLockduration(rs.getString("lockduration"));
				rrd.setWbsecode(rs.getString("wbsecode"));
				rrd.setDemandpriority(rs.getString("demandpriority"));
				rrd.setSrclocation(rs.getString("srclocation"));
				rrd.setWrklocation(rs.getString("wrklocation"));
				rrd.setCareerlevel(rs.getString("careerlevel"));
				rrd.setOnsitecomponent(rs.getBoolean("onsitecomponent"));
				rrd.setVisatype(rs.getString("visatype"));
				rrd.setVisaready(rs.getBoolean("visaready"));
				rrd.setDemandid(rs.getString("demandid"));
				rrd.setCreatedby(rs.getString("createdby"));
				rrd.setUpdatedby(rs.getString("updatedby"));
				rrd.setCreatedts(rs.getTimestamp("createdts"));
				rrd.setUpdatedts(rs.getTimestamp("updatedts"));
				rrd.setStatus(rs.getBoolean("status"));
				rrdList.add(rrd);
			}
			return rrdList;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closeStmt(st);
			DatabaseConnection.closeCon(con);
		}
		return null;
	}
	
	List<AclReport> getAclDetails() {
		ResultSet rs = null;
		AclReport aclRep = null;
		List<AclReport> list = new ArrayList<AclReport>();
		try {
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			list = new ArrayList<AclReport>();
			String selectStatement = "SELECT employeedetails.enterpriseid, employeedetails.first_name,employeedetails.last_name, employeedetails.wmt_userid,employeedetails.onboard_start_date,employeedetails.currentlocation,employeedetails.role_desc,employeedetails.specificstream,employeedetails.rolloffdate,employeedetails.wmt_grantdate,employeedetails.employee_status,rollon_checklist.acknowledge_time FROM rollon_checklist RIGHT OUTER JOIN employeedetails ON rollon_checklist.employeenumber=employeedetails.employeenumber";
			pst = con.prepareStatement(selectStatement);
			rs = pst.executeQuery();
			while (rs.next()) {
				aclRep = new AclReport();
				int empStatus=rs.getInt("employee_status");	
				System.out.println("status "+empStatus);
				
				aclRep.setEnterpriseId(rs.getString("enterpriseid"));
				aclRep.setFirstName(rs.getString("first_name"));
				aclRep.setLastName(rs.getString("last_name"));
				aclRep.setWmtid(rs.getString("wmt_userid"));
				aclRep.setRollonDate(rs.getString("onboard_start_date"));
				aclRep.setCurrLocation(rs.getString("currentlocation"));
				aclRep.setRoleDesc(rs.getString("role_desc"));
				aclRep.setStream(rs.getString("specificstream"));
				aclRep.setRolloffDate(rs.getString("rolloffdate"));
				
				if(empStatus==4  || empStatus==5 ){
					aclRep.setVdiRevokeDate(rs.getString("rolloffdate"));
				} 
				
				aclRep.setGrantdate(rs.getString("wmt_grantdate"));
				aclRep.setAckDate(rs.getDate("acknowledge_time"));
				list.add(aclRep);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return list;
	}
	
	
	List<RollOnCheckList> getRollOnChkListDetails() {
		ResultSet rs = null;
		RollOnCheckList rOnChkList = null;
		List<RollOnCheckList> list = new ArrayList<RollOnCheckList>();
		try {
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			list = new ArrayList<RollOnCheckList>();
			String selectStatement = "SELECT employeedetails.employeenumber, employeedetails.enterpriseid, CONCAT(employeedetails.first_name, ' ', employeedetails.last_name) as Employeename, employeedetails.specificstream, employeedetails.rollondate, rollon_checklist.status, rollon_checklist.acknowledge_time FROM rollon_checklist INNER JOIN employeedetails ON rollon_checklist.employeenumber=employeedetails.employeenumber";
			pst = con.prepareStatement(selectStatement);
			rs = pst.executeQuery();
			while (rs.next()) {
				String enterpriseId = rs.getString("enterpriseid");
				rOnChkList = new RollOnCheckList();
				rOnChkList.setEmpNum("<a target='_black' href='rolloncheck.action?page=checkListReport&entId="+enterpriseId+"'>"+rs.getString("employeenumber")+"</a>");
				rOnChkList.setEmpName(rs.getString(3));
				rOnChkList.setStream(rs.getString(4));
				rOnChkList.setRollOnDate(rs.getString(5));
				String status = rs.getString(6);
				if(status.equalsIgnoreCase("1")){
					status = "Completed";
				} else {
					status = "Pending";
				}
				rOnChkList.setStatus(status);
				rOnChkList.setAckDate(rs.getDate(7));
				list.add(rOnChkList);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return list;
	}
	
	
	
	
	List<TableDetail> getRewardsReport() {
		List<TableDetail> rewardslist = new ArrayList<TableDetail>();
		Statement st = null;
		try {
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from rewards_recognition order by rewardtimestamp desc");
			while (rs.next()) {
				TableDetail td = new TableDetail();
				td.setRname(rs.getString("employeename"));
				td.setEmpId(rs.getInt("employeenumber"));
				td.setStream(rs.getString("stream"));
				td.setAwardType(rs.getString("awardtype"));
				td.setAward_receiver(rs.getString("award_receiver"));
				td.setAward_period(rs.getString("award_period"));
				td.setAward(rs.getString("award"));
				td.setReason(rs.getString("awardreason"));
				td.setTimestamp(rs.getTimestamp("rewardtimestamp"));
				td.setRewardId(rs.getInt("reward_id"));
				rewardslist.add(td);

			}
			return rewardslist;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closeStmt(st);
			DatabaseConnection.closeCon(con);
		}
		return null;
	}

	public TableDetail getEmployeeDetails(String empId) {
		Connection con = null;// dbConn.mySqlConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		TableDetail td = null;
		try {
			String selectStatement = "select * from EmployeeDetails where employeenumber = ?";
			con = DatabaseConnection.getRAWConnection();
			pst = con.prepareStatement(selectStatement);
			pst.setInt(1, Integer.parseInt(empId.trim()));
			rs = pst.executeQuery();
			if (rs.next()) {
				td = new TableDetail();

				td.setRname(rs.getString("ResourceName"));
				td.setFirstName(rs.getString("first_name"));
				td.setLastName(rs.getString("last_name"));
				td.setEmpId(rs.getInt("employeenumber"));
				td.setEnterpriseId(rs.getString("enterpriseid"));
				td.setIdentifierType(rs.getString("identifier_type"));
				td.setIdentifierNumber(rs.getString("identifier_number"));
				td.setStream(rs.getString("specificstream"));
				td.setDeptNumber(rs.getString("department_number"));
				td.setCountry(rs.getString("country"));
				td.setDeliveryCentre(rs.getString("delivery_centre"));
				td.setCurrLocation(rs.getString("currentlocation"));
				td.setRoleDesc(rs.getString("role_desc"));
				td.setContractType(rs.getString("contract_type"));
				td.setRate(rs.getDouble("rate"));
				td.setRollonDate(rs.getString("onboard_start_date"));
				td.setManagerId(rs.getString("manager_id"));
				td.setDirectorId(rs.getString("director_id"));
				td.setVpUserId(rs.getString("vp_user_id"));
				td.setComments(rs.getString("comments"));
				td.setContractorHostPattern(rs.getString("contractor_host_pattern"));
				td.setContractorUnixPattern(rs.getString("contractor_unix_pattern"));
				td.setUnixBoxes(rs.getString("unix_boxes"));
				String remedyPattern = rs.getString("remedy_pattern");
				td.setGender(rs.getString("gender"));
				td.setRollonDate(rs.getString("rollondate"));
				td.setCapability(rs.getString("capability"));
				td.setClevel(rs.getString("careerlevel"));
				td.setVisaType(rs.getString("visa_type"));
				td.setDuration(rs.getString("duration_stay"));
				td.setPhoneNo(rs.getLong("phone_no"));
				td.setLockType(rs.getString("locktype"));
				td.setPrimarySkill(rs.getString("primary_skill"));
				td.setSecondarySkill(rs.getString("secondary_skill"));
				td.setProficiency(rs.getString("proficiency_level"));
				td.setWmtid(rs.getString("wmt_userid"));
				td.setRequestdate(rs.getString("wmt_accessdate"));
				td.setGrantdate(rs.getString("wmt_grantdate"));
				td.setWorkstationNumber(rs.getString("workstation"));
				td.setBayNumber(rs.getInt("bayno"));
				td.setProjName(rs.getString("projectname"));
				td.setClient(rs.getString("client"));
				td.setProjDetails(rs.getString("projectdetails"));
				td.setIdentifierNumber(rs.getString("identifier_number"));
				td.setIdentifierType(rs.getString("identifier_type"));
				td.setContractorADPattern(rs.getString("contractor_ad_pattern"));
				td.setADGroupShared(rs.getString("ad_groups_shared"));
				td.setContractorTDPattern(rs.getString("contractor_td_pattern"));
				td.setTeraApplication(rs.getString("teradata_application"));
				td.setBusinessJustification(rs.getString("business_justification"));
				td.setSupervisorName(rs.getString("supervisor_name"));
				td.setRolloffDate(rs.getString("rolloffdate"));
				td.setRolloffReason(rs.getString("rolloffreason"));
				td.setExit(rs.getBoolean("isexit"));
				td.setFloor(rs.getString("floor"));
				try {
					if (remedyPattern != null)
						remedyPattern = remedyPattern.replaceAll("\\^", ", ");
				} catch (Exception e) {
					e.printStackTrace();
				}
				td.setContractorRemedyPattern(remedyPattern);
				td.setContractorADPattern(rs.getString("contractor_ad_pattern"));
				td.setADGroupShared(rs.getString("ad_groups_shared"));
				td.setContractorTDPattern(rs.getString("contractor_td_pattern"));
				td.setTeraApplication(rs.getString("teradata_application"));
				td.setBusinessJustification(rs.getString("business_justification"));
				td.setEmployeeStatus(rs.getInt("employee_status"));
				td.setRrdId(rs.getString("rrdId"));

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return td;
	}


	public List<String> getProjectList(){
		Connection con = null;// dbConn.mySqlConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		ArrayList<String> projectList = null;
		//String selectStatement = "select distinct isnull(projectname, '') +'@@'+ isnull(specificstream, '') projectmapping from employeedetails";
		String selectStatement = "select distinct concat(projectname,'@@',specificstream) projectmapping from employeedetails where projectname is not null and specificstream is not null";
		try {
			projectList = new ArrayList<String>();
			con = DatabaseConnection.getRAWConnection();
			pst = con.prepareStatement(selectStatement);
			rs = pst.executeQuery();
			while(rs.next()){
				String projectMap = rs.getString(1);
				if(projectMap!=null)
					projectList.add(projectMap);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DatabaseConnection.closeConnection(con, pst, rs);
		}
		return projectList;
	}
	
}
package com.pmo.dboperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.google.gson.Gson;
import com.pmo.connection.DatabaseConnection;
import com.pmo.model.ResourceRequestDemandDetails;
import com.pmo.model.RollOffCheckList;

public class RollOffCheckListDAO {
	
	public boolean insertRollOffCheckListDetails(String employeeId,String updUser) {
		int empId = Integer.parseInt(employeeId);
		Connection con = null;
		PreparedStatement pstmt = null;
		boolean status = false;
		try {
			// con=dbconn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			String insertSqlTable = "INSERT INTO rolloffchecklist (employeenumber, updatedtime, status, updatedby) VALUES (?, CURRENT_TIMESTAMP, ?, ?)";
			pstmt = con.prepareStatement(insertSqlTable);
			pstmt.setInt(1, empId);
			pstmt.setString(2, "Active");
			pstmt.setString(3, updUser);
			int count = pstmt.executeUpdate();
			if (count == 1) {
				status = true;
				con.commit();
			} else {
				status = false;
				con.rollback();
			}
		}

		catch (SQLException e) {
			e.printStackTrace();
			status = false;
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		} finally {
			// DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pstmt);
			DatabaseConnection.closeCon(con);
		}

		return status;

	}
	
	public boolean isEmployeePresent(int employeeId){
		boolean retVal = false;
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		RollOffCheckList rollOffDetails = new RollOffCheckList();
		try {
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement("select employeenumber from rolloffchecklist where employeenumber=?");
			statement.setInt(1, employeeId);
			rs = statement.executeQuery();
			if (rs.next()){
				rollOffDetails.setEmpNum(rs.getString("employeenumber"));
				retVal= true;
			} else {
				System.out.println("Error: no resultset found!!");
			}
				
			
		} catch (Exception e) {
			e.printStackTrace();
			retVal = false;
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}
		
		
		return retVal;
	}
	
	public static String getRollOffCheckListStatus(int employeeId){
		String retVal = "Active";
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		try {
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement("select status from rolloffchecklist where employeenumber=?");
			statement.setInt(1, employeeId);
			rs = statement.executeQuery();
			if (rs.next()){
				retVal= rs.getString("status");
			} else {
				System.out.println("Error: no resultset found!!");
			}
				
			
		} catch (Exception e) {
			e.printStackTrace();
			retVal = "Active";
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
		}
		
		
		return retVal;
	}
	
	
	public static int rollOffCheckListUpdate(RollOffCheckList rollOffForm, String userLoggedIn){
		int responseCode=0;
		Date dNow = new Date( );
	    SimpleDateFormat ft = new SimpleDateFormat ("MM/dd/yyyy");
	    String currentDate=ft.format(dNow).toString();
		try {
			Connection con = DatabaseConnection.getRAWConnection();
			PreparedStatement ps=con.prepareStatement("update rolloffchecklist set checklistdata=?,updatedtime=?,status=?,updatedby=? where employeenumber=?");
			ps.setString(1, new Gson().toJson(rollOffForm).toString());
			ps.setString(2, currentDate);
			ps.setString(3, rollOffForm.getStatus());
			ps.setString(4, userLoggedIn);
			String resName =rollOffForm.getEmpNum();
			String empNum = resName.split("- ")[1];
			int empId = Integer.parseInt(empNum);
			ps.setInt(5, empId);
			
			responseCode = ps.executeUpdate();
			if(responseCode == 1){
				con.commit();
			}else {
				con.rollback();
			}
			
			System.out.println("Response Code:" + responseCode);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return responseCode;
	}
	
	public static String rollOfDataFetch(int empNumber) throws ParseException{
		String rollOffData= null;
		try {
			Connection con = DatabaseConnection.getRAWConnection();
			PreparedStatement ps=con.prepareStatement("select checklistdata from rolloffchecklist where employeenumber =?");
			ps.setInt(1, empNumber);
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				 rollOffData = rs.getString("checklistdata");
			
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return rollOffData;
	}
	

}

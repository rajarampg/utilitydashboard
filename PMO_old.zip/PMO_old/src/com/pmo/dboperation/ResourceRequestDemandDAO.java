package com.pmo.dboperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

import com.pmo.commons.Util;
import com.pmo.connection.DatabaseConnection;
import com.pmo.login.OnBoardingFormDetails;
import com.pmo.model.RRDMapper;
import com.pmo.model.ResourceRequestDemandDetails;

public class ResourceRequestDemandDAO {
	
	public static int rrdInsert(ResourceRequestDemandDetails rrdDetails, String userLoggedIn) throws ParseException{
		Util pmoUtil = new Util();
		String edFulfilDate = setResourceDateDetails(rrdDetails.getEdfulfilldate()); 
		String rrStartDate = setResourceDateDetails(rrdDetails.getRrstartdate());
		String demandEndDate = setResourceDateDetails(rrdDetails.getDemandenddate());
		int responseCode=0;
		try {
			InsertOnboardingDetails insertIntoTask = new InsertOnboardingDetails();
			Connection con = DatabaseConnection.getRAWConnection();
			PreparedStatement ps=con.prepareStatement("INSERT INTO resourcerequestdetails(portfolio, edfulfilldate, rrstartdate, demandenddate, demandsegment, clientiview, priskill, ishlready, ffentity, lockduration, wbsecode, demandpriority, srclocation, wrklocation, careerlevel, onsitecomponent, visatype, visaready, demandid, createdby, updatedby, createdts, updatedts,status,resourcecount) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,?,?)");
			ps.setString(1, rrdDetails.getPortfolio());
			ps.setString(2, edFulfilDate);
			ps.setString(3, rrStartDate);
			ps.setString(4, demandEndDate);
			ps.setString(5, rrdDetails.getDemandsegment());
			ps.setBoolean(6, rrdDetails.isClientiview());
			ps.setString(7, rrdDetails.getPriskill());
			ps.setBoolean(8, rrdDetails.isIshlready());
			ps.setString(9, rrdDetails.getFfentity());
			ps.setString(10, rrdDetails.getLockduration());
			ps.setString(11, rrdDetails.getWbsecode());
			ps.setString(12, rrdDetails.getDemandpriority());
			ps.setString(13, rrdDetails.getSrclocation());
			ps.setString(14, rrdDetails.getWrklocation());
			ps.setString(15, rrdDetails.getCareerlevel());
			ps.setBoolean(16, rrdDetails.isOnsitecomponent());
			ps.setString(17, rrdDetails.getVisatype());
			ps.setBoolean(18, rrdDetails.isVisaready());
			ps.setString(19, pmoUtil.randomNumber());
			ps.setString(20, userLoggedIn);
			ps.setString(21, userLoggedIn);
			ps.setBoolean(22, false);
			ps.setInt(23, rrdDetails.getRescount());
			rrdDetails.setDemandid(pmoUtil.randomNumber());
			rrdDetails.setCreatedby(userLoggedIn);
			rrdDetails.setEdfulfilldate(edFulfilDate);
			rrdDetails.setRrstartdate(rrStartDate);
			rrdDetails.setDemandenddate(demandEndDate);
			
			responseCode = ps.executeUpdate();
			if(responseCode == 1  && insertIntoTask.insertTaskDetails("Demand Request", rrdDetails.getDemandid(), userLoggedIn, "demandReq")){
				con.commit();
			}else {
				con.rollback();
			}
			
			System.out.println("Response Code:" + responseCode);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return responseCode;
	}
	
	public int rrdMultipleInsert(ResourceRequestDemandDetails[] rrdDetailsArray, String userLoggedIn) throws ParseException{
		
		int responseCode=0;
		int i=1;
		try {
			InsertOnboardingDetails insertIntoTask = new InsertOnboardingDetails();
			Connection con = DatabaseConnection.getRAWConnection();
			con.setAutoCommit(false);
			Util pmoUtil = new Util();
			String randInit= pmoUtil.randomNumber(); 
			PreparedStatement ps=con.prepareStatement("INSERT INTO resourcerequestdetails(portfolio, edfulfilldate, rrstartdate, demandenddate, demandsegment, clientiview, priskill, ishlready, ffentity, lockduration, wbsecode, demandpriority, srclocation, wrklocation, careerlevel, onsitecomponent, visatype, visaready, demandid, createdby, updatedby, createdts, updatedts,status,resourcecount) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,?,?)");
			for(ResourceRequestDemandDetails rrdDetails:rrdDetailsArray){
				String randAppend = Integer.toString(i++);
				String randAppNew = "-"+randAppend;
				String randFinal = randInit.concat(randAppNew);
				String edFulfilDate = setResourceDateDetails(rrdDetails.getEdfulfilldate()); 
				String rrStartDate = setResourceDateDetails(rrdDetails.getRrstartdate());
				String demandEndDate = setResourceDateDetails(rrdDetails.getDemandenddate());
				ps.setString(1, rrdDetails.getPortfolio());
				ps.setString(2, edFulfilDate);
				ps.setString(3, rrStartDate);
				ps.setString(4, demandEndDate);
				ps.setString(5, rrdDetails.getDemandsegment());
				ps.setBoolean(6, rrdDetails.isClientiview());
				ps.setString(7, rrdDetails.getPriskill());
				ps.setBoolean(8, rrdDetails.isIshlready());
				ps.setString(9, rrdDetails.getFfentity());
				ps.setString(10, rrdDetails.getLockduration());
				ps.setString(11, rrdDetails.getWbsecode());
				ps.setString(12, rrdDetails.getDemandpriority());
				ps.setString(13, rrdDetails.getSrclocation());
				ps.setString(14, rrdDetails.getWrklocation());
				ps.setString(15, rrdDetails.getCareerlevel());
				ps.setBoolean(16, rrdDetails.isOnsitecomponent());
				ps.setString(17, rrdDetails.getVisatype());
				ps.setBoolean(18, rrdDetails.isVisaready());
				ps.setString(19, randFinal);
				ps.setString(20, userLoggedIn);
				ps.setString(21, userLoggedIn);
				ps.setBoolean(22, false);
				ps.setInt(23, rrdDetails.getRescount());
				rrdDetails.setDemandid(randFinal);
				rrdDetails.setCreatedby(userLoggedIn);
				rrdDetails.setEdfulfilldate(edFulfilDate);
				rrdDetails.setRrstartdate(rrStartDate);
				rrdDetails.setDemandenddate(demandEndDate);
				ps.addBatch();
				System.out.println("Added insert stmts to batch");
			}
			
			int[] count = ps.executeBatch();
			boolean dbInsertionState= checkAllRowsInsertion(count);
			if(dbInsertionState){
				System.out.println("Commiting to DB");
				con.commit();
				responseCode = 1;
				for(ResourceRequestDemandDetails rrdDetails:rrdDetailsArray){
					if(responseCode == 1 && insertIntoTask.insertTaskDetails("Demand Request", rrdDetails.getDemandid(), userLoggedIn, "demandReq")){
						System.out.println("Committed to tasks table!");
					} else{
						System.out.println("Error committing multiple values into tasks table!");
					}
				}
			} else {
				System.out.println("Not commiting to DB");
				con.rollback();
				responseCode = 0;
			}
			
			System.out.println("Response Code:" + responseCode);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return responseCode;
	}
	
	
	public static ResourceRequestDemandDetails rrdFetch(String demandID) throws ParseException{
		ResourceRequestDemandDetails rrdVal= new ResourceRequestDemandDetails();
		try {
			Connection con = DatabaseConnection.getRAWConnection();
			PreparedStatement ps=con.prepareStatement("select * from resourcerequestdetails where demandid =?");
			ps.setString(1, demandID);
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				rrdVal.setPortfolio(rs.getString("portfolio"));
				rrdVal.setEdfulfilldate(rs.getString("edfulfilldate"));
				rrdVal.setRrstartdate(rs.getString("rrstartdate"));
				rrdVal.setDemandenddate(rs.getString("demandenddate"));
				rrdVal.setDemandsegment(rs.getString("demandsegment"));
				rrdVal.setClientiview(rs.getBoolean("clientiview"));
				rrdVal.setPriskill(rs.getString("priskill"));
				rrdVal.setIshlready(rs.getBoolean("ishlready"));
				rrdVal.setFfentity(rs.getString("ffentity"));
				rrdVal.setLockduration(rs.getString("lockduration"));
				rrdVal.setWbsecode(rs.getString("wbsecode"));
				rrdVal.setDemandpriority(rs.getString("demandpriority"));
				rrdVal.setSrclocation(rs.getString("srclocation"));
				rrdVal.setWrklocation(rs.getString("wrklocation"));
				rrdVal.setCareerlevel(rs.getString("careerlevel"));
				rrdVal.setOnsitecomponent(rs.getBoolean("onsitecomponent"));
				rrdVal.setVisatype(rs.getString("visatype"));
				rrdVal.setVisaready(rs.getBoolean("visaready"));
				rrdVal.setDemandid(demandID);
				rrdVal.setCreatedby(rs.getString("createdby"));
				rrdVal.setUpdatedby("updatedby");
				rrdVal.setCreatedts(rs.getTimestamp("createdts"));
				rrdVal.setUpdatedts(rs.getTimestamp("updatedts"));
				rrdVal.setStatus(rs.getBoolean("status"));
				rrdVal.setRescount(rs.getInt("resourcecount"));
			
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return rrdVal;
	}
	
	public static ArrayList<RRDMapper> rrdNumberFetch(String demandID) throws ParseException, SQLException{
		ArrayList<RRDMapper> arrJson = new ArrayList<>();
		Connection con = DatabaseConnection.getRAWConnection();
		PreparedStatement ps=con.prepareStatement("select * from rrddemandmap where demandid=?");
		ps.setString(1, demandID);
		try {
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				RRDMapper rrdVal = new RRDMapper();
				rrdVal.setId(rs.getInt("serialno"));
				rrdVal.setRrdid(rs.getString("rrdid"));
				rrdVal.setSearchDemandId(demandID);
				System.out.println("RRD Val: " + rrdVal.toString());
				arrJson.add(rrdVal);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return arrJson;
	}
	
	
	public static boolean isDemandIdPresent(String demandID){
		boolean demandIdStatus = false;
		try {
			Connection con = DatabaseConnection.getRAWConnection();
			PreparedStatement ps=con.prepareStatement("select * from resourcerequestdetails where demandid=?");
			ps.setString(1, demandID);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				demandIdStatus = true;
			}else {
				demandIdStatus = false;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return demandIdStatus;
	}
	
	public static boolean isRrdMappedValuePresent(RRDMapper rrdVal) throws ParseException, SQLException{
		boolean rrdMapStatus = false;
		try {
			Connection con = DatabaseConnection.getRAWConnection();
			PreparedStatement ps=con.prepareStatement("select * from rrddemandmap where demandid=? and serialno=?");
			ps.setString(1, rrdVal.getSearchDemandId());
			ps.setInt(2, rrdVal.getId());
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				rrdMapStatus = true;
			}else {
				rrdMapStatus = false;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return rrdMapStatus;
	}
	
	
	public static boolean updateRrdMapValues(RRDMapper rrdVal) throws ParseException, SQLException{
		boolean rrdMapStatus = false;
		int responseCode=0;
		try {
			Connection con = DatabaseConnection.getRAWConnection();
			PreparedStatement ps=con.prepareStatement("update rrddemandmap set rrdid =? where demandid=? and serialno=?");
			ps.setString(1, rrdVal.getRrdid());
			ps.setString(2, rrdVal.getSearchDemandId());
			ps.setInt(3, rrdVal.getId());
			responseCode = ps.executeUpdate();
			if(responseCode == 1){
				con.commit();
				rrdMapStatus= true;
			}else {
				con.rollback();
			}
			System.out.println("Response Code:" + responseCode);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return rrdMapStatus;
	}
	
	
	public static boolean insertRrdMapValues(RRDMapper rrdVal) throws ParseException, SQLException{
		boolean rrdMapStatus = false;
		int responseCode=0;
		try {
			Connection con = DatabaseConnection.getRAWConnection();
			PreparedStatement ps=con.prepareStatement("insert into rrddemandmap(rrdid,demandid,serialno) values (?,?,?)");
			ps.setString(1, rrdVal.getRrdid());
			ps.setString(2, rrdVal.getSearchDemandId());
			ps.setInt(3, rrdVal.getId());
			responseCode = ps.executeUpdate();
			if(responseCode == 1){
				con.commit();
				rrdMapStatus= true;
			}else {
				con.rollback();
			}
			System.out.println("Response Code:" + responseCode);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return rrdMapStatus;
	}
	

	private static String setResourceDateDetails(String rrdDate) throws ParseException {
		String datefrmJson = rrdDate; 
		DateTimeFormatter fmt = ISODateTimeFormat.dateTime().withZoneUTC();
		String x=fmt.parseDateTime(datefrmJson).toDate().toString();
		System.out.println("Ed Fulfill Date Initial: " + datefrmJson);
		System.out.println("Ed Fulfill Date Joda IST: " + x);
		
		
				String dateStr = x;
				DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
				Date date = (Date)formatter.parse(dateStr);
				System.out.println(date);        

				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				String formatedDate = cal.get(Calendar.DATE) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" +         cal.get(Calendar.YEAR);
				System.out.println("formatedDate : " + formatedDate);
		return formatedDate;
	}
	
	private boolean checkAllRowsInsertion(int[] batchArray){
		boolean success = false;
		for(int arrayVal:batchArray){
			if(arrayVal == 1){
				success = true;
			}else {
				success = false;
				break;
			}
		}
		return success;
	}
	

}

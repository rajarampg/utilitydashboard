/**
 * 
 */
package com.pmo.dboperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.pmo.commons.Util;
import com.pmo.connection.DatabaseConnection;
import com.pmo.login.TableDetail;

/**
 * @author sankar.arumugam
 * 
 */
public class InsertResourceDetails {

	// DatabaseConnection dbConn = new DatabaseConnection();
	Connection con = null;
	PreparedStatement pst;
	Statement st;
	ResultSet rs = null;
	java.util.Date date = new java.util.Date();
	Timestamp timestamp = new Timestamp(date.getTime());

	/**
	 * @param td
	 * @param timestamp
	 * @return
	 */
	public String insertDetails(TableDetail td) {
		String status = "false";
		try {
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			String insertTableSQL = "insert into EmployeeDetails (employeenumber,resourcename,enterpriseid,rollondate,specificstream,capability,careerlevel,projectname,client,currentlocation,projectdetails,gender,wmt_userid,wmt_accessdate,wmt_grantdate,bayno,floor,workstation,locktype,onboardtimestamp,delivery_centre,visa_type,duration_stay,phone_no,primary_skill,secondary_skill,proficiency_level,first_name,last_name,manager_id, supervisor_name, employee_status, rolloffdate, rolled_on_by,rrdid)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			pst = con.prepareStatement(insertTableSQL);
			pst.setInt(1, td.getEmpId());
			pst.setString(2, td.getRname());
			pst.setString(3, td.getEnterpriseId());
			pst.setString(4, td.getRollonDate());
			pst.setString(5, td.getStream());
			pst.setString(6, td.getCapability());
			pst.setString(7, td.getClevel());
			pst.setString(8, td.getProjName());
			pst.setString(9, td.getClient());
			pst.setString(10, td.getCurrLocation());
			pst.setString(11, td.getProjDetails());
			pst.setString(12, td.getGender());
			pst.setString(13, td.getWmtid());
			pst.setString(14, td.getRequestdate());
			pst.setString(15, td.getGrantdate());
			pst.setInt(16, td.getBayNumber());
			pst.setString(17, td.getFloor());
			pst.setString(18, td.getWorkstationNumber());
			pst.setString(19, td.getLockType());
			// pst.setString(20, td.getEmployeeType());
			//pst.setTimestamp(20, timestamp);
			pst.setString(20, td.getSiteLocation());
			pst.setString(21, td.getVisaType());
			pst.setString(22, td.getDuration());
			pst.setLong(23, td.getPhoneNo());
			pst.setString(24, td.getPrimarySkill());
			pst.setString(25, td.getSecondarySkill());
			pst.setString(26, td.getProficiency());
			pst.setString(27, td.getFirstName());
			pst.setString(28, td.getLastName());
			pst.setString(29, td.getManagerId());
			pst.setString(30, td.getSupervisorName());
			pst.setInt(31, td.getEmployeeStatus());
			pst.setString(32, td.getRolloffDate());
			pst.setString(33, td.getRolledOnBy());
			pst.setString(34, td.getRrdId());
			int count = pst.executeUpdate();
			if (count == 1) {
				status = "true";
				con.commit();
			}

			else {
				status = "false";
				con.rollback();
			}

		} catch (SQLException e) {
			status = "false";
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			status = "false";
		} finally {
			// DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return status;

	}


	public boolean updateEmployeeDetails(TableDetail td) {
		try {
			// con = dbConn.mySqlConnection();
			// con.setAutoCommit(false);
			con = DatabaseConnection.getRAWConnection();
			String updateTableSQL = "UPDATE EmployeeDetails SET ResourceName = ?, EnterpriseId = ?,RollOnDate=?,rolloffdate=?, "
					+ " specificstream=?,Capability=?,CareerLevel=?,ProjectName=?,Client=?,"
					+ " CurrentLocation=?,ProjectDetails=?,Gender=?,"
					+ " wmt_userid=?,wmt_accessdate=?,wmt_grantdate=?,workstation=?,bayno=?,floor=?,locktype=?,onboardtimestamp=CURRENT_TIMESTAMP, "
					+ " delivery_centre=? ,visa_type=?,duration_stay=?,phone_no=? ,primary_skill=? ,secondary_skill=? ,proficiency_level=?, manager_id=?,"
					+ " supervisor_name = ? ,employee_status =?, rolled_on_by=?, rrdid=?" + " WHERE EmployeeNumber=?";
			pst = con.prepareStatement(updateTableSQL);
			pst.setString(1, td.getRname());
			pst.setString(2, td.getEnterpriseId());
			pst.setString(3, td.getRollonDate());
			pst.setString(4, td.getRolloffDate());
			pst.setString(5, td.getStream());
			pst.setString(6, td.getCapability());
			pst.setString(7, td.getClevel());
			pst.setString(8, td.getProjName());
			pst.setString(9, td.getClient());
			pst.setString(10, td.getCurrLocation());
			pst.setString(11, td.getProjDetails());
			pst.setString(12, td.getGender());
			pst.setString(13, td.getWmtid());
			pst.setString(14, td.getRequestdate());
			pst.setString(15, td.getGrantdate());
			pst.setString(16, td.getWorkstationNumber());
			pst.setInt(17, td.getBayNumber());
			pst.setString(18, td.getFloor());
			pst.setString(19, td.getLockType());
			//pst.setTimestamp(20, timestamp);
			pst.setString(20, td.getSiteLocation());
			pst.setString(21, td.getVisaType());
			pst.setString(22, td.getDuration());
			pst.setLong(23, td.getPhoneNo());
			pst.setString(24, td.getPrimarySkill());
			pst.setString(25, td.getSecondarySkill());
			pst.setString(26, td.getProficiency());
			pst.setString(27, td.getManagerId());
			pst.setString(28, td.getSupervisorName());
			pst.setInt(29, td.getEmployeeStatus());
			pst.setString(30, td.getRolledOnBy());
			pst.setString(31, td.getRrdId());
			pst.setInt(32, td.getEmpId());
			int count = pst.executeUpdate();

			if (count >= 1 && !(td.getWmtid().isEmpty())) {
				InsertTaskDetails insertTasks = new InsertTaskDetails();
				td.setTaskDescription(td.getRname());
				td.setTaskName("WMT Onboard");
				SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
				Date date = new Date();
				Date endDate = new Date(date.getTime()); 
				td.setEndDate(dateFormat.format(endDate).toString());
				if (insertTasks.updateRequestTasks(td)) {
					con.commit();
					return true;
				} else {
					try {
						con.rollback();
					} catch (Exception ex) {
						ex.printStackTrace();
					}
					return false;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} finally {
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return false;
	}
	
	
	public boolean modifyEmployeeDetails(TableDetail td) {
		try {
			con = DatabaseConnection.getRAWConnection();
			String updateTableSQL = "update employeedetails SET enterpriseid =?, first_name=?,"
					+ " last_name=?, wmt_userid=?, phone_no = ?, secondary_skill = ? WHERE EmployeeNumber=?";
			pst = con.prepareStatement(updateTableSQL);
			pst.setString(1, td.getEnterpriseId());
			pst.setString(2, td.getFirstName());
			pst.setString(3, td.getLastName());
			pst.setString(4, td.getWmtid());
			pst.setLong(5, td.getPhoneNo());
			pst.setString(6, td.getSecondarySkill());
			pst.setInt(7, td.getEmpId());
			int count = pst.executeUpdate();

			if (count == 1) {
				con.commit();
				return true;
			}

		} catch (SQLException e) {
				e.printStackTrace();
		} finally {
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return false;
	}
	
	public TableDetail getEmployeeDetails(String enterpriseId) {
		TableDetail tableDetail = null;
		try {
			con = DatabaseConnection.getRAWConnection();
			String selectQuery = "select employeenumber, enterpriseid, first_name,last_name,wmt_userid,phone_no,secondary_skill from employeedetails WHERE enterpriseid=?";
			pst = con.prepareStatement(selectQuery);
			pst.setString(1, enterpriseId);
			rs = pst.executeQuery();
			if(rs.next()){
				tableDetail = new TableDetail();
				tableDetail.setFirstName(rs.getString("first_name"));
				tableDetail.setLastName(rs.getString("last_name"));
				tableDetail.setPhoneNo(rs.getLong("phone_no"));
				tableDetail.setEmpId(rs.getInt("employeenumber"));
//				tableDetail.setEnterpriseId(enterpriseId);
				tableDetail.setEnterpriseId(rs.getString("enterpriseid"));
				tableDetail.setSecondarySkill(Util.checkForNull(rs.getString("secondary_skill")));
				
				if(rs.getString("wmt_userid")!=null)
				tableDetail.setWmtid(rs.getString("wmt_userid"));
				else
				tableDetail.setWmtid("");
				
				
			}

		} catch (SQLException e) {
				e.printStackTrace();
		} finally {
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return tableDetail;
	}
	

	/**
	 * @param employeeNo
	 * @return
	 */
	public String checkCountHardware(int employeeNo) {
		int check = 0;

		try {
			String countRSA = "select count(*) from rsadetails  where employeenumber=?";
			con = DatabaseConnection.getRAWConnection();
			pst = con.prepareStatement(countRSA);
			pst.setInt(1, employeeNo);
			rs = pst.executeQuery();
			while (rs.next()) {
				check = rs.getInt(1);
			}
			if (check > 0) {
				return "rsafalse";
			} else {
				String countMob = "select count(*) from mobiledetails  where employeenumber=?";
				pst = con.prepareStatement(countMob);
				pst.setInt(1, employeeNo);
				rs = pst.executeQuery();
				while (rs.next()) {
					check = rs.getInt(1);
				}
				if (check > 0) {
					return "mobfalse";
				} else {
					String countLap = "select count(*) from laptopdetails  where employeenumber=?";
					pst = con.prepareStatement(countLap);
					pst.setInt(1, employeeNo);
					rs = pst.executeQuery();
					while (rs.next()) {
						check = rs.getInt(1);
					}
					if (check > 0) {
						return "lapfalse";
					} else {
						String countCer = "select count(*) from certification  where employeenumber=?";
						pst = con.prepareStatement(countCer);
						pst.setInt(1, employeeNo);
						rs = pst.executeQuery();
						while (rs.next()) {
							check = rs.getInt(1);
						}
						if (check > 0) {
							return "certfalse";
						} else {
							String countReward = "select count(*) from rewards_recognition  where employeenumber=?";
							pst = con.prepareStatement(countReward);
							pst.setInt(1, employeeNo);
							rs = pst.executeQuery();
							while (rs.next()) {
								check = rs.getInt(1);
							}
							if (check > 0) {
								return "rewardfalse";
							}
						}
					}
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}

		return "true";
	}

	/*
	 * public void sendmail() throws InterruptedException {
	 * System.setProperty("webdriver.chrome.driver",
	 * "C:/sankar/chromedriver.exe"); ChromeOptions options = new
	 * ChromeOptions(); options.addArguments("--test-type");
	 * options.addArguments("--disable-extensions"); // WebDriver driver = new
	 * ChromeDriver(options); WebDriver driver = new HtmlUnitDriver();
	 * ((HtmlUnitDriver)driver).setJavascriptEnabled(true);
	 * driver.get("https://email.accenture.com"); //
	 * driver.manage().window().maximize();
	 * 
	 * // Select location = new Select(driver.findElement(By.id("domain"))); //
	 * location.selectByValue("Homeoffice");
	 * driver.findElement(By.id("username")).sendKeys(
	 * "sankar.arumugam@accenture.com");
	 * driver.findElement(By.id("password")).sendKeys("Gr8british123*");
	 * driver.findElement(By.xpath("//input[@value='Sign in']")).click();
	 * 
	 * Thread.sleep(20000); driver.findElement( By.xpath(
	 * "//span[text()='New mail']")) .click();
	 * 
	 * Thread.sleep(2000);
	 * 
	 * 
	 * driver.findElement(By.xpath("//input[@autoid='_fp_7']")).sendKeys(
	 * "sankar.arumugam@accenture.com");
	 * driver.findElement(By.xpath("//input[@autoid='_mcp_k']")).sendKeys(
	 * "Test ");
	 * 
	 * 
	 * 
	 * driver.switchTo().frame(driver.findElement(By.id("EditorBody")));
	 * driver.findElement(By.xpath("//body/div")).sendKeys("Success");
	 * driver.switchTo().defaultContent();
	 * driver.findElement(By.xpath("//span[text()='SEND']")) .click(); //
	 * Thread.sleep(3000);
	 * 
	 * // driver.close(); //driver.switchTo().window(ParentWindow);
	 * 
	 * // driver.findElement(By.xpath("//a[@id='aLogOff']/span")).click();
	 * 
	 * driver.quit();
	 * 
	 * }
	 */

	public void deleteResourceHardware(int employeeId) {

		int count = 0;
		boolean status = false;
		try {
			con = DatabaseConnection.getRAWConnection();

			String deleteEmployeeRsa = "Delete from rsaDetails WHERE EmployeeNumber=?";
			try {

				pst = con.prepareStatement(deleteEmployeeRsa);
				pst.setInt(1, employeeId);
				count = pst.executeUpdate();
				if (count >= 1)
					status = true;

			} catch (SQLException e) {
				e.printStackTrace();
				status = false;
			} finally {
				DatabaseConnection.closePst(pst);
			}

			String deleteEmployeeMob = "Delete from mobileDetails WHERE EmployeeNumber=?";
			try {
				pst = con.prepareStatement(deleteEmployeeMob);
				pst.setInt(1, employeeId);
				count = pst.executeUpdate();
				if (count >= 1)
					status = true;

			} catch (SQLException e) {
				e.printStackTrace();
				status = false;
			} finally {
				DatabaseConnection.closePst(pst);
			}
			String deleteEmployeeLap = "Delete from laptopDetails WHERE EmployeeNumber=?";
			try {
				pst = con.prepareStatement(deleteEmployeeLap);
				pst.setInt(1, employeeId);
				count = pst.executeUpdate();
				if (count >= 1)
					status = true;
			} catch (SQLException e) {
				e.printStackTrace();
				status = false;
			} finally {
				DatabaseConnection.closePst(pst);
			}

			String deleteEmployeeCert = "Delete from certification WHERE EmployeeNumber=?";
			try {
				pst = con.prepareStatement(deleteEmployeeCert);
				pst.setInt(1, employeeId);
				count = pst.executeUpdate();
				if (count >= 1)
					status = true;

			} catch (SQLException e) {
				e.printStackTrace();
				status = false;
			} finally {
				DatabaseConnection.closePst(pst);
			}

			String deleteEmployeereward = "Delete from rewards_recognition WHERE EmployeeNumber=?";
			try {
				pst = con.prepareStatement(deleteEmployeereward);
				pst.setInt(1, employeeId);
				count = pst.executeUpdate();
				if (count >= 1)
					status = true;

			} catch (SQLException e) {
				e.printStackTrace();
				status = false;
			} finally {
				DatabaseConnection.closePst(pst);
			}

			if (status)
				con.commit();
			else
				con.rollback();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeCon(con);
		}

	}

}
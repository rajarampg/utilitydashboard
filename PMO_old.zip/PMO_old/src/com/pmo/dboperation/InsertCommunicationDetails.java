package com.pmo.dboperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.pmo.connection.DatabaseConnection;
import com.pmo.login.HardwareMaintenance;

public class InsertCommunicationDetails {

	// DatabaseConnection dbconn = new DatabaseConnection();
	// Connection con = dbconn.mySqlConnection();
	Connection con = null;
	PreparedStatement pst = null;
	Statement stmt = null;
	ResultSet rs = null;

	public boolean insertIntoCommunication(ArrayList<HardwareMaintenance> list) {
		boolean insertStatus = false;
		boolean status = false;
		try {
			con = DatabaseConnection.getRAWConnection();
			for (HardwareMaintenance hm : list) {
				if (DeleteCommnication(hm, con) && insertIntoCommunication(hm, con)) {
					insertStatus = true;
				} else {
					insertStatus = false;
					break;
				}
			}
			if (insertStatus) {
				con.commit();
				status = true;
			} else {
				con.rollback();
				status = false;
			}

		} catch (SQLException e) {
			e.printStackTrace();
			status = false;
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		} finally {
			DatabaseConnection.closeCon(con);
		}

		return status;
	}

	public boolean DeleteCommnication(HardwareMaintenance td, Connection con) {
		boolean status = false;
		String deleteTableSQL = "Delete from communication WHERE employeenumber=? and month = ? and assettype = ?";
		try {

			pst = con.prepareStatement(deleteTableSQL);
			pst.setInt(1, td.getEmployeeNumber());
			pst.setString(2, td.getMonth());
			pst.setInt(3, td.getAssetType());
			int count = pst.executeUpdate();
			status = true;
			if (count != 0){status = true;con.commit();}
			else
				status = false;

		} catch (SQLException e) {
			status = false;
			e.printStackTrace();
			status = false;
		} catch (Exception e) {
			status = false;
			e.printStackTrace();
			status = false;
		} finally {
			DatabaseConnection.closePst(pst);
		}
		return status;

	}

	public boolean insertIntoCommunication(HardwareMaintenance td, Connection con) {
		boolean status = false;
		try {
			String insertTableSQL = "insert into communication (employeenumber, project, month, assettype, assetnumber, cost) values (?,?,?,?,?,?)";
			pst = con.prepareStatement(insertTableSQL);
			pst.setInt(1, td.getEmployeeNumber());
			pst.setString(2, td.getProjectName());
			pst.setString(3, td.getMonth());
			pst.setInt(4, td.getAssetType());
			if(td.getAssetType()==1)
				pst.setLong(5, td.getMobileNo());
			else
				pst.setLong(5, td.getDataCardNumber());
			pst.setDouble(6, td.getCost());
			int count = pst.executeUpdate();
			if (count == 1)
				{status = true;con.commit();}
			else
				status = false;

		} catch (SQLException e) {
			e.printStackTrace();
			status = false;
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		} finally {
			DatabaseConnection.closePst(pst);
		}
		return status;

	}

}

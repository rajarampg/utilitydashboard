/**
 * 
 */
package com.pmo.dboperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import com.pmo.connection.DatabaseConnection;
import com.pmo.login.HardwareMaintenance;

/**
 * @author sankar.arumugam
 *
 */
public class InsertHardwareDetails {

	
	Connection con;
	java.util.Date date;
    Timestamp timestamp;
	PreparedStatement pst;
	Statement st;
	ResultSet rs;
	
    
    
    
    
	public String saveHardwareDetails(HardwareMaintenance hardwareDetails){
		String status = null;
		boolean rsastatus = true,mobstatus = true,lapstatus = true, dataCardStatus = true;
		boolean insert = false, update = false;
		try{
		con = DatabaseConnection.getRAWConnection();
		date= new java.util.Date();
		timestamp=new Timestamp(date.getTime());


		if(hardwareDetails.getRsaToken()!=0){
			if(hardwareDetails.isRsa()){
				rsastatus = updateRsaDetails(hardwareDetails);
				update = true;
			}else{
				rsastatus = insertRsaDetails(hardwareDetails);
				insert = true;
			}
		}

		if(hardwareDetails.getLaptopNo()!=null && !hardwareDetails.getLaptopNo().trim().equals("")){
			if(hardwareDetails.isLaptop()){
				lapstatus = updateLapDetails(hardwareDetails);
				update=true;
			}
			else{
				lapstatus = insertLapDetails(hardwareDetails);
				insert = true;
			}
		}

		if(hardwareDetails.getMobileNo()!=0){
			if(hardwareDetails.isMobile()){
				mobstatus = updateMobDetails(hardwareDetails);
				update = true;
			}else{
				mobstatus = insertMobDetails(hardwareDetails);
				insert = true;
			}
		}

		if(hardwareDetails.getDataCardNumber()!=0){
			if(hardwareDetails.isDataCard()){
				dataCardStatus = updateDataCardDetails(hardwareDetails);
				update = true;
			}
			else{
				dataCardStatus = insertDataCardDetails(hardwareDetails);
				insert = true;
			}
		}

		if(mobstatus && rsastatus && lapstatus && dataCardStatus){
			if(update || insert){
				if(commitTransaction())
					status = "Details Saved Successfully!!";
				else
					status = "Error saving details!!";
			}else{
				status = "No data to save";
				DatabaseConnection.closeCon(con);
			}
		}else{
			rollbackTransaction();
			status = "Oops! Error while saving hardware details";
		}
		}catch(Exception e){
			e.printStackTrace();
			status = "Oops! Error while saving hardware details";
		}finally{
			DatabaseConnection.closeCon(con);
		}
		
		return status;
	}
    
    
    public boolean commitTransaction(){
    	try{
    	con.commit();
    	return true;
    	}catch(Exception e){
    		e.printStackTrace();
    	}finally{
    		try{
    		con.close();
    		}catch(Exception e){
    			e.printStackTrace();
    		}
    	}
    	return false;
    }
    
    public boolean rollbackTransaction(){
    	try{
    	con.rollback();
    	
    	return true;
    	}catch(Exception e){
    		e.printStackTrace();
    	}finally{
    		try{
    		con.close();
    		}catch(Exception e){
    			e.printStackTrace();
    		}
    	}
    	return false;
    }
	
	public boolean insertRsaDetails(HardwareMaintenance td){
	try {

		String insertTableSQL = "insert into rsadetails VALUES(?,?,?,?,CURRENT_TIMESTAMP)";
		pst = con.prepareStatement(insertTableSQL);
		pst.setInt(1, td.getRsaToken());
		pst.setInt(2, td.getEmployeeNumber());
		pst.setString(3, td.getEmployeeName());	
		pst.setString(4, td.getValidDate());
	//	pst.setTimestamp(5, timestamp);
		if(pst.executeUpdate() == 1)
			return true;
	} catch (SQLException e) {
		e.printStackTrace();
	}finally{
		DatabaseConnection.closePst(pst);
	}
	return false;
}
public boolean insertMobDetails(HardwareMaintenance td)
{
	try {

		String insertTableSQL = "insert into mobiledetails VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)";
		pst = con.prepareStatement(insertTableSQL);
		pst.setLong(1, td.getMobileNo());
		pst.setInt(2, td.getEmployeeNumber());
		pst.setString(3, td.getEmployeeName());	
		pst.setString(4,td.getStream());		
		pst.setString(5,td.getBillCycle());	
		pst.setString(6,td.getServiceProvider());
		//pst.setTimestamp(7, timestamp);
		if(pst.executeUpdate() == 1)
			return true;

	} catch (SQLException e) {
		e.printStackTrace();
	}finally{
		DatabaseConnection.closePst(pst);
	}
	return false;
}
public boolean insertLapDetails(HardwareMaintenance td)
{
	try {

		String insertTableSQL = "insert into laptopdetails VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)";
		pst = con.prepareStatement(insertTableSQL);
		pst.setString(1, td.getLaptopNo());
		pst.setInt(2, td.getEmployeeNumber());
		pst.setString(3, td.getEmployeeName());		
		pst.setString(4,td.getAssetTag());
		pst.setString(5,td.getMake());	
		//pst.setTimestamp(6, timestamp);
		if(pst.executeUpdate() ==1)
			return true;

	} catch (SQLException e) {
		e.printStackTrace();
	}finally{
		DatabaseConnection.closePst(pst);
	}
	return false;
}

public boolean insertDataCardDetails(HardwareMaintenance td)
{
	try {

		String insertTableSQL = "insert into datacarddetails (datacardnumber,employeenumber,billcycle,serviceprovider,datatimestamp)VALUES(?,?,?,?,CURRENT_TIMESTAMP)";
		pst = con.prepareStatement(insertTableSQL);
		pst.setLong(1, td.getDataCardNumber());
		pst.setInt(2, td.getEmployeeNumber());
		pst.setString(3, td.getDataCardBillCycle());	
		pst.setString(4,td.getDataCardServiceProvider());	
		//pst.setTimestamp(5, timestamp);
		if(pst.executeUpdate() ==1)
			return true;

	} catch (SQLException e) {
		e.printStackTrace();
	} catch (Exception e) {
		e.printStackTrace();
	}finally{
		DatabaseConnection.closePst(pst);
	}
	return false;
}


public boolean updateDataCardDetails(HardwareMaintenance td)
{
	try {

		String insertTableSQL = "update datacarddetails set datacardnumber = ?,billcycle = ?,serviceprovider = ?, datatimestamp = CURRENT_TIMESTAMP where employeenumber = ?";
		pst = con.prepareStatement(insertTableSQL);
		pst.setLong(1, td.getDataCardNumber());
		pst.setString(2, td.getDataCardBillCycle());	
		pst.setString(3,td.getDataCardServiceProvider());	
		//pst.setTimestamp(4, timestamp);
		pst.setInt(4, td.getEmployeeNumber());
		if(pst.executeUpdate() == 1)
			return true;
	} catch (SQLException e) {
		e.printStackTrace();
	} catch (Exception e) {
		e.printStackTrace();
	}finally{
		DatabaseConnection.closePst(pst);
	}
	return false;
}


public boolean updateRsaDetails(HardwareMaintenance td)
{
	try {
		String updateTableSQL = "UPDATE rsadetails SET rsatoken=?,employeename = ?,validdate = ?,rsatimestamp=CURRENT_TIMESTAMP WHERE employeenumber=?";
		pst = con.prepareStatement(updateTableSQL);
		pst.setInt(1, td.getRsaToken());
		pst.setString(2, td.getEmployeeName());		
		pst.setString(3, td.getValidDate());
		//pst.setTimestamp(4, timestamp);
		pst.setInt(4, td.getEmployeeNumber());
		int updateCount = pst.executeUpdate();
		
		if(updateCount==1)
			return true;
			
	} catch (SQLException e) {
		e.printStackTrace();
		return false;
	} catch (Exception e) {
		e.printStackTrace();
	}finally{
		DatabaseConnection.closePst(pst);
	}
	return false;
}
	public boolean updateMobDetails(HardwareMaintenance td)
	{
		try {
			String updateTableSQL = "UPDATE mobiledetails SET  mobileno = ?,employeename = ?,stream = ?,billcycle = ?, Servicepro=?,mobiletimestamp=CURRENT_TIMESTAMP WHERE employeenumber=?";
			pst = con.prepareStatement(updateTableSQL);
			pst.setLong(1, td.getMobileNo());
			pst.setString(2, td.getEmployeeName());			
			pst.setString(3,td.getStream());			
			pst.setString(4,td.getBillCycle());	
			pst.setString(5,td.getServiceProvider());
			//pst.setTimestamp(6, timestamp);
			pst.setInt(6, td.getEmployeeNumber());
			int updateCount = pst.executeUpdate();
			if(updateCount==1)
				return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DatabaseConnection.closePst(pst);
		}
		return false;
	}
		
		public boolean updateLapDetails(HardwareMaintenance td)
		{
			try {
				String updateTableSQL = "UPDATE laptopdetails SET Laptopno = ?,Employeename = ?, Assettag = ?,Make = ?,laptoptimestamp=CURRENT_TIMESTAMP WHERE employeenumber=?";
				pst = con.prepareStatement(updateTableSQL);
				pst.setString(1, td.getLaptopNo());
				pst.setString(2, td.getEmployeeName());					
				pst.setString(3,td.getAssetTag());
				pst.setString(4,td.getMake());	
			//	pst.setTimestamp(5, timestamp);
				pst.setInt(5, td.getEmployeeNumber());
				int updateCount = pst.executeUpdate();
				if(updateCount==1){

					return true;
				}
					
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				DatabaseConnection.closePst(pst);
			}
			return false;
		}


	}
	




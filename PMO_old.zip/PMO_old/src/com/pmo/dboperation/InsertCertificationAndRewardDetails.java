package com.pmo.dboperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;

//import javafx.scene.control.Tab;

import com.pmo.connection.DatabaseConnection;
import com.pmo.login.TableDetail;

public class InsertCertificationAndRewardDetails {

	// DatabaseConnection dbConn = new DatabaseConnection();
	Connection con = null;
	PreparedStatement pst = null;
	Statement st = null;
	ResultSet rs = null;
	java.util.Date date = new java.util.Date();
	Timestamp timestamp = new Timestamp(date.getTime());
	boolean status = false;

	public boolean insertCertificationDetails(TableDetail td) {

		try {
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			String insertSqlTable = "insert into certification(employeenumber,employeename,stream,certificationtype,certificationname,certificationdate,certtimestamp,score,status) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP,?,?)";
			pst = con.prepareStatement(insertSqlTable);
			pst.setInt(1, td.getEmpId());
			pst.setString(2, td.getRname());
			pst.setString(3, td.getStream());
			pst.setString(4, td.getCertificationType());
			pst.setString(5, td.getCertificationName());
			pst.setString(6, td.getCertificationDate());
			//pst.setTimestamp(7, timestamp);
			pst.setInt(7, td.getScore());
			pst.setString(8, td.getCertificationStatus());

			int count = pst.executeUpdate();
			if (count >= 1) {
				con.commit();
				status = true;
			} else {
				System.out.println("Error occured while inserting certification details into database");
				con.rollback();
				status = false;
			}

		}

		catch (SQLException e) {
			status = false;
			e.printStackTrace();

		} catch (Exception e) {
			status = false;
			e.printStackTrace();

		} finally {
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return status;

	}
	
	public boolean updateCertificationDetails(TableDetail td) {

		try {
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			String insertSqlTable = "update certification set certificationdate=?,certtimestamp=CURRENT_TIMESTAMP,score=?,status=? where employeenumber=? and certificationname=? and status='training'";
			pst = con.prepareStatement(insertSqlTable);
			pst.setString(1, td.getCertificationDate());
			pst.setInt(2, td.getScore());
			pst.setString(3, td.getCertificationStatus());
			pst.setInt(4, td.getEmpId());
			pst.setString(5, td.getCertificationName());

			int count = pst.executeUpdate();
			if (count >= 1) {
				con.commit();
				status = true;
			} else {
				System.out.println("Error occured while updating certification details into database");
				con.rollback();
				status = false;
			}

		}

		catch (SQLException e) {
			status = false;
			e.printStackTrace();

		} catch (Exception e) {
			status = false;
			e.printStackTrace();

		} finally {
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return status;

	}
	
	
	public boolean updateCertificationDetailsFrmCerti(TableDetail td) {

		try {
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			String insertSqlTable = "update certification set certificationdate=?,certtimestamp=CURRENT_TIMESTAMP,score=?,status=? where employeenumber=? and certificationname=? and status='certification'";
			pst = con.prepareStatement(insertSqlTable);
			pst.setString(1, td.getCertificationDate());
			pst.setInt(2, td.getScore());
			pst.setString(3, td.getCertificationStatus());
			pst.setInt(4, td.getEmpId());
			pst.setString(5, td.getCertificationName());

			int count = pst.executeUpdate();
			if (count >= 1) {
				con.commit();
				status = true;
			} else {
				System.out.println("Error occured while updating certification details into database");
				con.rollback();
				status = false;
			}

		}

		catch (SQLException e) {
			status = false;
			e.printStackTrace();

		} catch (Exception e) {
			status = false;
			e.printStackTrace();

		} finally {
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return status;

	}
	
	
	public boolean updateTrainingDetails(TableDetail td) {

		try {
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			String insertSqlTable = "update certification set status=? where employeenumber=? and certificationname=? and status='notraining'";
			pst = con.prepareStatement(insertSqlTable);
			pst.setString(1, td.getCertificationStatus());
			pst.setInt(2, td.getEmpId());
			pst.setString(3, td.getCertificationName());

			int count = pst.executeUpdate();
			if (count >= 1) {
				con.commit();
				status = true;
			} else {
				System.out.println("Error occured while updating training details into database");
				con.rollback();
				status = false;
			}

		}

		catch (SQLException e) {
			status = false;
			e.printStackTrace();

		} catch (Exception e) {
			status = false;
			e.printStackTrace();

		} finally {
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}
		return status;

	}
	
	
	public int checkCertiDtls(TableDetail td) throws SQLException{
		int retVal =0;
		con = DatabaseConnection.getRAWConnection();
//		pst = con.prepareStatement("select * from certification where employeenumber=? and certificationname=? and status='training'");
		pst = con.prepareStatement("select employeenumber,certificationname,status from certification where employeenumber=? and certificationname=?");
		pst.setInt(1, td.getEmpId());
		pst.setString(2, td.getCertificationName());
//		pst.setString(3, td.getCertificationStatus());
		System.out.println(td.getEmpId()+td.getCertificationName()+td.getCertificationStatus());
		rs = pst.executeQuery();
		if (rs.next()){
			int empNum = rs.getInt("employeenumber");
			String certiName= rs.getString("certificationname");
			String currentStatus=rs.getString("status");
			System.out.println("Status from UI:" + currentStatus);
			if(empNum==td.getEmpId() && certiName.equalsIgnoreCase(td.getCertificationName()) && currentStatus.equalsIgnoreCase("notraining")){
				retVal=1;
			} else if (empNum==td.getEmpId() && certiName.equalsIgnoreCase(td.getCertificationName()) && currentStatus.equalsIgnoreCase("training")) {
				retVal=2;
			} else if(empNum==td.getEmpId() && certiName.equalsIgnoreCase(td.getCertificationName()) && currentStatus.equalsIgnoreCase("certification")){
				retVal=3;
			}
			
		} else {
			retVal=4;
		}	 
		DatabaseConnection.closeRs(rs);
		DatabaseConnection.closePst(pst);
		DatabaseConnection.closeCon(con);
		return retVal;
		
	}
	
	
	public int insertRewards(List<TableDetail> list) {
		int recordCount = 0;
		boolean status = false;
		Connection con = null;
		try {
			// con.setAutoCommit(false);
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			for (TableDetail td : list) {
				if (insertRewardDetails(td, con)) {
					recordCount++;
					status = true;
				} else {
					// con.rollback();
					// dbConn.closeConnection(con, null, null);
					status = false;
					break;
				}

			}

			if (status) {
				con.commit();
			} else {
				recordCount = 0;
				con.rollback();

			}
		} catch (SQLException e) {
			e.printStackTrace();

			recordCount = 0;

		} catch (Exception e) {
			e.printStackTrace();

			recordCount = 0;
		} finally {
			DatabaseConnection.closeCon(con);
		}

		// con.close();
		System.out.println("no of records inserted :" + recordCount);
		return recordCount;
	}

	public boolean insertRewardDetails(TableDetail td, Connection con) {
		boolean status = false;
		
		try {
				
			String insertSqlTable1 = "INSERT INTO rewards_recognition(employeenumber, employeename, stream, awardtype, award, awardreason, rewardtimestamp, award_receiver, award_period)VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?, ?)";
			pst = con.prepareStatement(insertSqlTable1);
			pst.setInt(1, td.getEmpId());
			pst.setString(2, td.getRname());
			pst.setString(3, td.getStream());
			pst.setString(4, td.getAwardType());
			pst.setString(5, td.getAward());
			pst.setString(6, td.getReason());
			//pst.setTimestamp(7, timestamp);
			pst.setString(7, td.getAward_receiver());
			pst.setString(8, td.getAward_period());
			int count = pst.executeUpdate();
			if (count == 1) {
				status = true;
			} else {
				status = false;
			}

		}

		catch (SQLException e) {
			e.printStackTrace();
			status = false;

		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		} finally {
			DatabaseConnection.closePst(pst);
		}
		return status;

	}
	
}

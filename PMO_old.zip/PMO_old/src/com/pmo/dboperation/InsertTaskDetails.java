package com.pmo.dboperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.pmo.connection.DatabaseConnection;
import com.pmo.login.TableDetail;

public class InsertTaskDetails {

	// DatabaseConnection dbconn=new DatabaseConnection();
	Connection con = null;
	PreparedStatement pstmt = null;
	Statement stmt = null;
	ResultSet rs = null;
	Date date = new Date();
	Timestamp timestamp = new Timestamp(date.getTime());

	String status = "false";

	public String insertTaskDetails(TableDetail td) {

		try {
			// con=dbconn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			String insertSqlTable = "insert into tasks(assigned_date,task_desc,complete_date,status,assignedby,task_timestamp,task_name, isRequest, taskCompletedBy) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP,?,?,?)";
			pstmt = con.prepareStatement(insertSqlTable);
			pstmt.setString(1, td.getAssignedDate());
			pstmt.setString(2, td.getTaskDescription());
			pstmt.setString(3, td.getEndDate());
			pstmt.setString(4, td.getStatus());
			pstmt.setString(5, td.getAssignedBy());
//			pstmt.setTimestamp(6, timestamp);
			pstmt.setString(6, td.getTaskName());
			pstmt.setString(7, td.getRequestType());
			pstmt.setString(8, td.getTaskCompletedBy());
			int count = pstmt.executeUpdate();

			// pstmt.close();
			// con.close();
			if (count == 1) {
				status = "true";
				con.commit();
			} else {
				status = "false";
				con.rollback();
			}
		}

		catch (SQLException e) {
			e.printStackTrace();
			status = "false";
		} catch (Exception e) {
			e.printStackTrace();
			status = "false";
		} finally {
			// DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pstmt);
			DatabaseConnection.closeCon(con);
		}

		return status;

	}

	public void updateTaskDetails(TableDetail td) {
		try {
			// con=dbconn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			StringBuffer updateTableSQL = new StringBuffer();
			updateTableSQL.append("UPDATE tasks SET  assigned_date =?, task_desc =?,")
					.append("complete_date=?, status=?, assignedby=?,task_timestamp= CURRENT_TIMESTAMP, task_name=?, taskCompletedBy=?")
					.append(" WHERE task_desc=? and task_name=?");
			pstmt = con.prepareStatement(updateTableSQL.toString());

			pstmt.setString(1, td.getAssignedDate());
			pstmt.setString(2, td.getTaskDescription());
			pstmt.setString(3, td.getEndDate());
			pstmt.setString(4, td.getStatus());
			pstmt.setString(5, td.getAssignedBy());
			
			//pstmt.setTimestamp(6, timestamp);
			pstmt.setString(6, td.getTaskName());
			pstmt.setString(7, td.getTaskCompletedBy());
			pstmt.setString(8, td.getTaskDescription());
			pstmt.setString(9, td.getTaskName());
			
			int count = pstmt.executeUpdate();
			if (count >= 1)
				con.commit();
			 else 
				con.rollback();
				
			// pstmt.close();
			// con.close();

		} catch (SQLException e) {
			e.printStackTrace();

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			// DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pstmt);
			DatabaseConnection.closeCon(con);
		}

	}

	public boolean updateTaskDetails(TableDetail td, String prevTaskDesc) {
		int updatedRecord = -1;
		boolean status = false;
		try {
			// con=dbconn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			StringBuffer updateTableSQL = new StringBuffer();
			updateTableSQL.append("UPDATE tasks SET  assigned_date =?, task_desc =?,")
					.append("complete_date=?, status=?, assignedby=?,task_timestamp=CURRENT_TIMESTAMP, task_name=?, taskCompletedBy=?")
					.append(" WHERE task_desc=?");
			pstmt = con.prepareStatement(updateTableSQL.toString());

			pstmt.setString(1, td.getAssignedDate());
			pstmt.setString(2, td.getTaskDescription());
			pstmt.setString(3, td.getEndDate());
			pstmt.setString(4, td.getStatus());
			pstmt.setString(5, td.getAssignedBy());
			;
			//pstmt.setTimestamp(6, timestamp);
			pstmt.setString(6, td.getTaskName());
			pstmt.setString(7, td.getTaskCompletedBy());
			pstmt.setString(8, prevTaskDesc);
			
			updatedRecord = pstmt.executeUpdate();
			// pstmt.close();
			// con.close();
			if (updatedRecord == 0) {
				if (insertTaskDetails(td).equals("true")){
					status = true;
					con.commit();
				}
				else{
					status = false;
					con.rollback();
				}
			} else if (updatedRecord == 1)
				status = true;
		} catch (SQLException e) {
			e.printStackTrace();
			status = false;

		} catch (Exception e) {
			e.printStackTrace();
			status = false;

		} finally {
			// DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pstmt);
			DatabaseConnection.closeCon(con);
		}
		return status;
	}

	public boolean updateRequestTasks(TableDetail td) {
		boolean status = false;
		try {
			// con=dbconn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			String updateTable = "update tasks set complete_date=?, status=? , task_timestamp = CURRENT_TIMESTAMP, taskCompletedBy=? where task_name=? and task_desc = ?";
			pstmt = con.prepareStatement(updateTable);
			/*SimpleDateFormat sf = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
			Timestamp endTimestamp = new Timestamp(sf.parse(td.getEndDate()).getTime()); 
			Timestamp timestamp = new Timestamp(sf.parse(td.getEndDate()).getTime()); */
			pstmt.setString(1, td.getEndDate());
			pstmt.setString(2, "Completed");
			//pstmt.setTimestamp(3, timestamp);
			pstmt.setString(3, td.getTaskCompletedBy());
			pstmt.setString(4, td.getTaskName());
			pstmt.setString(5, td.getTaskDescription());
			int updatedRecords = pstmt.executeUpdate();

			if (updatedRecords == 1 ){
				status = true;
				con.commit();
			}
			else if (updatedRecords == 0 ){
				status = true;				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			status = false;
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		} finally {
			// DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pstmt);
			DatabaseConnection.closeCon(con);
		}
		return status;

	}
}
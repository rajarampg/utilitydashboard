/**
 * 
 */
package com.pmo.login;

import java.sql.Timestamp;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * @author sankar.arumugam
 *
 */
@JsonIgnoreProperties (ignoreUnknown = true)
public class TableDetail {

	private int empId;
	private String rname;
	private String firstName;
	private String lastName;
	private String enterpriseId;
	private String stream;
	private String rollonDate;
	private String rolloffDate;
	private String vdiRevokeDate;
	private String capability;
	private String clevel;	
	private String projName;
	private String client;
	private String currLocation;
	private String projDetails;		
	private int countQA;
	private int countDev;
	private int countOps;
	private String gender;
	private String wmtid;
	private String requestdate;
	private String grantdate;
	private String workstationNumber;
	private String floor;
	private int bayNumber;
	private String lockType;
	private String identifierType;
	private String identifierNumber;
	//private String employeeType;
	
	private boolean isExit ;
	private String rolloffReason;
	private String certificationType;
	private String certificationName;
	private String certificationDate;
	private String certificationStatus;
	private String awardType;
	private String award;
	private String reason;
	private Timestamp timestamp;
	private String assignedDate;
	private int daysElapsed;
	private String taskDescription;
	private String endDate;
	private String status;
	private String assignedBy;
	private String taskName;
	private String taskCompletedBy;
	private int task_id;
	private int score;
	private String siteLocation;
	private String deliveryCentre;
	private String visaType;
	private String duration;
	private long phoneNo;
	private String primarySkill;
	private String secondarySkill;
	private String proficiency;
	private String award_receiver;
	private String award_period;
	private String deptNumber;
	private String country;
	private String roleDesc;
	private String contractType;
	private int employeeStatus;
	private String managerId;
	private String directorId;
	private String vpUserId;
	private String supervisorName;
	private String requestType;
	private String contractorHostPattern;
	private String contractorUnixPattern;
	private String contractorRemedyPattern;
	private String contractorADPattern;
	private String contractorTDPattern;
	private String teraApplication;
	private String ADGroupShared;
	private String unixBoxes;
	private String businessJustification;
	private double rate;
	private String comments;
	private String technology;
	private String difficutyLevel;
	private String reportPeriod;
	private String rolledOnBy;
	private int rewardId;
	private String rrdId;
	private String contractId;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the empId
	 */
	public final int getEmpId() {
		return empId;
	}
	/**
	 * @param empId the empId to set
	 */
	public final void setEmpId(int empId) {
		this.empId = empId;
	}
	/**
	 * @return the rname
	 */
	public final String getRname() {
		return rname;
	}
	/**
	 * @param rname the rname to set
	 */
	public final void setRname(String rname) {
		this.rname = rname;
	}
	
	/**
	 * @return the capability
	 */
	public final String getCapability() {
		return capability;
	}
	/**
	 * @param capability the capability to set
	 */
	public final void setCapability(String capability) {
		this.capability = capability;
	}
	/**
	 * @return the clevel
	 */
	public final String getClevel() {
		return clevel;
	}
	/**
	 * @param clevel the clevel to set
	 */
	public final void setClevel(String clevel) {
		this.clevel = clevel;
	}	
	/**
	 * @return the projName
	 */
	public final String getProjName() {
		return projName;
	}
	/**
	 * @param projName the projName to set
	 */
	public final void setProjName(String projName) {
		this.projName = projName;
	}
	/**
	 * @return the client
	 */
	public final String getClient() {
		return client;
	}
	/**
	 * @param client the client to set
	 */
	public final void setClient(String client) {
		this.client = client;
	}
	/**
	 * @return the currLocation
	 */
	public final String getCurrLocation() {
		return currLocation;
	}
	/**
	 * @param currLocation the currLocation to set
	 */
	public final void setCurrLocation(String currLocation) {
		this.currLocation = currLocation;
	}
	/**
	 * @return the projDetails
	 */
	public final String getProjDetails() {
		return projDetails;
	}
	/**
	 * @param projDetails the projDetails to set
	 */
	public final void setProjDetails(String projDetails) {
		this.projDetails = projDetails;
	}	
	/**
	 * @return the enterpriseId
	 */
	public final String getEnterpriseId() {
		return enterpriseId;
	}
	/**
	 * @param enterpriseId the enterpriseId to set
	 */
	public final void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}
	/**
	 * @return the stream
	 */
	public final String getStream() {
		return stream;
	}
	/**
	 * @param stream the stream to set
	 */
	public final void setStream(String stream) {
		this.stream = stream;
	}
	/**
	 * @return the rollonDate
	 */
	public final String getRollonDate() {
		return rollonDate;
	}
	/**
	 * @param rollonDate the rollonDate to set
	 */
	public final void setRollonDate(String rollonDate) {
		this.rollonDate = rollonDate;
	}
	/**
	 * @return the rolloffDate
	 */
	public final String getRolloffDate() {
		return rolloffDate;
	}
	/**
	 * @param rolloffDate the rolloffDate to set
	 */
	public final void setRolloffDate(String rolloffDate) {
		this.rolloffDate = rolloffDate;
	}
	public String getVdiRevokeDate() {
		return vdiRevokeDate;
	}
	public void setVdiRevokeDate(String vdiRevokeDate) {
		this.vdiRevokeDate = vdiRevokeDate;
	}
	/**
	 * @return the countQA
	 */
	public final int getCountQA() {
		return countQA;
	}
	/**
	 * @param countQA the countQA to set
	 */
	public final void setCountQA(int countQA) {
		this.countQA = countQA;
	}
	/**
	 * @return the countDev
	 */
	public final int getCountDev() {
		return countDev;
	}
	/**
	 * @param countDev the countDev to set
	 */
	public final void setCountDev(int countDev) {
		this.countDev = countDev;
	}
	/**
	 * @return the countOps
	 */
	public final int getCountOps() {
		return countOps;
	}
	/**
	 * @param countOps the countOps to set
	 */
	public final void setCountOps(int countOps) {
		this.countOps = countOps;
	}
	/**
	 * @return the gender
	 */
	public final String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public final void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return the wmtid
	 */
	public final String getWmtid() {
		return wmtid;
	}
	/**
	 * @param wmtid the wmtid to set
	 */
	public final void setWmtid(String wmtid) {
		this.wmtid = wmtid;
	}
	/**
	 * @return the requestdate
	 */
	public final String getRequestdate() {
		return requestdate;
	}
	/**
	 * @param requestdate the requestdate to set
	 */
	public final void setRequestdate(String requestdate) {
		this.requestdate = requestdate;
	}
	/**
	 * @return the grantdate
	 */
	public final String getGrantdate() {
		return grantdate;
	}
	/**
	 * @param grantdate the grantdate to set
	 */
	public final void setGrantdate(String grantdate) {
		this.grantdate = grantdate;
	}
	/**
	 * @return the workstationNumber
	 */
	public final String getWorkstationNumber() {
		return workstationNumber;
	}
	/**
	 * @param workstationNumber the workstationNumber to set
	 */
	public final void setWorkstationNumber(String workstationNumber) {
		this.workstationNumber = workstationNumber;
	}
	/**
	 * @return the floor
	 */
	public final String getFloor() {
		return floor;
	}
	/**
	 * @param floor the floor to set
	 */
	public final void setFloor(String floor) {
		this.floor = floor;
	}
	/**
	 * @return the bayNumber
	 */
	public final int getBayNumber() {
		return bayNumber;
	}
	/**
	 * @param bayNumber the bayNumber to set
	 */
	public final void setBayNumber(int bayNumber) {
		this.bayNumber = bayNumber;
	}
	/**
	 * @return the lockType
	 */
	public final String getLockType() {
		return lockType;
	}
	/**
	 * @param lockType the lockType to set
	 */
	public final void setLockType(String lockType) {
		this.lockType = lockType;
	}
	/**
	 * @return the rolloffReason
	 */
	public final String getRolloffReason() {
		return rolloffReason;
	}
	/**
	 * @param rolloffReason the rolloffReason to set
	 */
	public final void setRolloffReason(String rolloffReason) {
		this.rolloffReason = rolloffReason;
	}
	/**
	 * @return the certificationType
	 */
	public final String getCertificationType() {
		return certificationType;
	}
	/**
	 * @param certificationType the certificationType to set
	 */
	public final void setCertificationType(String certificationType) {
		this.certificationType = certificationType;
	}
	/**
	 * @return the certificationName
	 */
	public final String getCertificationName() {
		return certificationName;
	}
	/**
	 * @param certificationName the certificationName to set
	 */
	public final void setCertificationName(String certificationName) {
		this.certificationName = certificationName;
	}
	/**
	 * @return the certificationDate
	 */
	public final String getCertificationDate() {
		return certificationDate;
	}
	/**
	 * @param certificationDate the certificationDate to set
	 */
	public final void setCertificationDate(String certificationDate) {
		this.certificationDate = certificationDate;
	}
	/**
	 * @return the certificationStatus
	 */
	public String getCertificationStatus() {
		return certificationStatus;
	}
	/**
	 * @param certificationStatus the certificationStatus to set
	 */
	public void setCertificationStatus(String certificationStatus) {
		this.certificationStatus = certificationStatus;
	}
	/**
	 * @return the awardType
	 */
	public final String getAwardType() {
		return awardType;
	}
	/**
	 * @param awardType the awardType to set
	 */
	public final void setAwardType(String awardType) {
		this.awardType = awardType;
	}
	/**
	 * @return the award
	 */
	public final String getAward() {
		return award;
	}
	/**
	 * @param award the award to set
	 */
	public final void setAward(String award) {
		this.award = award;
	}
	/**
	 * @return the reason
	 */
	public final String getReason() {
		return reason;
	}
	/**
	 * @param reason the reason to set
	 */
	public final void setReason(String reason) {
		this.reason = reason;
	}
	/**
	 * @return the timestamp
	 */
	public final Timestamp getTimestamp() {
		return timestamp;
	}
	/**
	 * @param timestamp the timestamp to set
	 */
	public final void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	public String getAssignedDate() {
		return assignedDate;
	}
	public void setAssignedDate(String assignedDate) {
		this.assignedDate = assignedDate;
	}
	//No of days pending in Queue
	public int getDaysElapsed() {
		return daysElapsed;
	}
	public void setDaysElapsed(int daysElapsed) {
		this.daysElapsed = daysElapsed;
	}
	public String getTaskDescription() {
		return taskDescription;
	}
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAssignedBy() {
		return assignedBy;
	}
	public void setAssignedBy(String assignedBy) {
		this.assignedBy = assignedBy;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getSiteLocation() {
		return siteLocation;
	}
	public void setSiteLocation(String siteLocation) {
		this.siteLocation = siteLocation;
	}
	public String getVisaType() {
		return visaType;
	}
	public void setVisaType(String visaType) {
		this.visaType = visaType;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getPrimarySkill() {
		return primarySkill;
	}
	public void setPrimarySkill(String primarySkill) {
		this.primarySkill = primarySkill;
	}
	public String getSecondarySkill() {
		return secondarySkill;
	}
	public void setSecondarySkill(String secondarySkill) {
		this.secondarySkill = secondarySkill;
	}
	public String getProficiency() {
		return proficiency;
	}
	public void setProficiency(String proficiency) {
		this.proficiency = proficiency;
	}
	public int getTask_id() {
		return task_id;
	}
	public void setTask_id(int task_id) {
		this.task_id = task_id;
	}
	public String getTaskCompletedBy() {
		return taskCompletedBy;
	}
	public void setTaskCompletedBy(String taskCompletedBy) {
		this.taskCompletedBy = taskCompletedBy;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getAward_receiver() {
		return award_receiver;
	}
	public void setAward_receiver(String award_receiver) {
		this.award_receiver = award_receiver;
	}
	public String getAward_period() {
		return award_period;
	}
	public void setAward_period(String award_period) {
		this.award_period = award_period;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public int getEmployeeStatus() {
		return employeeStatus;
	}
	public void setEmployeeStatus(int employeeStatus) {
		this.employeeStatus = employeeStatus;
	}
	public String getManagerId() {
		return managerId;
	}
	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}
	public String getSupervisorName() {
		return supervisorName;
	}
	public void setSupervisorName(String supervisorName) {
		this.supervisorName = supervisorName;
	}
	public String getIdentifierType() {
		return identifierType;
	}
	public void setIdentifierType(String identifierType) {
		this.identifierType = identifierType;
	}
	public String getIdentifierNumber() {
		return identifierNumber;
	}
	public void setIdentifierNumber(String identifierNumber) {
		this.identifierNumber = identifierNumber;
	}
	public String getDeliveryCentre() {
		return deliveryCentre;
	}
	public void setDeliveryCentre(String deliveryCentre) {
		this.deliveryCentre = deliveryCentre;
	}
	public String getDeptNumber() {
		return deptNumber;
	}
	public void setDeptNumber(String deptNumber) {
		this.deptNumber = deptNumber;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getRoleDesc() {
		return roleDesc;
	}
	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public String getContractorHostPattern() {
		return contractorHostPattern;
	}
	public void setContractorHostPattern(String contractorHostPattern) {
		this.contractorHostPattern = contractorHostPattern;
	}
	public String getContractorUnixPattern() {
		return contractorUnixPattern;
	}
	public void setContractorUnixPattern(String contractorUnixPattern) {
		this.contractorUnixPattern = contractorUnixPattern;
	}
	public String getContractorRemedyPattern() {
		return contractorRemedyPattern;
	}
	public void setContractorRemedyPattern(String contractorRemedyPattern) {
		this.contractorRemedyPattern = contractorRemedyPattern;
	}
	public String getContractorADPattern() {
		return contractorADPattern;
	}
	public void setContractorADPattern(String contractorADPattern) {
		this.contractorADPattern = contractorADPattern;
	}
	public String getContractorTDPattern() {
		return contractorTDPattern;
	}
	public void setContractorTDPattern(String contractorTDPattern) {
		this.contractorTDPattern = contractorTDPattern;
	}
	public String getTeraApplication() {
		return teraApplication;
	}
	public void setTeraApplication(String teraApplication) {
		this.teraApplication = teraApplication;
	}
	public String getADGroupShared() {
		return ADGroupShared;
	}
	public void setADGroupShared(String aDGroupShared) {
		ADGroupShared = aDGroupShared;
	}
	public String getUnixBoxes() {
		return unixBoxes;
	}
	public void setUnixBoxes(String unixBoxes) {
		this.unixBoxes = unixBoxes;
	}
	public String getBusinessJustification() {
		return businessJustification;
	}
	public void setBusinessJustification(String businessJustification) {
		this.businessJustification = businessJustification;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public String getDirectorId() {
		return directorId;
	}
	public void setDirectorId(String directorId) {
		this.directorId = directorId;
	}
	public String getVpUserId() {
		return vpUserId;
	}
	public void setVpUserId(String vpUserId) {
		this.vpUserId = vpUserId;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getDifficutyLevel() {
		return difficutyLevel;
	}
	public void setDifficutyLevel(String difficutyLevel) {
		this.difficutyLevel = difficutyLevel;
	}
	public String getReportPeriod() {
		return reportPeriod;
	}
	public void setReportPeriod(String reportPeriod) {
		this.reportPeriod = reportPeriod;
	}
	public boolean isExit() {
		return isExit;
	}
	public void setExit(boolean isExit) {
		this.isExit = isExit;
	}
	public int getRewardId() {
		return rewardId;
	}
	public void setRewardId(int rewardId) {
		this.rewardId = rewardId;
	}
	public String getRrdId() {
		return rrdId;
	}
	public void setRrdId(String rrdId) {
		this.rrdId = rrdId;
	}
	public String getRolledOnBy() {
		return rolledOnBy;
	}
	public void setRolledOnBy(String rolledOnBy) {
		this.rolledOnBy = rolledOnBy;
	}
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	
}

/**
 * 
 */
package com.pmo.login;

import java.sql.Timestamp;
import java.util.ArrayList;

import org.postgresql.util.PGobject;


/**
 * @author s.ghouse.mohideen
 *
 */
public class Assessment {

	private int empId;
	private int examId;
	private String stream;
	private String technology;
	private String difficultyLevel;
	private ArrayList<AssessmentJson> jsonAnswers; 
	private PGobject answers;
	private int marks;
	private String grade;
	private int assessmentStatus;
	private Timestamp date;
	
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public int getExamId() {
		return examId;
	}
	public void setExamId(int examId) {
		this.examId = examId;
	}
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getDifficultyLevel() {
		return difficultyLevel;
	}
	public void setDifficultyLevel(String difficultyLevel) {
		this.difficultyLevel = difficultyLevel;
	}
	public PGobject getAnswers() {
		return answers;
	}
	public void setAnswers(PGobject answers) {
		this.answers = answers;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public Timestamp getDate() {
		return date;
	}
	public void setDate(Timestamp date) {
		this.date = date;
	}
	public int getAssessmentStatus() {
		return assessmentStatus;
	}
	public void setAssessmentStatus(int assessmentStatus) {
		this.assessmentStatus = assessmentStatus;
	}
	public ArrayList<AssessmentJson> getJsonAnswers() {
		return jsonAnswers;
	}
	public void setJsonAnswers(ArrayList<AssessmentJson> jsonAnswers) {
		this.jsonAnswers = jsonAnswers;
	}
	
}

/**
 * 
 */
package com.pmo.login;


public class CheckList {


	public static final String YES = "YES";
	public static final String NO = "NO";
	public static final String NA = "Not Applicable";
	public static final int PENDING = 0;
	public static final int ACKNOWLEDGED = 1;

	public static final int STATUS_PENDING = 0;
	public static final int ROLL_ON_CHECKLIST_COMPLETE = 1;
	public static final int ROLL_OFF_CHECKLIST_COMPLETE = 2;

	private int employeeId;
	private int status = STATUS_PENDING;
	private int rollOnCheckList = PENDING;
	private int dataProtectionStatus = PENDING;
	private int culturePresentation = PENDING;
	private int welcomePresentation = PENDING;
	private int inductionKit = PENDING;
	private String enterpriseId;
	private String resourceName;
	private String fullName;
	private String startDate;
	private boolean dataExisting;
	private String contractorName;
	private String projectName;
	private String currentDate;		
	private Flag acknowledgement = new Flag();
	private Flag affidavit = new Flag();
	private String workforce;
//	@JsonDeserialize(dataProtectionCheckList = CheckList.Flag.class)
	private Flag dataProtectionCheckList[] = new Flag[25];




	public Flag getAcknowledgement() {
		return acknowledgement;
	}
	public void setAcknowledgement(Flag acknowledgement) {
		this.acknowledgement = acknowledgement;
	}
	public Flag getAffidavit() {
		return affidavit;
	}
	public void setAffidavit(Flag affidavit) {
		this.affidavit = affidavit;
	}
	public Flag[] getDataProtectionCheckList() {
		return dataProtectionCheckList;
	}
	public void setDataProtectionCheckList(Flag[] dataProtectionCheckList) {
		this.dataProtectionCheckList = dataProtectionCheckList;
	}
	public String getWorkforce() {
		return workforce;
	}
	public void setWorkforce(String workforce) {
		this.workforce = workforce;
	}
	public String getContractorName() {
		return contractorName;
	}
	public void setContractorName(String contractorName) {
		this.contractorName = contractorName;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;
	}





	public String getStartDate() {
		return startDate;
	}


	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}



	public String getEnterpriseId() {
		return enterpriseId;
	}


	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}


	public String getResourceName() {
		return resourceName;
	}


	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}



	public int getRollOnCheckList() {
		return rollOnCheckList;
	}


	public void setRollOnCheckList(int rollOnCheckList) {
		this.rollOnCheckList = rollOnCheckList;
	}


	public int getDataProtectionStatus() {
		return dataProtectionStatus;
	}


	public void setDataProtectionStatus(int dataProtectionStatus) {
		this.dataProtectionStatus = dataProtectionStatus;
	}


	public int getCulturePresentation() {
		return culturePresentation;
	}


	public void setCulturePresentation(int culturePresentation) {
		this.culturePresentation = culturePresentation;
	}


	public int getWelcomePresentation() {
		return welcomePresentation;
	}


	public void setWelcomePresentation(int welcomePresentation) {
		this.welcomePresentation = welcomePresentation;
	}


	public int getInductionKit() {
		return inductionKit;
	}
	public void setInductionKit(int inductionKit) {
		this.inductionKit = inductionKit;
	}
	
	public int getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}


	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public boolean isDataExisting() {
		return dataExisting;
	}


	public void setDataExisting(boolean dataExisting) {
		this.dataExisting = dataExisting;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

}

 class Flag{
	String status;
	String comments;

	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
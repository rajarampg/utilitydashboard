/**
 * 
 */
package com.pmo.login;

import java.sql.Timestamp;


/**
 * @author deepika.rp
 *
 */
public class HardwareMaintenance {

	private int rsaToken;
	private int employeeNumber;
	private String employeeName;
	private String validDate;
	private long mobileNo;	
	private String serviceProvider;
	private String stream;
	private String billCycle;
	private String laptopNo;	
	private String assetTag;
	private String make;
	private Timestamp timestamp;
	private String Application;
	private String Month;
	private double cost;
	private long dataCardNumber;
	private String dataCardBillCycle;
	private boolean rsa;
	private boolean mobile;
	private boolean laptop;
	private boolean dataCard;
	private int assetType = -1;
	private String dataCardServiceProvider;
	private String billStartDate;
	private String billEndDate;
	private String dataCardBillStartDate;
	private String dataCardBillEndDate;
	private String projectName;
	
	/**
	 * @return the rsaToken
	 */
	public int getRsaToken() {
		return rsaToken;
	}
	/**
	 * @param rsaToken the rsaToken to set
	 */
	public void setRsaToken(int rsaToken) {
		this.rsaToken = rsaToken;
	}
	/**
	 * @return the employeeNumber
	 */
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	/**
	 * @param employeeNumber the employeeNumber to set
	 */
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}
	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	/**
	 * @return the validDate
	 */
	public String getValidDate() {
		return validDate;
	}
	/**
	 * @param validDate the validDate to set
	 */
	public void setValidDate(String validDate) {
		this.validDate = validDate;
	}
	/**
	 * @return the mobileNo
	 */
	public long getMobileNo() {
		return mobileNo;
	}
	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	/**
	 * @return the serviceProvider
	 */
	public String getServiceProvider() {
		return serviceProvider;
	}
	/**
	 * @param serviceProvider the serviceProvider to set
	 */
	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}
	/**
	 * @return the stream
	 */
	public String getStream() {
		return stream;
	}
	/**
	 * @param stream the stream to set
	 */
	public void setStream(String stream) {
		this.stream = stream;
	}
	/**
	 * @return the billCycle
	 */
	public String getBillCycle() {
		return billCycle;
	}
	/**
	 * @param billCycle the billCycle to set
	 */
	public void setBillCycle(String billCycle) {
		this.billCycle = billCycle;
	}
	
	/**
	 * @return the assetTag
	 */
	public String getAssetTag() {
		return assetTag;
	}
	/**
	 * @param assetTag the assetTag to set
	 */
	public void setAssetTag(String assetTag) {
		this.assetTag = assetTag;
	}
	/**
	 * @return the make
	 */
	public String getMake() {
		return make;
	}
	/**
	 * @param make the make to set
	 */
	public void setMake(String make) {
		this.make = make;
	}
	/**
	 * @return the laptopNo
	 */
	public final String getLaptopNo() {
		return laptopNo;
	}
	/**
	 * @param laptopNo the laptopNo to set
	 */
	public final void setLaptopNo(String laptopNo) {
		this.laptopNo = laptopNo;
	}
	/**
	 * @return the timestamp
	 */
	public final Timestamp getTimestamp() {
		return timestamp;
	}
	/**
	 * @param timestamp the timestamp to set
	 */
	public final void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public String getApplication() {
		return Application;
	}
	public void setApplication(String application) {
		Application = application;
	}
	public String getMonth() {
		return Month;
	}
	public void setMonth(String month) {
		Month = month;
	}
	public String getBillStartDate() {
		return billStartDate;
	}
	public void setBillStartDate(String billStartDate) {
		this.billStartDate = billStartDate;
	}
	public String getBillEndDate() {
		return billEndDate;
	}
	public void setBillEndDate(String billEndDate) {
		this.billEndDate = billEndDate;
	}
	public long getDataCardNumber() {
		return dataCardNumber;
	}
	public void setDataCardNumber(long dataCardNumber) {
		this.dataCardNumber = dataCardNumber;
	}
	public String getDataCardBillCycle() {
		return dataCardBillCycle;
	}
	public void setDataCardBillCycle(String dataCardBillCycle) {
		this.dataCardBillCycle = dataCardBillCycle;
	}
	public String getDataCardServiceProvider() {
		return dataCardServiceProvider;
	}
	public void setDataCardServiceProvider(String dataCardServiceProvider) {
		this.dataCardServiceProvider = dataCardServiceProvider;
	}
	public String getDataCardBillStartDate() {
		return dataCardBillStartDate;
	}
	public void setDataCardBillStartDate(String dataCardBillStartDate) {
		this.dataCardBillStartDate = dataCardBillStartDate;
	}
	public String getDataCardBillEndDate() {
		return dataCardBillEndDate;
	}
	public void setDataCardBillEndDate(String dataCardBillEndDate) {
		this.dataCardBillEndDate = dataCardBillEndDate;
	}
	public boolean isRsa() {
		return rsa;
	}
	public void setRsa(boolean rsa) {
		this.rsa = rsa;
	}
	public boolean isMobile() {
		return mobile;
	}
	public void setMobile(boolean mobile) {
		this.mobile = mobile;
	}
	public boolean isLaptop() {
		return laptop;
	}
	public void setLaptop(boolean laptop) {
		this.laptop = laptop;
	}
	public boolean isDataCard() {
		return dataCard;
	}
	public void setDataCard(boolean dataCard) {
		this.dataCard = dataCard;
	}
	public int getAssetType() {
		return assetType;
	}
	public void setAssetType(int assetType) {
		this.assetType = assetType;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	
}
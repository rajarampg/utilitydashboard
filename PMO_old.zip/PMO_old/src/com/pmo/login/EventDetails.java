package com.pmo.login;

public class EventDetails {

	/*
	 * String initiator; String eventName; String eventDesc; String
	 * eventTimestamp; long eventStartTime; long eventEndTime;
	 */

	public final String TYPE1 = "event-success";
	public final String TYPE2 = "event-info";
	public final String TYPE3 = "event-inverse";
	public final String TYPE4 = "event-warning";

	int id;
	String title;
	String initiator;
	String eventDesc;
	String startTime;
	int hrs;
	int mins;
	String duration;
	String eventColorCode = "blue";
	long start;
	long end;
	String eventType = TYPE2;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public long getStart() {
		return start;
	}

	public void setStart(long start) {
		this.start = start;
	}

	public long getEnd() {
		return end;
	}

	public void setEnd(long end) {
		this.end = end;
	}

	public String getInitiator() {
		return initiator;
	}

	public void setInitiator(String initiator) {
		this.initiator = initiator;
	}

	public String getEventDesc() {
		return eventDesc;
	}

	public void setEventDesc(String eventDesc) {
		this.eventDesc = eventDesc;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public int getHrs() {
		return hrs;
	}

	public void setHrs(int hrs) {
		this.hrs = hrs;
	}

	public int getMins() {
		return mins;
	}

	public void setMins(int mins) {
		this.mins = mins;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getEventColorCode() {
		return eventColorCode;
	}

	public void setEventColorCode(String eventColorCode) {
		this.eventColorCode = eventColorCode;
	}

	@Override
	public String toString() {
		return "{" + "\"id\":" + id + ", \"title\":\"" + title + "\"" + ", \"start\":" + start + ", \"end\":" + end
				+ ", \"hrs\":" + hrs + ", \"mins\":" + mins
				// + ", \"url\":\"eventDescription.jsp\""
				+ ", \"url\":\"eventSchedule?action=populateEventDetails&eventId=\"" + ", \"class\":\"" + getClassType()
				+ "\"" + ", \"startTime\":\"" + startTime + "\"" + ", \"duration\":\"" + duration + "\""
				+ ", \"eventColorCode\":\"" + eventColorCode + "\""
				+ ", \"initiator\":\"" + initiator + "\""
				/*
				 * + ", \"eventDesc\":\"" + eventDesc.replaceAll("\\\r\\\n",
				 * "\\\\\\n")+"\""
				 */
				+ "}";
	}

	String getClassType() {
		switch (id % 4) {
		case 0:
			return TYPE1;
		case 1:
			return TYPE2;
		case 2:
			return TYPE3;
		default:
			return TYPE4;
		}
	}

}
/**
 * @author sankar.arumugam
 * @modifed valarmathi : 24/06/2015
 */
package com.pmo.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.pmo.commons.AESencrp;
import com.pmo.connection.DatabaseConnection;

public class LoginDao {
	public static int validate(String name, String pass, String role)
			throws Exception {
		int validity = 0;
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String usertype = null;

		con = DatabaseConnection.getRAWConnection();
		AESencrp encryDecry = new AESencrp();
		pass = encryDecry.encrypt(pass);

		try {

			pst = con
					.prepareStatement("select * from login where username=? and password=?");
			pst.setString(1, name);
			pst.setString(2, pass);

			rs = pst.executeQuery();
			if (rs.next()) {
				usertype = rs.getString("usertype");
				if (usertype != null
						&& usertype.trim().equalsIgnoreCase(role.trim())) {
					validity = 1;
				} else {
					validity = 2;
				}

			} else {
				validity = 0;
			}

		} catch (SQLException e) {
			System.out
					.println("SQl Exception occured while validation login user"
							+ e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Exception occured while validation login user"
					+ e.getMessage());
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}

		return validity;
	}

	public static String getEnterprizeId(String name) throws SQLException {

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String userid = null;

		con = DatabaseConnection.getRAWConnection();

		try {

			pst = con
					.prepareStatement("select enterpriseid from login where UserName=? ");
			pst.setString(1, name);

			rs = pst.executeQuery();
			if (rs.next()) {
				userid = rs.getString("enterpriseid");
			}
		} catch (SQLException e) {
			System.out
					.println("SQl Exception occured while validation login user"
							+ e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Exception occured while validation login user"
					+ e.getMessage());
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}

		return userid;
	}
}

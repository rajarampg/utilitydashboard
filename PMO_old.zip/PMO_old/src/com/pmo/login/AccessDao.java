package com.pmo.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.pmo.connection.DatabaseConnection;

public class AccessDao {

	public static String getAccess(String role) throws SQLException {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String accesstype = "0";
		// DatabaseConnection dbConn = new DatabaseConnection();
		// con = dbConn.mySqlConnection();
		con = DatabaseConnection.getRAWConnection();

		try {

			pst = con
					.prepareStatement("select userrights from formrights where usertype=?");
			pst.setString(1, role);

			rs = pst.executeQuery();

			if (rs.next()) {
				accesstype = rs.getString("userrights");

			}

		} catch (SQLException e) {
			System.out
					.println("SQl Exception occured while fetching the access rights"
							+ e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out
					.println("Exception occured while fetching the access rights"
							+ e.getMessage());
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}

		return accesstype;
	}

	public static ArrayList<String> uiFormRights() throws SQLException {

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		// DatabaseConnection dbConn = new DatabaseConnection();
		// con = dbConn.mySqlConnection();
		con = DatabaseConnection.getRAWConnection();
		ArrayList<String> list = new ArrayList<String>();
		try {

			pst = con
					.prepareStatement("select uiformid from forms order by formorder");

			rs = pst.executeQuery();

			while (rs.next()) {
				list.add(rs.getString("uiformid"));
			}

		} catch (Exception e) {
			System.out
					.println("Exception occured while fetching the access rights"
							+ e.getMessage());
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}

		return list;

	}

	public static ArrayList<String> getPmoUserID() throws SQLException {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DatabaseConnection dbConn = new DatabaseConnection();
		con = dbConn.mySqlConnection();
		ArrayList<String> userlist = new ArrayList<String>();

		try {

			pst = con
					.prepareStatement("select enterpriseid from login where usertype='pmo' ");

			rs = pst.executeQuery();

			while (rs.next()) {
				userlist.add(rs.getString("enterpriseid"));
			}

		} catch (Exception e) {
			System.out
					.println("Exception occured while fetching the access rights"
							+ e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception e) {
			}
			try {
				if (pst != null)
					pst.close();
			} catch (Exception e) {
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
			rs = null;
			pst = null;
			con = null;
		}

		return userlist;

	}

	public static String getEnterpriseID(int empId) {

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String renterprise = "0";
		// DatabaseConnection dbConn = new DatabaseConnection();
		// con = dbConn.mySqlConnection();
		con = DatabaseConnection.getRAWConnection();

		try {

			pst = con
					.prepareStatement("select enterpriseid from employeedetails where employeenumber=?");
			pst.setLong(1, empId);

			rs = pst.executeQuery();

			if (rs.next()) {
				renterprise = rs.getString("enterpriseid");

			}

		} catch (SQLException e) {
			System.out
					.println("SQl Exception occured while fetching enterprisedetails"
							+ e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out
					.println("Exception occured while fetching enterprisedetails"
							+ e.getMessage());
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}

		return renterprise;

	}
	
	public static TableDetail getResourceDetails(String resName) {

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		TableDetail td = new TableDetail();
		// DatabaseConnection dbConn = new DatabaseConnection();
		// con = dbConn.mySqlConnection();
		con = DatabaseConnection.getRAWConnection();

		try {

			pst = con
					.prepareStatement("select enterpriseid,first_name,last_name,wmt_userid from employeedetails where resourcename=?");
			pst.setString(1, resName);

			rs = pst.executeQuery();

			if (rs.next()) {
				td.setEnterpriseId(rs.getString("enterpriseid"));
				td.setFirstName(rs.getString("first_name"));
				td.setLastName(rs.getString("last_name"));
				td.setWmtid(rs.getString("wmt_userid"));

			}

			
		} catch (SQLException e) {
			System.out
					.println("SQl Exception occured while fetching enterprisedetails"
							+ e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out
					.println("Exception occured while fetching enterprisedetails"
							+ e.getMessage());
			e.printStackTrace();
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(pst);
			DatabaseConnection.closeCon(con);
		}

		return td;

	}
	
	
	public static String getSupervisorID(String enterpriseID) throws SQLException {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DatabaseConnection dbConn = new DatabaseConnection();
		con = dbConn.mySqlConnection();
		String userlist = null;

		try {

			pst = con.prepareStatement("select supervisor_name from employeedetails where enterpriseid=?");
			pst.setString(1,enterpriseID);

			rs = pst.executeQuery();

			while (rs.next()) {
				userlist=rs.getString("supervisor_name");
			}

		} catch (Exception e) {
			System.out
					.println("Exception occured while fetching the supervisor ID"
							+ e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception e) {
			}
			try {
				if (pst != null)
					pst.close();
			} catch (Exception e) {
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
			rs = null;
			pst = null;
			con = null;
		}

		return userlist;

	}

}

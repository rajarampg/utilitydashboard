package com.pmo.login;

public class OnBoardingFormDetails {

	private String firstName;
	private String lastName;
	private long employeeId;
	private String enterpriseId;
	private String uniqueUserID;
	private String role;
	private String location;
	private String resourceManager;
	private String skill;
	private String patterAfter;
	private String contactId;
	private String renew;
	private String portfolio;
	
	private double rate;
	private String directorId;
	private String vicePresId;
	private String businessJust;
	private String requestFor;
	private String specificAccessRequests;
	private String unixBox;
	private String teraDataBox;
	private String clarityAccess;
	private String adAccess;
	private String additionalDetailsAction;
			
	
	/**
	 * @return the renew
	 */
	public String getRenew() {
		return renew;
	}
	/**
	 * @param renew the renew to set
	 */
	public void setRenew(String renew) {
		this.renew = renew;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}
	public String getEnterpriseId() {
		return enterpriseId;
	}
	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}
	public String getUniqueUserID() {
		return uniqueUserID;
	}
	public void setUniqueUserID(String uniqueUserID) {
		this.uniqueUserID = uniqueUserID;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getResourceManager() {
		return resourceManager;
	}
	public void setResourceManager(String resourceManager) {
		this.resourceManager = resourceManager;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public String getPatterAfter() {
		return patterAfter;
	}
	public void setPatterAfter(String patterAfter) {
		this.patterAfter = patterAfter;
	}
	public String getContactId() {
		return contactId;
	}
	public void setContactId(String contactId) {
		this.contactId = contactId;
	}
	public String getPortfolio() {
		return portfolio;
	}
	public void setPortfolio(String portfolio) {
		this.portfolio = portfolio;
	}
	
	
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public String getDirectorId() {
		return directorId;
	}
	public void setDirectorId(String directorId) {
		this.directorId = directorId;
	}
	public String getVicePresId() {
		return vicePresId;
	}
	public void setVicePresId(String vicePresId) {
		this.vicePresId = vicePresId;
	}
	public String getBusinessJust() {
		return businessJust;
	}
	public void setBusinessJust(String businessJust) {
		this.businessJust = businessJust;
	}
	public String getRequestFor() {
		return requestFor;
	}
	public void setRequestFor(String requestFor) {
		this.requestFor = requestFor;
	}
	public String getSpecificAccessRequests() {
		return specificAccessRequests;
	}
	public void setSpecificAccessRequests(String specificAccessRequests) {
		this.specificAccessRequests = specificAccessRequests;
	}
	public String getUnixBox() {
		return unixBox;
	}
	public void setUnixBox(String unixBox) {
		this.unixBox = unixBox;
	}
	public String getTeraDataBox() {
		return teraDataBox;
	}
	public void setTeraDataBox(String teraDataBox) {
		this.teraDataBox = teraDataBox;
	}
	public String getClarityAccess() {
		return clarityAccess;
	}
	public void setClarityAccess(String clarityAccess) {
		this.clarityAccess = clarityAccess;
	}
	public String getAdAccess() {
		return adAccess;
	}
	public void setAdAccess(String adAccess) {
		this.adAccess = adAccess;
	}
	public String getAdditionalDetailsAction() {
		return additionalDetailsAction;
	}
	public void setAdditionalDetailsAction(String additionalDetailsAction) {
		this.additionalDetailsAction = additionalDetailsAction;
	}
	
	@Override
	public String toString() {
		return "OnBoardingFormDetails [firstName=" + firstName + ", lastName="
				+ lastName + ", employeeId=" + employeeId + ", enterpriseId="
				+ enterpriseId + ", uniqueUserID=" + uniqueUserID + ", role="
				+ role + ", location=" + location + ", resourceManager="
				+ resourceManager + ", skill=" + skill + ", patterAfter="
				+ patterAfter + ", contactId=" + contactId + ", renew=" + renew
				+ ", portfolio=" + portfolio + ", rate=" + rate
				+ ", directorId=" + directorId + ", vicePresId=" + vicePresId
				+ ", businessJust=" + businessJust + ", requestFor="
				+ requestFor + ", specificAccessRequests="
				+ specificAccessRequests + ", unixBox=" + unixBox
				+ ", teraDataBox=" + teraDataBox + ", clarityAccess="
				+ clarityAccess + ", adAccess=" + adAccess
				+ ", additionalDetailsAction=" + additionalDetailsAction + "]";
	}
	
	
}

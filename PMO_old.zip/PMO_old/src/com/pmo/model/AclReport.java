package com.pmo.model;

import java.sql.Date;

public class AclReport {

	private String enterpriseId;
	private String firstName;
	private String lastName;
	private String wmtid;
	private String rollonDate;
	private String currLocation;
	private String roleDesc;
	private String stream;
	private String rolloffDate;
	private String vdiRevokeDate;
	private String grantdate;
	private Date ackDate;
	public String getEnterpriseId() {
		return enterpriseId;
	}
	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getWmtid() {
		return wmtid;
	}
	public void setWmtid(String wmtid) {
		this.wmtid = wmtid;
	}
	public String getCurrLocation() {
		return currLocation;
	}
	public void setCurrLocation(String currLocation) {
		this.currLocation = currLocation;
	}
	public String getRoleDesc() {
		return roleDesc;
	}
	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	
	public Date getAckDate() {
		return ackDate;
	}
	public void setAckDate(Date ackDate) {
		this.ackDate = ackDate;
	}
	public String getRollonDate() {
		return rollonDate;
	}
	public void setRollonDate(String rollonDate) {
		this.rollonDate = rollonDate;
	}
	public String getRolloffDate() {
		return rolloffDate;
	}
	public void setRolloffDate(String rolloffDate) {
		this.rolloffDate = rolloffDate;
	}
	public String getVdiRevokeDate() {
		return vdiRevokeDate;
	}
	public void setVdiRevokeDate(String vdiRevokeDate) {
		this.vdiRevokeDate = vdiRevokeDate;
	}
	public String getGrantdate() {
		return grantdate;
	}
	public void setGrantdate(String grantdate) {
		this.grantdate = grantdate;
	}
	@Override
	public String toString() {
		return "AclReport [enterpriseId=" + enterpriseId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", wmtid=" + wmtid + ", rollonDate=" + rollonDate + ", currLocation=" + currLocation + ", roleDesc="
				+ roleDesc + ", stream=" + stream + ", rolloffDate=" + rolloffDate + ",vdiRevokeDate=" + vdiRevokeDate + " grantdate=" + grantdate
				+ ", ackDate=" + ackDate + "]";
	}
	
	
}

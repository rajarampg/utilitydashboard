package com.pmo.model;

import java.sql.Timestamp;
import java.util.Date;

public class ResourceRequestDemandDetails {
	
	private String portfolio;
	private String edfulfilldate;
	private String rrstartdate;
	private String demandenddate;
	private String demandsegment;
	private boolean clientiview;
	private String priskill;
	private boolean ishlready;
	private String ffentity;
	private String lockduration;
	private String wbsecode;
	private String demandpriority;
	private String srclocation;
	private String wrklocation;
	private String careerlevel;
	private boolean onsitecomponent;
	private String visatype;
	private boolean visaready;
	private String demandid;
	private String createdby;
	private String updatedby;
	private boolean status;
	private Timestamp createdts;
	private Timestamp updatedts;
	private int rescount;
	
	public String getPortfolio() {
		return portfolio;
	}
	public void setPortfolio(String portfolio) {
		this.portfolio = portfolio;
	}
	
	public String getEdfulfilldate() {
		return edfulfilldate;
	}
	public void setEdfulfilldate(String edfulfilldate) {
		this.edfulfilldate = edfulfilldate;
	}
	public String getRrstartdate() {
		return rrstartdate;
	}
	public void setRrstartdate(String rrstartdate) {
		this.rrstartdate = rrstartdate;
	}
	public String getDemandenddate() {
		return demandenddate;
	}
	public void setDemandenddate(String demandenddate) {
		this.demandenddate = demandenddate;
	}
	
	public String getDemandsegment() {
		return demandsegment;
	}
	public void setDemandsegment(String demandsegment) {
		this.demandsegment = demandsegment;
	}
	public boolean isClientiview() {
		return clientiview;
	}
	public void setClientiview(boolean clientiview) {
		this.clientiview = clientiview;
	}
	public String getPriskill() {
		return priskill;
	}
	public void setPriskill(String priskill) {
		this.priskill = priskill;
	}
	public boolean isIshlready() {
		return ishlready;
	}
	public void setIshlready(boolean ishlready) {
		this.ishlready = ishlready;
	}
	public String getFfentity() {
		return ffentity;
	}
	public void setFfentity(String ffentity) {
		this.ffentity = ffentity;
	}
	public String getLockduration() {
		return lockduration;
	}
	public void setLockduration(String lockduration) {
		this.lockduration = lockduration;
	}
	public String getWbsecode() {
		return wbsecode;
	}
	public void setWbsecode(String wbsecode) {
		this.wbsecode = wbsecode;
	}
	public String getDemandpriority() {
		return demandpriority;
	}
	public void setDemandpriority(String demandpriority) {
		this.demandpriority = demandpriority;
	}
	public String getSrclocation() {
		return srclocation;
	}
	public void setSrclocation(String srclocation) {
		this.srclocation = srclocation;
	}
	public String getWrklocation() {
		return wrklocation;
	}
	public void setWrklocation(String wrklocation) {
		this.wrklocation = wrklocation;
	}
	public String getCareerlevel() {
		return careerlevel;
	}
	public void setCareerlevel(String careerlevel) {
		this.careerlevel = careerlevel;
	}
	public boolean isOnsitecomponent() {
		return onsitecomponent;
	}
	public void setOnsitecomponent(boolean onsitecomponent) {
		this.onsitecomponent = onsitecomponent;
	}
	public String getVisatype() {
		return visatype;
	}
	public void setVisatype(String visatype) {
		this.visatype = visatype;
	}
	public boolean isVisaready() {
		return visaready;
	}
	public void setVisaready(boolean visaready) {
		this.visaready = visaready;
	}
	public String getDemandid() {
		return demandid;
	}
	public void setDemandid(String demandid) {
		this.demandid = demandid;
	}
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	public String getUpdatedby() {
		return updatedby;
	}
	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}
	public Date getCreatedts() {
		return createdts;
	}
	public void setCreatedts(Timestamp createdts) {
		this.createdts = createdts;
	}
	public Timestamp getUpdatedts() {
		return updatedts;
	}
	public void setUpdatedts(Timestamp updatedts) {
		this.updatedts = updatedts;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	
	public int getRescount() {
		return rescount;
	}
	public void setRescount(int rescount) {
		this.rescount = rescount;
	}
	@Override
	public String toString() {
		return "ResourceRequestDemandDetails [portfolio=" + portfolio + ", edfulfilldate=" + edfulfilldate
				+ ", rrstartdate=" + rrstartdate + ", demandenddate=" + demandenddate + ", demandsegment="
				+ demandsegment + ", clientiview=" + clientiview + ", priskill=" + priskill + ", ishlready=" + ishlready
				+ ", ffentity=" + ffentity + ", lockduration=" + lockduration + ", wbsecode=" + wbsecode
				+ ", demandpriority=" + demandpriority + ", srclocation=" + srclocation + ", wrklocation=" + wrklocation
				+ ", careerlevel=" + careerlevel + ", onsitecomponent=" + onsitecomponent + ", visatype=" + visatype
				+ ", visaready=" + visaready + ", demandid=" + demandid + ", createdby=" + createdby + ", updatedby="
				+ updatedby + ", status=" + status + ", createdts=" + createdts + ", updatedts=" + updatedts
				+ ", rescount=" + rescount + "]";
	}
	
}

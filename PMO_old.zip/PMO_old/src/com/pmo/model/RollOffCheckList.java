package com.pmo.model;

import java.io.Serializable;

public class RollOffCheckList implements Serializable {
	
	private String empNum; 
	private String status; 
	private String updatedBy;
	private String updatedTs;
	private Flag checklist1 = new Flag();
	private Flag checklist2 = new Flag();
	private Flag checklist3 = new Flag();
	private Flag checklist4 = new Flag();
	private Flag checklist5 = new Flag();
	private Flag checklist6 = new Flag();
	private Flag checklist7 = new Flag();
	private Flag checklist8 = new Flag();
	private Flag checklist9 = new Flag();
	private Flag checklist10 = new Flag();
	private Flag checklist11 = new Flag();
	private Flag checklist12 = new Flag();
	private Flag checklist13 = new Flag();
	private Flag checklist14 = new Flag();
	private Flag checklist15 = new Flag();
	private Flag checklist16 = new Flag();
	private Flag checklist17 = new Flag();
	private Flag checklist18 = new Flag();
	private Flag checklist19 = new Flag();
	private Flag checklist20 = new Flag();
	
	
	
	public String getEmpNum() {
		return empNum;
	}
	public void setEmpNum(String empNum) {
		this.empNum = empNum;
	}

	public Flag getChecklist1() {
		return checklist1;
	}
	public void setChecklist1(Flag checklist1) {
		this.checklist1 = checklist1;
	}
	public Flag getChecklist2() {
		return checklist2;
	}
	public void setChecklist2(Flag checklist2) {
		this.checklist2 = checklist2;
	}
	public Flag getChecklist3() {
		return checklist3;
	}
	public void setChecklist3(Flag checklist3) {
		this.checklist3 = checklist3;
	}
	public Flag getChecklist4() {
		return checklist4;
	}
	public void setChecklist4(Flag checklist4) {
		this.checklist4 = checklist4;
	}
	public Flag getChecklist5() {
		return checklist5;
	}
	public void setChecklist5(Flag checklist5) {
		this.checklist5 = checklist5;
	}
	public Flag getChecklist6() {
		return checklist6;
	}
	public void setChecklist6(Flag checklist6) {
		this.checklist6 = checklist6;
	}
	public Flag getChecklist7() {
		return checklist7;
	}
	public void setChecklist7(Flag checklist7) {
		this.checklist7 = checklist7;
	}
	public Flag getChecklist8() {
		return checklist8;
	}
	public void setChecklist8(Flag checklist8) {
		this.checklist8 = checklist8;
	}
	public Flag getChecklist9() {
		return checklist9;
	}
	public void setChecklist9(Flag checklist9) {
		this.checklist9 = checklist9;
	}
	public Flag getChecklist10() {
		return checklist10;
	}
	public void setChecklist10(Flag checklist10) {
		this.checklist10 = checklist10;
	}
	public Flag getChecklist11() {
		return checklist11;
	}
	public void setChecklist11(Flag checklist11) {
		this.checklist11 = checklist11;
	}
	public Flag getChecklist12() {
		return checklist12;
	}
	public void setChecklist12(Flag checklist12) {
		this.checklist12 = checklist12;
	}
	public Flag getChecklist13() {
		return checklist13;
	}
	public void setChecklist13(Flag checklist13) {
		this.checklist13 = checklist13;
	}
	public Flag getChecklist14() {
		return checklist14;
	}
	public void setChecklist14(Flag checklist14) {
		this.checklist14 = checklist14;
	}
	public Flag getChecklist15() {
		return checklist15;
	}
	public void setChecklist15(Flag checklist15) {
		this.checklist15 = checklist15;
	}
	public Flag getChecklist16() {
		return checklist16;
	}
	public void setChecklist16(Flag checklist16) {
		this.checklist16 = checklist16;
	}
	public Flag getChecklist17() {
		return checklist17;
	}
	public void setChecklist17(Flag checklist17) {
		this.checklist17 = checklist17;
	}
	public Flag getChecklist18() {
		return checklist18;
	}
	public void setChecklist18(Flag checklist18) {
		this.checklist18 = checklist18;
	}
	public Flag getChecklist19() {
		return checklist19;
	}
	public void setChecklist19(Flag checklist19) {
		this.checklist19 = checklist19;
	}
	public Flag getChecklist20() {
		return checklist20;
	}
	public void setChecklist20(Flag checklist20) {
		this.checklist20 = checklist20;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getUpdatedTs() {
		return updatedTs;
	}
	public void setUpdatedTs(String updatedTs) {
		this.updatedTs = updatedTs;
	}
	
	
	
	@Override
	public String toString() {
		return "RollOffCheckList [empNum=" + empNum + ", status=" + status + ", updatedBy=" + updatedBy + ", updatedTs="
				+ updatedTs + ", checklist1=" + checklist1 + ", checklist2=" + checklist2 + ", checklist3=" + checklist3
				+ ", checklist4=" + checklist4 + ", checklist5=" + checklist5 + ", checklist6=" + checklist6
				+ ", checklist7=" + checklist7 + ", checklist8=" + checklist8 + ", checklist9=" + checklist9
				+ ", checklist10=" + checklist10 + ", checklist11=" + checklist11 + ", checklist12=" + checklist12
				+ ", checklist13=" + checklist13 + ", checklist14=" + checklist14 + ", checklist15=" + checklist15
				+ ", checklist16=" + checklist16 + ", checklist17=" + checklist17 + ", checklist18=" + checklist18
				+ ", checklist19=" + checklist19 + ", checklist20=" + checklist20 + "]";
	}

	class Flag{
		String status;
		String comment;
		String compdate;
		
		public Flag(){
			status = "Not Started";
		}
		
		public Flag(String status, String comment, String compdate){
			this.status = status;
			this.comment = comment;
			this.compdate = compdate;
		}
		
		public Flag(String status, String comment){
			this.status = status;
			this.comment = comment;
		}
		
		public Flag(String status){
			this.status = status;
		}
		
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getComment() {
			return comment;
		}
		public void setComment(String comment) {
			this.comment = comment;
		}
		public String getCompdate() {
			return compdate;
		}
		public void setCompdate(String compdate) {
			this.compdate = compdate;
		}
		
	}
	
}

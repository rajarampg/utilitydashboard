package com.pmo.model;

public class RRDMapper {
	
	private String searchDemandId; 
	private String rrdid;
	private int id;
	
	
	public String getSearchDemandId() {
		return searchDemandId;
	}
	public void setSearchDemandId(String searchDemandId) {
		this.searchDemandId = searchDemandId;
	}
	public String getRrdid() {
		return rrdid;
	}
	public void setRrdid(String rrdid) {
		this.rrdid = rrdid;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "RRDMapper [searchDemandId=" + searchDemandId + ", rrdid=" + rrdid + ", id=" + id + "]";
	}
	
}

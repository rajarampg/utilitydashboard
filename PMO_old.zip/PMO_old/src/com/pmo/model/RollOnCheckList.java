package com.pmo.model;

import java.sql.Date;

public class RollOnCheckList {
	
	private String empNum;
	private String empName;
	private String stream;
	private String rollOnDate;
	private String status;
	private Date ackDate;
	
	
	public String getEmpNum() {
		return empNum;
	}
	public void setEmpNum(String empNum) {
		this.empNum = empNum;
	}
	public String getEmpName() {
		return empName;
	}
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getRollOnDate() {
		return rollOnDate;
	}
	public void setRollOnDate(String rollOnDate) {
		this.rollOnDate = rollOnDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getAckDate() {
		return ackDate;
	}
	public void setAckDate(Date ackDate) {
		this.ackDate = ackDate;
	}
	
	@Override
	public String toString() {
		return "RollOnCheckList [empNum=" + empNum + ", empName=" + empName + ", stream=" + stream + ", rollOnDate="
				+ rollOnDate + ", status=" + status + ", ackDate=" + ackDate + "]";
	}
}

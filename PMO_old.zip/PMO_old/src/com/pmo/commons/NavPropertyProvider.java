/*------------------------------------------------------------------------------
Modification History

	Date		 Version		Author			         Description
----------	----------	--------------- ----------------------------------------
07-15-2015    1.0       Harikrishna  Intial Version
------------------------------------------------------------------------------*/
package com.pmo.commons;

import java.io.IOException;

import java.io.InputStream;
import java.util.Properties;

public class NavPropertyProvider {

	private static Properties pmoproperties = new Properties();
	InputStream inputStream;

	public NavPropertyProvider() {
		inputStream = null;
		try {
			inputStream = getClass().getClassLoader().getResourceAsStream("config\\navigation.properties");
			pmoproperties.load(inputStream);			
		} catch (IOException e) {
			System.out.println("Cannot Load Navigation Property Files" + e.getMessage());
		} catch (Exception e) {
			System.out.println("Cannot Load Navigation Property Files" + e.getMessage());
		}
		finally {
			try {
				inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}

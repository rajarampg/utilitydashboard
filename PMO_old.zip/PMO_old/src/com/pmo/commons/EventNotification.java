package com.pmo.commons;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.pmo.connection.PmoProperties;

public class EventNotification {

	Properties emailProperties;
	Session mailSession;
	MimeMessage emailMessage;
	
	public static void sendSimpleEmailNotification(List<String> toSendMailId,List<String> ccSendMailId,String mailSubject, String mailContent) throws AddressException, MessagingException{

		EventNotification javaEmail = new EventNotification();
		String fromMailId =  PmoProperties.getProperty("FROMMAILID");
		
		List<String> toMailId = new ArrayList<String>() ;
		List<String> ccMailId = new ArrayList<String>() ;
		String concate ="@accenture.com";
		for (String characterCheck: toSendMailId)
		{
			if(!(characterCheck.contains("@")))
			{
				characterCheck=characterCheck.concat(concate);
			}
			
			toMailId.add(characterCheck);
		}
		
		// added CC email option as well
		
		for (String characterCheck: ccSendMailId)
		{
			if(!(characterCheck.contains("@")))
			{
				characterCheck=characterCheck.concat(concate);
			}
			
			ccMailId.add(characterCheck);
		}
		javaEmail.setMailServerProperties();
		javaEmail.createEmailMessage(fromMailId, toMailId,ccMailId,mailSubject,mailContent);
		javaEmail.sendEmail();


	}

	public void setMailServerProperties() {
		//inputStream = null;
		String emailHost =null;
		String emailPort =null;
		
		try {
			emailHost= PmoProperties.getProperty("EMAILHOST");
			emailPort= PmoProperties.getProperty("EMAILPORT");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		emailProperties = System.getProperties();
		emailProperties.setProperty("mail.smtp.host", emailHost);
		emailProperties.put("mail.smtp.port", emailPort);
		emailProperties.put("mail.smtp.socketFactory.port", emailPort);
		// emailProperties.put("mail.smtp.starttls.enable", "true");
		//emailProperties.put("mail.smtp.auth", "true");

	}

	public void createEmailMessage(String fromMailId, List<String> toMailId,List<String> ccMailId,String mailSubject, String mailContent) throws AddressException,
	MessagingException {
		/*String[] toEmails = { "@accenture.com" };
		String fromUser = "@accenture.com";
		String emailSubject = "Java Email";
		String emailBody = "This is an email sent by JavaMail api.";*/

		mailSession = Session.getDefaultInstance(emailProperties, null);
		emailMessage = new MimeMessage(mailSession);
       
		String[] strarray = toMailId.toArray(new String[0]);
		for (int i = 0; i < toMailId.size(); i++) {
			emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(strarray[i]));
		}
		// added CC email option as well
		String[] strarraycc = ccMailId.toArray(new String[0]);
		for (int j = 0; j < ccMailId.size(); j++) {
			emailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(strarraycc[j]));
		}
		emailMessage.setFrom(new InternetAddress(fromMailId));
		emailMessage.setSubject(mailSubject);
		emailMessage.setContent(mailContent, "text/html");//for a html email
		//emailMessage.setText(emailBody);// for a text email

	}

	public void sendEmail() throws AddressException, MessagingException {

		//String fromUserEmailPassword = "Gr8british123*";

		//Transport transport = mailSession.getTransport("smtp");

		// transport.connect(emailHost, fromUser, fromUserEmailPassword);
		Transport.send(emailMessage);
		// transport.close();
		System.out.println("Email sent successfully.");
	}
}



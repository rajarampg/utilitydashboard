package com.pmo.commons;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.joda.time.DateTime;
import org.joda.time.Interval;
import org.joda.time.Period;

import com.google.gson.Gson;
import com.pmo.connection.DatabaseConnection;

public class Util {

	public static final int ONBOARDED = 1;
	public static final int WAITING_ONBOARD_ROLLEDON = 2;
	public static final int ROLLEDON = 3;
	public static final int OFFBOARDED = 4;
	public static final int ROLLEDOFF = 5;

	// REQUEST TYPES
	public static final int ONBOARD_EMPLOYEE_DETAILS = 101;
	public static final int TRANSPORT_COSTS_REPORT = 102;
	public static final int GENDER_REPORT = 103;
	public static final int HARDWARE_REPORT = 104;
	public static final int COMMUNICATION_COSTS_REPORT = 105;
	public static final int CERTIFCATION_REPORT = 106;
	public static final int REWARDS_REPORT = 107;
	public static final int OFFBOARD_EMPLOYEE_DETAILS = 108;
	public static final int RESOURCE_DETAILS = 109;
	public static final int GET_EMPLOYEE_DETAILS = 110;
	public static final int TRAINING_REPORT = 111;
	public static final int RRD_REPORT = 112;
	public static final int ACL_REPORT = 113;
	public static final int ROLLON_CHECKLIST_REPORT = 114;
	public static final int CERTIFICATION_MASTER_REPORT = 115;
	public static final int TASKS_MASTER_REPORT = 116;
	
	
	
	

	public static void setResponseStatus(HttpServletResponse response, String alertMessage, String targetJspPage) {
		try {
			PrintWriter writer = response.getWriter();
			String reply = "<script type=\"text/javascript\">" + "alert('" + alertMessage + "');" + "location='"
					+ targetJspPage + "';" + "</script>";
			writer.write(reply);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void setResponseStatus(HttpServletResponse response, String alertMessage) {
		try {
			PrintWriter writer = response.getWriter();
			writer.write(alertMessage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String checkForNull(String inputString) {
		if (inputString == null)
			return "";
		return inputString;
	}

	public static String getResourceListQuery(String filter, String onboardFilter) {
		if (filter != null) {
			if (filter.trim().equals("onBoard")) {
				return "select resourcename,specificstream from employeedetails where employee_status in (" + ONBOARDED
						+ ", " + WAITING_ONBOARD_ROLLEDON +","+ROLLEDON+") and onboarded_by = '"+onboardFilter+"'";
			} else if (filter.trim().equals("rollOn")) {
				return "select resourcename,specificstream from employeedetails where employee_status in (" + ONBOARDED+ ", " + WAITING_ONBOARD_ROLLEDON +","+ROLLEDON+")";
			} else if (filter.trim().equals("offBoard")) {
				return "select resourcename,specificstream from employeedetails where employee_status in (" + ROLLEDON
						+ ")";
			} else if (filter.trim().equals("inRoll")) {
				return "select resourcename,specificstream from employeedetails where employee_status in (" + ROLLEDON
						+ ")";
			} else if (filter.trim().equals("changeRequest")) {
				return "select resourcename,specificstream from employeedetails where employee_status in (" + ROLLEDON
						+ ")";
			} else if (filter.trim().equals("rollOff")) {
				return "select resourcename,specificstream from employeedetails where employee_status in (" + OFFBOARDED
						+ ")";}
				else if (filter.trim().equals("AddCertification")) {
					return "select resourcename,specificstream from employeedetails where supervisor_name = '"+onboardFilter+"'";
				
			}
		}
		return "select resourcename,specificstream from employeedetails";
	}
	
	public static String getResourcesList(String filter) {
		return getResourcesList(filter, null);
	}

	public static String getResourcesList(String filter, String onboardFilter) {
		// DatabaseConnection dbConn = new DatabaseConnection();
		Connection con = null;
		PreparedStatement statement = null;
		String json = null;
		ArrayList<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();
		HashMap<String, String> empName = null;
		ResultSet rs = null;
		try {
			// con = dbConn.mySqlConnection();
			con = DatabaseConnection.getRAWConnection();
			statement = con.prepareStatement(getResourceListQuery(filter, onboardFilter));
			rs = statement.executeQuery();
			while (rs.next()) {
				empName = new HashMap<String, String>();
				empName.put(rs.getString("resourcename"), rs.getString("specificstream"));
				list.add(empName);
			}
			json = new Gson().toJson(list);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			DatabaseConnection.closeRs(rs);
			DatabaseConnection.closePst(statement);
			DatabaseConnection.closeCon(con);
			// dbConn.closeConnection(con, statement, rs);
		}
		return json;
	}
	
	public static String getEmployeeStatusDesc(int status){
		switch(status){
			case ONBOARDED:
				return "Onboarded";
			case WAITING_ONBOARD_ROLLEDON:
				return "Awaiting Onboard";
			case ROLLEDON:
				return "Rolled On";
			case OFFBOARDED:
				return "Off boarded";
			case ROLLEDOFF:
				return "Rolled off";
			default:
				return "Unknown";
		}
	}

	public Map requestParamsToJSON(ServletRequest req) {
		  
		  Map<String,String[]> params = req.getParameterMap();
		  for (Map.Entry<String,String[]> entry : params.entrySet()) {
		    String v[] = entry.getValue();
		    Object o = (v.length == 1) ? v[0] : v;
		    
		  }
		  return params;
		}	
	
	public int printDifference(String startDate, String endDate){
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		long sDate = Date.parse(startDate);
		Date sDate1 = new Date(sDate);
		long eDate = Date.parse(endDate);
		Date eDate1 = new Date(eDate);
		  Interval interval = 
	               new Interval(sDate1.getTime(), eDate1.getTime());
		  Period period = interval.toPeriod();
			   return period.getDays();
			
		}
	
	public String randomNumber(){
		Random r = new Random( System.currentTimeMillis() );
	    int randVal= 10000 + r.nextInt(20000);
	    return "D" + Integer.toString(randVal);
	}
}

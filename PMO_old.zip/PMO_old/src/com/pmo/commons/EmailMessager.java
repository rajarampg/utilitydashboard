package com.pmo.commons;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import freemarker.core.ParseException;
import freemarker.template.Configuration;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

public class EmailMessager {
	
	
	
	public static String generateEmailMessage(ServletContext context,HttpServletRequest request,String emailtemplate) throws TemplateException
	
	{
	

	@SuppressWarnings("deprecation")
	Configuration cfg = new Configuration();
	System.out.println(request.getClass());
	cfg.setServletContextForTemplateLoading(context, "WEB-INF");
	Writer out = new StringWriter();
	Map<String, Object> rootMap = new HashMap<String, Object>();
	
	Map<String, String[]> hasher  =request.getParameterMap();
	
		for ( Entry<String, String[]> entry : hasher.entrySet()) {
		    String v[] = entry.getValue();
		    Object o = (v.length == 1) ? v[0] : v;
		    System.out.println(entry.getKey() +"  "+o);
		    rootMap.put(entry.getKey(), o);
		  }
		
    try {
    	Template template = cfg.getTemplate(emailtemplate);
    	
    		try {
    			template.process(rootMap,out);
    			} catch (IOException e) {
			// TODO Auto-generated catch block
    				e.printStackTrace();
    			}

   

	} catch (TemplateNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (MalformedTemplateNameException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ParseException e) {
		// TODO Auto-generated catch block
	
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
 	return out.toString(); 
   }

	
}	

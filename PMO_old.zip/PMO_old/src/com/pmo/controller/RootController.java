/*------------------------------------------------------------------------------
Modification History

	Date		 Version		Author			         Description
----------	----------	--------------- ----------------------------------------
07-15-2015    1.0       Harikrishna  Intial Version
------------------------------------------------------------------------------*/
package com.pmo.controller;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pmo.commons.NavigationProperties;

/**
 * Servlet implementation class RootController
 */

public class RootController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RootController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String strServletPath = request.getServletPath().substring(1);
		String l_contr_class_name	=	NavigationProperties.getProperty (strServletPath+".classname");
		String strSuccessJsp        =	NavigationProperties.getProperty (strServletPath+".success");
		String strFailureJsp        =	NavigationProperties.getProperty (strServletPath+".failure");
		System.out.println("hello root controoler"+"l_contr_class_name ::"+l_contr_class_name+ "::strSuccessJsp ::"+strSuccessJsp+"::strFailureJsp ::"+strFailureJsp);
		if(l_contr_class_name != null && !l_contr_class_name.trim().equals("")){
//			Controller's forward/redirect/response is handled at their respective implementations
			if(!reDistributeController(request, response, l_contr_class_name)){
//				Forwards to failure page in case of exceptions
				request.getRequestDispatcher(strFailureJsp).forward(request, response);
				return;
			}
		}
//		 Common request forward to handle static pages
		else
			request.getRequestDispatcher(strSuccessJsp).forward(request, response);
		
	}
	
	private boolean reDistributeController(HttpServletRequest request, HttpServletResponse response, String className) {
		try {
			Class<?> controllerClass = Class.forName(className);
			Object instance = controllerClass.getConstructor().newInstance();
			Method postMethod = controllerClass.getDeclaredMethod("doPost",HttpServletRequest.class, HttpServletResponse.class);
			postMethod.invoke(instance , request, response);
			return true;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (Exception e){
			e.printStackTrace();
		}
		return false;
	}

}

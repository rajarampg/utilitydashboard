/**
 * @author sankar.arumugam
 *modified by harikrishna.kamepali date : 1-July-2015
 * *modified by harikrishna.kamepali date : 17-July-2015
 */
package com.pmo.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {

	public Connection mySqlConnection() {

		return getRAWConnection();

	}

	public static Connection getRAWConnection() {
		Connection connection;
		connection = null;
		String driverName = null;
		String driver = null;
		String serverName = null;
		String portNumber = null;
		String sid = null;
		String username = null;
		String password = null;
		String url = null;

		try {

			driverName = PmoProperties.getProperty("DRIVERCLASS");
			driver = PmoProperties.getProperty("DRIVER");
			serverName = PmoProperties.getProperty("DBHOST");
			portNumber = PmoProperties.getProperty("DBPORT");
			sid = PmoProperties.getProperty("DBSID");
			username = PmoProperties.getProperty("DBUSERNAME");
			password = PmoProperties.getProperty("DBPASSWORD");
			url = (new StringBuilder(String.valueOf(driver))).append("://").append(serverName).append(":")
					.append(portNumber).append(";databaseName=").append(sid).toString();
			Class.forName(driverName).newInstance();
			connection = DriverManager.getConnection(url, username, password);
			connection.setAutoCommit(false);
		} catch (SQLException e) {
			System.out.println("SQL Exception occured while creating the connection ::" + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Cannot Load DB Property Files" + e.getMessage());
			e.printStackTrace();
		}

		return connection;
	}

	public static void closeCon(Connection con) {
		try {
			if (con != null)
				con.close();
		} catch (Exception e) {
		}
		con = null;

	}

	public static void closePst(PreparedStatement pst) {
		try {
			if (pst != null)
				pst.close();
		} catch (Exception e) {
		}
		pst = null;

	}

	public static void closeStmt(Statement st) {
		try {
			if (st != null)
				st.close();
		} catch (Exception e) {
		}
		st = null;

	}

	public static void closeRs(ResultSet rs) {
		try {
			if (rs != null)
				rs.close();
		} catch (Exception e) {
		}
		rs = null;

	}

	public static void closeConnection(Connection connection, PreparedStatement ps, ResultSet resultSet) {
		if (resultSet != null) {
			try {
				resultSet.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (ps != null) {
			try {
				ps.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (connection != null) {
			try {
				if (!connection.isClosed()) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

}

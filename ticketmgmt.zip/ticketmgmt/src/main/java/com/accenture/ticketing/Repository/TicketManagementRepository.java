package com.accenture.ticketing.Repository;

import org.springframework.data.repository.CrudRepository;

import com.accenture.ticketing.model.TicketDetailsMapping;

public interface TicketManagementRepository extends CrudRepository<TicketDetailsMapping, String> {

}

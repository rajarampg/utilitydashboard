package com.accenture.ticketing.business;

import com.accenture.ticketing.model.TicketDetails;

public interface TicketManagementBusiness {

	String addTicket(TicketDetails tickDetails);
}

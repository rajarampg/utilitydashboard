/**
 * 
 */
package com.accenture.ticketing;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.ticketing.business.TicketManagementBusiness;
import com.accenture.ticketing.model.TicketDetails;
import com.accenture.ticketing.model.TicketResponse;

@CrossOrigin
@RestController
@RequestMapping(value="/tickets")
public class TicketManagementController {

	@Autowired
	TicketManagementBusiness ticketMgmtBiz;
	
	@RequestMapping(value="/addticket",method=RequestMethod.POST,headers="Accept=Application/JSON")
	public TicketResponse addTicket(@RequestBody TicketDetails ticketDetails){
		TicketResponse tickResp = new TicketResponse();
		tickResp.setStatusCode("200");
		tickResp.setStatusMessage(ticketMgmtBiz.addTicket(ticketDetails));
		return tickResp;
	}
}

package com.accenture.ticketing.mapper;

import org.springframework.stereotype.Component;

import com.accenture.ticketing.model.TicketDetails;
import com.accenture.ticketing.model.TicketDetailsMapping;

@Component
public class TicketManagementMapper {

	public TicketDetailsMapping mapTickets(TicketDetails tickDetails){
		TicketDetailsMapping tickMapped= new TicketDetailsMapping();
		tickMapped.setTicketId(tickDetails.getTicketId());
		tickMapped.setTicketName(tickDetails.getTicketName());
		tickMapped.setTicketDesc(tickDetails.getTicketDesc());
		tickMapped.setPriority(tickDetails.getPriority());
		tickMapped.setCreatedBy(tickDetails.getCreatedBy());
		tickMapped.setUpdatedy(tickDetails.getUpdatedy());
		return tickMapped;
	}
}

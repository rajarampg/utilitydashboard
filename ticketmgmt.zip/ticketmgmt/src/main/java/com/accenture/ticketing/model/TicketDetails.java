package com.accenture.ticketing.model;

public class TicketDetails {

	private String ticketId;
	private String ticketName;
	private String ticketDesc;
	private String priority;
	private String createdBy;
	private String updatedy;
	/**
	 * @return the ticketId
	 */
	public String getTicketId() {
		return ticketId;
	}
	/**
	 * @param ticketId the ticketId to set
	 */
	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}
	/**
	 * @return the ticketName
	 */
	public String getTicketName() {
		return ticketName;
	}
	/**
	 * @param ticketName the ticketName to set
	 */
	public void setTicketName(String ticketName) {
		this.ticketName = ticketName;
	}
	/**
	 * @return the ticketDesc
	 */
	public String getTicketDesc() {
		return ticketDesc;
	}
	/**
	 * @param ticketDesc the ticketDesc to set
	 */
	public void setTicketDesc(String ticketDesc) {
		this.ticketDesc = ticketDesc;
	}
	/**
	 * @return the priority
	 */
	public String getPriority() {
		return priority;
	}
	/**
	 * @param priority the priority to set
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the updatedy
	 */
	public String getUpdatedy() {
		return updatedy;
	}
	/**
	 * @param updatedy the updatedy to set
	 */
	public void setUpdatedy(String updatedy) {
		this.updatedy = updatedy;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TicketDetails [ticketId=");
		builder.append(ticketId);
		builder.append(", ticketName=");
		builder.append(ticketName);
		builder.append(", ticketDesc=");
		builder.append(ticketDesc);
		builder.append(", priority=");
		builder.append(priority);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", updatedy=");
		builder.append(updatedy);
		builder.append("]");
		return builder.toString();
	}
	
}


package com.accenture.ticketing.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.ticketing.Repository.TicketManagementRepository;
import com.accenture.ticketing.mapper.TicketManagementMapper;
import com.accenture.ticketing.model.TicketDetails;

@Component
public class TicketManagementBusinessImpl implements TicketManagementBusiness {

	@Autowired
	TicketManagementMapper ticketMgmtMapper;
	
	@Autowired
	TicketManagementRepository ticketMgmtRepo;
	
	@Override
	public String addTicket(TicketDetails tickDetails) {
		// TODO Auto-generated method stub
		String status="Ticket not created! Try Again!";
		try {
			ticketMgmtRepo.save(ticketMgmtMapper.mapTickets(tickDetails));
			status="Ticket created successfully";
		} catch (Exception e) {
			// TODO: handle exception
			status="Failed to create ticket!";
		}
		
		return status;
	}

}

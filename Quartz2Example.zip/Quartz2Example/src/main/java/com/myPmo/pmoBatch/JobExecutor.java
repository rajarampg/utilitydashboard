package com.myPmo.pmoBatch;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pmo.batch.model.EmployeeDetails;
import com.pmo.batch.model.TaskDetails;
import com.pmo.batch.util.EventNotification;
import com.pmo.batch.util.Utility;
import com.pmo.connection.DatabaseConnection;

public class JobExecutor implements Job
{
    static final Logger logger;
    
    static {
        logger = LoggerFactory.getLogger(JobExecutor.class);
    }
    
    @Override
    public void execute(final JobExecutionContext context) throws JobExecutionException {
    	
    	executetasks();
    	executeReminderRollonmails();    
        
    }
    
    public void executetasks()throws JobExecutionException{
    	
    	Connection con = null;
        PreparedStatement pst = null;  
        ResultSet rs = null;
        TaskDetails td = null;
        int daysOpen = 0;
        List<TaskDetails> list = new ArrayList<TaskDetails>();
        try {
            final Utility util = new Utility();
            con = DatabaseConnection.getRAWConnection();
            list = new ArrayList<TaskDetails>();
            final String selectStatement = "select assigned_date, task_desc, isrequest,status,complete_date,assignedby,task_name from tasks where status!='Completed'";
            pst = con.prepareStatement(selectStatement);
            rs = pst.executeQuery();
            while (rs.next()) {
                td = new TaskDetails();
                td.setAssignedDate(rs.getString("assigned_date"));
                td.setTaskDesc(rs.getString("task_desc"));
                td.setIsRequest(rs.getString("isrequest"));
                td.setStatus(rs.getString("status"));
                td.setTaskCompDate(rs.getString("complete_date"));
                td.setAssignedBy(rs.getString("assignedby"));
                td.setTaskName(rs.getString("task_name"));
                final String taskStartDate = td.getAssignedDate();
                final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                final Date date = new Date();
                final Date endDate = new Date(date.getTime());
                final String taskSla = dateFormat.format(endDate).toString();
                if (!td.getStatus().equalsIgnoreCase("Completed")) {
                    daysOpen = util.printDifference(taskStartDate, taskSla);
                }
                else {
                    daysOpen = util.printDifference(taskStartDate, td.getTaskCompDate());
                }
                td.setSlaDays(daysOpen);
                list.add(td);
            }
            for (final TaskDetails itr : list) {
                System.out.println("Task details from DB:" + itr.toString());
                if (itr.getStatus().equalsIgnoreCase("Pending")) {
                    if (itr.getSlaDays() == 1) {
                        final List<String> mailTo = new ArrayList<String>();
                        mailTo.add(itr.getAssignedBy());
                        final List<String> mailCc = new ArrayList<String>();
                        mailCc.add("walmart.idc.pmo");
                        final String mailSub = "Action Required : Task not acknowledged - " + itr.getTaskName();
                        final String mailBody = "The task :" + itr.getTaskName() + " with description: " + itr.getTaskDesc() + " is pending since " + itr.getSlaDays() + " days. You are requested to take necessary action.";
                        EventNotification.sendSimpleEmailNotification(mailTo, mailCc, mailSub, mailBody);
                    }
                    else if (itr.getSlaDays() == 2) {
                        final String leadId = itr.getAssignedBy();
                        final String levelOneSupervisor = util.levelOneSupervisor(leadId);
                        final List<String> mailTo2 = new ArrayList<String>();
                        mailTo2.add(levelOneSupervisor);
                        final List<String> mailCc2 = new ArrayList<String>();
                        mailCc2.add("walmart.idc.pmo");
                        final String mailSub2 = "Action Required : Task not acknowledged - " + itr.getTaskName();
                        final String mailBody2 = "The task :" + itr.getTaskName() + " with description: " + itr.getTaskDesc() + " is pending since " + itr.getSlaDays() + " days. You are requested to take necessary action.";
                        EventNotification.sendSimpleEmailNotification(mailTo2, mailCc2, mailSub2, mailBody2);
                    }
                    else if (itr.getSlaDays() > 2) {                    	
                        final String leadId = itr.getAssignedBy();
                        final List<String> mailTo3 = util.levelTwoMailerList(leadId);
                        final List<String> mailCc3 = new ArrayList<String>();
                        mailCc3.add("walmart.idc.pmo");
                        final String mailSub3 = "Action Required : Task not acknowledged - " + itr.getTaskName();
                        final String mailBody3 = "The task :" + itr.getTaskName() + " with description: " + itr.getTaskDesc() + " is pending since " + itr.getSlaDays() + " days. You are requested to take necessary action.";
                        EventNotification.sendSimpleEmailNotification(mailTo3, mailCc3, mailSub3, mailBody3);
                    }                   
                    else {
                        System.out.println("Task moved to progress queue as expected!");
                    }
                }
                else if (itr.getStatus().equalsIgnoreCase("Progress")) {
                    if (itr.getIsRequest().equalsIgnoreCase("rollOn")) {
                        if (itr.getSlaDays() >= 14) {
                            final String leadId = itr.getAssignedBy();
                            final List<String> mailTo3 = util.levelTwoMailerList(leadId);
                            final List<String> mailCc3 = new ArrayList<String>();
                            mailCc3.add("walmart.idc.pmo");
                            final String mailSub3 = "Action Required : SLA Breached - " + itr.getTaskName();
                            final String mailBody3 = "The task :" + itr.getTaskName() + " with description: " + itr.getTaskDesc() + " is not completed within " + itr.getSlaDays() + " days. You are requested to take necessary action.";
                            EventNotification.sendSimpleEmailNotification(mailTo3, mailCc3, mailSub3, mailBody3);
                        }
                        else {
                            System.out.println("Task completed within agreed SLA");
                        }
                    }
                    else if (itr.getIsRequest().equalsIgnoreCase("rollOff")) {
                        if (itr.getSlaDays() >= 1) {
                            final String leadId = itr.getAssignedBy();
                            final List<String> mailTo3 = util.levelTwoMailerList(leadId);
                            final List<String> mailCc3 = new ArrayList<String>();
                            mailCc3.add("walmart.idc.pmo");
                            final String mailSub3 = "Action Required : SLA Breached - " + itr.getTaskName();
                            final String mailBody3 = "The task :" + itr.getTaskName() + " with description: " + itr.getTaskDesc() + " is not completed within " + itr.getSlaDays() + " days. You are requested to take necessary action.";
                            EventNotification.sendSimpleEmailNotification(mailTo3, mailCc3, mailSub3, mailBody3);
                        }
                        else {
                            System.out.println("Task completed within agreed SLA");
                        }
                    }
                    else if (itr.getSlaDays() >= 2) {
                        final String leadId = itr.getAssignedBy();
                        final List<String> mailTo3 = util.levelTwoMailerList(leadId);
                        final List<String> mailCc3 = new ArrayList<String>();
                        mailCc3.add("walmart.idc.pmo");
                        final String mailSub3 = "Action Required : SLA Breached - " + itr.getTaskName();
                        final String mailBody3 = "The task :" + itr.getTaskName() + " with description: " + itr.getTaskDesc() + " is not completed within " + itr.getSlaDays() + " days. You are requested to take necessary action.";
                        EventNotification.sendSimpleEmailNotification(mailTo3, mailCc3, mailSub3, mailBody3);
                    }
                    else {
                        System.out.println("Task completed within agreed SLA");
                    }
                }
                else {
                    System.out.println("Check the code! Completed tasks should not be returned by resultset!!");
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        catch (Exception e2) {
            e2.printStackTrace();
        }
        finally {
            DatabaseConnection.closeConnection(con, pst, rs);
        }
        
    }
    
    public void executeReminderRollonmails()throws JobExecutionException{
    	
    	Connection con = null;
        PreparedStatement pst = null;       
        ResultSet rs = null;
        EmployeeDetails ed = null;
        int daysOpen = 0;
        List<EmployeeDetails> list = new ArrayList<EmployeeDetails>();
        try {
            final Utility util = new Utility();
            con = DatabaseConnection.getRAWConnection();
            list = new ArrayList<EmployeeDetails>();
            final String selectStatement = "select e.employeenumber,e.enterpriseid,e.rollondate,e.employee_status,e.supervisor_name,e.onboarded_by from employeedetails e where e.employeenumber not in (select employeenumber from rollon_checklist)";
            pst = con.prepareStatement(selectStatement);
            rs = pst.executeQuery();
            while (rs.next()) {
            	
                int status =rs.getInt("employee_status");
            	
            	if(!(status==4 ||status==5)){
            	ed = new EmployeeDetails();
            	ed.setEmployeenumber(rs.getInt("employeenumber"));
            	ed.setEmployee_status(status);
            	ed.setRollondate(rs.getString("rollondate"));
            	ed.setSupervisorid(rs.getString("supervisor_name"));
            	ed.setOnboardedby(rs.getString("onboarded_by"));
            	ed.setEmployeeid(rs.getString("enterpriseid"));
            	            
                final String rollonDate = ed.getRollondate();
                final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                final Date date = new Date();
                final Date endDate = new Date(date.getTime());
                
                final String currentdate = dateFormat.format(endDate).toString();                
                
                daysOpen = util.printDifference(rollonDate, currentdate);
                ed.setDaysopen(daysOpen);
              
                list.add(ed);
                }
                
            }
            
            StringBuilder contentBuilder = new StringBuilder();
    		
		    BufferedReader in = new BufferedReader(new InputStreamReader(JobExecutor.class.getClassLoader().getResourceAsStream("config/onBoardCompletion.html")));
		    String str;
		    while ((str = in.readLine()) != null) {
		        contentBuilder.append(str);
		    }
		    in.close();
		
		    String content = contentBuilder.toString();
            for (final EmployeeDetails itr : list) {
            	
            	System.out.println("Roll on details from DB:" + itr.toString());
                                           
                    if (itr.getDaysopen() == 5 && itr.getDaysopen() < 30 ) {
                        final List<String> mailTo = new ArrayList<String>();
                        mailTo.add(itr.getEmployeeid());                        
                        final List<String> mailCc1 = new ArrayList<String>();
                        if(!itr.getSupervisorid().isEmpty()){
                        mailCc1.add(itr.getSupervisorid());
                        }
                        mailCc1.add("walmart.idc.pmo");
                        final String mailSub = "Action Required : Complete your CDP and RollOn Checklist";                        
                        final String mailBody = content;
                        EventNotification.sendSimpleEmailNotification(mailTo, mailCc1, mailSub, mailBody);
                        
                    } else if(itr.getDaysopen()== 6 && itr.getDaysopen() < 30){                    	
                    	final List<String> mailTo = new ArrayList<String>();
                        mailTo.add(itr.getEmployeeid());                        
                        final List<String> mailCc2 = new ArrayList<String>(); 
                        if(!itr.getOnboardedby().isEmpty()){
                        	mailCc2.add(itr.getOnboardedby()); 
                        }
                        if(!itr.getSupervisorid().isEmpty()){
                        	mailCc2.add(itr.getSupervisorid());
                            } 
                        mailCc2.add("walmart.idc.pmo");
                        final String mailSub = "Action Required : Complete your CDP and RollOn Checklist";                        
                        final String mailBody = content;
                        EventNotification.sendSimpleEmailNotification(mailTo, mailCc2, mailSub, mailBody);
                        
                    }else if(itr.getDaysopen() == 7 && itr.getDaysopen() < 30){
                    	final List<String> mailTo = new ArrayList<String>();
                        mailTo.add(itr.getEmployeeid());
                        final List<String> mailCc3 = new ArrayList<String>();
                        if(!itr.getOnboardedby().isEmpty()){
                        	 final String levelOneSupervisor = util.levelOneSupervisor(itr.getOnboardedby());
                        	 mailCc3.add(levelOneSupervisor);
                        	 mailCc3.add(itr.getOnboardedby()); 
                        }
                        if((!itr.getSupervisorid().isEmpty())){
                        	mailCc3.add(itr.getSupervisorid());
                            }                 
                        
                        mailCc3.add("walmart.idc.pmo");
                        final String mailSub = "Action Required : Complete your CDP and RollOn Checklist";                        
                        final String mailBody = content;                        
                        EventNotification.sendSimpleEmailNotification(mailTo, mailCc3, mailSub, mailBody); 
                        
                    }else if(itr.getDaysopen() > 7 && itr.getDaysopen() < 30){                    	
                    	final List<String> mailTo = new ArrayList<String>();
                        mailTo.add(itr.getEmployeeid());                       
                        final String leadId = itr.getOnboardedby();
                        List<String> mailCc3 = new ArrayList<String>();   
                        if(leadId!=null){
                        	mailCc3 =util.levelTwoMailerList(leadId);
                        }                                            
                        if(!itr.getSupervisorid().isEmpty()){
                        	mailCc3.add(itr.getSupervisorid());
                            }  
                        mailCc3.add("walmart.idc.pmo");
                        final String mailSub = "Action Required : Complete your CDP and RollOn Checklist";                        
                        final String mailBody = content;
                        EventNotification.sendSimpleEmailNotification(mailTo, mailCc3, mailSub, mailBody);
                    
                    }
                    
                              
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        catch (Exception e2) {
            e2.printStackTrace();
        }
        finally {
            DatabaseConnection.closeConnection(con, pst, rs);
        }
        
    }
  
    
 }

    



package com.pmo.connection;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Properties;

public final class PmoProperties implements Serializable {

	private static final long serialVersionUID = 1340022878374048835L;
	private static Properties properties;
	private static boolean Initialized;
	private static final String BLK = "BLOCK";
	public static final String PATH = "resources/pmo.properties";

	private PmoProperties() {
	}

	public static String getProperty(String p_property_name) {

		if (!Initialized) {
			synchronized (BLK) {
				if (Initialized) {
					return properties.getProperty(p_property_name);
				}
				try {
					loadProperties(PATH);
					System.out.println(" pmo Properties Loaded ");
					Initialized = true;
				} catch (Exception e1) {
					e1.printStackTrace();
					Initialized = false;
				}

			}
		}
		return properties.getProperty(p_property_name);
	}

	// --------------------------------------------------------------------------
	public static void loadProperties(String p_file) throws Exception {

		InputStream inputStream = null;
		try {
			if (properties != null) {
				return;
			}

			properties = new Properties();

			inputStream = (new PropertyProvider()).getClass().getClassLoader().getResourceAsStream(p_file);

			properties.load(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (inputStream != null)
					inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}
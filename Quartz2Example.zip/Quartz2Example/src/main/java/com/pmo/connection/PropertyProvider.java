package com.pmo.connection;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyProvider {

	private static Properties pmoproperties = new Properties();
	InputStream inputStream;

	public PropertyProvider() {
		inputStream = null;
		try {
			inputStream = PropertyProvider.class.getClassLoader().getResourceAsStream(PmoProperties.PATH);
			pmoproperties.load(inputStream);
			inputStream.close();
		} catch (IOException e) {			
			System.out.println("Cannot Load pmo Property Files" + e.getMessage());
		} catch (Exception e) {			
			System.out.println("Cannot Load pmo Property Files" + e.getMessage());
		} finally {
			try {
				inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
}

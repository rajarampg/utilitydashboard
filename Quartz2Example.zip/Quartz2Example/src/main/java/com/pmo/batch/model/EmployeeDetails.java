package com.pmo.batch.model;


public class EmployeeDetails {

	private int employeenumber;
	private String rollondate;
	private String rolloffdate;
	private int employee_status;
	private int daysopen;
	private String employeeid;
	private String supervisorid;
	private String onboardedby;

	public int getEmployeenumber() {
		return employeenumber;
	}

	public void setEmployeenumber(int employeenumber) {
		this.employeenumber = employeenumber;
	}

	public String getRollondate() {
		return rollondate;
	}

	public void setRollondate(String rollondate) {
		this.rollondate = rollondate;
	}

	public String getRolloffdate() {
		return rolloffdate;
	}

	public void setRolloffdate(String rolloffdate) {
		this.rolloffdate = rolloffdate;
	}

	public int getEmployee_status() {
		return employee_status;
	}

	public void setEmployee_status(int employee_status) {
		this.employee_status = employee_status;
	}

	public int getDaysopen() {
		return daysopen;
	}

	public void setDaysopen(int daysopen) {
		this.daysopen = daysopen;
	}

	public String getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}

	public String getSupervisorid() {
		return supervisorid;
	}

	public void setSupervisorid(String supervisorid) {
		this.supervisorid = supervisorid;
	}

	public String getOnboardedby() {
		return onboardedby;
	}

	public void setOnboardedby(String onboardedby) {
		this.onboardedby = onboardedby;
	}

	@Override
	public String toString() {
		return "EmployeeDetails [employeenumber=" + employeenumber
				+ ", rollondate=" + rollondate + ", rolloffdate=" + rolloffdate
				+ ", employee_status=" + employee_status + ", daysopen="
				+ daysopen + ", employeeid=" + employeeid + ", supervisorid="
				+ supervisorid + ", onboardedby=" + onboardedby + "]";
	}

}

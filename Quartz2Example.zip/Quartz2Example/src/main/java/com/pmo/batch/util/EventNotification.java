package com.pmo.batch.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.pmo.connection.PmoProperties;

public class EventNotification
{
    Properties emailProperties;
    Session mailSession;
    MimeMessage emailMessage;
    
    public static void sendSimpleEmailNotification(final List<String> toSendMailId, final List<String> ccSendMailId, final String mailSubject, final String mailContent) throws AddressException, MessagingException {
        final EventNotification javaEmail = new EventNotification();
        final String fromMailId = PmoProperties.getProperty("FROMMAILID");
        final List<String> toMailId = new ArrayList<String>();
        final List<String> ccMailId = new ArrayList<String>();
        final String concate = "@accenture.com";
        for (String characterCheck : toSendMailId) {
            if (!characterCheck.contains("@")) {
                characterCheck = characterCheck.concat(concate);
            }
            toMailId.add(characterCheck);
        }
        for (String characterCheck : ccSendMailId) {
            if (!characterCheck.contains("@")) {
                characterCheck = characterCheck.concat(concate);
            }
            ccMailId.add(characterCheck);
        }
        javaEmail.setMailServerProperties();
        javaEmail.createEmailMessage(fromMailId, toMailId, ccMailId, mailSubject, mailContent);
        javaEmail.sendEmail();
    }
    
    public void setMailServerProperties() {
        String emailHost = null;
        String emailPort = null;
        try {
            emailHost = PmoProperties.getProperty("EMAILHOST");
            emailPort = PmoProperties.getProperty("EMAILPORT");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        (this.emailProperties = System.getProperties()).setProperty("mail.smtp.host", emailHost);
        (this.emailProperties).put("mail.smtp.port", emailPort);
        (this.emailProperties).put("mail.smtp.socketFactory.port", emailPort);
    }
    
    public void createEmailMessage(final String fromMailId, final List<String> toMailId, final List<String> ccMailId, final String mailSubject, final String mailContent) throws AddressException, MessagingException {
        this.mailSession = Session.getDefaultInstance(this.emailProperties, null);
        this.emailMessage = new MimeMessage(this.mailSession);
        final String[] strarray = toMailId.toArray(new String[0]);
        for (int i = 0; i < toMailId.size(); ++i) {
            this.emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(strarray[i]));
        }
        final String[] strarraycc = ccMailId.toArray(new String[0]);
        for (int j = 0; j < ccMailId.size(); ++j) {
            this.emailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(strarraycc[j]));
        }
        this.emailMessage.setFrom(new InternetAddress(fromMailId));
        this.emailMessage.setSubject(mailSubject);
        this.emailMessage.setContent(mailContent, "text/html");
    }
    
    public void sendEmail() throws AddressException, MessagingException {
        Transport.send(this.emailMessage);
        System.out.println("Email sent successfully.");
    }
}

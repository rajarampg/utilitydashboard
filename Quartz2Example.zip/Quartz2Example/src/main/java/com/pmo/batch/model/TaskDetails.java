package com.pmo.batch.model;

public class TaskDetails
{
    private String assignedDate;
    private String taskDesc;
    private String taskCompDate;
    private String status;
    private String assignedBy;
    private String taskTimeStamp;
    private String taskName;
    private String isRequest;
    private int slaDays;
    
    public String getAssignedDate() {
        return this.assignedDate;
    }
    
    public void setAssignedDate(final String assignedDate) {
        this.assignedDate = assignedDate;
    }
    
    public String getTaskDesc() {
        return this.taskDesc;
    }
    
    public void setTaskDesc(final String taskDesc) {
        this.taskDesc = taskDesc;
    }
    
    public String getTaskCompDate() {
        return this.taskCompDate;
    }
    
    public void setTaskCompDate(final String taskCompDate) {
        this.taskCompDate = taskCompDate;
    }
    
    public String getStatus() {
        return this.status;
    }
    
    public void setStatus(final String status) {
        this.status = status;
    }
    
    public String getAssignedBy() {
        return this.assignedBy;
    }
    
    public void setAssignedBy(final String assignedBy) {
        this.assignedBy = assignedBy;
    }
    
    public String getTaskTimeStamp() {
        return this.taskTimeStamp;
    }
    
    public void setTaskTimeStamp(final String taskTimeStamp) {
        this.taskTimeStamp = taskTimeStamp;
    }
    
    public String getTaskName() {
        return this.taskName;
    }
    
    public void setTaskName(final String taskName) {
        this.taskName = taskName;
    }
    
    public String getIsRequest() {
        return this.isRequest;
    }
    
    public void setIsRequest(final String isRequest) {
        this.isRequest = isRequest;
    }
    
    public int getSlaDays() {
        return this.slaDays;
    }
    
    public void setSlaDays(final int slaDays) {
        this.slaDays = slaDays;
    }
    
    @Override
    public String toString() {
        return "TaskDetails [assignedDate=" + this.assignedDate + ", taskDesc=" + this.taskDesc + ", taskCompDate=" + this.taskCompDate + ", status=" + this.status + ", assignedBy=" + this.assignedBy + ", taskTimeStamp=" + this.taskTimeStamp + ", taskName=" + this.taskName + ", isRequest=" + this.isRequest + ", slaDays=" + this.slaDays + "]";
    }
}

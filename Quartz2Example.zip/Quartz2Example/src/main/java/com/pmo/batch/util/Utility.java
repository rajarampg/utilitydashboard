package com.pmo.batch.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;
import org.joda.time.Days;

public class Utility
{
   /* public int printDifference(final String startDate, final String endDate) {
        final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        final Date date = new Date();
        
        final long sDate = Date.parse(startDate);
        final Date sDate2 = new Date(sDate);
        final long eDate = Date.parse(endDate);
        final Date eDate2 = new Date(eDate);
        final Interval interval = new Interval(sDate2.getTime(), eDate2.getTime());
        final Period period = interval.toPeriod();
        return period.getDays();
    }
    */
	
	   public int printDifference(String startDate,String endDate) {
		   	int totalDays=0;
		   	SimpleDateFormat formattor = new SimpleDateFormat("MM/dd/yyyy");
		   	SimpleDateFormat inFormat = new SimpleDateFormat("dd-MMM-yy");
			Date d1 = null;
			Date d2 = null;			
				
			try {	
				
				if (!startDate.matches("([0-9]{1,2})/([0-9]{1,2})/([0-9]{4})")){					
					   Date d3 = inFormat.parse(startDate);
					   startDate = formattor.format(d3);
					   
				}
				d1 = formattor.parse(startDate);
				d2 = formattor.parse(endDate);
				DateTime dt1 = new DateTime(d1);
				DateTime dt2 = new DateTime(d2);				
				totalDays=Days.daysBetween(dt1, dt2).getDays();

			 } catch (ParseException  e) {
				e.printStackTrace();
			 }	
			
			return totalDays;
	   }

    public String levelOneSupervisor(final String leadId) {
        System.out.println("L1 LeadID received:" + leadId);
        String levelOneSupervisor = null;
        final Map<String, String> levelOne = new HashMap<String, String>();
        levelOne.put("arvindh.varadharajan", "s.dasarathy");
        levelOne.put("n.anil.darapureddi", "s.dasarathy");
        levelOne.put("karthik.jeyapal", "s.dasarathy");        
        levelOne.put("lakshmi.paramasivam", "radhu.selvaraj");
        levelOne.put("g.a.voorappan", "vijayabaskaran.mannu");
        levelOne.put("melissa.weatherspoon", "gowri.krishnamurthi");       
        levelOne.put("guest", "rajaram.govindarasu");
        for (final Map.Entry<String, String> entry : levelOne.entrySet()) {
            final String key = entry.getKey();
            if (key.equalsIgnoreCase(leadId)) {
                 levelOneSupervisor = entry.getValue();
                System.out.println("L1 Super :" + levelOneSupervisor);
            }
        }
        return levelOneSupervisor;
    }
        
    public List<String> levelTwoMailerList(final String leadId) {
        System.out.println("L2 LeadID received:" + leadId);
        List<String> levelTwoSupervisor = null;
        final Map<String, List<String>> levelTwo = new HashMap<String, List<String>>();
        final List<String> valArvindh = new ArrayList<String>();
        valArvindh.add("s.dasarathy");
        valArvindh.add("d.krishnakumar");
        final List<String> valAnil = new ArrayList<String>();
        valAnil.add("s.dasarathy");
        valAnil.add("d.krishnakumar");
        final List<String> valKarthik = new ArrayList<String>();
        valKarthik.add("s.dasarathy");
        valKarthik.add("d.krishnakumar");
        final List<String> valLakshmi = new ArrayList<String>();
        valLakshmi.add("radhu.selvaraj");
        valLakshmi.add("d.krishnakumar");
        final List<String> valGuest = new ArrayList<String>();
        valGuest.add("rajaram.govindarasu");
        valGuest.add("deepika.rp");
        final List<String> valVoorappan = new ArrayList<String>();
        valVoorappan.add("vijayabaskaran.mannu");
        valVoorappan.add("d.krishnakumar");
        final List<String> valMelissa = new ArrayList<String>();
        valMelissa.add("gowri.krishnamurthi");       
        
        levelTwo.put("arvindh.varadharajan", valArvindh);
        levelTwo.put("n.anil.darapureddi", valAnil);
        levelTwo.put("karthik.jeyapal", valKarthik);
        levelTwo.put("lakshmi.paramasivam", valLakshmi);
        levelTwo.put("g.a.voorappan", valVoorappan);
        levelTwo.put("melissa.weatherspoon", valMelissa);
        levelTwo.put("guest", valGuest);
        for (final Map.Entry<String, List<String>> entry : levelTwo.entrySet()) {
            final String key = entry.getKey();
            if (key.equalsIgnoreCase(leadId)) {
                 levelTwoSupervisor = entry.getValue();
                System.out.println("L2 Super :" + levelTwoSupervisor.toString());
            }
        }
        return levelTwoSupervisor;
    }
}

(function() {

    angular
        .module('app.roleDetails')
        .controller('roleDetailsViewController', roleDetailsViewController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    roleDetailsViewController.$inject = ["roleDetailsWebService", "$rootScope", "$scope", "$stateParams", "$state"];

    function roleDetailsViewController(roleDetailsWebService, $rootScope, $scope, $stateParams, $state) {
        var vm = this;
        vm.editRoleDetails = editRoleDetails;
        vm.id = $stateParams.id;
        
        
        roleDetailsWebService.getRoleDetailsWebService(vm.id).then(function(response){
        	vm.selectmodel = response;
            vm.selectmodel.createdOn = moment(new Date(response.createdOn)).format("MM/DD/YYYY");
            vm.selectmodel.modifiedOn = moment(new Date(response.modifiedOn)).format("MM/DD/YYYY");

            angular.forEach(vm.location,function(value){
                if(vm.selectmodel.locationId === value.id){
                        vm.selectmodel.locationName = value.locationName;
                }
            });
        });
        
        function editRoleDetails(){
        	$state.go('roleDetailsAdd', {
        		id: vm.id,
        		view: "update"
        	});
           // $rootScope.$emit("titleChange",{title: "Role Update"});
        };
        
        
    }
})();
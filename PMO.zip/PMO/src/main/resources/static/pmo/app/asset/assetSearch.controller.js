(function () {

	angular
		.module('app.asset')
		.controller('AssetSearchController', AssetSearchController);

	/**
		 * Main Controller for the Angular Material Starter App
		 * @param $scope
		 * @param $mdSidenav
		 * @param avatarsService
		 * @constructor
		 */
	AssetSearchController.$inject = ["AssetDataService", "$timeout", "$scope", "$stateParams", "AssetWebService"];

	function AssetSearchController(AssetDataService, $timeout, $scope, $stateParams, AssetWebService) {
		var vm = this;

		vm.assetDetailsfilterFlag = false;
		vm.exportToExcel = exportToExcel;
		vm.getAssetDetailsBasedOnFilter = getAssetDetailsBasedOnFilter;
		vm.exportFile = exportFile;

		vm.assetType = AssetDataService.getAssetOptions();
		vm.assetOwnType = AssetDataService.getAssetOwnTypeOptions();

		vm.getSearchData = $stateParams.getSearchData;
		vm.view = $stateParams.view;

		vm.assetDetailsfilterFlag = false;
		vm.limitOptions = [5, 10, 15, 25];

		if (vm.view !== undefined && vm.view === "search") {
			AssetWebService.getAssetDetailsWebService(vm.getSearchData).then(function (response) {
				vm.asset_details = response;
				vm.assetDetailsFiltered = vm.asset_details;
			});
		} else {
			AssetWebService.getAllAssetDetailsRequest().then(function (response) {
				vm.asset_details = response;
				vm.assetDetailsFiltered = vm.asset_details;
			});
		}


		vm.fieldName = {
			"order": "-createdOn",
			"tableDetails": [
				{
					"type": "link",
					"label": "Asset Type",
					"name": "assertType",
					"orderBy": true,
					"url": "assetUpdate",
					"displayField": "assertType"
				}, {
					"type": "label",
					"label": "Asset Own Type",
					"name": "assertOwnType",
					"orderBy": true,
					"displayField": "assertOwnType"
				}, {
					"type": "label",
					"label": "Asset Id",
					"name": "assertId",
					"orderBy": true,
					"displayField": "assertId"
				}, {
					"type": "label",
					"label": "Asset Tag",
					"name": "assetTag",
					"orderBy": true,
					"displayField": "assetTag"
				}, {
					"type": "label",
					"label": "Service Provider",
					"name": "serviceProvider",
					"orderBy": true,
					"displayField": "serviceProvider"
				}, {
					"type": "datelabel",
					"label": "Issued Date",
					"name": "issuedDate",
					"orderBy": true,
					"displayField": "issuedDate"
				}, {
					"type": "datelabel",
					"label": "Return Date",
					"name": "returnDate",
					"orderBy": true,
					"displayField": "returnDate"
				}, {
					"type": "label",
					"label": "Assigned To",
					"name": "assignedTo",
					"orderBy": true,
					"displayField": "assignedTo"
				}, {
					"type": "edit",
					"label": "",
					"name": "",
					"orderBy": true,
					"url": "assetAdd",
					"urlParams": {
						view: "update"
					},
					"displayField": "Edit"
				}]
		};
 
		function getAssetDetailsBasedOnFilter(modelDataAssetType, modelDataAssetOwntype) {
			vm.assetOwntypeDetails = [];
			vm.assetTypeDetails = [];
			vm.asset_details = [];

			if (modelDataAssetType !== undefined && modelDataAssetType.length > 0) {
				vm.assetTypeDetails = getAssetDetailsBasedOnAssetType(modelDataAssetType, vm.assetDetailsFiltered);
			}
			if (modelDataAssetOwntype !== undefined && modelDataAssetOwntype.length > 0) {
				vm.assetOwntypeDetails = getAssetDetailsBasedOnAssetOwntype(modelDataAssetOwntype, vm.assetDetailsFiltered);
			}
			else if (modelDataAssetType !== undefined && modelDataAssetType.length > 0) {
				vm.asset_details = vm.assetTypeDetails;
			} else if (modelDataAssetOwntype !== undefined && modelDataAssetOwntype.length > 0) {
				vm.asset_details = vm.assetOwntypeDetails;
			} else {
				vm.asset_details = vm.assetDetailsFiltered;
			}
		}

		function getAssetDetailsBasedOnAssetType(modelDataAssetType, assetDetails) {
			vm.assetTypeDetails = [];
			angular.forEach(modelDataAssetType, function (value) {
				angular.forEach(assetDetails, function (data) {
					if (data.assertType === value.assetName) {
						vm.assetTypeDetails.push(data);
					}
				});
			});
			return vm.assetTypeDetails;
		}

		function getAssetDetailsBasedOnAssetOwntype(modelDataAssetOwntype, assetDetails) {
			vm.assetOwntypeDetails = [];
			angular.forEach(modelDataAssetOwntype, function (value) {
				angular.forEach(assetDetails, function (data) {
					if (data.assertOwnType === value.assetOwnName) {
						vm.assetOwntypeDetails.push(data);
					}
				});
			});
			return vm.assetOwntypeDetails;
		}

		function exportToExcel(tableId) { // ex: '#my-table'
			var exportHref = ExporttoExcel.tableToExcel(tableId, 'WireWorkbenchDataExport');
			$timeout(function () { location.href = exportHref; }, 100); // trigger download
		}

		function exportFile() {
			console.log("vm.asset_details", vm.asset_details);
			angular.forEach(vm.asset_details, function (value) {
				value.issuedDate = moment(new Date(value.issuedDate)).format("MM/DD/YYYY");
				value.returnDate = moment(new Date(value.returnDate)).format("MM/DD/YYYY");
				value.validity = moment(new Date(value.validity)).format("MM/DD/YYYY");
			});
			var arrData = typeof vm.asset_details != 'object' ? JSON.parse(vm.asset_details) : vm.asset_details;
			var CSV = '';
			CSV += "download" + '\r\n\n';
			var row = "";
			for (var index in arrData[0]) {
				row += index + ',';
			}
			row = row.slice(0, -1);
			CSV += row + '\r\n';
			for (var i = 0; i < arrData.length; i++) {
				var row = "";
				for (var index in arrData[i]) {
					row += '"' + arrData[i][index] + '",';
				}
				row.slice(0, row.length - 1);
				CSV += row + '\r\n';
			}
			if (CSV == '') {
				alert("Invalid data");
				return;
			}
			var fileName = "download";
			var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
			var link = document.createElement("a");
			link.href = uri;
			link.style = "visibility:hidden";
			link.download = fileName + ".csv";
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
		}

	}

})();
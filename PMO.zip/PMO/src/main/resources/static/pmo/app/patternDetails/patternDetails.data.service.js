(function () {
    'use strict';

    angular
        .module('app.patternDetails')
        .factory('patternDetailsDataService', patternDetailsDataService);

    patternDetailsDataService.$inject = ["commonService"];

    /* @ngInject */
    function patternDetailsDataService(commonService) {
        var service = {
            getPortfolioOptions: getPortfolioOptions,
            getPatternDetailsModel: getPatternDetailsModel,
            prepareFinalSubmitDataCreate: prepareFinalSubmitDataCreate,
            prepareFinalSubmitDataUpdate: prepareFinalSubmitDataUpdate,
            testData: testData,
        };
        return service;

        function getPortfolioOptions() {
            var portfolios = [{
                id: 1,
                portfolioName: "Application Operations"
            }, {
                id: 2,
                portfolioName: "Application Stores Program"
            }, {
                id: 3,
                portfolioName: "Stores AD - Windows 2003 Elimination"
            }, {
                id: 4,
                portfolioName: "Walmart Captive"
            }];
            return portfolios;
        }

        function getPatternDetailsModel() {
            var selectmodel = {
                portfoliosModel: "",
                patternName: "",
                patternDescription: "",
                clarity: "No",
                skillTeamDetails: "",
                unixBoxes: "",
                teradataAccess: "",
                adAccess: "",
                additionalAccess: "",
                specificAccess: "",
                businessJustification: "",
                createdBy: "",
                createdOn: null,
                modifiedBy: "",
                modifiedOn: null,
                active: "",
            };
            return selectmodel;
        }

        function getFormatedDate(date) {
            var tempMoment = new Date(date).getTime();
            return tempMoment;
        };


        function prepareFinalSubmitDataCreate(patternDetailsRequestData) {
            var finalData = {
        		"portfolioId": patternDetailsRequestData.portfoliosModel.id,
        		"patternName": patternDetailsRequestData.patternName,
        		"patternDescription": patternDetailsRequestData.patternDescription,
        		"clarity": (patternDetailsRequestData.clarity === "Yes") ? "Yes" : "No",
        		"skillTeamDetails": patternDetailsRequestData.skillTeamDetails,
        		"unixBoxes": patternDetailsRequestData.unixBoxes,
        		"teradataAccess": patternDetailsRequestData.teradataAccess,
        		"adAccess": patternDetailsRequestData.adAccess,
        		"additionalAccess": patternDetailsRequestData.additionalAccess,
        		"specificAccess": patternDetailsRequestData.specificAccess,
        		"businessJustification": patternDetailsRequestData.businessJustification,
        		"createdBy": commonService.getUserIdService(),
        		"createdOn": new Date().getTime(),
        		"modifiedBy": commonService.getUserIdService(),
        		"modifiedOn":new Date().getTime(),
        		"active": true
            };
            console.log(finalData);

            return finalData;
        }
        
        function prepareFinalSubmitDataUpdate(patternDetailsRequestData) {
            var finalData = {
            	"id": patternDetailsRequestData.id,
        		"portfolioId": patternDetailsRequestData.portfoliosModel.id,
        		"patternName": patternDetailsRequestData.patternName,
        		"patternDescription": patternDetailsRequestData.patternDescription,
        		"clarity": (patternDetailsRequestData.clarity == "true"),
        		"skillTeamDetails": patternDetailsRequestData.skillTeamDetails,
        		"unixBoxes": patternDetailsRequestData.unixBoxes,
        		"teradataAccess": patternDetailsRequestData.teradataAccess,
        		"adAccess": patternDetailsRequestData.adAccess,
        		"additionalAccess": patternDetailsRequestData.additionalAccess,
        		"specificAccess": patternDetailsRequestData.specificAccess,
        		"businessJustification": patternDetailsRequestData.businessJustification,
        		"createdBy": commonService.getUserIdService(),
        		"createdOn": new Date().getTime(),
        		"modifiedBy": commonService.getUserIdService(),
        		"modifiedOn":new Date().getTime(),
        		"active": true
            };
            console.log(finalData);

            return finalData;
        }
        
        function testData() {
            var data = {
                status: 200
            }
            return data;
        }

    }
})();
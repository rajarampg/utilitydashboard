(function () {

    angular
        .module('app.employeeReport')
        .controller('employeeReportSearchController', employeeReportSearchController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    employeeReportSearchController.$inject = ["$timeout", "$scope", "$state", "$stateParams", "employeeReportWebService", "employeeReportDataService"];

    function employeeReportSearchController($timeout, $scope, $state, $stateParams, employeeReportWebService, employeeReportDataService) {

        var vm = this;
        vm.employeeReportfilterFlag = false;
        vm.exportToExcel = exportToExcel;
        vm.exportFile = exportFile;
        //vm.editEmployeeReport = editEmployeeReport;
        vm.viewEmployeeReport = viewEmployeeReport;
        //vm.getfilterData = getfilterData;

        vm.getSearchData = $stateParams.getSearchData;
        vm.employee_report = []
        vm.view = $stateParams.view;
        vm.limitOptions = [5, 10, 15, 25];

        vm.options = {
            rowSelection: true,
            multiSelect: true,
            autoSelect: true,
            decapitate: false,
            largeEditDialog: false,
            boundaryLinks: false,
            limitSelect: true,
            pageSelect: true
        };

        vm.query = {
            order: 'createdOn',
            limit: 10,
            page: 1
        };

        function viewEmployeeReport(item) {
            $state.go("employeeDetailsView", {
                employeeNumber: item.employeeNumber,
                id: item.id
            });
        }

        employeeReportWebService.getAllEmployeeReportWebService().then(function (response) {
            vm.employee_report = response;

            angular.forEach(vm.employee_report, function (value) {
                //vm.employee_report.employeeDetails.enterpriseId = value.employeeDetails.enterpriseId;
                value.employeeClientDetails.wmtAccessDate = moment(new Date(value.employeeClientDetails.wmtAccessDate)).format("MM/DD/YYYY");
                value.employeeClientDetails.wmtGrantDate = moment(new Date(value.employeeClientDetails.wmtGrantDate)).format("MM/DD/YYYY");
                value.employeeClientDetails.onboardStartDate = moment(new Date(value.employeeClientDetails.onboardStartDate)).format("MM/DD/YYYY");
                if (value.employeeClientDetails.onboardTime = new Date(value.employeeClientDetails.onboardTime).getTime() === 0) {
                    value.employeeClientDetails.onboardTime = "null";       //CAN ALSO USE 'null'
                }
                else {
                    value.employeeClientDetails.onboardTime = new Date(value.employeeClientDetails.onboardTime).getTime();
                }
                if (value.employeeDetails.rolledoffBy === null) {   //MAY OR MAY NOT BE NEEDED
                    value.employeeDetails.rolledoffBy = "NULL";
                }
                vm.employeeReportFiltered = vm.employee_report;
            });
        });
        function exportToExcel(tableId) { // ex: '#my-table'
            var exportHref = ExporttoExcel.tableToExcel(tableId, 'WireWorkbenchDataExport');
            $timeout(function () { location.href = exportHref; }, 100); // trigger download
        }

        vm.employee_object = [];

        function exportFile() {
            /*vm.employee_object = [];*/
            angular.forEach(vm.employee_report, function (value) {
                var emtyobj ={};
                emtyobj = angular.extend(value.employeeDetails, value.employeeClientDetails);
                vm.employee_object.push(emtyobj);
            });
            
            var arrData = typeof vm.employee_object != 'object' ? JSON.parse(vm.employee_object) : vm.employee_object;
            var CSV = '';
            CSV += "download" + '\r\n\n';
            var row = "";
            for (var index in arrData[0]) {
                row += index + ',';
            }
            row = row.slice(0, -1);
            CSV += row + '\r\n';
            for (var i = 0; i < arrData.length; i++) {
                var row = "";
                for (var index in arrData[i]) {
                    row += '"' + arrData[i][index] + '",';
                }
                row.slice(0, row.length - 1);
                CSV += row + '\r\n';
            }
            if (CSV == '') {
                alert("Invalid data");
                return;
            }
            var fileName = "download";
            var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
            var link = document.createElement("a");
            link.href = uri;
            link.style = "visibility:hidden";
            link.download = fileName + ".csv";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

    }
})();








                /*vm.employee_JSON_details = {

                    // "employeeDetails": JSON.stringify(vm.employeeDetails),
                    // "employeeClientDetails": JSON.stringify(vm.employeeClientDetails),

                    "portfolioId" : employeeDetails.portfolioId ,
                    "employeeNumber" : employeeDetails.employeeNumber,
                    "enterpriseId" : employeeDetails.enterpriseId,
                    "firstName" : employeeDetails.firstName,
                    "lastName" : employeeDetails.lastName,
                    "gender" : employeeDetails.gender,
                    "capability" : employeeDetails.capability,
                    "careerLevel" : employeeDetails.careerLevel,
                    "supervisorEntId" : employeeDetails.supervisorEntId,
                    "phoneNo" : employeeDetails.phoneNo,
                    "currentLocation" : employeeDetails.currentLocation,
                    "deliveryCenter" : employeeDetails.deliveryCenter,
                    "primarySkill" : employeeDetails.primarySkill,
                    "secondarySkill" : employeeDetails.secondarySkill,
                    "proficiencyLevel" : employeeDetails.proficiencyLevel,
                    "visaType" : employeeDetails.visaType,
                    "durationStay" : employeeDetails.durationStay,
                    "lockType" : employeeDetails.lockType,
                    "employeeStatus" : employeeDetails.employeeStatus,
                    "employeeType" : employeeDetails.employeeType,
                    "rollonDate" : employeeDetails.rollonDate,
                    "rollonBy" : employeeDetails.rollonBy,
                    "rolloffDate" : employeeDetails.rolloffDate,
                    "rolloffReason" : employeeDetails.rolloffReason,
                    "rolledoffBy" : employeeDetails.rolledoffBy,
                    "exit" : employeeDetails.exit,
                    "clientManagerId" : employeeClientDetails.clientManagerId,
                    "patternId" : employeeClientDetails.patternId,
                    "roleId" : employeeClientDetails.roleId,
                    "wmtUserId" : employeeClientDetails.wmtUserId,
                    "wmtAccessDate" : employeeClientDetails.wmtAccessDate,
                    "wmtGrantDate" : employeeClientDetails.wmtGrantDate,
                    "contractType" : employeeClientDetails.contractType,
                    "projectName" : employeeClientDetails.projectName,
                    "projectDetails" : employeeClientDetails.projectDetails,
                    "client" : employeeClientDetails.client,
                    "departmentNumber" : employeeClientDetails.departmentNumber,
                    "country" : employeeClientDetails.country,
                    "workstation" : employeeClientDetails.workstation,
                    "bayDetails" : employeeClientDetails.bayDetails,
                    "floor" : employeeClientDetails.floor,
                    "wbse" : employeeClientDetails.wbse,
                    "identifierType" : employeeClientDetails.identifierType,
                    "identifierNumber" : employeeClientDetails.identifierNumber,
                    "comments" : employeeClientDetails.comments,
                    "onboardStartDate" : employeeClientDetails.onboardStartDate,
                    "onboardTime" : employeeClientDetails.onboardTime,
                    "onboardedBy" : employeeClientDetails.onboardedBy,
                    "renew" : employeeClientDetails.renew

                };*/
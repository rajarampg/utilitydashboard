(function() {
    'use strict';

    angular
        .module('app.webservices')
        .factory('loginWebService', loginWebService);

    loginWebService.$inject = ["$q", "baseWebService"];




    /* @ngInject */
    function loginWebService($q, baseWebService) {

        var service = {
        		getViewAllWebService: getViewAllWebService,
        		postUpdateloginDetailsService: postUpdateloginDetailsService,
        		getloginAccess: getloginAccess,
        		addLoginDetails: addLoginDetails
        };

        return service;
        

        function getViewAllWebService() {
            var loginRequest = angular.extend({

            	postloginRequest: function() {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/logindetails/viewalllogindetails",
                        method: "GET",
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;
                }
            }, baseWebService);

            return loginRequest.postloginRequest();

        }
        
        function postUpdateloginDetailsService(options) {
            var taskRequest = angular.extend({

                postTaskRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/logindetails/updatelogindetails",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return taskRequest.postTaskRequest(options);

        }
        
        function getloginAccess(options){
        	var loginRequest = angular.extend({

        		getLoginDetailsRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/logindetails/viewlogindetailsbyenterpriseid?enterpriseId="+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return loginRequest.getLoginDetailsRequest(options);
        }
        
        function addLoginDetails(options) {
            var addLoginDetailsRequest = angular.extend({

            	postaddLoginDetailsRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/logindetails/addlogindetails",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return addLoginDetailsRequest.postaddLoginDetailsRequest(options);

        }
        
        
        
        
    }
})();
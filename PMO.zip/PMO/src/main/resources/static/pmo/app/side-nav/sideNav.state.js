(function() {
    'use strict';
    angular
        .module('app.sideNav')
        .run(appRun);

    /* @ngInject */
    function appRun(routerHelper) {
        routerHelper.configureStates(getStates());
    }

    function getStates() {
        return [{
            state: 'home',
            config: {
                url: '/home'
            }
        }];
    }
})();
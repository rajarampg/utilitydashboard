"use strict";
angular.module("app.blocks").app.constant("moment", moment);
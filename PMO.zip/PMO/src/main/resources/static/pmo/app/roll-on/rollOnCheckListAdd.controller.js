/**
 * Created by abhishek.m.bhabutmal on 3/7/2017.
 */
(function() {

    angular
        .module('app.rollOn')
        .controller('RollOnCheckListAddController', RollOnCheckListAddController);

    /**
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    RollOnCheckListAddController.$inject = ["rollOnDataService", "rollOnWebService", "$mdToast", "$state", "$stateParams","$mdDialog", "commonService", "$scope"];

    function RollOnCheckListAddController(rollOnDataService, rollOnWebService, $mdToast, $state, $stateParams, $mdDialog, commonService, $scope) {
        var vm = this;
        vm.dataPrtStatus = true;
        vm.submitted = false;
        vm.updateFlag = false;
        vm.checklistDetails = vm.checklistDetails ? vm.checklistDetails : {};
        vm.approval = rollOnDataService.getChkListOptions();
        vm.dataProtectionData1 = rollOnDataService.getDataProtectionData1();
        vm.dataProtectionData2 = rollOnDataService.getDataProtectionData2();
        vm.workForceData = rollOnDataService.getworkForceData();
        
         rollOnWebService.getRollOnChecklistBasedOnEmpNoWebService(commonService.getEmpNoService()).then(function (response) {
            if(response.status !== "No content found"){
                vm.updateFlag = true;
                vm.checklistDetails = {};
                //vm.checklistDetails.startDate = null;
                vm.checklistDetails = JSON.parse(response.checklistDetails);
                vm.checklistDetails.startDate = new Date(moment(vm.checklistDetails.startDate).format());
                vm.rollOnCheckListAddForm.$setPristine();
                vm.rollOnCheckListAddForm.$setUntouched();
                //vm.checklistDetails.currentDate = vm.checklistDetails.dataProtectionCheckList.data28.date;
            }
        });

        vm.protectonChkLst = function(ev) {
            $mdDialog.show({
                controller: dataProtectionController,
                templateUrl: './app/roll-on/dataProtection.html',
                parent: angular.element(document.body),
                locals: {
                    items: vm.checklistDetails ? vm.checklistDetails.dataProtectionCheckList : {},
                    dataProtectionData1: vm.dataProtectionData1,
                    dataProtectionData2: vm.dataProtectionData2,
                    workForceData: vm.workForceData
                },
                targetEvent: ev,
                clickOutsideToClose: false,
                fullscreen: true // Only for -xs, -sm breakpoints.
            }).then(function(response) {
                    vm.dataPrtStatus = false;
                    vm.checklistDetails.dataProtectionCheckList = response;
            }, function() {
                    vm.dataPrtStatus = vm.dataPrtStatus ? vm.dataPrtStatus : false;
            });
        };

      /*  vm.disabled = function (event) {
            if (!vm.dataPrtStatus) {
                event.stoppropagation();
            }
        };
*/

        vm.onClickSubmitAllSkills = function(){
            if(vm.rollOnCheckListAddForm.$valid) {
                vm.submitted = false;
                if(vm.checklistDetails.rollOnCheckList == "Acknowledged" && vm.checklistDetails.dataProtectionStatus == "Acknowledged" && vm.checklistDetails.dataProtectionStatus == "Acknowledged" && vm.checklistDetails.culturePresentation == "Acknowledged" && vm.checklistDetails.welcomePresentation == "Acknowledged" && vm.checklistDetails.inductionKit == "Acknowledged"){
                    if(!vm.updateFlag){
                        var request = {
                            "employeeNumber": commonService.getEmpNoService(),
                            "checklistDetails": JSON.stringify(vm.checklistDetails),
                            "updatedby": commonService.getUserIdService(),
                            "status" : "true",
                            "active" : "true"

                        /* "id":2,
                            "employeeNumber": 8794498,
                            "checklistDetails": JSON.stringify(vm.checklistDetails),
                            //"status": certificationRequestData.status,
                            "updatedby": "c.athinaraynanan",
                            "updatedOn" : new Date().getTime(),
                            "active": "true"*/ 
                        };
                        rollOnWebService.addRollOnCheckListService({
                            data: request
                        }).then(function (success) {
                            vm.showSimpleToast("Roll-On Checklist Details Added Successfully");
                        }, function (error) {
                            console.log(error);
                            vm.showSimpleToast("Roll-On Checklist Details Addition Failed");
                        });
                    }else if(vm.updateFlag){
                        console.log("update roll on");
                    }
                    
                }else{
                    $mdDialog.show(
                        $mdDialog.alert()
                            .parent(angular.element(document.querySelector('#popupContainer')))
                            .clickOutsideToClose(true)
                            .title('Alert')
                            .textContent('Please Acknowledge all the Fields')
                            .ariaLabel('Alert Dialog Demo')
                            .ok('Got it!')
                    );
                }
            }else{
                vm.submitted = true;
            }
        };

        function dataProtectionController($scope, $mdDialog, items, dataProtectionData1, dataProtectionData2, workForceData) {
            $scope.submitted = false;
            $scope.items = items ? items : {};
            if($scope.items.data28 !== undefined){
                $scope.items.data28.date =  ($scope.items.data28 !== undefined) ? new Date(moment($scope.items.data28.date).format("MM/DD/YYYY")) : null;
            }
            $scope.dataProtectionData1 = dataProtectionData1;
            $scope.dataProtectionData2 = dataProtectionData2;
            $scope.workForceData = workForceData;
            $scope.items.data28 
            $scope.confirm = function() {
                if($scope.dataProtectionForm.$valid) {
                    $scope.submitted = false;
                    $mdDialog.hide($scope.items);
                }else{
                    $scope.submitted = true;
                }
            };

            $scope.cancel = function() {
                $mdDialog.cancel();
            };
        }


        vm.showSimpleToast = function(message) {
            $mdToast.show(
                $mdToast.simple()
                    .textContent(message)
                    .hideDelay(3000)
            );
        };

    }
})();
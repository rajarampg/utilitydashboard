(function() {
    'use strict';

    angular
        .module('app.webservices')
        .factory('AssetWebService', AssetWebService);

    AssetWebService.$inject = ["$q", "baseWebService"];




    /* @ngInject */
    function AssetWebService($q, baseWebService) {

        var service = {
            postAssetWebService: postAssetWebService,
            postAssetWebServiceUpdate: postAssetWebServiceUpdate,
            getAssetWebService: getAssetWebService,
            getAssetDetailsWebService: getAssetDetailsWebService,
            getAllAssetDetailsRequest: getAllAssetDetailsRequest
        };

        return service;
        

        function postAssetWebService(options) {
            var assetRequest = angular.extend({

                postAssetRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/assertdetails/addassertdetails",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return assetRequest.postAssetRequest(options);

        }
        
        function getAssetWebService(options) {
            var assetRequest = angular.extend({

                getAssetRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/assertdetails/viewassertdetails/"+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return assetRequest.getAssetRequest(options);

        }
      
        function getAssetDetailsWebService(options) {
            var assetRequest = angular.extend({

            	getAssetDetailsRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/assertdetails/viewassertdetailsbyassignedto?assignedTo="+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return assetRequest.getAssetDetailsRequest(options);

        }

        function getAllAssetDetailsRequest(options) {
            var assetRequest = angular.extend({

            	getAllAssetDetailsRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/assertdetails/viewallassertdetails",
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return assetRequest.getAllAssetDetailsRequest(options);

        }

        function postAssetWebServiceUpdate(options) {
            var assetRequest = angular.extend({

                postAssetWebServiceUpdate: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/assertdetails/updateassertdetails",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return assetRequest.postAssetWebServiceUpdate(options);

        }
    }
})();
(function () {

    angular
        .module('app.portfolioDetails')
        .controller('portfolioDetailsAddController', portfolioDetailsAddController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    portfolioDetailsAddController.$inject = ["portfolioDetailsDataService", "portfolioDetailsWebService", "$mdToast", "$state", "$stateParams"];

    function portfolioDetailsAddController(portfolioDetailsDataService, portfolioDetailsWebService, $mdToast, $state, $stateParams) {

        var vm = this;
        vm.submitted = false;
        vm.editButtonEnable = false;
        vm.id = ($stateParams.id !== undefined) ? $stateParams.id : "create";
        //vm.view = ($stateParams.view !== undefined) ? $stateParams.view : "create";   //TO DISABLE FIELDS

        vm.selectmodel = portfolioDetailsDataService.getPortfolioModel();
        vm.onClickSubmitPortfolioDetails = onClickSubmitPortfolioDetails;

        if (vm.id !== "create") {
            portfolioDetailsWebService.getPortfolioDetailsWebService(vm.id).then(function (response) {
                vm.selectmodel = {};
                vm.selectmodel = response;
                vm.editButtonEnable = false;
                vm.selectmodel.createdOn = new Date(moment(vm.selectmodel.createdOn).format());
                vm.selectmodel.modifiedOn = new Date(moment(vm.selectmodel.modifiedOn).format());
                /*angular.forEach(vm.selectmodel, function(value){
                    if(response.id === value.id){
                        vm.selectmodel.portfolioName = value.portfolioName;
                    }
                });*/
                console.log("vm.selectmodel", vm.selectmodel);
            });
        }

        function onClickSubmitPortfolioDetails() {
            if (vm.id === "create") {
                if (vm.portfolioDetailsAddForm.$valid) {
                    vm.submitted = false;
                    var createPortfolioDetails = portfolioDetailsDataService.prepareFinalSubmitDataCreate(vm.selectmodel);
                    portfolioDetailsWebService.postPortfolioDetailsWebService({
                        data: createPortfolioDetails
                    }).then(function (success) {
                        vm.showSimpleToast("Portfolio Details Submitted ");
                        $state.go("portfolioDetailsSearch", {
                            getSearchData: createPortfolioDetails,
                            view: "search"

                        }, function (error) {
                            console.log(error);
                        });
                    });
                } else {
                    vm.submitted = true;
                }
            }
            else if (vm.id !== "create") {
                if (vm.editButtonEnable) {
                    vm.editButtonEnable = false;
                } else {
                    if (vm.portfolioDetailsAddForm.$valid) {
                        var updatePortfolioDetails = portfolioDetailsDataService.prepareFinalSubmitDataUpdate(vm.selectmodel);
                        portfolioDetailsWebService.postPortfolioDetailsWebServiceUpdate({
                            data: updatePortfolioDetails
                        }).then(function (success) {
                            vm.showSimpleToast("Portfolio Details Updated Succesfully");
                            vm.editButtonEnable = true;
                            $state.go("portfolioDetailsSearch");

                        }, function (error) {
                            console.log(error);
                        });
                    } else {
                        vm.submitted = true;
                    }
                }
            }
        }

        vm.showSimpleToast = function (message) {

            $mdToast.show(
                $mdToast.simple()
                    .textContent(message)
                    /*.position("
                        center ")*/
                    .hideDelay(3000)
            );
        };
    }
})();
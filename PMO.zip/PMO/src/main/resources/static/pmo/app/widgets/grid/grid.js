(function () {

    
    angular.module("app.widgets", []).directive("uiGrid", uiGrid);

    uiGrid.$inject = [];

    function uiGrid() {
        var directive = {
            restrict: "E",
            templateUrl: "./app/widgets/grid/grid.html",
            scope: {
            	dataSource: '=datasource',
            	fieldName: '=fieldName'
            },
            controller: uiGridController,
            controllerAs: "vm",
            bindToController: true
        };
        return directive;
    }

    uiGridController.$inject = ["$state"];

    function uiGridController($state) {
        var vm = this;
        vm.linkClick = linkClick;
        vm.getData = getData;
        vm.editClick = editClick;
        
        vm.limitOptions = [5, 10, 15, 25];
        
        vm.options = {
          rowSelection: true,
          multiSelect: true,
          autoSelect: true,
          decapitate: false,
          largeEditDialog: false,
          boundaryLinks: false,
          limitSelect: true,
          pageSelect: true
        };
        
        vm.query = {
          order: vm.fieldName.order,   //If order:"" it will default sort all the rows and columns depending on our selected row
          limit: 5,
          page: 1
        };
        
        function linkClick(data, url, id){
        	$state.go(url, {
        		id: id
        	});
        }
        
        function editClick(url, id, urlParams){
        	$state.go(url, {
        		id: id
        	});
        }
        
        function getData(parentIndex,Index){
        	console.log("dfg");
        	/*console.log("data, key", key);
        	if(key.indexOf(".") > 0){
        		var pathStep = "";
        		var segs = key.split('.');
        		while (segs.length > 0) {
            		    pathStep = segs.shift();
        		  }
        		
//        		var segs = key.split('.');
//
//        		  while (segs.length > 0) {
//        		    var pathStep = segs.shift();
//        		    if (typeof items[pathStep] === 'undefined') {
//        		      root[pathStep] = segs.length === 0 ? { value:  '' } : {};
//        		    }
//        		    root = root[pathStep];
//        		  }
//        		  return root;
//        		return splitString.join('.');
        		//key.split[]
        	}*/
        	return vm.dataSource[parentIndex][vm.fieldName[index].displayField];
        	
        }
        
        
//        
//        $scope.getTypes = function () {
//            return ['Candy', 'Ice cream', 'Other', 'Pastry'];
//          };
       
    }
})();

(function() {
    'use strict';

    angular
        .module('app.demandRequest')
        .factory('demandRequestDataService', demandRequestDataService);

    demandRequestDataService.$inject = ["commonService"];

    /* @ngInject */
    function demandRequestDataService(commonService) {
        var service = {
            getProtfolioModel: getProtfolioModel,
            getSkillsModel: getSkillsModel,
            getPortfolioOptions: getPortfolioOptions,
            getDemandSegmentsOptions: getDemandSegmentsOptions,
            getPrioritiesOptions: getPrioritiesOptions,
            getVisaListOptions: getVisaListOptions,
            getSourceLocationOptions: getSourceLocationOptions,
            getWorkLocationOptions: getWorkLocationOptions,
            getPrimarySkillOptions: getPrimarySkillOptions,
            getCareerlevelOptions: getCareerlevelOptions,
            getFulfillmentEntityOptions: getFulfillmentEntityOptions,
            getTermOptions: getTermOptions,
            prepareFinalSubmitData: prepareFinalSubmitData,
            prepareResourceMapCreate: prepareResourceMapCreate
        };
        return service;

        function getProtfolioModel() {
            var selectmodel = {
                portfoliosModel: "",
                demandSegmentsModel: "",
                prioritiesModel: "",
                startdateModel: null,
                fulfillmentdateModel: null,
                enddateModel: null,
                visaModel: "",
                sourcelocModel: "",
                worklocModel: "",
                visareadyModel: "",
                clientInterviewModel: false,
                onsitecomponentModel: false
            };


            return selectmodel;
        }

        function getSkillsModel() {
            var skillsModel = {
                primarySkillModel: "",
                careerlevelModel: "",
                fulfillmentEntityModel: "",
                termModel: "",
                hardlockModel: false,
                wbseModel: "",
                numberModel: ""
            };
            return skillsModel;
        }

        function getPortfolioOptions() {
            var portfolios = [{
                id: 1,
                portfolioName: "Application Operations"
            }, {
                id: 2,
                portfolioName: "Application Stores Program"
            }, {
                id: 3,
                portfolioName: "Stores AD - Windows 2003 Elimination"
            }, {
                id: 4,
                portfolioName: "Walmart Captive"
            }];
            return portfolios;
        }




        function getDemandSegmentsOptions() {
            var demandSegments = [
                "New Client",
                "Existing Client",
                "Internal Organizational Movement",
                "Contractor Conversion",
                "Application Services - New",
                "Application Services - Backfill",
                "Application Services - Contractor Replacement"
            ];
            return demandSegments;

        }


        function getPrioritiesOptions() {
            var priorities = [
                "At-Risk",
                "Critical",
                "High",
                "Normal"
            ];
            return priorities;
        }

        function getVisaListOptions() {
            var visaList = [
                "USA - B1",
                "USA - H1B",
                "USA - H1B Anticipatory Visa",
                "USA - H1B Regular",
                "USA - J1",
                "USA - L1 Blanket",
                "USA - L1A Blanket",
                "USA - L1B Blanket",
                "USA- L2 (EAD)",
                "USAGreen Card",
                "USA H-1B Amended",
                "USA H-1B Premium",
                "USA H-1B Regular",
                "USAH-1B Shift",
                "USA- H1B Extension",
                "USA- L1 (A) Individual extension",
                "USA-L1 (B) Blanket extension",
                "USA- L1 (B) Individual extension",
                "Work permit",
                "Work visa/ permit"
            ];
            return visaList;
        }

        function getSourceLocationOptions() {
            var sourceLocation = ["BDC1 - STPI", "BDC10 - SEZ", "BDC2 - STPI", "BDC3A - STPI", "BDC3B - STPI", "BDC3C - STPI", "BDC4A - STPI", "BDC4B - STPI", "BDC5 - STPI", "BDC6A - SEZ", "BDC6B - SEZ", "BDC6C - SEZ", "BDC6D - SEZ", "BDC7A - SEZ", "BDC7B - SEZ", "BDC7C - SEZ", "BDC8A - SEZ", "BDC8B - SEZ", "BDC8C - SEZ", "BDC9 - STPI", "CDC 1A - STPI", "CDC 1B - STPI", "CDC2A - SEZ", "CDC2B - SEZ", "CDC2C - SEZ", "CDC2D - SEZ", "Client Onsite - Out of India", "Client Onsite - Within India"];
            return sourceLocation;
        }

        function getWorkLocationOptions() {
            var workLocation = ["Bangalore", "Chennai", "Gurgaon", "Hyderabad", "Kolkata", "Mumbai", "New Delhi", "Noida", "Not available in LN", "Pune"];
            return workLocation;
        }

        function getPrimarySkillOptions() {
            var primarySkill = [
                "C++ (UNIX)",
                "Java Enterprise Edition",
                "Mainframe",
                "Microsoft- .NET Architecture",
                "ASP.NET",
                "COBOL",
                "J2EE Architecture",
                "HTML 5",
                "AngularJS",
                "Java Platform Language and Class Libraries",
                "Java Standard Edition",
                "C (UNIX)",
            ];
            return primarySkill;
        }

        function getCareerlevelOptions() {
            var careerlevel = [

                "Accenture Leadership",
                "5",
                "6",
                "7",
                "9",
                "10",
                "11",
                "12",
                "13",
                "Intern ASE",

            ];
            return careerlevel;
        }

        function getFulfillmentEntityOptions() {
            var fulfillmentEntity = [

                "ASE Trainee",
                "ASW",
                "ASW CD",
                "ASW PE",
                "Avanade",
                "Avanade Pembroke",
                "IDC",
                "BTG-IDC",
                "Capacity Services",
                "DCN-ISU",
                "Expat",
                "Graduate Associate",
                "Graduate Associate ISIS",
                "IDC Pembroke",
                "IO-DC",
                "IO-DC - NON IDC",
                "IS- Implementation Services",
                "PG Associates",
                "Services in IDC",
                "SI Specialist",

            ];
            return fulfillmentEntity;
        }

        function getTermOptions() {
            var term = [
                "short",
                "long",
            ];
            return term;
        }

        function getFormatedDate(date) {
            var tempMoment=new moment(date).format('YYYY-MM-DD');
            return tempMoment;
        };

        function prepareFinalSubmitData(demandRequestData, skillsData) {

            // "resourceStartdate": demandRequestData.startdateModel.toString(),
            //                 "demandFullfilldate": demandRequestData.fulfillmentdateModel.toString(),
            //                 "demandEnddate": demandRequestData.enddateModel.toString(),
            var tempDemandRequest = {
                "portfolioId": demandRequestData.portfoliosModel.id,
                "demandSegment": demandRequestData.demandSegmentsModel,
                "sourceLocation": demandRequestData.sourcelocModel,
                "demandPriority": demandRequestData.prioritiesModel,
                "resourceStartdate": getFormatedDate(demandRequestData.startdateModel.toString()),
                "demandFullfilldate": getFormatedDate( demandRequestData.fulfillmentdateModel.toString()),
                "demandEnddate": getFormatedDate(demandRequestData.enddateModel.toString()),
                "clientInterview": (demandRequestData.clientInterviewModel == "true"),
                "onsiteComponent": (demandRequestData.onsitecomponentModel == "true"),
                "visaType": demandRequestData.visaModel,
                "visaReady": (demandRequestData.visareadyModel == "true"),
                "workLocation": demandRequestData.worklocModel,
                "createdBy": "p.senthilrajan",
                "createdOn": "2017-01-19",
                "updatedBy": "karthik.jeyapal",
                "updatedOn": "2017-1-31"

            };

            var skills = [];

            for (var i = 0; i < skillsData.length; i++) {
                var tempSkill = skillsData[i];
                var finalTempSkill = {
                    "primarySkill": tempSkill.primarySkillModel,
                    "lockDuration": tempSkill.termModel,
                    "isHardlockready": (tempSkill.hardlockModel == "true"),
                    "fulfillmentEntity": tempSkill.fulfillmentEntityModel,
                    "careerLevel": tempSkill.careerlevelModel,
                    "resourceCount": tempSkill.numberModel,
                    "status": true,
                    "wbseCode": tempSkill.wbseModel,
                    "active": true,
                    "term": tempSkill.termModel
                }

                skills.push(finalTempSkill);

            };

            var finalData = {
                "primaryDetails": tempDemandRequest,
                "skillsDetails": skills
            };
            console.log(finalData);

            return finalData;



        }
        
        function prepareResourceMapCreate(demandRequestData) {
            var finalData = {
            		"demandId": demandRequestData.primaryDetails.demandId,
        		    "createdBy": demandRequestData.primaryDetails.createdBy,
        		    "createdOn": new Date().getTime(),
        		    "updatedBy": commonService.getUserIdService(),
        		    "updatedOn": new Date().getTime(),
        		    "active": demandRequestData.skillsDetails[0].active
            };

            return finalData;



        }

    }
})();
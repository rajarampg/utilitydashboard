(function() {
    'use strict';
    angular
        .module('app.demandRequest')
        .controller('DemandRequestController', DemandRequestController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    DemandRequestController.$inject = ["$log", "demandRequestDataService", "demandRequestWebService", "$mdToast", "$stateParams", "$state"];

    function DemandRequestController($log, demandRequestDataService, demandRequestWebService, $mdToast, $stateParams, $state) {
        var vm = this;
        vm.id = ($stateParams.id !== undefined) ? $stateParams.id : "create";
        vm.submitted = false;	
        vm.submittedVisa = false;
        vm.submitAddSkill = false;
        vm.title = (vm.id === "create") ? "Demand Request Add" : "Demand Request Update";
        vm.selectmodel = demandRequestDataService.getProtfolioModel();
        vm.skillsModel = initSkillsModel();
        //options
        vm.portfolios = demandRequestDataService.getPortfolioOptions();
        vm.demandSegments = demandRequestDataService.getDemandSegmentsOptions();
        vm.priorities = demandRequestDataService.getPrioritiesOptions();
        vm.visaList = demandRequestDataService.getVisaListOptions();
        vm.sourceLocation = demandRequestDataService.getSourceLocationOptions();
        vm.workLocation = demandRequestDataService.getWorkLocationOptions();
        vm.primarySkill = demandRequestDataService.getPrimarySkillOptions();
        vm.careerlevel = demandRequestDataService.getCareerlevelOptions();
        vm.fulfillmentEntity = demandRequestDataService.getFulfillmentEntityOptions();
        vm.term = demandRequestDataService.getTermOptions();
        //vm.onChange = onChange;
        vm.array_table = [];

        vm.onClickAddRow = onClickAddRow;
        vm.onClickSubmitAllSkills = onClickSubmitAllSkills;


        function onClickAddRow() {
        	if(vm.demandAddSkillForm.$valid){
        		vm.submitAddSkill = false;
        		vm.showSimpleToast("Skill added to table");
                vm.array_table.push(angular.copy(vm.skillsModel));
                vm.demandAddSkillForm.$setPristine();
                vm.demandAddSkillForm.$setUntouched();
                vm.skillsModel = initSkillsModel();
        	}else{
        		vm.submitAddSkill = true;
        	}
            
        }

        function onClickSubmitAllSkills() {
        	if(vm.demandAddForm.$valid){
        		vm.submitted = false;
        		vm.submittedVisa = false;
        		//console.log("submit successful");
        		var createDemandData = demandRequestDataService.prepareFinalSubmitData(vm.selectmodel, vm.array_table);
                demandRequestWebService.postDemandRequestDataService({
                    data: createDemandData
                }).then(function(success) {
                    vm.showSimpleToast("Demand and Skills Request Submitted ");
                    $state.go("demandSearch");
                }, function(error) {
                    console.log(error);

                });
        	}else {
        		vm.submitted = true;
        	
        	}
            

            // demandRequestWebService.

        }

        function initSkillsModel() {
        	vm.submitAddSkill = false;
            return angular.copy(demandRequestDataService.getSkillsModel());
        }


        vm.showSimpleToast = function(message) {

            $mdToast.show(
                $mdToast.simple()
                .textContent(message)
                /*.position("
                    center ")*/
                .hideDelay(3000)
            );
        };




    }
})();
(function () {
    'use strict';

    angular
        .module('app.webservices')
        .factory('patternDetailsWebService', patternDetailsWebService);

    patternDetailsWebService.$inject = ["$q", "baseWebService"];

    /* $ngInject */
    function patternDetailsWebService($q, baseWebService) {

        var service = {
            postPatternWebService: postPatternWebService,
            getPatternWebService: getPatternWebService,
            getPatternDetailsWebService: getPatternDetailsWebService,
            getAllPatternDetailsWebService: getAllPatternDetailsWebService,
            postPatternWebServiceUpdate: postPatternWebServiceUpdate

        };
        return service;

        function postPatternWebService(options) {
            var patternDetailRequest = angular.extend({

                postPatternRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/patterndetails/addpattern",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return patternDetailRequest.postPatternRequest(options);

        }
        
        function getPatternWebService(options) {
            var patternDetailRequest = angular.extend({

                getPatternRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/patterndetails/viewpattern/"+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return patternDetailRequest.getPatternRequest(options);

        }
      
        function getPatternDetailsWebService(options) {
            var patternDetailRequest = angular.extend({

            	getPatternDetailsRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/patterndetails/viewpatternbyportfolioid/"+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return patternDetailRequest.getPatternDetailsRequest(options);

        }
        
        
        
        function getAllPatternDetailsWebService() {
            var patternDetailRequest = angular.extend({

            	getPatternDetailsRequest: function() {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/patterndetails/viewallpattern",
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return patternDetailRequest.getPatternDetailsRequest();

        }
        
        function postPatternWebServiceUpdate(options) {
            var patternDetailRequest = angular.extend({

                postPatternDetailsRequestUpdate: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/patterndetails/updatepattern",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return patternDetailRequest.postPatternDetailsRequestUpdate(options);

        }

    }


})();
(function () {
    'use strict';
    angular
        .module('app.certification')
        .run(appRun);

    /* @ngInject */
    function appRun(routerHelper) {
        routerHelper.configureStates(getStates());
    }

    function getStates() {
        return [{
            state: 'certificationAdd',
            config: {
                url: '/certificationAdd?id&view',
                views: {
                    main: {
                        templateUrl: './app/certification/certificationAdd.html',
                        controller: 'certificationAddController as vm'
                    }
                }
            }
        },{
            state: 'certificationSearch',
            config: {
                url: '/certificationSearch?getSearchData&view',
                views: {
                    main: {
                        templateUrl: './app/certification/certificationSearch.html',
                        controller: 'certificationSearchController as vm'
                    }
                }
            }
        },{
            state: 'certificationView',
            config: {
                url: '/certificationView?id',
                views: {
                    main: {
                        templateUrl: './app/certification/certificationView.html',
                        controller: 'certificationViewController as vm'
                    }
                }
            }
        }
        ]
    }
})();
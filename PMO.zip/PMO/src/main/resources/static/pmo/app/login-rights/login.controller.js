(function() {
    'use strict';
    angular
        .module('app.login')
        .controller('LoginController', LoginController);

    LoginController.$inject = ["$mdToast","loginWebService", "commonService", "$state", "$rootScope"];

    function LoginController($mdToast, loginWebService, commonService,$state, $rootScope) {
        var vm = this;
        vm.login = login;
        vm.submitted = false;
        vm.selectmodel = {
        		username : "",
        		password : ""
        };
        $rootScope.uiview = (!localStorage.getItem("loginValue")) ? false: true;
        if($rootScope.uiview === false){
        	$state.go("login");
        }
        commonService.setUserTypeService(localStorage.getItem("userType"));
        commonService.setUserIdService(localStorage.getItem("userId"));
        function login(){
        	if(vm.loginForm.$valid){
        		vm.submitted = false;
        		if(vm.selectmodel.username === ""){
            		console.log("please enter the username");
            	}else if(vm.selectmodel.password === ""){
            		console.log("please enter the password");
            	}else if(vm.selectmodel.username === "" && vm.selectmodel.password === ""){
            		console.log("please enter the username and password");
            	}else{
            		loginWebService.getloginAccess(vm.selectmodel.username).then(function(success) {
                        vm.showSimpleToast("Login Success");
                        localStorage.setItem("userType", success.userTypeId);
                        localStorage.setItem("userId", success.enterpriseId);
                        localStorage.setItem("empNo", success.employeeNumber);
                        
                        commonService.setUserTypeService(localStorage.getItem("userType"));
                        commonService.setUserIdService(localStorage.getItem("userId"));
                        commonService.setEmpNoService(localStorage.getItem("empNo"));
                        localStorage.setItem("loginValue", false)
                    	$rootScope.uiview = localStorage.getItem("loginValue");
                    	$state.go('home');
                    }, function(error) {
                    	
                    });
            	}
        	}else {
        		vm.submitted = true;
        	}
        	
        	
        }
        vm.showSimpleToast = function(message) {

            $mdToast.show(
                $mdToast.simple()
                .textContent(message)
                /*.position("
                    center ")*/
                .hideDelay(3000)
            );
        };
        
    }

})();
(function() {
    'use strict';

    angular
        .module('app.webservices')
        .factory('employeeReportWebService', employeeReportWebService);

    employeeReportWebService.$inject = ["$q", "baseWebService"];

    /* @ngInject */
    function employeeReportWebService($q, baseWebService) {

        var service = {
            getEmployeeReportWebService: getEmployeeReportWebService,
            getAllEmployeeReportWebService: getAllEmployeeReportWebService
        };

        return service;
        
        function getEmployeeReportWebService(options) {
            var employeeReportRequest = angular.extend({

                getEmployeeReportRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/employeecustomdetails/viewallemployeecustomdetailsbyempnumber/"+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);
            return employeeReportRequest.getEmployeeReportRequest(options);
        }

        function getAllEmployeeReportWebService(options) {
            var employeeReportRequest = angular.extend({

            	getAllEmployeeReportRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/employeecustomdetails/viewallemployeecustomdetails",
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;
                }
            }, baseWebService);
            return employeeReportRequest.getAllEmployeeReportRequest(options);
        }
    }
})();
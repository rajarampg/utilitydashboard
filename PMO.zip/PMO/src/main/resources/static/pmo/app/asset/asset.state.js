(function(){

        'use strict';
        angular.module('app.asset')
        .run(appRun);

        /* @ngInject */
        function appRun(routerHelper){
            routerHelper.configureStates(getStates());
        }

        function getStates(){

            return [
                {
                    state :'assetAdd',
                    config : {
                        url : '/assetAdd?id&view',
                        views : {
                            'main' : {
                                templateUrl : "./app/asset/assetAdd.html",
                                controller : "AssetAddController as vm"
                                }
                            }
                        }
                 },
                 {
                    state : 'assetSearch',
                    config : {
                        url : '/assetSearch?getSearchData&view',
                        views : {
                            'main' : {
                                templateUrl : "./app/asset/assetSearch.html",
                                controller : "AssetSearchController as vm"
                            }
                        }
                    }
                 },
                 {
                     state : 'assetView',
                     config : {
                         url : '/assetView',
                         views : {
                             'main' : {
                                 templateUrl : './app/asset/assetView.html',
                                 controller : 'AssetViewController as vm'
                             }
                         }
                     }
                 },
                 {
                     state : 'assetUpdate',
                     config : {
                         url : '/assetUpdate?id',
                         views : {
                             'main' : {
                                 templateUrl : './app/asset/assetUpdate.html',
                                 controller : 'AssetUpdateController as vm'
                             }
                         }
                     }
                 }
                ]
        }

})();
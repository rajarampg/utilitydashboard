(function(){

	angular.module("app.task",[]);

})();
(function() {
    'use strict';

    angular
        .module('app.asset')
        .factory('AssetDataService', AssetDataService);

    AssetDataService.$inject = [];

    /* @ngInject */
    function AssetDataService() {
        var service = {
    		getAssetOptions: getAssetOptions,
    		getAssetOwnTypeOptions: getAssetOwnTypeOptions,
            getAssetModel: getAssetModel,
            prepareFinalSubmitDataCreate: prepareFinalSubmitDataCreate,
            prepareFinalSubmitDataUpdate: prepareFinalSubmitDataUpdate,
            testData: testData
        };
        return service;

        function getAssetOptions() {
        	var assetType = [{
	                id: "RSA Token",
	                assetName: "RSA Token"
	            }, {
	                id: "Laptop",
	                assetName: "Laptop"
	            }, {
	                id: "Head Phone with Mic",
	                assetName: "Head Phone with Mic"
	            }, {
	                id: "Datacard",
	                assetName: "Datacard"
	            }, {
	                id: "Mobile",
	                assetName: "Mobile"
	            },{
	                id: "Others",
	                assetName: "Others"
	            }];
            return assetType;
        }
        
        function getAssetOwnTypeOptions() {
            var assetOwnType = [{
	                id: "Rental",
	                assetOwnName: "Rental"
	            }, {
	                id: "Own",
	                assetOwnName: "Own"
	            },{
	                id: "Others",
	                assetOwnName: "Others"
	            }];
            return assetOwnType;
        }

        function getAssetModel() {
            var selectModel = {
        		assetType: "",
                assetId: "",
                assetTag: "",
                assetOwnType: "",
                serviceProviderName: "",
                billDetails: "",
                comments: "",
                issuedDate: null,
                issuedBy: "",
                returnDate: null,
                returnBy: "",
                validity: null,
                assignedTo: ""
            };
            return selectModel;
        }

        function getFormatedDate(date) {
            var tempMoment=new Date(date).getTime();
            return tempMoment;
        };
        
        
        function prepareFinalSubmitDataCreate(assetRequestData) {

            var finalData = {
                    "assignedTo":assetRequestData.assignedTo,
                    "assertType":assetRequestData.assetType.assetName,
                    "assertId":assetRequestData.assetId,
                    "assetTag":assetRequestData.assetTag,
                    "assertOwnType":assetRequestData.assetOwnType.assetOwnName,
                    "comments":assetRequestData.comments,
                    "serviceProvider":assetRequestData.serviceProvider,
                    "billDetails":assetRequestData.billDetails,
                    "issuedDate":(assetRequestData.issuedDate !== null && assetRequestData.issuedDate !== "") ? getFormatedDate(assetRequestData.issuedDate.toString()) : null,
                    "issuedBy":assetRequestData.issuedBy,
                    "validity":(assetRequestData.validity !== null && assetRequestData.validity !== "") ? getFormatedDate(assetRequestData.validity.toString()) : null,
                    "returnDate":(assetRequestData.returnDate !== null && assetRequestData.returnDate !== "") ? getFormatedDate(assetRequestData.returnDate.toString()) : null,
                    "returnBy":assetRequestData.returnBy,
                    "active":"true"
                };
            console.log(finalData);
            return finalData;

        }
        
        function prepareFinalSubmitDataUpdate(assetRequestData) {
            var finalData = {
            	"id": assetRequestData.id,
                "assignedTo": assetRequestData.assignedTo,
                "assertType": assetRequestData.assertType,
                "assertId": assetRequestData.assertId,
        		"assetTag": assetRequestData.assetTag,
        		"assertOwnType": assetRequestData.assertOwnType,
                "comments": assetRequestData.comments,
        		"serviceProvider":assetRequestData.serviceProvider,
                "billDetails":assetRequestData.billDetails,
                "issuedDate":(assetRequestData.issuedDate !== "") ? getFormatedDate(assetRequestData.issuedDate.toString()) : null,
                "issuedBy":assetRequestData.issuedBy,
                "validity":(assetRequestData.validity !== "") ? getFormatedDate(assetRequestData.validity.toString()) : null,
                "returnDate":(assetRequestData.returnDate !== "") ? getFormatedDate(assetRequestData.returnDate.toString()) : null,
                "returnBy":assetRequestData.returnBy,
                "active": assetRequestData.active
            };
            console.log(finalData);
            return finalData;
        }

        function testData(){
        	var data = {
        			status: 200
        	}
        	return data;
        }
    }
})();
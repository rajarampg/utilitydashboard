(function() {

    angular
        .module('app.employeeDetails')
        .controller('employeeDetailsSearchController', employeeDetailsSearchController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    employeeDetailsSearchController.$inject = ["$timeout", "$scope", "$state", "$stateParams", "employeeDetailWebService", "employeeDetailsDataService"];

    function employeeDetailsSearchController($timeout, $scope, $state, $stateParams, employeeDetailWebService, employeeDetailsDataService) {
        var vm = this;
        vm.taskDetailsfilterFlag = false;
        vm.exportToExcel = exportToExcel;
        vm.exportFile = exportFile;
        vm.editEmployeeDetails = editEmployeeDetails;
        vm.viewEmployeeDetails = viewEmployeeDetails;
        vm.getfilterData = getfilterData;
        
        vm.getSearchData = $stateParams.getSearchData;
        vm.selectmodel = {
        		portfolioId : [],
        		employeeStatus: [],
        		primarySkill: []
        }
        vm.view = $stateParams.view;
        vm.employeeStatusOptions = employeeDetailsDataService.getEmployeeStatusOptions();
        vm.portfolios = employeeDetailsDataService.getPortfolioOptions();
        vm.primarySkill = employeeDetailsDataService.getPrimarySkillOptions();
        vm.limitOptions = [5, 10, 15, 25];
        
        vm.options = {
          rowSelection: true,
          multiSelect: true,
          autoSelect: true,
          decapitate: false,
          largeEditDialog: false,
          boundaryLinks: false,
          limitSelect: true,
          pageSelect: true
        };
        
        vm.query = {
          order: 'createdOn',
          limit: 5,
          page: 1
        };
    	employeeDetailWebService.getAllEmployeeDetailsWebService().then(function(response){
        	vm.employee_details = response;
        	angular.forEach(vm.employee_details, function(data){
				angular.forEach(vm.employeeStatusOptions, function(value){
	    			if(value.employeeStatusId === data.employeeStatus){
	    				data.employeStatusName =  value.employeeStatusName;
	    			}
	    		});
    		});
    		vm.taskDetailsFiltered = vm.employee_details;
        });
        
        vm.limitOptions = [5, 10, 15, 25];
        
        vm.options = {
          rowSelection: true,
          multiSelect: true,
          autoSelect: true,
          decapitate: false,
          largeEditDialog: false,
          boundaryLinks: false,
          limitSelect: true,
          pageSelect: true
        };
        
        vm.query = {
          order: '-rollonDate',
          limit: 5,
          page: 1
        };
        
        function exportToExcel(tableId){ // ex: '#my-table'
            var exportHref=ExporttoExcel.tableToExcel(tableId,'WireWorkbenchDataExport');
            $timeout(function(){location.href=exportHref;},100); // trigger download
        }
        
        function viewEmployeeDetails(item){
        	$state.go("employeeDetailsView",{
        		employeeNumber: item.employeeNumber,
        		id: item.id
        	})
        }
        
        function editEmployeeDetails(item){
        	$state.go("employeeDetailsUpdate", {
        		id: item.id
        	});
        }
        
        function getfilterData(portfolio, employeeStatus, primarySkill){
        	vm.employee_details = [];
        	vm.portfolioFiltered = [];	
        	vm.employeeStatusFilter = [];
        	vm.primarySkillFilter = [];
        	vm.temp_details = [];
        	if(portfolio.length > 0){
        		vm.portFolioFilter = [];
        		vm.portfolioFiltered = getPortfolioBasedOnSelected(portfolio);
        	}
        	if(employeeStatus.length > 0){
        		vm.employeeStatusFiltered = [];
        		vm.employeeStatusFilter = getEmployeeStatusBasedOnSelected(employeeStatus)
        	}
        	if(primarySkill.length > 0){
        		vm.primarySkillFiltered = [];
        		vm.primarySkillFilter = getPrimarySkillBasedOnSelected(primarySkill);
        	}
        	
        	if(vm.portfolioFiltered.length > 0 && vm.employeeStatusFilter.length > 0 && vm.primarySkillFilter.length > 0){
        		console.log("filter");
        		angular.forEach(vm.portfolioFiltered, function(portfolioValue){
        			angular.forEach(vm.employeeStatusFilter, function(employeeStatusValue){
        				if(employeeStatusValue.id === portfolioValue.id){
        					vm.temp_details.push(employeeStatusValue);
        				} 
        			});
        		});
        		angular.forEach(vm.temp_details, function(previousFiltered){
        			angular.forEach(vm.primarySkillFilter, function(primarySkillValue){
        				if(primarySkillValue.id === previousFiltered.id){
        					vm.employee_details.push(primarySkillValue);
        				} 
        			});
        		});
        	}else if(vm.portfolioFiltered.length > 0 && vm.employeeStatusFilter.length > 0){
        		
        		angular.forEach(vm.portfolioFiltered, function(portfolioValue){
        			angular.forEach(vm.employeeStatusFilter, function(employeeStatusValue){
        				if(employeeStatusValue.id === portfolioValue.id){
        					vm.employee_details.push(employeeStatusValue);
        				} 
        			});
        		});
        	}else if(vm.employeeStatusFilter.length > 0 && vm.primarySkillFilter.length > 0){
        		
        		angular.forEach(vm.employeeStatusFilter, function(employeeStatusValue){
        			angular.forEach(vm.primarySkillFilter, function(primaryValue){
        				if(primaryValue.id === employeeStatusValue.id){
        					vm.employee_details.push(primaryValue);
        				}     					
        				
        			});
        		});	
        	}else if(vm.portfolioFiltered.length > 0 && vm.primarySkillFilter.length > 0){
        		
        		angular.forEach(vm.portfolioFiltered, function(portfolioValue){
        			angular.forEach(vm.primarySkillFilter, function(primaryValue){
        				if(primaryValue.id === portfolioValue.id){
        					vm.employee_details.push(primaryValue);
        				}     					
        				
        			});
        		});
        	}else if(vm.portfolioFiltered.length > 0){
        		vm.employee_details = vm.portFolioFilter;
        	}else if(vm.employeeStatusFilter.length > 0){
        		vm.employee_details = vm.employeeStatusFilter;
        	}else if(vm.primarySkillFilter.length > 0){
        		vm.employee_details = vm.primarySkillFilter;
        	}
        	else{
        		vm.employee_details = vm.taskDetailsFiltered;
        	}
        }
        
        function getPortfolioBasedOnSelected(portfolio){
        	vm.portFolioFilter = [];
        	angular.forEach(portfolio, function(data){
        		angular.forEach(vm.taskDetailsFiltered, function(value){
        			if(data.id === value.portfolioId){
            			vm.portFolioFilter.push(value);
            		}
            	});
        	});
        	return vm.portFolioFilter;
        }
        
        function getEmployeeStatusBasedOnSelected(employeeStatus){
        	vm.employeeStatusFiltered = [];
        	angular.forEach(employeeStatus, function(data){
        		angular.forEach(vm.taskDetailsFiltered, function(value){
            		if(data.employeeStatusId === value.employeeStatus){
            			vm.employeeStatusFiltered.push(value);
            		}
            	});
        	});
        	return vm.employeeStatusFiltered;
        }
        
        function getPrimarySkillBasedOnSelected(primarySkill){
        	vm.primarySkillFiltered = [];
        	angular.forEach(primarySkill, function(data){
        		angular.forEach(vm.taskDetailsFiltered, function(value){
        			if(data === value.primarySkill){
            			vm.primarySkillFiltered.push(value);
            		}
            	});
        	});
        	return vm.primarySkillFiltered;
        }
        
        function exportFile(){
        	var arrData = typeof vm.task_details != 'object' ? JSON.parse(vm.task_details) : vm.task_details;
            var CSV = '';
            CSV += "download" + '\r\n\n';
            var row = "";
            for (var index in arrData[0]) {
                row += index + ',';
            }
            row = row.slice(0, -1);
            CSV += row + '\r\n';
            for (var i = 0; i < arrData.length; i++) {
                var row = "";
                for (var index in arrData[i]) {
                    row += '"' + arrData[i][index] + '",';
                }
                row.slice(0, row.length - 1);
                CSV += row + '\r\n';
            }
            if (CSV == '') {        
                alert("Invalid data");
                return;
            }
            var fileName = "download";
            var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
            var link = document.createElement("a");    
            link.href = uri;
            link.style = "visibility:hidden";
            link.download = fileName + ".csv";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
        
    }
})();
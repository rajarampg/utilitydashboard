(function() {
    'use strict';

    angular
        .module('app.webservices')
        .factory('roleDetailsWebService', roleDetailsWebService);

    roleDetailsWebService.$inject = ["$q", "baseWebService"];

    /* @ngInject */
    function roleDetailsWebService($q, baseWebService) {

        var service = {
            postRoleDetailsWebService: postRoleDetailsWebService,
            postRoleDetailsWebServiceUpdate: postRoleDetailsWebServiceUpdate,
            getRoleDetailsWebService: getRoleDetailsWebService,
            getAllRoleDetailsRequest: getAllRoleDetailsRequest
        };

        return service;
        
        function postRoleDetailsWebService(options) {
            var roleDetailsRequest = angular.extend({

                postRoleDetailsRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/roledetails/addrole/",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return roleDetailsRequest.postRoleDetailsRequest(options);
        }
        
        function getRoleDetailsWebService(options) {
            var roleDetailsRequest = angular.extend({

                getRoleDetailsRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/roledetails/viewrole/"+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);
            return roleDetailsRequest.getRoleDetailsRequest(options);
        }

        function getAllRoleDetailsRequest(options) {
            var roleDetailsRequest = angular.extend({

            	getAllRoleDetailsRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/roledetails/viewallrole",
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;
                }
            }, baseWebService);
            return roleDetailsRequest.getAllRoleDetailsRequest(options);
        }

        function postRoleDetailsWebServiceUpdate(options) {
            var roleDetailsRequest = angular.extend({

                postRoleDetailsWebServiceUpdate: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/roledetails/updaterole/",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;
                }
            }, baseWebService);
            return roleDetailsRequest.postRoleDetailsWebServiceUpdate(options);
        } 
    }
})();
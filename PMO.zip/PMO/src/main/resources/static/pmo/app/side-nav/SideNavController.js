(function() {
    'use strict';
    angular
        .module('app.sideNav')
        .controller('SideNavController', SideNavController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    SideNavController.$inject = ["$log", "$mdSidenav","$rootScope","$state", "commonService"];

    function SideNavController($log, $mdSidenav,$rootScope,$state, commonService) {
        var vm = this;
        
        vm.userType = commonService.getUserTypeService();
        
        vm.managerMenuList = [
	          {
	              title: "Demand",
	              subtitle : [{title:"Add Demand Request",path:"demandAdd"},{title:"Search Demand Request",path:"demandSearch"}],
	              path: ""
	          },{
	              title: "Employee Details",
	              subtitle : [{title:"Employee Rollon",path:"employeeDetailsAdd"},{title:"Employee RollOff",path:"employeeRollOff"},{title:"Employee Details Search",path:"employeeDetailsSearch"}, {title:"Employee Onboard",path:"employeeOnboard"}, {title:"Employee Offboard",path:"employeeOffboard"}],
	              path: ""
	          },{
                title: "Report",
                subtitle : [{title:"Employee Report",path:"employeeReportSearch"}],
                path: ""
            },{
	              title: "Configuration",
	              subtitle : [{
	          			title: "Pattern Details",
	      				path:"patternDetailsSearch"
	              	},
		            {
	              		title: "Role Details",
	              		path: "roleDetailsSearch"
		            },{
		            	title: "Portfolio Details",
		            	path: "portfolioDetailsSearch"
		    		},{
	                    title: "Login Rights",
	                    path: "loginRights"
	                }
	    		]
	          }
	      ];
        
        vm.sideNavData = [{
            title: "Task",
            subtitle : [{title:"Add Task",path:"taskAdd"},{title:"Search Task",path:"taskSearch"},{title:"View Task",path:"view"}],
            path: ""
        },{
            title: "Asset",
            subtitle : [{title:"Add Asset",path:"assetAdd"},{title:"Search Asset",path:"assetSearch"}],
            path: ""
        },{
            title: "Certification",
            subtitle : [{title:"Add Certification",path:"certificationAdd"},{title:"Search Certification Details",path:"certificationSearch"}],
            path: ""
        },{
            title: "Checklist",
            subtitle : [{title:"Add Roll On CheckList",path:"rollOnCheckListAdd"}],
            path: ""
        }];
        
        if(vm.userType === "3" || vm.userType === "4"){
        	vm.sideNavData = vm.sideNavData.concat(vm.managerMenuList);
        }
        
        vm.onChangePath=function(sideNavItemdata){
           /* angular.forEach(vm.sideNavData, function(value, key) {
                value.currentScreen = (value.title == sideNavItemdata.title);
                if(value.subtitle){
                    angular.forEach(value.subtitle, function(value1, key1) {
                      value1.currentScreen = (value1.title == sideNavItemdata.title);
                    });
                }
            });*/
            if(sideNavItemdata.path) {
                $state.go(sideNavItemdata.path);
                $rootScope.$emit("titleChange", {title: sideNavItemdata.title});
            }
        };

        vm.toggleList = function() {
            $mdSidenav('left').toggle();
        };


    }

})();
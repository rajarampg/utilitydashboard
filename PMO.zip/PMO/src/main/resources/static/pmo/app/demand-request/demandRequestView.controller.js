(function () {

    angular
        .module('app.demandRequest')
        .controller('DemandRequestViewController', DemandRequestViewController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    DemandRequestViewController.$inject = ["$log", "demandRequestDataService", "$state", "demandRequestWebService", "$stateParams", "$mdToast", "commonService"];

    function DemandRequestViewController($log, demandRequestDataService, $state, demandRequestWebService, $stateParams, $mdToast, commonService) {
        var vm = this;
        vm.selectmodel = undefined;
        vm.demandRequestViewData = undefined;
        vm.id = $stateParams.id;
        vm.rrdMapOnloadEmpty = true;
        vm.view = $stateParams.view;
        vm.title= (vm.view === "view") ? "Demand View Request": "Demand Update Request";
        vm.portfolios = demandRequestDataService.getPortfolioOptions();
        vm.onSelectPortfolio = onSelectPortfolio;
        vm.navigateView = navigateView;
        vm.editResourceMap = editResourceMap;
        vm.saveResourceMap = saveResourceMap;
                //vm.onSelectPortfolio
        function onSelectPortfolio(demand) {
        	if(vm.view === "view"){
        		vm.resourceMapDisable = true;
        	}
        	
        	vm.resourceMap = [];
           
            vm.demandRequestViewData = undefined;
            
            demandRequestWebService.getDemandRequestViewService(vm.id).then(function(response){
            	vm.demandRequestViewData = response;
            	vm.demandRequestViewData.primaryDetails.resourceStartDate = moment(new Date(response.primaryDetails.resourceStartDate)).format("MM/DD/YYYY");
            	vm.demandRequestViewData.primaryDetails.demandFullfillDate = moment(new Date(response.primaryDetails.demandFullfillDate)).format("MM/DD/YYYY");
            	vm.demandRequestViewData.primaryDetails.demandEndDate = moment(new Date(response.primaryDetails.demandEndDate)).format("MM/DD/YYYY");
            	vm.demandRequestViewData.primaryDetails.createdOn = moment(new Date(response.primaryDetails.createdOn)).format("MM/DD/YYYY");
            	angular.forEach(vm.portfolios, function(value){
            		if(vm.demandRequestViewData.primaryDetails.portfolioId === value.id){
            			vm.demandRequestViewData.primaryDetails.portfolioName = value.portfolioName;
            		}
            	});
            	if(vm.demandRequestViewData.skillsDetails[0].resourceCount > 0){
            		vm.temp = [];
            		var j = 0;
            		for(var i = 0; i < vm.demandRequestViewData.skillsDetails[0].resourceCount; i++){
            		
            			vm.temp.push(++j);
            		}
            	}
            	
            	demandRequestWebService.getRRDMappingDetailService(vm.demandRequestViewData.primaryDetails.demandId).then(function(response){
            		//console.log("response", response);
            		if(response.length > 0){
            			vm.rrdMapData = response;
            			vm.rrdMapOnloadEmpty = false;
                		angular.forEach(response, function(value, key){
                			vm.resourceMap[key] = value.rrdId;
                		});
            		}
            	});
            });
        }
        
        function saveResourceMap(){
        	console.log("resourcemap model",vm.resourceMap);
        	
        	
        	if(vm.rrdMapOnloadEmpty){
        		var generateParams = [];
            	angular.forEach(vm.resourceMap, function(value, key){
            		if(value !== ""){
            			var resourceMapData = demandRequestDataService.prepareResourceMapCreate(vm.demandRequestViewData);
                		resourceMapData.rrdId = value;
                		generateParams.push(resourceMapData);
            		}
            		       		
            	});
        		demandRequestWebService.postResourceMapAddService({
            		data: generateParams
            	}).then(function(success) {
            		if(vm.view === "view"){
            			vm.showSimpleToast("RRD Mapping Created Successfully");
            			vm.resourceMapDisable = true;
            			$state.go("demandSearch");
            		}else if(vm.view !== "view"){
            			vm.showSimpleToast("Demand and Skills Request Created Successfully");
            			$state.go("demandSearch");
            		}
            		vm.rrdMapOnloadEmpty = false;
            	}, function(error) {
            		vm.resourceMapDisable = true;
            	});
        	}else{
        		var generateParams = [];
            	angular.forEach(vm.resourceMap, function(value, key){
            		
            		if(vm.rrdMapData[key] !== undefined && vm.rrdMapData[key] !== null){
            			if(vm.rrdMapData[key].rrdId !== value){
            				vm.rrdMapData[key].rrdId = value;
            				vm.rrdMapData[key].updatedBy = commonService.getUserIdService();
            				vm.rrdMapData[key].updatedOn = new Date().getTime();
                			generateParams.push(vm.rrdMapData[key]);
            			}
            		}else{
            			var resourceMapData = demandRequestDataService.prepareResourceMapCreate(vm.demandRequestViewData);
                		resourceMapData.rrdId = value;
                		generateParams.push(resourceMapData);
            		}
            		
            		
            		       		
            	});
            	demandRequestWebService.postResourceMapUpdateService({
            		data: generateParams
            	}).then(function(success) {
            		if(vm.view === "view"){
            			vm.showSimpleToast("RRD Mapping Updated Successfully");
            			vm.resourceMapDisable = true;
            			$state.go("demandSearch");
            		}else if(vm.view !== "view"){
            			vm.showSimpleToast("Demand and Skills Request Updated Successfully");
            			$state.go("demandSearch");
            		}
            		vm.rrdMapOnloadEmpty = false;
            	}, function(error) {
            		vm.resourceMapDisable = true;
            	});
        		console.log("update call");
        	}
        	
        }
        
        function editResourceMap(){
        	vm.resourceMapDisable = false;
        }
        
        
        function navigateView(id){
        	console.log("id", id);
        	demandRequestViewWebService.getAllDemandRequestData(id).then(function(response){
        		$state.go('demand');
            	console.log("response", response);
            	
        	});
        }
        
        vm.showSimpleToast = function(message) {

            $mdToast.show(
                $mdToast.simple()
                .textContent(message)
                /*.position("
                    center ")*/
                .hideDelay(3000)
            );
        };
    }
})();
(function() {

    angular
        .module('app.portfolioDetails')
        .controller('portfolioDetailsViewController', portfolioDetailsViewController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    portfolioDetailsViewController.$inject = ["portfolioDetailsWebService", "$rootScope", "$scope", "$stateParams", "$state"];

    function portfolioDetailsViewController(portfolioDetailsWebService, $rootScope, $scope, $stateParams, $state) {
        var vm = this;
        vm.editPortfolioDetails = editPortfolioDetails;
        vm.id = $stateParams.id;
        
        
        portfolioDetailsWebService.getPortfolioDetailsWebService(vm.id).then(function(response){
        	vm.selectmodel = response;
            vm.selectmodel.createdOn = moment(new Date(response.createdOn)).format("MM/DD/YYYY");
            vm.selectmodel.modifiedOn = moment(new Date(response.modifiedOn)).format("MM/DD/YYYY");

            /*angular.forEach(vm.portfolios,function(value){
                if(vm.selectmodel.portfolioName === value.portfolioName){
                        vm.selectmodel.portfolioName = value.portfolioName;
                }
            });*/
        });
        
        function editPortfolioDetails(){
        	$state.go('portfolioDetailsAdd', {
        		id: vm.id,
        		view: "update"
        	});
           // $rootScope.$emit("titleChange",{title: "Portfolio Update"});
        };
        
        
    }
})();
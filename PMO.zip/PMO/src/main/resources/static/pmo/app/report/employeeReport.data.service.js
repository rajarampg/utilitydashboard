(function() {
    'use strict';

    angular
        .module('app.employeeReport')
        .factory('employeeReportDataService', employeeReportDataService);

    employeeReportDataService.$inject = ["commonService"];

    /* @ngInject */
    function employeeReportDataService(commonService) {

		var service = {
            testData: testData
        };
        return service;

        function getFormatedDate(date) {
            var tempMoment = new moment(date).format('YYYY-MM-DD');
            return tempMoment;
        };

        
        function testData() {
            var data = {
                status: 200
            }
            return data;
        }
       
    }
})();
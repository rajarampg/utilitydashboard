(function () {

    angular
        .module('app.demandRequest')
        .controller('DemandRequestSearchController', DemandRequestSearchController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    DemandRequestSearchController.$inject = ["$log", "demandRequestDataService", "demandRequestWebService", "$state"];

    function DemandRequestSearchController($log, demandRequestDataService, demandRequestWebService, $state) {
        var vm = this;
        vm.selectmodel = undefined;
        vm.changeStateView = changeStateView;
        vm.changeStateEdit = changeStateEdit;
        vm.demandRequestViewData = [];
        vm.portfolios = demandRequestDataService.getPortfolioOptions();
        vm.onSelectPortfolio = onSelectPortfolio;
    	vm.limitOptions = [5, 10, 15, 25];
        
    	vm.options = {
          rowSelection: true,
          multiSelect: true,
          autoSelect: true,
          decapitate: false,
          largeEditDialog: false,
          boundaryLinks: false,
          limitSelect: true,
          pageSelect: true
        };
        
        vm.query = {
          order: '-createdBy',
          limit: 5,
          page: 1
        };
        demandRequestWebService.getDemandRequestViewAllService().then(function(response){
        	vm.demandRequestViewData = response; 
        }, function(error){
        	console.log(error);
        });


        //vm.onSelectPortfolio
        function onSelectPortfolio(demand) {
            vm.demandRequestViewData = [];

            demandRequestWebService.getAllDemandRequestData({
                id: demand.id
            }).then(function (response) {
                    vm.demandRequestViewData = response;  
            }, function (error) {
                console.log(error);

            });


        }

        vm.limitOptions = [5, 10, 15, 25];
        
        vm.options = {
          rowSelection: true,
          multiSelect: true,
          autoSelect: true,
          decapitate: false,
          largeEditDialog: false,
          boundaryLinks: false,
          limitSelect: true,
          pageSelect: true
        };
        
        vm.query = {
          order: 'name',
          limit: 5,
          page: 1
        };

        function changeStateView(id){
        	$state.go("demandView", {
        		id: id,
        		view: "view"
        	})
        }
        
        function changeStateEdit(id){
        	$state.go("demandView", {
        		id: id,
        		view: "update"
        	})
        }
        
        

    }
})();
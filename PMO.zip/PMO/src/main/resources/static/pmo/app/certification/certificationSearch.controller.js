(function () {

	angular
		.module('app.certification')
		.controller('certificationSearchController', certificationSearchController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
	certificationSearchController.$inject = ["certificationDataService", "$timeout", "$scope", "$stateParams", "certificationWebService", "certificationDataService"];

	function certificationSearchController(certificationDataService, $timeout, $scope, $stateParams, certificationWebService, certificationDataService) {
		var vm = this;
		vm.certificationFilter = certificationFilter;
		vm.getSearchData = $stateParams.getSearchData;
		vm.view = $stateParams.view;
		vm.certification_details = [];
		vm.selectmodel = {};
		vm.selectmodel = {
			certificationName: "",
			assignedTo: ""
		};

		vm.limitOptions = [5, 10, 15, 25];

		//vm.exportToExcel = exportToExcel;
		vm.exportFile = exportFile;

		if (vm.view !== undefined && vm.view === "search") {
			certificationWebService.getCertificationDetailsWebService(vm.getSearchData).then(function (response) {
				vm.certification_details = response;
				vm.certificationDetailsFiltered = vm.certification_details;
			});
		} else {
			certificationWebService.getAllCertificationDetailsWebService().then(function (response) {
				vm.certification_details = response;
				vm.certificationDetailsFiltered = vm.certification_details;
			});
		}

		vm.fieldName = {
			"order": "-createdOn",
			"tableDetails": [
				{
					"type": "link",
					"label": "Certification Name",
					"name": "certificationName",
					"orderBy": false,
					"url": "certificationView",
					"displayField": "certificationName"
				}, {
					"type": "label",
					"label": "Certification Type",
					"name": "certificationType",
					"orderBy": true,
					"displayField": "certificationType"
				}, {
					"type": "label",
					"label": "Stream",
					"name": "stream",
					"orderBy": false,
					"displayField": "stream"
				}, {
					"type": "label",
					"label": "Status",
					"name": "status",
					"orderBy": true,
					"displayField": "status"
				}, {
					"type": "label",
					"label": "Assigned To",
					"name": "assignedTo",
					"orderBy": true,
					"displayField": "assignedTo"
				}, {
					"type": "datelabel",
					"label": "Certification Date",
					"name": "certificationDate",
					"orderBy": true,
					"displayField": "certificationDate"
				}, {
					"type": "edit",
					"label": "",
					"name": "",
					"orderBy": true,
					"url": "certificationAdd",
					"urlParams": {
						view: "update"
					},
					"displayField": "Edit"
				}]
		};


		function certificationFilter(certificationNameModel, assignedToModel) {
			vm.certification_details = [];
			if (certificationNameModel !== "" && assignedToModel !== "") {
				angular.forEach(vm.certificationDetailsFiltered, function (value) {
					if (value.certificationName === certificationNameModel && value.assignedTo === assignedToModel) {
						vm.certification_details.push(value);
					}
				});
			} else if (assignedToModel !== "") {
				angular.forEach(vm.certificationDetailsFiltered, function (value) {
					if (value.assignedTo === assignedToModel) {
						vm.certification_details.push(value);
					}
				});
			} else if (certificationNameModel !== "") {
				angular.forEach(vm.certificationDetailsFiltered, function (value) {
					if (value.certificationName === certificationNameModel) {
						vm.certification_details.push(value);
					}
				});
			} else {
				vm.certification_details = vm.certificationDetailsFiltered;
			}
		}


		function exportFile() {
			console.log("vm.certification_details", vm.certification_details);
			angular.forEach(vm.certification_details, function (value) {
				value.certificationDate = moment(new Date(value.certificationDate)).format("MM/DD/YYYY");
				value.approvedOn = moment(new Date(value.approvedOn)).format("MM/DD/YYYY");
				value.createdOn = moment(new Date(value.createdOn)).format("MM/DD/YYYY");
				value.modifiedOn = moment(new Date(value.modifiedOn)).format("MM/DD/YYYY");
			})

			var arrData = typeof vm.certification_details != 'object' ? JSON.parse(vm.certification_details) : vm.certification_details;
			var CSV = '';
			CSV += "download" + '\r\n\n';
			var row = "";
			for (var index in arrData[0]) {
				row += index + ',';
			}
			row = row.slice(0, -1);
			CSV += row + '\r\n';
			for (var i = 0; i < arrData.length; i++) {
				var row = "";
				for (var index in arrData[i]) {
					row += '"' + arrData[i][index] + '",';
				}
				row.slice(0, row.length - 1);
				CSV += row + '\r\n';
			}
			if (CSV == '') {
				alert("Invalid data");
				return;
			}
			var fileName = "download";
			var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
			var link = document.createElement("a");
			link.href = uri;
			link.style = "visibility:hidden";
			link.download = fileName + ".csv";
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
		}

	}
})();
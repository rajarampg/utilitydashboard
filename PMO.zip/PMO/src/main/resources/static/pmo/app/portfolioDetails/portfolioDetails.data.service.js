(function () {
    'use strict';

    angular
        .module('app.portfolioDetails')
        .factory('portfolioDetailsDataService', portfolioDetailsDataService);

    portfolioDetailsDataService.$inject = ["commonService"];

    /* @ngInject */
    function portfolioDetailsDataService(commonService) {
        var service = {
            getPortfolioModel: getPortfolioModel,
            prepareFinalSubmitDataCreate: prepareFinalSubmitDataCreate,
            prepareFinalSubmitDataUpdate: prepareFinalSubmitDataUpdate,
            testData: testData
        };
        return service;

        function getPortfolioModel() {
            var selectmodel = {
                portfolioName: "",
                portfolioDescription: "",
                createdOn: null,
                createdBy: "",
                modifiedOn: null,
                modifiedBy: ""
            };
            return selectmodel;
        }

        function getFormatedDate(date) {
            var tempMoment = new moment(date).format('YYYY-MM-DD');
            return tempMoment;
        };

        function prepareFinalSubmitDataCreate(portfolioDetailsRequest) {

            var finalData = {
                "portfolioName": portfolioDetailsRequest.portfolioName,
                "portfolioDescription": portfolioDetailsRequest.portfolioDescription,
                "createdBy": commonService.getUserIdService(),
                "createdOn": new Date().getTime(),
                "modifiedBy": commonService.getUserIdService(),
                "modifiedOn": new Date().getTime(),
                "active": "true"

            };
            console.log(finalData);
            return finalData;
        }

        function prepareFinalSubmitDataUpdate(portfolioDetailsRequest) {
            var finalData = {
                "id": portfolioDetailsRequest.id,
                "portfolioName": portfolioDetailsRequest.portfolioName,
                "portfolioDescription": portfolioDetailsRequest.portfolioDescription,
                "createdBy": portfolioDetailsRequest.createdBy,
                "createdOn": portfolioDetailsRequest.createdOn,
                "modifiedBy": commonService.getUserIdService(),
                "modifiedOn": new Date().getTime(),
                "active": portfolioDetailsRequest.active
            };
            console.log(finalData);
            return finalData;
        }

        function testData() {
            var data = {
                status: 200
            }
            return data;
        }
    }
})();
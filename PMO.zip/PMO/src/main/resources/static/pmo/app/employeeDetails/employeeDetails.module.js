(function(){

	angular.module("app.employeeDetails",[]);

})();
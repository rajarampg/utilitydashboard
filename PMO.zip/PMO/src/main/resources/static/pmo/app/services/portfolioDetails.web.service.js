(function() {
    'use strict';

    angular
        .module('app.webservices')
        .factory('portfolioDetailsWebService', portfolioDetailsWebService);

    portfolioDetailsWebService.$inject = ["$q", "baseWebService"];

    /* @ngInject */
    function portfolioDetailsWebService($q, baseWebService) {

        var service = {
            postPortfolioDetailsWebService: postPortfolioDetailsWebService,
            postPortfolioDetailsWebServiceUpdate: postPortfolioDetailsWebServiceUpdate,
            getPortfolioDetailsWebService: getPortfolioDetailsWebService,
            getAllPortfolioDetailsRequest: getAllPortfolioDetailsRequest
        };

        return service;
        
        function postPortfolioDetailsWebService(options) {
            var portfolioDetailsRequest = angular.extend({

                postPortfolioDetailsRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/portfoliodetails/addportfolio/",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return portfolioDetailsRequest.postPortfolioDetailsRequest(options);
        }
        
        function getPortfolioDetailsWebService(options) {
            var portfolioDetailsRequest = angular.extend({

                getPortfolioDetailsRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/portfoliodetails/viewportfolio/"+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);
            return portfolioDetailsRequest.getPortfolioDetailsRequest(options);
        }

        function getAllPortfolioDetailsRequest(options) {
            var portfolioDetailsRequest = angular.extend({

            	getAllPortfolioDetailsRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/portfoliodetails/viewallportfolio",
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;
                }
            }, baseWebService);
            return portfolioDetailsRequest.getAllPortfolioDetailsRequest(options);
        }

        function postPortfolioDetailsWebServiceUpdate(options) {
            var portfolioDetailsRequest = angular.extend({

                postPortfolioDetailsWebServiceUpdate: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/portfoliodetails/updateportfolio/",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;
                }
            }, baseWebService);
            return portfolioDetailsRequest.postPortfolioDetailsWebServiceUpdate(options);
        } 
    }
})();
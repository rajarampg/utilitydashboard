(function () {

	angular
		.module('app.portfolioDetails')
		.controller('portfolioDetailsSearchController', portfolioDetailsSearchController);

	/**
		 * Main Controller for the Angular Material Starter App
		 * @param $scope
		 * @param $mdSidenav
		 * @param avatarsService
		 * @constructor
		 */
	portfolioDetailsSearchController.$inject = ["portfolioDetailsDataService", "$timeout", "$scope", "$stateParams", "portfolioDetailsWebService", "$state"];

	function portfolioDetailsSearchController(portfolioDetailsDataService, $timeout, $scope, $stateParams, portfolioDetailsWebService, $state) {
		var vm = this;

		vm.portfolioDetailsfilterFlag = false;
		vm.exportToExcel = exportToExcel;
		vm.exportFile = exportFile;
		vm.navigateToAdd = navigateToAdd;
        vm.selectmodel = portfolioDetailsDataService.getPortfolioModel();
		vm.getSearchData = $stateParams.getSearchData;
		vm.view = $stateParams.view;
		vm.limitOptions = [5, 10, 15, 25];

		/*if (vm.view !== undefined && vm.view === "search") {
			portfolioDetailsWebService.getPortfolioDetailsWebService(vm.getSearchData).then(function (response) {
				vm.portfolio_details = response;
				vm.portfolioDetailsFiltered = vm.portfolio_details;
			});
		} else {*/
			portfolioDetailsWebService.getAllPortfolioDetailsRequest().then(function (response) {
				vm.portfolio_details = response;
				/*angular.forEach(response, function(data){
                angular.forEach(vm.selectmodel, function (value) {
                    if (value.id === data.id) {
                        data.portfolioName = value.portfolioName;
                    }
                });
            });*/
			vm.portfolioDetailsFiltered = vm.portfolio_details;

			});


		vm.fieldName = {
			"order": "-createdOn",
			"tableDetails": [
				{
					"type": "link",
					"label": "Portfolio Name",
					"name": "portfolioName",
					"orderBy": true,
					"url": "portfolioDetailsView",
					"displayField": "portfolioName"
				}, {
					"type": "label",
					"label": "Portfolio Description",
					"name": "portfolioDescription",
					"orderBy": true,
					"displayField": "portfolioDescription"
				}, {
					"type": "datelabel",
					"label": "Created On",
					"name": "createdOn",
					"orderBy": true,
					"displayField": "createdOn"
				}, {
					"type": "label",
					"label": "Created By",
					"name": "createdBy",
					"orderBy": true,
					"displayField": "createdBy"
				}, {
					"type": "edit",
					"label": "",
					"name": "",
					"orderBy": true,
					"url": "portfolioDetailsAdd",
					"urlParams": {
						view: "update"
					},
					"displayField": "Edit"
				}]
		};

		function exportToExcel(tableId) { // ex: '#my-table'
			var exportHref = ExporttoExcel.tableToExcel(tableId, 'WireWorkbenchDataExport');
			$timeout(function () { location.href = exportHref; }, 100); // trigger download
		}
		
		function navigateToAdd(){
			$state.go("portfolioDetailsAdd");
		}

		function exportFile() {
			console.log("vm.portfolio_details", vm.portfolio_details);
			angular.forEach(vm.portfolio_details, function (value) {
				value.createdOn = moment(new Date(value.createdOn)).format("MM/DD/YYYY");
				value.modifiedOn = moment(new Date(value.modifiedOn)).format("MM/DD/YYYY");
			});
			var arrData = typeof vm.portfolio_details != 'object' ? JSON.parse(vm.portfolio_details) : vm.portfolio_details;
			var CSV = '';
			CSV += "download" + '\r\n\n';
			var row = "";
			for (var index in arrData[0]) {
				row += index + ',';
			}
			row = row.slice(0, -1);
			CSV += row + '\r\n';
			for (var i = 0; i < arrData.length; i++) {
				var row = "";
				for (var index in arrData[i]) {
					row += '"' + arrData[i][index] + '",';
				}
				row.slice(0, row.length - 1);
				CSV += row + '\r\n';
			}
			if (CSV == '') {
				alert("Invalid data");
				return;
			}
			var fileName = "download";
			var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
			var link = document.createElement("a");
			link.href = uri;
			link.style = "visibility:hidden";
			link.download = fileName + ".csv";
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
		}

	}

})();
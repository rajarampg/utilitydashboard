(function() {
   'use strict';
    angular
        .module('app.rollOn')
        .controller('RollOnController', RollOnController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    RollOnController.$inject = ["$log", "rollOnDataService", "rollOnWebService", "$mdToast"];

    function RollOnController($log, rollOnDataService, rollOnWebService, $mdToast) {
        var vm = this;

        vm.rollOnModel = rollOnDataService.getRollOnModel();
        vm.portfolios = rollOnDataService.getPortfolioOptions();
        vm.lockType = rollOnDataService.getLockTypeOptions();
        vm.gender = rollOnDataService.getGenderOptions();
        vm.careerLevel = rollOnDataService.getCareerlevelOptions();
        vm.stayDuration = rollOnDataService.getStayDurationOptions();
        vm.visaType = rollOnDataService.getVisaTypeOptions();
        vm.proficiencyLevel = rollOnDataService.getProficiencyLevelOptions();
        vm.supervisorName = rollOnDataService.getSupervisorOptions();
        vm.floor = rollOnDataService.getFloorOptions(); 

        vm.onClickSubmitDetails = onClickSubmitDetails;

        function onClickSubmitDetails() {
            var createRollOnData=rollOnDataService.prepareFinalSubmitData(vm.rollOnModel);
            rollOnWebService.postRollOnDataService({data:createRollOnData}).then(function(success) {
                vm.showSimpleToast("Demand and Skills Request Submitted ");

            }, function(error) {
                console.log(error);

            });

            vm.showSimpleToast = function(message) {

            $mdToast.show(
                $mdToast.simple()
                .textContent(message)
                /*.position("
                    center ")*/
                .hideDelay(3000)
            );
        };

        }
    }
})();
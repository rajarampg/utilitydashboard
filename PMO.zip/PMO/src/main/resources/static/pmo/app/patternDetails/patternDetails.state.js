(function () {
    'use strict';
    angular
        .module('app.patternDetails')
        .run(appRun);

    /* @ngInject */

    function appRun(routerHelper) {
        routerHelper.configureStates(getStates());
    }

    function getStates() {

        return [
            {
                state: 'patternDetailsAdd',
                config: {
                    url: '/patternDetailsAdd?id&view',
                    views: {
                        'main': {
                            templateUrl: "./app/patternDetails/patternDetailsAdd.html",
                            controller: "patternDetailsAddController as vm"
                        }
                    }
                }
            }, {
                state: 'patternDetailsSearch',
                config: {
                    url: '/patternDetailsSearch?getSearchData&view',
                    views: {
                        'main': {
                            templateUrl: "./app/patternDetails/patternDetailsSearch.html",
                            controller: "patternDetailsSearchController as vm"
                        }
                    }
                }
            }, {
                state: 'patternDetailsView',
                config: {
                    url: '/patternDetailsView?id',
                    views: {
                        'main': {
                            templateUrl: "./app/patternDetails/patternDetailsView.html",
                            controller: "patternDetailsViewController as vm"
                        }
                    }
                }
            }
        ];

    }

})();
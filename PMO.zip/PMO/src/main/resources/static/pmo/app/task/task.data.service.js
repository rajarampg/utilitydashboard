(function() {
    'use strict';

    angular
        .module('app.task')
        .factory('taskDataService', taskDataService);

    taskDataService.$inject = [];

    /* @ngInject */
    function taskDataService() {
        var service = {
    		getRequestOptions: getRequestOptions,
    		getSubRequestOptions: getSubRequestOptions,
            getTaskModel: getTaskModel,
            prepareFinalSubmitDataCreate: prepareFinalSubmitDataCreate,
            getStatusOptions: getStatusOptions,
            prepareFinalSubmitDataUpdate: prepareFinalSubmitDataUpdate,
            prepareEmailCreate: prepareEmailCreate,
            prepareEmailUpdate: prepareEmailUpdate,
            testData: testData
        };
        return service;



        function getRequestOptions() {
        	var requestType = [{
	                id: "resource",
	                requestName: "Resource"
	            }, {
	                id: "asset",
	                requestName: "Asset"
	            }, {
	                id: "cabRoaster",
	                requestName: "Cab roaster"
	            }, {
	                id: "facilities",
	                requestName: "Facilities"
	            },{
	                id: "others",
	                requestName: "Others"
	            }
            ];
            return requestType;

        }
        
        function getSubRequestOptions() {
            var subRequestType = [{
				resource:["New Demand", "On boarding", "Off boarding", "Roll off", "Others"],
				asset:["RSA Token", "Laptop", "Head Phone with Mic", "Mobile", "Datacard", "Others"],
				cabRoaster: ["Pickup", "Drop", "Pickup & Drop", "Others"],
				facilities: ["Conference Room", "Projector", "Others"],
				others: [
					"Others"
				]}
            ];
            return subRequestType;
        }
        
        function getStatusOptions() {
        	var statusType = [{
	                id: "new",
	                statusName: "New"
	            }, {
	                id: "inProgress",
	                statusName: "In Progress"
	            }, {
	                id: "completed",
	                statusName: "Completed"
	            }, {
	                id: "waitingforApproval",
	                statusName: "Waiting for Approval"
	            },{
	                id: "approved",
	                statusName: "Approved"
	            },{
	                id: "rejected",
	                statusName: "Rejected"
	            },{
	                id: "deferred",
	                statusName: "Deferred"
	            },{
	                id: "onhold",
	                statusName: "On hold"
	            },{
	                id: "revoke",
	                statusName: "Revoke"
	            }
            ];
            return statusType;

        }
        
        function getTaskModel() {
            var selectModel = {
        		taskName: "",
                taskDescription: "",
                requestType: "",
                subrequestType: "",
                approvedBy: "",
                approvedOn: "",
                approverComments: "",
                assignedTo: "",
                assignedOn: "",
                status: "",
                comments: "",
                createdBy: "",
                createdOn: ""
            };
            return selectModel;
        }
        
        function getFormatedDate(date) {
            var tempMoment=new Date(date).getTime();
            return tempMoment;
        };
        
        
        function prepareFinalSubmitDataCreate(taskRequestData) {
            var finalData = {
        		"taskName": taskRequestData.taskName,
        		"taskDescription": taskRequestData.taskDescription,
        		"requestType": taskRequestData.requestType.requestName,
        		"subrequestType": taskRequestData.subrequestType,
        		"approvedBy": taskRequestData.approvedBy,
        		"approvedOn": (taskRequestData.approvedOn !== undefined && taskRequestData.approvedOn !== null && taskRequestData.approvedOn !== "") ? getFormatedDate(taskRequestData.approvedOn) : null,
        		"approverComments": taskRequestData.approverComments,
        		"assignedTo": taskRequestData.assignedTo,
        		"assignedOn": (taskRequestData.assignedOn !== undefined && taskRequestData.assignedOn !== null && taskRequestData.assignedOn !== "") ? getFormatedDate(taskRequestData.assignedOn) : null,
        		"status": "New",
        		"comments": taskRequestData.comments,
        		"createdBy": "p.senthilrajan",
        		"createdOn": (taskRequestData.createdOn !== undefined && taskRequestData.createdOn !== null && taskRequestData.createdOn !== "") ? getFormatedDate(taskRequestData.createdOn) : (taskRequestData.createdOn !== "") ? taskRequestData.createdOn : new Date().getTime(),
        		"active": true
            };
            console.log(finalData);

            return finalData;
        }
        
        function prepareFinalSubmitDataUpdate(taskRequestData) {
            var finalData = {
            	"id": taskRequestData.id,
        		"taskName": taskRequestData.taskName,
        		"taskDescription": taskRequestData.taskDescription,
        		"requestType": taskRequestData.requestType.requestName,
        		"subrequestType": taskRequestData.subrequestType,
        		"approvedBy": taskRequestData.approvedBy,
        		"approvedOn": (taskRequestData.approvedOn !== undefined && taskRequestData.approvedOn !== null && taskRequestData.approvedOn !== "") ? getFormatedDate(taskRequestData.approvedOn) : null,
        		"approverComments": taskRequestData.approverComments,
        		"assignedTo": (taskRequestData.assignedTo.enterpriseId !== undefined) ? taskRequestData.assignedTo.enterpriseId : taskRequestData.assignedTo,
        		"assignedOn": ((taskRequestData.assignedOn !== undefined && taskRequestData.assignedOn !== null && taskRequestData.assignedOn !== "") || (taskRequestData.assignedTo.enterpriseId !== undefined)) ? new Date().getTime() : null,
        		"status": taskRequestData.status.statusName,
        		"comments": taskRequestData.comments,
        		"createdBy": taskRequestData.createdBy,
        		"createdOn": (taskRequestData.createdOn !== undefined && taskRequestData.createdOn !== null && taskRequestData.createdOn !== "") ? getFormatedDate(taskRequestData.createdOn) : (taskRequestData.createdOn !== "") ? taskRequestData.createdOn : new Date().getTime(),
        		"active": taskRequestData.active
            };
            console.log(finalData);

            return finalData;
        }
        
        function prepareEmailCreate(taskRequestData) {
            var finalData = {
            		"fromAddress": "aswin.sundaramoorthi@accenture.com",
            		"toAddress": "aswin.sundaramoorthi@accenture.com",
            		"cc": "aswin.sundaramoorthi@accenture.com",
            		"bcc": "sample@accenture.com",
            		"createdDate": taskRequestData.createdOn,
            		"createdBy": taskRequestData.createdBy,
            		"sentDate": null,
            		"status": taskRequestData.status,
            		"active": taskRequestData.active
            	};

            return finalData;
        }
        
        function prepareEmailUpdate(taskRequestData) {
            var finalData = {
            		"id": taskRequestData.id,
            		"fromAddress": "aswin.sundaramoorthi@accenture.com",
            		"toAddress": "aswin.sundaramoorthi@accenture.com",
            		"cc": "aswin.sundaramoorthi@accenture.com",
            		"bcc": "sample@accenture.com",
            		"createdDate": taskRequestData.createdOn,
            		"createdBy": taskRequestData.createdBy,
            		"sentDate": null,
            		"status": "New",
            		"active": taskRequestData.active
            	};

            return finalData;
        }
        
        function testData(){
        	var data = {
        			status: 200
        	}
        	return data;
        }

    }
})();
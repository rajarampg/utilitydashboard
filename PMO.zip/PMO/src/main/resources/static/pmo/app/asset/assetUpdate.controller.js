(function() {

    angular
        .module('app.asset')
        .controller('AssetUpdateController', AssetUpdateController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    AssetUpdateController.$inject = ["AssetWebService", "$scope", "$stateParams", "$state"];

    function AssetUpdateController(AssetWebService, $scope, $stateParams, $state) {
        var vm = this;
        vm.editAssetDetails = editAssetDetails;
        vm.id = $stateParams.id;
        
        
        AssetWebService.getAssetWebService(vm.id).then(function(response){
        	vm.selectmodel = response;
            vm.selectmodel.validity = moment(new Date(response.validity)).format("MM/DD/YYYY");
            vm.selectmodel.issuedDate = moment(new Date(response.issuedDate)).format("MM/DD/YYYY");
            vm.selectmodel.returnDate = moment(new Date(response.returnDate)).format("MM/DD/YYYY");

        });
        
        
        function editAssetDetails(){
        	$state.go('assetAdd', {
        		id: vm.id,
        		view: "update"
        	});
            $rootScope.$emit("titleChange",{title: "Asset Update"});
        };
        
        
    }
})();
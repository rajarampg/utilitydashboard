(function () {

    angular
        .module('app.asset')
        .controller('AssetAddController', AssetAddController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    AssetAddController.$inject = ["AssetDataService", "$mdToast", "AssetWebService", "$state", "$stateParams"];

    function AssetAddController(AssetDataService, $mdToast, AssetWebService, $state, $stateParams) {

        var vm = this;
        vm.submitted = false;
        vm.editButtonEnable = false;
        vm.id = ($stateParams.id !== undefined) ? $stateParams.id : "create";
        vm.view = ($stateParams.view !== undefined) ? $stateParams.view : "create";

        vm.assetType = AssetDataService.getAssetOptions();
        vm.assetOwnType = AssetDataService.getAssetOwnTypeOptions();
        vm.selectmodel = AssetDataService.getAssetModel();
        vm.onClickSubmitAssetDetails = onClickSubmitAssetDetails;

        if (vm.id !== "create") {
            AssetWebService.getAssetWebService(vm.id).then(function (response) {
                vm.selectmodel = {};
                vm.selectmodel = response;

                vm.selectmodel.validity = new Date(moment(vm.selectmodel.validity).format());
                vm.selectmodel.returnDate = new Date(moment(vm.selectmodel.returnDate).format());
                vm.selectmodel.issuedDate = new Date(moment(vm.selectmodel.issuedDate).format());

                if (response.assetType !== "") {
                    angular.forEach(vm.assetType, function (value) {
                        if (response.assetType === value.assetName) {
                            vm.selectmodel.assetType = {
                                id: value.id,
                                assetName: response.assetType
                            };
                        }
                    });
                }

                if (response.status !== "") {
                    angular.forEach(vm.statusType, function (value) {
                        if (response.status === value.statusName) {
                            vm.selectmodel.status = {
                                id: value.id,
                                statusName: response.status
                            };
                        }
                    });
                }
                console.log("vm.selectmodel", vm.selectmodel);
            });
        }

        function onClickSubmitAssetDetails() {
            if (vm.id === "create") {
                if (vm.assetAddForm.$valid) {
                    vm.submitted = false;
                    var createAssetData = AssetDataService.prepareFinalSubmitDataCreate(vm.selectmodel);
                    AssetWebService.postAssetWebService({
                        data: createAssetData
                    }).then(function (success) {
                        vm.showSimpleToast("Asset Details Submitted ");
                        $state.go("assetSearch", {
                            getSearchData: createAssetData.assignedTo,
                            view: "search"

                        }, function (error) {
                            console.log(error);
                        });
                    });
                } else {
                    vm.submitted = true;
                }
            }
            else if (vm.id !== "create") {
                if (vm.editButtonEnable) {
                    vm.editButtonEnable = false;
                } else {
                    if (vm.assetAddForm.$valid) {
                        var updateAssetData = AssetDataService.prepareFinalSubmitDataUpdate(vm.selectmodel);
                        AssetWebService.postAssetWebServiceUpdate({
                            data: updateAssetData
                        }).then(function (success) {
                            vm.showSimpleToast("Asset Updated Succesfully");
                            vm.editButtonEnable = true;
                            $state.go("assetSearch");

                        }, function (error) {
                            console.log(error);
                        });
                    } else {
                        vm.submitted = true;
                    }
                }
            }

        }

        vm.showSimpleToast = function (message) {

            $mdToast.show(
                $mdToast.simple()
                    .textContent(message)
                    /*.position("
                        center ")*/
                    .hideDelay(3000)
            );
        };
    }
})();
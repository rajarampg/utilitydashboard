(function() {

    angular
        .module('app.task')
        .controller('taskSearchController', taskSearchController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    taskSearchController.$inject = ["demandRequestDataService", "$timeout", "$scope", "$stateParams", "taskWebService", "taskDataService"];

    function taskSearchController(demandRequestDataService, $timeout, $scope, $stateParams, taskWebService, taskDataService) {
        var vm = this;
        vm.taskDetailsfilterFlag = false;
        vm.exportToExcel = exportToExcel;
        vm.getTaskDetailsBasedOnReqType = getTaskDetailsBasedOnReqType;
        vm.exportFile = exportFile;
        
        vm.requestType = taskDataService.getRequestOptions();
        vm.statusType = taskDataService.getStatusOptions();
        
        vm.getSearchData = $stateParams.getSearchData;
        
        vm.view = $stateParams.view;
        
        vm.limitOptions = [5, 10, 15, 25];
        
        vm.options = {
          rowSelection: true,
          multiSelect: true,
          autoSelect: true,
          decapitate: false,
          largeEditDialog: false,
          boundaryLinks: false,
          limitSelect: true,
          pageSelect: true
        };
        
        vm.query = {
          order: 'createdOn',
          limit: 5,
          page: 1
        };
        
        if(vm.view !== undefined && vm.view === "search"){
        	taskWebService.gettaskDetailsWebService(vm.getSearchData).then(function(response){
            	vm.task_details = response;
            	vm.taskDetailsFiltered = vm.task_details;
            });
        }else{
        	taskWebService.getAlltaskDetailsWebService().then(function(response){
            	vm.task_details = response;
        		vm.taskDetailsFiltered = vm.task_details;
            });
        }
        
        vm.fieldName = {
    		"order": "-createdOn",
    		"tableDetails": [
	          {
	        	"type": "link",
	        	"label": "Task Name",
	        	"name": "taskName",
	        	"orderBy": false,
	        	"url": "taskView",
	        	"displayField": "taskName"
	        }, {
	        	"type": "label",
	        	"label": "Request Type",
	        	"name": "requestType",
	        	"orderBy": false,
	        	"displayField": "requestType"
	        }, {
	        	"type": "label",
	        	"label": "Sub Request Type",
	        	"name": "subrequestType",
	        	"orderBy": false,
	        	"displayField": "subrequestType"
	        }, {
	        	"type": "label",
	        	"label": "Status",
	        	"name": "status",
	        	"orderBy": false,
	        	"displayField": "status"
	        }, {
	        	"type": "label",
	        	"label": "Assigned To",
	        	"name": "assignedTo",
	        	"orderBy": false,
	        	"displayField": "assignedTo"
	        }, {
	        	"type": "label",
	        	"label": "Created By",
	        	"name": "createdBy",
	        	"orderBy": true,
	        	"displayField": "createdBy"
	        }, {
	        	"type": "datelabel",
	        	"label": "Created On",
	        	"name": "createdOn",
	        	"orderBy": false,
	        	"displayField": "createdOn"
	        }, {
	        	"type": "edit",
	        	"label": "",
	        	"name": "",
	        	"orderBy": false,
	        	"url": "taskAdd",
	        	"urlParams": {
	        		view: "update"
	        	},
	        	"displayField": "Edit"
	        }]
        };
        
        function getTaskDetailsBasedOnReqType(modelDataRequestType, modelDataStatus){
        	vm.statusTaskDetails = [];
        	vm.requestTypeTaskDetails = [];
        	vm.task_details = [];
        	if(modelDataRequestType !== undefined && modelDataRequestType.length > 0){
        		vm.requestTypeTaskDetails = gettaskDetailsBasedOnRequestType(modelDataRequestType, vm.taskDetailsFiltered);
        	}
        	if(modelDataStatus !== undefined && modelDataStatus.length > 0){
        		vm.statusTaskDetails = gettaskDetailsBasedOnStatus(modelDataStatus, vm.taskDetailsFiltered);
        	}
        	
        	if(modelDataRequestType !== undefined && modelDataRequestType.length > 0 && modelDataStatus !== undefined && modelDataStatus.length > 0){
        		angular.forEach(vm.requestTypeTaskDetails, function(value){
        			angular.forEach(vm.statusTaskDetails, function(data){
        				if(value.id === data.id){
        					console.log("value", value);
        					vm.task_details.push(value);
        				}
        			});
        		});
        	}else if(modelDataRequestType !== undefined && modelDataRequestType.length > 0){
        		vm.task_details = vm.requestTypeTaskDetails;
        	}else if(modelDataStatus !== undefined && modelDataStatus.length > 0){
        		vm.task_details = vm.statusTaskDetails;
        	}else{
        		vm.task_details = vm.taskDetailsFiltered;
        	}
        }
        
        function gettaskDetailsBasedOnRequestType(modelDataRequestType, taskDetails){
        	vm.requestTypeTaskDetails = [];
        	angular.forEach(modelDataRequestType, function(value){
        		angular.forEach(taskDetails, function(data){
            		if(data.requestType === value.requestName){
            			vm.requestTypeTaskDetails.push(data);
            		}
            	});
        	});
        	return vm.requestTypeTaskDetails;
        }
        
        function gettaskDetailsBasedOnStatus(modelDataStatus, taskDetails){
        	vm.statusTaskDetails = [];
        	angular.forEach(modelDataStatus, function(value){
        		angular.forEach(taskDetails, function(data){
            		if(data.status === value.statusName){
            			vm.statusTaskDetails.push(data);
            		}
            	});
        	});
        	return vm.statusTaskDetails;
        }
        
        function exportToExcel(tableId){ // ex: '#my-table'
            var exportHref=ExporttoExcel.tableToExcel(tableId,'WireWorkbenchDataExport');
            $timeout(function(){location.href=exportHref;},100); // trigger download
        }
        
        function exportFile(){
        	var arrData = typeof vm.task_details != 'object' ? JSON.parse(vm.task_details) : vm.task_details;
            var CSV = '';
            CSV += "download" + '\r\n\n';
            var row = "";
            for (var index in arrData[0]) {
                row += index + ',';
            }
            row = row.slice(0, -1);
            CSV += row + '\r\n';
            for (var i = 0; i < arrData.length; i++) {
                var row = "";
                for (var index in arrData[i]) {
                    row += '"' + arrData[i][index] + '",';
                }
                row.slice(0, row.length - 1);
                CSV += row + '\r\n';
            }
            if (CSV == '') {        
                alert("Invalid data");
                return;
            }
            var fileName = "download";
            var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
            var link = document.createElement("a");    
            link.href = uri;
            link.style = "visibility:hidden";
            link.download = fileName + ".csv";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
        
    }
})();
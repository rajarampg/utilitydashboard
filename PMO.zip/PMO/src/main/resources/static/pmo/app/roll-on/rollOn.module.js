(function(){

	angular.module("app.rollOn",[]);

})();
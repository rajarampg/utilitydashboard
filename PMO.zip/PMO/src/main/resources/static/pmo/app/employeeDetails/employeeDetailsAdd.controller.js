(function() {

    angular
        .module('app.employeeDetails')
        .controller('employeeDetailsAddController', employeeDetailsAddController);

    /**
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    employeeDetailsAddController.$inject = ["employeeDetailsDataService", "$mdToast", "$state", "$stateParams", "employeeDetailWebService", "emailWebService", "loginWebService"];

    function employeeDetailsAddController(employeeDetailsDataService, $mdToast, $state, $stateParams, employeeDetailWebService, emailWebService, loginWebService) {
        var vm = this;
        vm.submitted = false;
        vm.editButtonEnable = false;
        //vm.selectmodel = {};
        //vm.selectmodel.gender = "M";	
        vm.onClickSubmitAllSkills = onClickSubmitAllSkills;
        vm.view = ($stateParams.id !== undefined) ? $stateParams.id : "create";
        vm.id = (vm.view !== "create") ? $stateParams.id : "";
        vm.title = (vm.id === "create") ? "Employee Details Add" : "Employee Details Update";
        
        vm.selectmodel = employeeDetailsDataService.getSelectModel();
        vm.portfolios = employeeDetailsDataService.getPortfolioOptions();
        vm.careerlevel = employeeDetailsDataService.getCareerlevelOptions();
        vm.visaList = employeeDetailsDataService.getVisaListOptions();
        vm.term = employeeDetailsDataService.getTermOptions();
        vm.primarySkill = employeeDetailsDataService.getPrimarySkillOptions();
        vm.proficienyLevel = employeeDetailsDataService.getProficiencyLevel();
        vm.lockType = employeeDetailsDataService.getlockTypeOptions();
        vm.employeeStatusOptions = employeeDetailsDataService.getEmployeeStatusOptions();
        vm.employeeTypeOptions = employeeDetailsDataService.getEmployeeTypeOptions();
        
        if(vm.view === "create" && vm.employeeStatusOptions.length > 0){
        	vm.selectmodel.employeeStatus = {
        			employeeStatusId: "1",
                	employeeStatusName: "Roll on - Initiated"
        	};
        }
        if(vm.view !== "create"){
        	vm.identifierType = employeeDetailsDataService.getIdentifierOptions();
        	vm.floors = employeeDetailsDataService.getFloorDetails();
        	vm.clientOptions = employeeDetailsDataService.getClientOptions();
        	vm.clientmodel = {};
        	
        	employeeDetailWebService.getEmployeeDetailWebService(vm.id).then(function(response){
            	vm.selectmodel = response;
            	vm.selectmodel.rolloffDate = moment(new Date(vm.selectmodel.rolloffDate)).format("MM/DD/YYYY");
            	vm.selectmodel.rollonDate = moment(new Date(vm.selectmodel.rolloffDate)).format("MM/DD/YYYY");
            	angular.forEach(vm.portfolios, function(value){
            		if(value.id === response.portfolioId){
            			vm.selectmodel.portfolioId = {
                				id: value.id,
            					portfolioName: value.portfolioName
                    	};
            		}
            	});
            	angular.forEach(vm.lockType, function(value){
            		if(value.lockId === response.lockType){
            			vm.selectmodel.lockType = {
        					lockId: value.lockId,
        	                lockName: value.lockName
                    	};
            		}
            	});
            	angular.forEach(vm.employeeStatusOptions, function(value){
            		if(value.employeeStatusId === response.employeeStatus){
            			vm.selectmodel.employeeStatus = {
            					employeeStatusId: value.employeeStatusId,
            	            	employeeStatusName: value.employeeStatusName
                    	};
            		}
            	});
            	angular.forEach(vm.employeeTypeOptions, function(value){
            		if(value.employeeTypeName === response.employeeType){
            			vm.selectmodel.employeeType = {
            					employeeTypeId: value.employeeTypeId,
            					employeeTypeName: value.employeeTypeName
                    	};
            		}
            	});
            	employeeDetailWebService.getEmployeeClientDetailByEntIdWebService(vm.selectmodel.employeeNumber).then(function(clientResponse){
            		vm.clientmodel = clientResponse;
            		vm.clientmodel.wmtAccessDate = (clientResponse.wmtAccessDate !== null) ? new Date(clientResponse.wmtAccessDate) : null;
                	vm.clientmodel.wmtGrantDate = (clientResponse.wmtGrantDate !== null) ? new Date(clientResponse.wmtGrantDate) : null;
                	vm.clientmodel.contractType = clientResponse.contractType;
                	vm.clientmodel.renew = (clientResponse.renew) ? "true" : "false";
                	employeeDetailWebService.getAllResourceManager().then(function(responseClient){
                		angular.forEach(responseClient, function(valueClient){
                			if(valueClient.id === vm.clientmodel.clientManagerId){
                				vm.clientmodel.clientManagerName = valueClient.resourceManager;
                				vm.clientmodel.vicePresident = valueClient.vicePresident;
                				vm.clientmodel.directorId = valueClient.directorId;
                			}
                		});
                	});
                	employeeDetailWebService.getAllPatternDetails().then(function(responsePattern){
                		angular.forEach(responsePattern, function(valuePattern){
                			if(valuePattern.id === vm.clientmodel.patternId){
                				vm.clientmodel.patternName = valuePattern.patternName;
                			}
                		});
                	});
                	employeeDetailWebService.getAllRoleDetails().then(function(responseRole){
                		angular.forEach(responseRole, function(valueRole){
                			if(valueRole.id === vm.clientmodel.roleId){
                				vm.clientmodel.roleName = valueRole.role;
                			}
                		});
                	});
                	angular.forEach(vm.identifierType, function(value){
                		if(value.identifierId ===  clientResponse.identifierType){
                			vm.clientmodel.identifierType = {
            					identifierId: value.identifierId,
            					identifierName: value.identifierName
                			}
                		}
                	});
                	angular.forEach(vm.clientOptions, function(value){
                		if(value.clientName ===  clientResponse.client){
                			vm.clientmodel.client = {
            					clientId: value.clientId,
            	                clientName: value.clientName
                			}
                		}
                	});
                	if(vm.clientmodel.client === ""){
                		vm.clientmodel.client = {
                			clientId: "WAL-MART STORES INC.",
                        	clientName: "WAL-MART STORES INC."	
                    	};
                	}
            	});
            });
        }
        function onClickSubmitAllSkills(){
        	if(vm.view === "create"){
    			if(vm.employeeDetailsAddForm.$valid){
		    		vm.submitted = false;
		    		var createEmployeeData = employeeDetailsDataService.prepareFinalSubmitDataCreate(vm.selectmodel);
		    		employeeDetailWebService.postemployeeDetailsWebService({
		               data: createEmployeeData
		            }).then(function(success) {
		                vm.showSimpleToast("Employee Details Created Successfully");
		                var employeeMailCreate = employeeDetailsDataService.prepareEmailCreate(createEmployeeData);
		                //employeeMailCreate.subject = createTaskData.taskName+"-"+createTaskData.requestType+"("+createTaskData.subrequestType+")";
		                //employeeMailCreate.contentDetails = "<html><title>"+createTaskData.taskName+"-"+createTaskData.requestType+"("
		                //										+createTaskData.subrequestType+")"+"</title><body>Hi,</br></br>Task Name: "+
		                //										createTaskData.taskName+"</br></br>Task Description: <p>"+createTaskData.taskDescription+".</p>" +
		        		//										"</br>Created By: "+createTaskData.createdBy+"</br>Created on: "+moment(createTaskData.createdOn).format("DD/MM/YYYY")+"</br></br>Thanks,</br>PMO Team.</body></html>";
		                employeeMailCreate.subject = "";
		                employeeMailCreate.contentDetails = ""
		                emailWebService.postEmailWebServiceCreate({
		                    data: employeeMailCreate
		                }).then(function(success) {
		                	var loginDetailsCreate = employeeDetailsDataService.prepareLoginDetails(createEmployeeData, vm.selectmodel);
		                	
		                	loginWebService.addLoginDetails({
			                    data: loginDetailsCreate
			                }).then(function(success) {
			                	  $state.go("employeeDetailsSearch", {
				                     view: "search"
			                	  });
			                }, function(error) {
			                	console.log(error);
			                });
		              
		                }, function(error) {
		                	console.log(error);
		               });
		            }, function(error) {
		               	console.log(error);
		            });
    			}else{
            		vm.submitted = true;
    			}
        	}else if(vm.view !== "create"){
        		if(vm.editButtonEnable){
        			vm.editButtonEnable = false;
        		}else {
        			if(vm.employeeDetailsAddForm.$valid){
        				var createEmployeeData = employeeDetailsDataService.prepareSubmitDataUpdate(vm.selectmodel);
    		    		employeeDetailWebService.postemployeeOffboardWebService({
    		                data: createEmployeeData
    		            }).then(function(success) {
    		            	var updateEmployeeData = employeeDetailsDataService.prepareFinalSubmitDataUpdate(vm.clientmodel);
    		            	employeeDetailWebService.postemployeeUpdateWebService({
    		            		data: updateEmployeeData
    		            	}).then(function(success){
    		            		$state.go("employeeDetailsSearch", {
        	                        view: "search"
        	                	});
    		            	}, function(error){
    		            		console.log(error);
    		            	});
    		            }, function(error) {
    		               	console.log(error);
    		            });
            			
                        /*taskWebService.posttaskWebServiceUpdate({
                            data: updateTaskData
                        }).then(function(success) {
                            vm.showSimpleToast("Task Updated Successfully");
                            vm.editButtonEnable = true;
                            $state.go("taskSearch");
                        }, function(error) {
                        	console.log(error);
                        });*/
        			}else{
                		vm.submitted = true;
                	}
        		}
        	}	
        }
 
        vm.showSimpleToast = function(message) {

            $mdToast.show(
                $mdToast.simple()
                .textContent(message)
                /*.position("center")*/
                .hideDelay(3000)
            );
        };
        
    }
})();
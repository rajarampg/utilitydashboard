(function() {
    "use strict";

    angular.module("app.webservices").service('commonService', commonService)

    commonService.$inject = [];

    function commonService() {
        this.setEmpNo = "";
        this.setUserTypeService = function(userType){
        	this.setUserType = userType;
        };
        
        this.getUserTypeService	 = function(){
        	return this.setUserType;
        };
        
        this.setUserIdService = function(userId){
        	this.setUserId = userId;
        };
        
        this.getUserIdService = function(){
        	return this.setUserId;
        };

        this.setEmpNoService = function(empNo){
        	this.setEmpNo = empNo;
        };
        
        this.getEmpNoService = function(){
        	return localStorage.getItem("empNo");
        };
    };
})();
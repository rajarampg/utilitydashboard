(function() {

    angular
        .module('app.employeeDetails')
        .controller('employeeRollOffController', employeeRollOffController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    employeeRollOffController.$inject = ["$state", "employeeDetailsDataService", "employeeDetailWebService", "$mdToast", "$mdDialog", "loginWebService", "emailWebService", "taskWebService"];

    function employeeRollOffController($state, employeeDetailsDataService, employeeDetailWebService, $mdToast, $mdDialog, loginWebService, emailWebService, taskWebService) {
        var vm = this;
        vm.submitted = false;
        vm.employeeDetails = employeeDetails;
        vm.rollOffDetails = rollOffDetails;
        vm.basicEmployeeDetails = basicEmployeeDetails;
        vm.employee =[];
        vm.disableField = true;
        vm.selectmodel = {};	
        vm.selectmodel.notify = "false";
        vm.portfolios = employeeDetailsDataService.getPortfolioOptions();
        function employeeDetails(portfolioModel){
        	employeeDetailWebService.getAllEmployeeDetailsWebService().then(function(response){
        		vm.employee = [];
        		angular.forEach(response, function(value){
        			vm.disableField = true;
        			if(portfolioModel.id === value.portfolioId && (value.employeeStatus === 4 || value.employeeStatus === "4")){
        				vm.employee.push(value);
        			}
        		});
        	});
        }
        
        function basicEmployeeDetails(basicEmployee){
        	vm.disableField = true;
        	vm.selectmodel.basicDetails = basicEmployee;
        	vm.selectmodel.firstName = basicEmployee.firstName;
        	vm.selectmodel.lastName = basicEmployee.lastName;
        	vm.selectmodel.supervisorEntId = basicEmployee.supervisorEntId;
        	vm.selectmodel.careerLevel = basicEmployee.careerLevel;
        	vm.selectmodel.primarySkill = basicEmployee.primarySkill;
        	vm.selectmodel.capability = basicEmployee.capability;
        	vm.selectmodel.rollonDate = (basicEmployee.rollonDate !== null) ? moment(new Date(basicEmployee.rollonDate)).format("MM/DD/YYYY") : null;
        	vm.selectmodel.rolloffDate = (basicEmployee.rolloffDate !== null) ? moment(new Date(basicEmployee.rolloffDate)).format("MM/DD/YYYY") : null;
    		vm.selectmodel.rolloffReason = basicEmployee.rolloffReason;
    		vm.disableField = false;
        }
        
        function rollOffDetails(selectmodel){
        	if(vm.employeeRollOffForm.$valid){
        		$mdDialog.show(
           			 {
           				 templateUrl: "./app/employeeDetails/employeeRollOffConfirm.html",
           				 clickOutsideToClose: true,
           				 controller: rollOffConfirmController,
           			 }).then(function(response){
           				 if(response){
           					vm.submitted = false;
           	        		var rollOffData = employeeDetailsDataService.createRollOffData(selectmodel);
           	        		employeeDetailWebService.postemployeeOffboardWebService({
           		                data: rollOffData
           		            }).then(function(success) {
           		            	vm.showSimpleToast("Employee Rolled Off Successfully");
           	        			var loginUpdateData = employeeDetailsDataService.createLoginData(rollOffData);
           	        			loginWebService.postUpdateloginDetailsService({
    			                    data: loginUpdateData
    			                }).then(function(success) {
    			                	  var emailRollOffData = employeeDetailsDataService.createEmailRollOff(rollOffData, vm.selectmodel);
    			                	  emailRollOffData.subject = "";
    			                	  emailRollOffData.contentDetails = "";
    			                	  emailWebService.postEmailWebServiceCreate({
    					                    data: emailRollOffData
    					              }).then(function(success) {
    					            	  var taskRollOffData = employeeDetailsDataService.createTaskRollOff(rollOffData);
    					            	  taskWebService.posttaskWebService({
    					            		  data: taskRollOffData
    					            	  }).then(function(success) {
						                	  $state.go("employeeDetailsSearch");
    					            	  }, function(error) {
    					            		  console.log(error);
    					            	  });
    					               }, function(error){
    					                	console.log(error);
    					               });
    			                }, function(error) {
    			                	console.log(error);
    			                });
           		               
           		            }, function(error) {
           		               	console.log(error);
           		            });
           				 }
           			 });
        		
        	}else{
        		vm.submitted = true;
        	}
        }
        
        function rollOffConfirmController($scope, $mdDialog) {
            $scope.confirm = function(status) {
              $mdDialog.hide(status);
            };

            $scope.cancel = function() {
              $mdDialog.cancel();
            };
          }
        
        vm.showSimpleToast = function(message) {

            $mdToast.show(
                $mdToast.simple()
                .textContent(message)
                /*.position("center")*/
                .hideDelay(3000)
            );
        };
    }
})();
(function() {
    'use strict';
    angular
        .module('app.task')
        .run(appRun);

    /* @ngInject */
    function appRun(routerHelper) {
        routerHelper.configureStates(getStates());
    }

    function getStates() {
        return [{
            state: 'taskAdd',
            config: {
                url: '/taskAdd?id&view',
                views: {
                    'main': {
                        templateUrl:"./app/task/taskAdd.html",
                        controller:"taskAddController as vm"
                    }

                }

            }
        },
        {
            state: 'taskView',
            config: {
                url: '/taskView?id',
                views: {
                    'main': {
                        templateUrl:"./app/task/taskView.html",
                        controller:"taskViewController as vm"
                    }

                }

            }
        },{
            state: 'taskSearch',
            config: {
                url: '/taskSearch?getSearchData&view',
                views: {
                    'main': {
                        templateUrl:"./app/task/taskSearch.html",
                        controller:"taskSearchController as vm"
                    }

                }

            }
        }];
    }
})();
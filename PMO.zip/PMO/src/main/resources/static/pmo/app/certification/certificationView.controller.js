(function() {

    angular
        .module('app.certification')
        .controller('certificationViewController', certificationViewController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    certificationViewController.$inject = ["certificationWebService", "$scope", "$stateParams", "$state"];

    function certificationViewController(certificationWebService, $scope, $stateParams, $state) {
        var vm = this;
        vm.editCertificationDetails = editCertificationDetails;
        vm.id = $stateParams.id;
        
        
        certificationWebService.getCertificationWebService(vm.id).then(function(response){
        	vm.selectmodel = response;
            vm.selectmodel.certificationDate = moment(new Date(response.certificationDate)).format("MM/DD/YYYY");
            vm.selectmodel.approvedOn = moment(new Date(response.approvedOn)).format("MM/DD/YYYY");
            vm.selectmodel.createdOn = moment(new Date(response.createdOn)).format("MM/DD/YYYY");
            vm.selectmodel.modifiedOn = moment(new Date(response.modifiedOn)).format("MM/DD/YYYY");
        });
        
        function editCertificationDetails(){
        	$state.go('certificationAdd', {
        		id: vm.id,
        		view: "update"
        	});
        };
        
        
    }
})();
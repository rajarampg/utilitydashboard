(function() {
    'use strict';
    angular
        .module('app.employeeDetails')
        .run(appRun);

    /* @ngInject */
    function appRun(routerHelper) {
        routerHelper.configureStates(getStates());
    }

    function getStates() {
        return [{
            state: 'employeeDetailsAdd',
            config: {
                url: '/employeeDetailsAdd?id&view',
                views: {
                    'main': {
                        templateUrl:"./app/employeeDetails/employeeDetailsAdd.html",
                        controller:"employeeDetailsAddController as vm"
                    }

                }

            }
        },
        {
            state: 'employeeDetailsSearch',
            config: {
                url: '/employeeDetailsSearch?getSearchData&view',
                views: {
                    'main': {
                        templateUrl:"./app/employeeDetails/employeeDetailsSearch.html",
                        controller:"employeeDetailsSearchController as vm"
                    }

                }

            }
        },
        {
            state: 'employeeDetailsView',
            config: {
                url: '/employeeDetailsView?id&employeeNumber',
                views: {
                    'main': {
                        templateUrl:"./app/employeeDetails/employeeDetailsView.html",
                        controller:"employeeDetailsViewController as vm"
                    }

                }

            }
        },
        {
            state: 'employeeDetailsUpdate',
            config: {
                url: '/employeeDetailsUpdate?id',
                views: {
                    'main': {
                        templateUrl:"./app/employeeDetails/employeeDetailsAdd.html",
                        controller:"employeeDetailsAddController as vm"
                    }

                }

            }
        },
        {
            state: 'employeeOnboard',
            config: {
                url: '/employeeOnboard',
                views: {
                    'main': {
                        templateUrl:"./app/employeeDetails/employeeOnboard.html",
                        controller:"employeeOnboardController as vm"
                    }

                }

            }
        },
        {
            state: 'employeeOffboard',
            config: {
                url: '/employeeOffboard',
                views: {
                    'main': {
                        templateUrl:"./app/employeeDetails/employeeOffboard.html",
                        controller:"employeeOffboardController as vm"
                    }

                }

            }
        },{
            state: 'employeeRollOff',
            config: {
                url: '/employeeRollOff',
                views: {
                    'main': {
                        templateUrl:"./app/employeeDetails/employeeRollOff.html",
                        controller:"employeeRollOffController as vm"
                    }

                }

            }
        }];
    }
})();
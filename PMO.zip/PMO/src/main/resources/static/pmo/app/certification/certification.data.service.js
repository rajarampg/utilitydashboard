(function() {
    'use strict';

    angular
        .module('app.certification')
        .factory('certificationDataService', certificationDataService);

    certificationDataService.$inject = ["commonService"];

    /* @ngInject */
    function certificationDataService(commonService) {
        var service = {
            getCertificationModel: getCertificationModel,
            prepareFinalSubmitDataCreate: prepareFinalSubmitDataCreate,
            prepareFinalSubmitDataUpdate: prepareFinalSubmitDataUpdate,
            testData: testData,
			//getFormatedDate: getFormatedDate
        };
		return service;
        
        function getCertificationModel() {
            var selectModel = {
        		certificationName: "",
                certificationType: "",
                stream: "",
                score: "",
				assignedTo: "",
				status:"",
				certificationDate:null,			
                approvedBy: "",
                approvedOn: null,
                approverComments: "",
                createdBy: "",
                createdOn: null,
				modifiedBy: "",
				modifiedOn: null,
				comments: "",
            };
            return selectModel;
        }
        
        function getFormatedDate(date) {
            var tempMoment=new Date(date).getTime();
            return tempMoment;
        };
        
        
        function prepareFinalSubmitDataCreate(certificationRequestData) {
            var finalData = {
        		"certificationName": certificationRequestData.certificationName,
        		"stream": certificationRequestData.stream,
        		"certificationType": certificationRequestData.certificationType,
        		"score": certificationRequestData.score,
        		"approvedBy": certificationRequestData.approvedBy,
        		"approvedOn": (certificationRequestData.approvedOn !== null && certificationRequestData.approvedOn !== "") ? getFormatedDate(certificationRequestData.approvedOn.toString()) : null,
        		"approverComments": certificationRequestData.approverComments,
        		"assignedTo": certificationRequestData.assignedTo,
        		"certificationDate": (certificationRequestData.certificationDate !== null && certificationRequestData.certificationDate !== "") ? getFormatedDate(certificationRequestData.certificationDate.toString()) : null,
        		"status": certificationRequestData.status,
        		"comments": certificationRequestData.comments,
        		"createdBy": commonService.getUserIdService(),
        		"createdOn": new Date().getTime(),
				/*"modifiedBy": commonService.getUserIdService(),
        		"modifiedOn":new Date().getTime(),*/
        		"modifiedBy": commonService.getUserIdService(),
        		"modifiedOn":new Date().getTime(),
				"active": true
            };
            console.log(finalData);

            return finalData;
        }
        
        function prepareFinalSubmitDataUpdate(certificationRequestData) {
            var finalData = {
            	"id": certificationRequestData.id,
        		"certificationName": certificationRequestData.certificationName,
        		"stream": certificationRequestData.stream,
        		"certificationType": certificationRequestData.certificationType,
        		"score": certificationRequestData.score,
        		"approvedBy": certificationRequestData.approvedBy,
        		"approvedOn": (certificationRequestData.approvedOn !== null && certificationRequestData.approvedOn !== "") ? getFormatedDate(certificationRequestData.approvedOn.toString()) : "",
        		"approverComments": certificationRequestData.approverComments,
        		"assignedTo": certificationRequestData.assignedTo,
        		"certificationDate": (certificationRequestData.certificationDate !== null && certificationRequestData.certificationDate !== "") ? getFormatedDate(certificationRequestData.certificationDate.toString()) : null,
        		"status": certificationRequestData.status,
        		"comments": certificationRequestData.comments,
        		"createdBy": certificationRequestData.createdBy,
        		"createdOn": (certificationRequestData.createdOn !== null && certificationRequestData.createdOn !== "") ? getFormatedDate(certificationRequestData.createdOn.toString()) : (certificationRequestData.createdOn !== null) ? certificationRequestData.createdOn : new Date().getTime(),
        		/*"modifiedBy": commonService.getUserIdService(),
        		"modifiedOn":new Date().getTime(),*/
				"modifiedBy": commonService.getUserIdService(),
        		"modifiedOn":new Date().getTime(),
				"active": certificationRequestData.active
            };
            console.log(finalData);

            return finalData;
        }
        
        function testData(){
        	var data = {
        			status: 200
        	}
        	return data;
        }

    }
})();
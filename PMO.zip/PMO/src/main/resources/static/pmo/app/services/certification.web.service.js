(function() {
    'use strict';

    angular
        .module('app.webservices')
        .factory('certificationWebService', certificationWebService);

    certificationWebService.$inject = ["$q", "baseWebService"];




    /* @ngInject */
    function certificationWebService($q, baseWebService) {

        var service = {
            postCertificationWebService: postCertificationWebService,
            getCertificationWebService: getCertificationWebService,
            getCertificationDetailsWebService: getCertificationDetailsWebService,
            getAllCertificationDetailsWebService: getAllCertificationDetailsWebService,
            postCertificationWebServiceUpdate: postCertificationWebServiceUpdate
        };

        return service;
        

        function postCertificationWebService(options) {
            var certificationRequest = angular.extend({

                postCertificationRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/certdetails/addcert",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return certificationRequest.postCertificationRequest(options);

        }
        
        function getCertificationWebService(options) {
            var certificationRequest = angular.extend({

                getCertificationRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/certdetails/viewcert/"+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return certificationRequest.getCertificationRequest(options);

        }
      
        function getCertificationDetailsWebService(options) {
            var certificationRequest = angular.extend({

            	getCertificationDetailsRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/certdetails/viewcertbyassignedto?assignedTo="+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return certificationRequest.getCertificationDetailsRequest(options);

        }
        
        
        
        function getAllCertificationDetailsWebService() {
            var certificationRequest = angular.extend({

            	getCertificationDetailsRequest: function() {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/certdetails/viewallcert",
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return certificationRequest.getCertificationDetailsRequest();

        }
        
        function postCertificationWebServiceUpdate(options) {
            var certificationRequest = angular.extend({

                postCertificationRequestUpdate: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/certdetails/addcert",
                       // url: "/certdetails/updatecert",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return certificationRequest.postCertificationRequestUpdate(options);

        }
    }
})();
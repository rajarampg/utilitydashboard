(function(){

    angular.module("app.roleDetails",[]);

})();
(function(){

    angular.module("app.portfolioDetails",[]);

})();
(function() {

    angular
        .module('app.login')
        .controller('loginRightsController', loginRightsController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    loginRightsController.$inject = ["$timeout", "$scope", "loginWebService", "$mdDialog", "loginDataService"];

    function loginRightsController($timeout, $scope, loginWebService, $mdDialog, loginDataService) {
        var vm = this;
        vm.getLoginDetailsBasedOnUserType = getLoginDetailsBasedOnUserType;
        vm.changeUserRights = changeUserRights;
        
        vm.limitOptions = [5, 10, 15, 25];
        
        vm.options = {
          rowSelection: true,
          multiSelect: true,
          autoSelect: true,
          decapitate: false,
          largeEditDialog: false,
          boundaryLinks: false,
          limitSelect: true,
          pageSelect: true
        };
        
        vm.query = {
          order: '-lastLogin',
          limit: 5,
          page: 1
        };
        
        vm.userTypeOption = loginDataService.getUSerTypeOptions();
        loginWebService.getViewAllWebService().then(function(response){
        	vm.login_details =  response;
        	//vm.login_details.lastLogin = moment(new Date(response.lastLogin).getTime()).format("MM/DD/YYYY");
        	angular.forEach(vm.login_details, function(value){
        		value.lastLogin = moment(new Date(value.lastLogin).getTime()).format("MM/DD/YYYY");
        		if(value.userTypeId === 1){
        			value.userName = "Admin";
        		}else if(value.userTypeId === 2){
        			value.userName = "Employee";
        		}else if(value.userTypeId === 3){
        			value.userName = "PMO";
        		}else if(value.userTypeId === 4){
        			value.userName = "Manager";
        		}else if(value.userTypeId === 5){
        			value.userName = "Portal - Backend";
        		}
        		
        	});
        	vm.temp_login_details = vm.login_details;
        });
        function changeUserRights(selectedRow, event){
        	 $mdDialog.show(
    			 {
    				 templateUrl: "./app/login-rights/loginRightsChangeConfirm.html",
    				 clickOutsideToClose: true,
    				 controller: loginRightsChangeConfirmController,
    			 }).then(function(response){
    				 if(response !== undefined){
    					 var updateLoginDetails = loginDataService.prepareLoginUpdate(selectedRow, response);
    					 loginWebService.postUpdateloginDetailsService({
    	                        data: updateLoginDetails
    	                    }).then(function(success) {
    	                        vm.showSimpleToast("Details Updated Successfully");

    	                    }, function(error) {
    	                    	vm.login_details = [];
    	                    	vm.temp_login_details = [];
    	                    	loginWebService.getViewAllWebService().then(function(response){
    	                        	vm.login_details =  response;
    	                        	angular.forEach(vm.login_details, function(value){
    	                        		if(value.userTypeId === 1){
    	                        			value.userName = "Admin";
    	                        		}else if(value.userTypeId === 2){
    	                        			value.userName = "Employee";
    	                        		}else if(value.userTypeId === 3){
    	                        			value.userName = "PMO";
    	                        		}else if(value.userTypeId === 4){
    	                        			value.userName = "Manager";
    	                        		}else if(value.userTypeId === 5){
    	                        			value.userName = "Portal - Backend";
    	                        		}
    	                        		
    	                        	});
    	                        	vm.temp_login_details = vm.login_details;
    	                        });
    	                    });

    				 
    				 }
    			 });
        }
        
        function getLoginDetailsBasedOnUserType(userType){
        	console.log("userType", userType);
        	vm.login_details = [];
        	if(userType.length > 0){
        		angular.forEach(userType, function(selectType){
            		angular.forEach(vm.temp_login_details, function(value){
                		if(value.userTypeId === selectType.id){
                			vm.login_details.push(value);
                		}
                	});
            	});
        	}else {
        		vm.login_details = vm.temp_login_details;
        	}
        	
        }
        function loginRightsChangeConfirmController($scope, $mdDialog) {
        	$scope.submitted = false;
        	$scope.userTypeOption = loginDataService.getUSerTypeOptions();
            

            $scope.confirm = function(userType) {
            	if($scope.loginRightConfirm.$valid){
            		$scope.submitted = false;
            		$mdDialog.hide(userType);
            	}else{
            		$scope.submitted = true;
            	}
            };

            $scope.cancel = function() {
              $mdDialog.cancel();
            };
          }
        
    }
})();
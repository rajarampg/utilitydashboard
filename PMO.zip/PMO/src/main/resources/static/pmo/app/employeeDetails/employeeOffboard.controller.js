(function() {

    angular
        .module('app.employeeDetails')
        .controller('employeeOffboardController', employeeOffboardController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    employeeOffboardController.$inject = ["$state", "employeeDetailsDataService", "employeeDetailWebService", "$mdToast", "emailWebService", "taskWebService"];

    function employeeOffboardController($state, employeeDetailsDataService, employeeDetailWebService, $mdToast, emailWebService, taskWebService) {
        var vm = this;
        vm.employeeDetails = employeeDetails;
        vm.employee = [];
        vm.submitted = false;
        vm.addOffboardDetails = addOffboardDetails;
        vm.getEmployeeSelected = getEmployeeSelected;
        vm.portfolios = employeeDetailsDataService.getPortfolioOptions();
        vm.disableField = false;
        
        function employeeDetails(portfolioModel){
        	employeeDetailWebService.getAllEmployeeDetailsWebService().then(function(response){
        		vm.employee = [];
        		vm.disableField = false;
        		angular.forEach(response, function(value){
        			if(portfolioModel.id === value.portfolioId && (value.employeeStatus !== 5 || value.employeeStatus !== 6)){
        				vm.employee.push(value);
        			}
        		});
        	});
        }
        
        function getEmployeeSelected(employeeDetail){
        	vm.selectmodel.firstName = employeeDetail.firstName;
        	vm.selectmodel.lastName = employeeDetail.lastName;
        	vm.selectmodel.supervisorEntId = employeeDetail.supervisorEntId;
        	vm.disableField = true;
        }
        
        /*function getWmIdBasedOnEnterpriseID(enterpriseIDModel){
        	vm.clientDetails = undefined;
        	employeeDetailWebService.getAllWMIdBasedOnEmpIdWebService(enterpriseIDModel.employeeNumber).then(function(response){
        		vm.selectmodel.wmtUserId = response.wmtUserId;
        		vm.clientDetails = response;
        	});
        }*/
        
        function addOffboardDetails(selectmodel){
        	if(vm.employeeOffboardForm.$valid){
	    		vm.submitted = false;

	        	
	        		var offboardData = employeeDetailsDataService.createOffboardData(selectmodel,vm.clientDetails);
	        		employeeDetailWebService.postemployeeOffboardWebService({
		                data: offboardData
		            }).then(function(success) {
		                vm.showSimpleToast("Employee Offboarded Successfully");
		                var employeeMailCreate = employeeDetailsDataService.prepareEmailOffboardCreate(selectmodel, vm.clientDetails);
	                	employeeMailCreate.subject = "";
		                employeeMailCreate.contentDetails = ""
	                	emailWebService.postEmailWebServiceCreate({
		                    data: employeeMailCreate
		                }).then(function(success) {
		                	var taskCreate = employeeDetailsDataService.prepareTaskDataOffboardCreate(selectmodel);
		                	taskWebService.posttaskWebService({
			                    data: taskCreate
			                }).then(function(success) {
			                	  $state.go("employeeDetailsSearch");
			               }, function(error) {
			                	console.log(error);
			                });
		                }, function(error) {
		                	console.log(error);
		                });
		            }, function(error) {
		              	console.log(error);
		            });
			}else{
        		vm.submitted = true;
			}
        	
        }
        
        
        
        vm.showSimpleToast = function(message) {

            $mdToast.show(
                $mdToast.simple()
                .textContent(message)
                /*.position("center")*/
                .hideDelay(3000)
            );
        };
    }
})();
(function() {
    'use strict';

    angular
        .module('app.webservices')
        .factory('emailWebService', emailWebService);

    emailWebService.$inject = ["$q", "baseWebService"];




    /* @ngInject */
    function emailWebService($q, baseWebService) {

        var service = {
        		postEmailWebServiceCreate: postEmailWebServiceCreate,
        		postEmailWebServiceUpdate: postEmailWebServiceUpdate
        };

        return service;
        

        function postEmailWebServiceCreate(options) {
            var taskRequest = angular.extend({

                postTaskRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/emaildetails/addemail",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;
                }
            }, baseWebService);

            return taskRequest.postTaskRequest(options);

        }
        
        function postEmailWebServiceUpdate(options) {
            var taskRequest = angular.extend({

                postTaskRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/emaildetails/updateemail",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;
                }
            }, baseWebService);

            return taskRequest.postTaskRequest(options);

        }
    }
})();
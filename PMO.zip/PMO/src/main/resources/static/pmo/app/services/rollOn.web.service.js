(function () {
    'use strict';

    angular
        .module('app.webservices')
        .factory('rollOnWebService', rollOnWebService);

    rollOnWebService.$inject = ["$q", "baseWebService"];




    /* @ngInject */
    function rollOnWebService($q, baseWebService) {

        var service = {
            postRollOnDataService: postRollOnDataService,
            addRollOnCheckListService: addRollOnCheckListService,
            getRollOnChecklistBasedOnEmpNoWebService: getRollOnChecklistBasedOnEmpNoWebService,
            getAllRollOnChecklistWebService: getAllRollOnChecklistWebService,
            updateRollOnCheckListService: updateRollOnCheckListService
        };

        return service;


        function getRollOnChecklistBasedOnEmpNoWebService(options) {
            var rollOnChecklistRequest = angular.extend({

                getRollOnChecklistRequest: function (options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/rollon/checklist?employee_number=" + options,
                        method: "GET"
                    }).then(function (response) {
                        deferred.resolve(response);
                    }, function (error) {
                        deferred.reject(error);

                    })
                    return deferred.promise;

                }
            }, baseWebService);

            return rollOnChecklistRequest.getRollOnChecklistRequest(options);
        }

        function getAllRollOnChecklistWebService(options) {
            var allRollOnChecklistRequest = angular.extend({

                getAllRollOnChecklistRequest: function (options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/rollon/checklist",
                        method: "GET"
                    }).then(function (response) {
                        deferred.resolve(response);
                    }, function (error) {
                        deferred.reject(error);

                    })
                    return deferred.promise;

                }
            }, baseWebService);

            return allRollOnChecklistRequest.getAllRollOnChecklistRequest(options);
        }

        function postRollOnDataService(options) {
            var rollOn = angular.extend({

                postRollOn: function (options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/employeedetails/rollonemp",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function (response) {
                        deferred.resolve(response);
                    }, function (error) {
                        deferred.reject(error);

                    })
                    return deferred.promise;

                }
            }, baseWebService);

            return rollOn.postRollOn(options);
        }

        function addRollOnCheckListService(options) {
            var addCheckListRequest = angular.extend({
                postAddCheckListRequestUpdate: function (options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/rollon/checklist",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function (response) {
                        deferred.resolve(response);
                    }, function (error) {
                        deferred.reject(error);
                    });
                    return deferred.promise;

                }
            }, baseWebService);

            return addCheckListRequest.postAddCheckListRequestUpdate(options);
        }

        function updateRollOnCheckListService(options) {
            var updateCheckListRequest = angular.extend({
                postUpdateCheckListRequestUpdate: function (options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/rollon/checklist",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function (response) {
                        deferred.resolve(response);
                    }, function (error) {
                        deferred.reject(error);
                    });
                    return deferred.promise;

                }
            }, baseWebService);

            return updateCheckListRequest.postUpdateCheckListRequestUpdate(options);

        }

    }
})();
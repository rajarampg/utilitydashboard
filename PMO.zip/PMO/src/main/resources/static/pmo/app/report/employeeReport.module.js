(function(){

    angular.module("app.employeeReport",[]);

})();
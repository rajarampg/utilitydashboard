(function() {
    'use strict';

    angular
        .module('app.login')
        .factory('loginDataService', loginDataService);

    loginDataService.$inject = [];

    /* @ngInject */
    function loginDataService() {
        var service = {
    		getUSerTypeOptions: getUSerTypeOptions,
    		prepareLoginUpdate: prepareLoginUpdate
        };
        return service;
        
        function getUSerTypeOptions() {
        	var statusType = [{
	                id: 1,
	                userName: "Admin"
	            }, {
	                id: 2,
	                userName: "Employee"
	            }, {
	                id: 3,
	                userName: "PMO"
	            }, {
	                id: 4,
	                userName: "Manager"
	            },{
	                id: 5,
	                userName: "Portal - Backend"
	            }
            ];
            return statusType;

        }
        
        function prepareLoginUpdate(selectedRow, changeValue){
        	var finalData = {
        			 "id": selectedRow.id,
        			  "employeeNumber": selectedRow.employeeNumber,
        			  "enterpriseId": selectedRow.enterpriseId,
        			  "password": selectedRow.password,
        			  "userTypeId": changeValue.id,
        			  "lastLogin": new Date().getTime()
                };
                return finalData;
        }

    }
})();
(function(){

    angular.module("app.asset",[]);

})();
(function() {
    'use strict';
    angular
        .module('app.login')
        .run(appRun);

    /* @ngInject */
    function appRun(routerHelper) {
        routerHelper.configureStates(getStates());
    }

    function getStates() {
        return [{
            state: 'loginRights',
            config: {
                url: '/loginRights',
                views: {
                    'main': {
                        templateUrl:"./app/login-rights/loginRights.html",
                        controller:"loginRightsController as vm"
                    }

                }

            }
        },
        {
            state: 'login',
            config: {
                url: '/login',
                views: {
                    'main': {
                        templateUrl:"./app/login-rights/login.html",
                        controller:"LoginController as vm"
                    }

                }

            }
        }
        ];
    }
})();
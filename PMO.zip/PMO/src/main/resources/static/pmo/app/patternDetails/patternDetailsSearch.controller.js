(function () {

    angular
        .module('app.patternDetails')
        .controller('patternDetailsSearchController', patternDetailsSearchController);

	/**
		 * Main Controller for the Angular Material Starter App
		 * @param $scope
		 * @param $mdSidenav
		 * @param avatarsService
		 * @constructor
		 */
    patternDetailsSearchController.$inject = ["patternDetailsDataService", "$timeout", "$scope", "$stateParams", "patternDetailsWebService", "$state"];

    function patternDetailsSearchController(patternDetailsDataService, $timeout, $scope, $stateParams, patternDetailsWebService, $state) {
        var vm = this;

        vm.patternDetailsfilterFlag = false;
        vm.view = $stateParams.view;
        vm.patternDetailsfilterFlag = false;
        vm.navigateToAdd = navigateToAdd;
        vm.selectmodel = undefined;
        vm.changeStateView = changeStateView;
        vm.changeStateEdit = changeStateEdit;
        vm.pattern_details = [];
        vm.portfolios = patternDetailsDataService.getPortfolioOptions();
        vm.onSelectPortfolio = onSelectPortfolio;
        vm.limitOptions = [5, 10, 15, 25];

        //vm.exportToExcel = exportToExcel;
        //vm.exportFile = exportFile;
        //vm.getSearchData = $stateParams.getSearchData; 
        //vm.selectmodel = patternDetailsDataService.getPatternDetailsModel();

        vm.options = {
            rowSelection: true,
            multiSelect: true,
            autoSelect: true,
            decapitate: false,
            largeEditDialog: false,
            boundaryLinks: false,
            limitSelect: true,
            pageSelect: true
        };

        vm.query = {
            order: '-lastLogin',
            limit: 5,
            page: 1
        };

        /*if (vm.view !== undefined && vm.view === "search") {
            patternDetailsWebService.getPatternDetailsWebService(vm.getSearchData).then(function (response) {
                vm.pattern_details = response;
                vm.patternDetailsFiltered = vm.pattern_details;
            });
        } else*/
        patternDetailsWebService.getAllPatternDetailsWebService().then(function (response) {
            vm.pattern_details = response;
            angular.forEach(response, function(data){
                angular.forEach(vm.portfolios, function (value) {
                    if (value.id === data.portfolioName) {
                        data.portfolioName = value.portfolioName;
                    }
                });
            });
            
            vm.patternDetailsFiltered = vm.pattern_details;
        });

        function onSelectPortfolio(pattern) {
            vm.pattern_details = [];
            
            patternDetailsWebService.getPatternDetailsWebService(pattern.id).then(function (response) {
                vm.pattern_details = response;

                /*angular.forEach(vm.pattern_details, function (value) {
                    value.createdOn = moment(new Date(value.createdOn)).format("MM/DD/YYYY");
                })*/

                vm.query.page = 1;
            }, function (error) {
                console.log(error);
            });

        }

        vm.limitOptions = [5, 10, 15, 25];

        vm.options = {
            rowSelection: true,
            multiSelect: true,
            autoSelect: true,
            decapitate: false,
            largeEditDialog: false,
            boundaryLinks: false,
            limitSelect: true,
            pageSelect: true
        };

        vm.query = {
            order: 'name',
            limit: 5,
            page: 1
        };

        function navigateToAdd(){
        	$state.go("patternDetailsAdd");
        }
        
        function changeStateView(id) {
            $state.go("patternDetailsView", {
                id: id,
                view: "view"
            })
        }

        function changeStateEdit(id) {
            $state.go("patternDetailsAdd", {
                id: id,
                view: "update"
            })
        }

    }

})();
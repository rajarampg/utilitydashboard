(function() {
	'use strict';
    angular.module("app.sideNav").factory("navDataService", navDataService);

    function navDataService() {
        var service = {
            "getSideNavData": getSideNavData
        };
        function getSideNavData() {
            var sidenData = [{
                title: "Dash Board",
                path: "dash-board"
            }, {
                title: "Users",
                path: "users"
            }, {
                title: "About you",
                path: "about"
            }];


        }



    }

})();
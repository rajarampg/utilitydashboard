(function(){
    'use strict';
    angular
        .module('app.employeeReport')
        .run(appRun);

    /* @ngInject */

    function appRun(routerHelper){
        routerHelper.configureStates(getStates());
    }

    function getStates(){

        return [
            {
                state: 'employeeReportSearch',
                config: {
                    url: '/employeeReportSearch?id',
                    views: {
                        'main': {
                            templateUrl: "./app/report/employeeReportSearch.html",
                            controller: "employeeReportSearchController as vm"
                        }
                    }
                }
            }
        ];
    }

})();
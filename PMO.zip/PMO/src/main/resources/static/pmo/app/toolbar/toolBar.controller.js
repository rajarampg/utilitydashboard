(function(){
'use strict';
  angular
       .module('app.toolbar',[])
       .controller('ToolBarController', ToolBarController);

  /**
   * Main Controller for the Angular Material Starter App
   * @param $scope
   * @param $mdSidenav
   * @param avatarsService
   * @constructor
   */
  ToolBarController.$inject=["$log","$mdSidenav","$rootScope", "$mdDialog", "$scope", "$state", "commonService"];
  function ToolBarController($log,$mdSidenav,$rootScope, $mdDialog, $scope, $state, commonService) {
    var vm = this;
    vm.logout = logout;
    vm.title="PMO";
    vm.viewEmployeeDetials = viewEmployeeDetials;
    vm.enterpriseId = commonService.getUserIdService();
    vm.toggleList=function(){
    	 $mdSidenav('left').toggle();
     };

     $rootScope.$on("titleChange",function(event,data){
    	 $mdSidenav('left').toggle();
      	vm.title="PMO >"+data.title;
     });
     
     function logout(){
    	 $mdDialog.show(
    			 {
    				 templateUrl: "./app/login-rights/logoutConfirm.html",
    				 clickOutsideToClose: true,
    				 controller: logoutConfirmController,
    			 }).then(function(response){
    				 if(response){
    					 localStorage.clear();
    					 //localStorage.removeItem("userType");
        		         //localStorage.removeItem("userId");
        		         //localStorage.removeItem("loginValue");
        		         $state.go("login");
        		         //location.reload();
    				 }
    			 });
    	 
     }
     
     function logoutConfirmController($scope, $mdDialog) {
         $scope.confirm = function(status) {
           $mdDialog.hide(status);
         };

         $scope.cancel = function() {
           $mdDialog.cancel();
         };
       }
     
     function viewEmployeeDetials(){
    	 $state.go("employeeDetailsView",{
     		employeeNumber: commonService.getEmpNoService()
     	});
     }
     
    // Load all registered users

    

   

  }

})();

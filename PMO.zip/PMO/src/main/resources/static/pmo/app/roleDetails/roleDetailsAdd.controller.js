(function () {

    angular
        .module('app.roleDetails')
        .controller('roleDetailsAddController', roleDetailsAddController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    roleDetailsAddController.$inject = ["roleDetailsDataService", "roleDetailsWebService", "$mdToast", "$state", "$stateParams"];

    function roleDetailsAddController(roleDetailsDataService, roleDetailsWebService, $mdToast, $state, $stateParams) {

        var vm = this;
        vm.submitted = false;
        vm.editButtonEnable = false;
        vm.id = ($stateParams.id !== undefined) ? $stateParams.id : "create";
        //vm.view = ($stateParams.view !== undefined) ? $stateParams.view : "create";   //TO DISABLE FIELDS

        vm.location = roleDetailsDataService.getLocationOptions();
        vm.selectmodel = roleDetailsDataService.getRoleModel();
        vm.onClickSubmitRoleDetails = onClickSubmitRoleDetails;

        if (vm.id !== "create") {
            roleDetailsWebService.getRoleDetailsWebService(vm.id).then(function (response) {
                vm.selectmodel = {};
                vm.selectmodel = response;
                vm.editButtonEnable = false;
                vm.selectmodel.createdOn = new Date(moment(vm.selectmodel.createdOn).format());
                vm.selectmodel.modifiedOn = new Date(moment(vm.selectmodel.modifiedOn).format());
                angular.forEach(vm.location, function (value) {
                    if (value.id === response.locationId) {
                        vm.selectmodel.location = {
                            id: value.id,
                            locationName: value.locationName
                        }
                    }
                });
                console.log("vm.selectmodel", vm.selectmodel);
            });
        }



        function onClickSubmitRoleDetails() {
            if (vm.id === "create") {
                if (vm.roleDetailsAddForm.$valid) {
                    vm.submitted = false;
                    var createRoleDetails = roleDetailsDataService.prepareFinalSubmitDataCreate(vm.selectmodel);
                    roleDetailsWebService.postRoleDetailsWebService({
                        data: createRoleDetails
                    }).then(function (success) {
                        vm.showSimpleToast("Role Details Submitted ");
                        $state.go("roleDetailsSearch", {
                            getSearchData: createRoleDetails,
                            view: "search"

                        }, function (error) {
                            console.log(error);
                        });
                    });
                } else {
                    vm.submitted = true;
                }
            }
            else if (vm.id !== "create") {
                if (vm.editButtonEnable) {
                    vm.editButtonEnable = false;
                } else {
                    if (vm.roleDetailsAddForm.$valid) {
                        var updateRoleDetails = roleDetailsDataService.prepareFinalSubmitDataUpdate(vm.selectmodel);
                        roleDetailsWebService.postRoleDetailsWebServiceUpdate({
                            data: updateRoleDetails
                        }).then(function (success) {
                            vm.showSimpleToast("Role Details Updated Succesfully");
                            vm.editButtonEnable = true;
                            $state.go("roleDetailsSearch");

                        }, function (error) {
                            console.log(error);
                        });
                    } else {
                        vm.submitted = true;
                    }
                }
            }
        }

        vm.showSimpleToast = function (message) {

            $mdToast.show(
                $mdToast.simple()
                    .textContent(message)
                    /*.position("
                        center ")*/
                    .hideDelay(3000)
            );
        };
    }
})();
(function() {
    'use strict';

    angular
        .module('app.webservices')
        .factory('taskWebService', taskWebService);

    taskWebService.$inject = ["$q", "baseWebService"];




    /* @ngInject */
    function taskWebService($q, baseWebService) {

        var service = {
            posttaskWebService: posttaskWebService,
            gettaskWebService: gettaskWebService,
            gettaskDetailsWebService: gettaskDetailsWebService,
            getAlltaskDetailsWebService: getAlltaskDetailsWebService,
            posttaskWebServiceUpdate: posttaskWebServiceUpdate
        };

        return service;
        

        function posttaskWebService(options) {
            var taskRequest = angular.extend({

                postTaskRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/taskdetails/addtask",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return taskRequest.postTaskRequest(options);

        }
        
        function gettaskWebService(options) {
            var taskRequest = angular.extend({

                getTaskRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/taskdetails/viewtask/"+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return taskRequest.getTaskRequest(options);

        }
      
        function gettaskDetailsWebService(options) {
            var taskRequest = angular.extend({

            	getTaskDetailsRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/taskdetails/viewtaskbycreatedby?createdBy="+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return taskRequest.getTaskDetailsRequest(options);

        }
        
        
        
        function getAlltaskDetailsWebService() {
            var taskRequest = angular.extend({

            	getTaskDetailsRequest: function() {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/taskdetails/viewalltask",
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return taskRequest.getTaskDetailsRequest();

        }
        
        function posttaskWebServiceUpdate(options) {
            var taskRequest = angular.extend({

                postTaskRequestUpdate: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/taskdetails/updatetask",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return taskRequest.postTaskRequestUpdate(options);

        }
    }
})();
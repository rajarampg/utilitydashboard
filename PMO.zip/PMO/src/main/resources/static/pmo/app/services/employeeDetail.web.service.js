(function() {
    'use strict';

    angular
        .module('app.webservices')
        .factory('employeeDetailWebService', employeeDetailWebService);

    employeeDetailWebService.$inject = ["$q", "baseWebService"];




    /* @ngInject */
    function employeeDetailWebService($q, baseWebService) {

        var service = {
        		getEmployeeDetailWebService: getEmployeeDetailWebService,
        		getAllEmployeeDetailsWebService: getAllEmployeeDetailsWebService,
        		getEmployeeClientDetailWebService: getEmployeeClientDetailWebService,
        		getAllResourceManager: getAllResourceManager,
        		getAllPatternDetails: getAllPatternDetails,
        		getAllWMIdBasedOnEmpIdWebService: getAllWMIdBasedOnEmpIdWebService,
        		getAllRoleDetails: getAllRoleDetails,
        		postemployeeDetailsWebService: postemployeeDetailsWebService,
        		postemployeeOffboardWebService: postemployeeOffboardWebService,
        		getEmployeeClientDetailByEntIdWebService: getEmployeeClientDetailByEntIdWebService,
        		postemployeeUpdateWebService: postemployeeUpdateWebService,
        		getAllResourceManagerBasedOnportfolio: getAllResourceManagerBasedOnportfolio,
        		postUpdateAllClientDetails: postUpdateAllClientDetails,
        		postUpdateAllEmpDetails: postUpdateAllEmpDetails,
        		postAllEmailWebServiceCreate: postAllEmailWebServiceCreate,
        		postAllTaskWebService:postAllTaskWebService,
        		getEmpDetailsBasedOnEmployeeNumber: getEmpDetailsBasedOnEmployeeNumber
        };

        return service;
        

        function getEmployeeDetailWebService(options) {
            var employeeDetailRequest = angular.extend({

            	getEmployeeDetailRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/empdetails/viewempdetails/"+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return employeeDetailRequest.getEmployeeDetailRequest(options);

        }
        
        function getEmpDetailsBasedOnEmployeeNumber(options){
        	var employeeDetailRequest = angular.extend({

            	getEmployeeDetailRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/empdetails/viewempdetailsbyemployeeid/"+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return employeeDetailRequest.getEmployeeDetailRequest(options);
        }
        
        function getAllEmployeeDetailsWebService() {
            var employeeDetailRequest = angular.extend({

            	getAllEmployeeDetailRequestRequest: function() {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/empdetails/viewallempdetails",
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return employeeDetailRequest.getAllEmployeeDetailRequestRequest();

        }
        
        function getEmployeeClientDetailWebService(options) {
            var employeeClientDetailRequest = angular.extend({

            	getEmployeeClientDetailRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/empclientdetails/viewempclientdetails/"+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return employeeClientDetailRequest.getEmployeeClientDetailRequest(options);

        }
        
        function getEmployeeClientDetailByEntIdWebService(options) {
            var employeeClientEnterpriseIdRequest = angular.extend({

            	getEmployeeClientEnterpriseIdRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/empclientdetails/viewempclientdetailsbyemployeeid/"+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return employeeClientEnterpriseIdRequest.getEmployeeClientEnterpriseIdRequest(options);

        }
        
        function getAllResourceManager(){
        	var resourceManagerRequest = angular.extend({

        		getResourceManagerRequest: function() {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/clientmanagerdetails/viewallclientmanagerdetails",
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return resourceManagerRequest.getResourceManagerRequest();
        }
        
        function getAllResourceManagerBasedOnportfolio(options){
        	var resourceManagerRequest = angular.extend({

        		getResourceManagerBasedOnPortfolioRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/clientmanagerdetails/viewclientmanagerdetailsbyportfolioid/"+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return resourceManagerRequest.getResourceManagerBasedOnPortfolioRequest(options);
        }
        
        function getAllPatternDetails(){
        	var patternDetailsRequest = angular.extend({

        		getAllPatternDetailsRequest: function() {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/patterndetails/viewallpattern",
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return patternDetailsRequest.getAllPatternDetailsRequest();
        }
        
        function getAllWMIdBasedOnEmpIdWebService(options){
        	var walmartIdRequest = angular.extend({

        		getWalmartIdRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/empclientdetails/viewempclientdetailsbyemployeeid/"+options,
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return walmartIdRequest.getWalmartIdRequest(options);
        }
        
        function getAllRoleDetails(){
        	var roleDetailsRequest = angular.extend({

        		getAllroleDetailsRequest: function() {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/roledetails/viewallrole",
                        method: "GET"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return roleDetailsRequest.getAllroleDetailsRequest();
        }
        
        function postemployeeDetailsWebService(options){
        	var employeeDetailsRequest = angular.extend({

        		postemployeeDetailsRequestRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/empdetails/addempdetails",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return employeeDetailsRequest.postemployeeDetailsRequestRequest(options);
        }
        
        function postemployeeOffboardWebService(options){
        	var employeeOffboardRequest = angular.extend({

        		postemployeeOffboardRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/empdetails/updateempdetails",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return employeeOffboardRequest.postemployeeOffboardRequest(options);
        }
        
        function postUpdateAllClientDetails(options){
        	var updateEmpClientDetailsRequest = angular.extend({

        		postUpdateEmpClientDetailsRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/empclientdetails/updateallempclientdetails",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return updateEmpClientDetailsRequest.postUpdateEmpClientDetailsRequest(options);
        }
        
        function postUpdateAllEmpDetails(options){
        	var updateEmpDetailsRequest = angular.extend({

        		postUpdateEmpDetailsRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/empdetails/updateallempdetails",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return updateEmpDetailsRequest.postUpdateEmpDetailsRequest(options);
        }
        
        function postemployeeUpdateWebService(options){
        	var employeeUpdateRequest = angular.extend({

        		postemployeeUpdateRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/empclientdetails/updateempclientdetails",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return employeeUpdateRequest.postemployeeUpdateRequest(options);
        }
        
        function postAllEmailWebServiceCreate(options){
        	var emailAllRequest = angular.extend({

        		postEmailAllRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/emaildetails/updateallemail",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return emailAllRequest.postEmailAllRequest(options);
        }
        
        function postAllTaskWebService(options){
        	var taskAllRequest = angular.extend({

        		postTaskAllRequest: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/taskdetails/updatealltask",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return taskAllRequest.postTaskAllRequest(options);
        }
    }
})();
(function () {

    angular
        .module('app.patternDetails')
        .controller('patternDetailsViewController', patternDetailsViewController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    patternDetailsViewController.$inject = ["$log", "$rootScope", "patternDetailsDataService", "$state", "patternDetailsWebService", "$stateParams", "$mdToast", "commonService"];

    function patternDetailsViewController($log, $rootScope, patternDetailsDataService, $state, patternDetailsWebService, $stateParams, $mdToast, commonService) {
        var vm = this;
        vm.selectmodel = undefined;
        vm.patternDetailsViewData = undefined;
        vm.id = $stateParams.id;
        //vm.rrdMapOnloadEmpty = true;
        vm.view = $stateParams.view;
        vm.title = (vm.view === "view") ? "Pattern View Request" : "Pattern Update Request";
        vm.pattern_details = patternDetailsDataService.getPortfolioOptions();
        vm.portfolios = patternDetailsDataService.getPortfolioOptions();
        vm.onSelectPortfolio = onSelectPortfolio;
        //vm.navigateView = navigateView;
        //vm.editResourceMap = editResourceMap;
        //vm.saveResourceMap = saveResourceMap;

        function onSelectPortfolio(demand) {
            /*if (vm.view === "view") {
                vm.resourceMapDisable = true;
            }*/

            //vm.resourceMap = [];

            vm.selectmodel = undefined;
            vm.editPatternDetails = editPatternDetails;
            patternDetailsWebService.getPatternWebService(vm.id).then(function (response) {
                vm.selectmodel = response;
                vm.selectmodel.createdOn = moment(new Date(response.createdOn)).format("MM/DD/YYYY");
                vm.selectmodel.modifiedOn = moment(new Date(response.modifiedOn)).format("MM/DD/YYYY");
                angular.forEach(vm.portfolios, function (value) {
                    if (vm.selectmodel.portfolioId === value.id) {
                        vm.selectmodel.portfolioName = value.portfolioName;
                    }
                });
            });
        }

        function editPatternDetails() {
            $state.go('patternDetailsAdd', {
                id: vm.id,
                view: "update"
            });
            //$rootScope.$emit("titleChange", { title: "Pattern Details Update" });
        };

    /*m.showSimpleToast = function (message) {

        $mdToast.show(
            $mdToast.simple()
                .textContent(message)
                /*.position("
                    center ")*/
               /* .hideDelay(3000)
        );
    };*/
}
})();
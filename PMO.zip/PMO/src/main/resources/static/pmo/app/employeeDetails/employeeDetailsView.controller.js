(function() {

    angular
        .module('app.employeeDetails')
        .controller('employeeDetailsViewController', employeeDetailsViewController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    employeeDetailsViewController.$inject = ["$stateParams", "$state", "employeeDetailWebService", "employeeDetailsDataService"];

    function employeeDetailsViewController($stateParams, $state, employeeDetailWebService, employeeDetailsDataService) {
        var vm = this;
        vm.editTaskDetails = editTaskDetails;
        vm.id = $stateParams.id;
        vm.employeeNumber = $stateParams.employeeNumber;
        vm.portfolios = employeeDetailsDataService.getPortfolioOptions();
        vm.employeeStatusOptions = employeeDetailsDataService.getEmployeeStatusOptions();
        vm.lockType = employeeDetailsDataService.getlockTypeOptions();
        vm.employeeTypeOptions = employeeDetailsDataService.getEmployeeTypeOptions();
     
        employeeDetailWebService.getEmpDetailsBasedOnEmployeeNumber(vm.employeeNumber).then(function(response){
        	vm.selectmodel = response;
        	if(vm.selectmodel.gender === "M"){
        		vm.selectmodel.genderOptions = "Male";
        	}else{
        		vm.selectmodel.genderOptions = "Female";
        	}
        	angular.forEach(vm.portfolios, function(value){
        		if(vm.selectmodel.portfolioId === value.id){
        			vm.selectmodel.portfolioName = value.portfolioName;
        		}
        	});
        	angular.forEach(vm.employeeStatusOptions, function(value){
        		if(value.employeeStatusId === vm.selectmodel.employeeStatus){
        			vm.selectmodel.employeeStatusName = value.employeeStatusName;
        		}
        	});
        	angular.forEach(vm.lockType, function(value){
        		if(value.lockId === vm.selectmodel.lockType){
        			vm.selectmodel.lockTypeName = value.lockName;
        		}
        	});
        	/*angular.forEach(vm.employeeTypeOptions, function(value){
        		if(value.employeeTypeName === vm.selectmodel.employeeType){
        			vm.selectmodel.employeeType = value.employeeTypeName;
        		}
        	});*/
        	vm.selectmodel.rolloffDate = moment(new Date(response.rolloffDate)).format("MM/DD/YYYY");
        	vm.selectmodel.rollonDate = moment(new Date(response.rollonDate)).format("MM/DD/YYYY");
        	employeeDetailWebService.getEmployeeClientDetailByEntIdWebService(vm.selectmodel.employeeNumber).then(function(clientResponse){
        		vm.clientmodel = clientResponse;
        		vm.clientmodel.wmtAccessDate = (clientResponse.wmtAccessDate !== null) ? moment(new Date(clientResponse.wmtAccessDate)).format("MM/DD/YYYY") : null;
            	vm.clientmodel.wmtGrantDate = (clientResponse.wmtGrantDate !== null) ? moment(new Date(clientResponse.wmtGrantDate)).format("MM/DD/YYYY") : null;
            	employeeDetailWebService.getAllResourceManager().then(function(responseClient){
            		angular.forEach(responseClient, function(valueClient){
            			if(valueClient.id === vm.clientmodel.clientManagerId){
            				vm.clientmodel.clientManagerName = valueClient.resourceManager;
            				vm.clientmodel.vicePresident = valueClient.vicePresident;
            				vm.clientmodel.directorId = valueClient.directorId;
            			}
            		});
            	});
            	employeeDetailWebService.getAllPatternDetails().then(function(responsePattern){
            		angular.forEach(responsePattern, function(valuePattern){
            			if(valuePattern.id === vm.clientmodel.patternId){
            				vm.clientmodel.patternName = valuePattern.patternName;
            			}
            		});
            	});
            	employeeDetailWebService.getAllRoleDetails().then(function(responseRole){
            		angular.forEach(responseRole, function(valueRole){
            			if(valueRole.id === vm.clientmodel.roleId){
            				vm.clientmodel.roleName = valueRole.role;
            			}
            		});
            	});
        	});
        });
        
        function editTaskDetails(){
        	$state.go('employeeDetailsAdd', {
        		id: vm.selectmodel.id,
        		view: "update"
        	});
        };
    }
})();
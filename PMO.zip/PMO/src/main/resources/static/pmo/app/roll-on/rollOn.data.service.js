(function() {
    'use strict';

    angular
        .module('app.rollOn')
        .factory('rollOnDataService', rollOnDataService);

    rollOnDataService.$inject = [];

    /* @ngInject */
    function rollOnDataService() {
        var service = {
            
            getRollOnModel: getRollOnModel,
            getPortfolioOptions: getPortfolioOptions,
            getLockTypeOptions: getLockTypeOptions,
            getGenderOptions: getGenderOptions,
            getCareerlevelOptions: getCareerlevelOptions,
            getStayDurationOptions: getStayDurationOptions,
            getVisaTypeOptions: getVisaTypeOptions,
            getProficiencyLevelOptions: getProficiencyLevelOptions,
            getSupervisorOptions: getSupervisorOptions,
            getFloorOptions: getFloorOptions,
            prepareFinalSubmitData: prepareFinalSubmitData,
            getChkListOptions: getChkListOptions,
            getDataProtectionData1: getDataProtectionData1,
            getworkForceData: getworkForceData,
            getDataProtectionData2: getDataProtectionData2,

        };
        return service;

        function getRollOnModel() {
            var rollOnModel = {

                rrdIDModel: "",
                rollOnDateModel: "",
                lockTypeModel: "",
                lockEndDateModel: "",
                portfoliosModel: "",
                resourceNameModel: "",
                employeeIDModel: "",
                firstNameModel: "",
                lastNameModel: "",
                enterpriseIdModel: "",
                genderModel: "",
                careerLevelModel: "",
                phoneNumberModel: "",
                currentLocModel: "",
                deliveryCenterModel: "",
                visaTypeModel: "",
                stayDurationModel: "",
                capabilityModel: "",
                primarySkillModel: "",
                secondarySkillModel: "",
                proficiencyLevelModel: "",
                wmtUserIDModel: "",
                WmtAccessReqDateModel: "",
                WmtAccessGrantDateModel: "",
                wmtMgrUserIDModel: "",
                supervisorNameModel: "",
                workstationNumberModel: "",
                bayNumberModel: "",
                floorModel: "",
                projectNameModel: "",
                projectDetailsModel: ""

            };
            return rollOnModel;
        }

        function getPortfolioOptions() {
            var portfolios = [{
                id: 1,
                portfolioName: "Application Operations"
            }, {
                id: 2,
                portfolioName: "Application Stores Program"
            }, {
                id: 3,
                portfolioName: "Stores AD - Windows 2003 Elimination"
            }, {
                id: 4,
                portfolioName: "Walmart Captive"
            }, {
                id: 5,
                portfolioName: "HR of the future(Business Driven)"
            }, {
                id: 6,
                portfolioName: "CSHER Walmart GEC 1P & 3P(Business Driven)"
            }, {
                id: 7,
                portfolioName: "AQ-Walmart MVT Pilot-Australia(Business Driven)"
            }, {
                id: 8,
                portfolioName: "Walmart - Site Redesign(Business Driven)"
            }, {
                id: 9,
                portfolioName: "Walmart - New FED(Business Driven)"
            }, {
                id: 10,
                portfolioName: "IT Financial Mgmt Strategy(Business Driven)"
            }];
            return portfolios;
        }

        function getLockTypeOptions() {
            var lockType = [
                "short term",
                "long term"
            ];
            return lockType;
        }

        function getGenderOptions() {
            var gender = [
                "Male",
                "Female"
            ];
            return gender;
        }

        function getCareerlevelOptions() {
            var careerlevel = [

                "Accenture Leadership",
                "5-Senior Manager",
                "6-Senior Manager",
                "7-Manager",
                "8-Associate Manager",
                "9-Team Lead",
                "10-Senior Software Engineer",
                "11-Software Engineer",
                "12-Associate Software Engineer",
                "13-Associate Software Engineer",
                "Intern ASE"

            ];
            return careerlevel;
        }

        function getStayDurationOptions() {
            var stayDuration = [
                "< 3 months",
                "3 to 6 months",
                "6 to 12 months"
            ];
            return stayDuration;
        }

        function getVisaTypeOptions() {
            var visaType = [
                "USA - B1",
                "USA - H1B",
                "USA - H1B Anticipatory Visa",
                "USA - H1B Regular",
                "USA - J1",
                "USA - L1 Blanket",
                "USA - L1A Blanket",
                "USA - L1B Blanket",
                "USA- L2 (EAD)",
                "USAGreen Card",
                "USA H-1B Amended",
                "USA H-1B Premium",
                "USA H-1B Regular",
                "USAH-1B Shift",
                "USA- H1B Extension",
                "USA- L1 (A) Individual extension",
                "USA-L1 (B) Blanket extension",
                "USA- L1 (B) Individual extension",
                "Work permit",
                "Work visa/ permit"
            ];
            return visaType;
        }

        function getProficiencyLevelOptions() {
            var proficiencyLevel = [
                "P0",
                "P1",
                "P2",
                "P3",
                "P4"
            ];
            return proficiencyLevel;
        }

        function getFloorOptions() {
            var floor = [
                "1st floor",
                "2nd floor",
                "3rd floor",
                "4th floor",
                "5th floor"
            ];
            return floor;
        }

        function getSupervisorOptions() {
            var supervisor = [

            ];
            return supervisor;
        }

        function getFormatedDate(date) {
            var tempMoment=new moment(date).format('MM/DD/YYYY');
            return tempMoment;
        };

        function prepareFinalSubmitData(rollOnData) {

           var finalData = {
                "rrdID" : rollOnData.rrdIDModel,
                "rollOnDate" : getFormatedDate(rollOnData.rollOnDateModel.toString()),
                "lockType" : rollOnData.lockTypeModel,
                "lockEndDate" : getFormatedDate(rollOnData.lockEndDateModel.toString()),
                "portfolioId" : rollOnData.portfoliosModel.id,
                "resourceName" : rollOnData.resourceNameModel,
                "employeeID" : rollOnData.employeeIDModel,
                "firstName" : rollOnData.firstNameModel,
                "lastName" : rollOnData.lastNameModel,
                "enterpriseId" : rollOnData.enterpriseIdModel,
                "gender" : rollOnData.genderModel,
                "deliveryCenter" : rollOnData.deliveryCenterModel,
                "currentLoc" : rollOnData.currentLocModel,
                "careerlevel" : rollOnData.careerlevelModel,
                "phoneNumber" : rollOnData.phoneNumberModel,
                "capability" : rollOnData.capabilityModel,
                "primarySkill" : rollOnData.primarySkillModel,
                "secondarySkill" : rollOnData.secondarySkillModel,
                "proficiencyLevel" : rollOnData.proficiencyLevelModel,
                "wmtUserID" : rollOnData.wmtUserIDModel,
                "WmtAccessReqDate" : getFormatedDate(rollOnData.WmtAccessReqDateModel.toString()),
                "WmtAccessGrantDateModel" : getFormatedDate(rollOnData.WmtAccessGrantDateModel.toString()),
                "wmtMgrUserID" : rollOnData.wmtMgrUserIDModel,
                "supervisorName" : rollOnData.supervisorNameModel,
                "workstationNumber" : rollOnData.workstationNumberModel,
                "bayNumber" : rollOnData.bayNumberModel,
                "floor" : rollOnData.floorModel,
                "projectName" : rollOnData.projectNameModel,
                "projectDetails" : rollOnData.projectDetailsModel
           };

           console.log(finalData);

            return finalData;

        }
        function getChkListOptions(){
            return [
                "Acknowledged",
                "Pending"
            ];
        }
        function getDataProtectionData1(){
            return [
                "Yes",
                "No"
            ];
        }
        function getworkForceData(){
            return [
                "Consulting",
                "Enterprise",
                "Services",
                "Solution",
                "Sub contractor"
            ];
        }
        function getDataProtectionData2(){
            return [
                "Yes",
                "No",
                "NA"
            ];
        }

    }
})();
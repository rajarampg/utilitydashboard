(function() {
    'use strict';

    angular
        .module('app.webservices')
        .factory('demandRequestWebService', demandRequestWebService);

    demandRequestWebService.$inject = ["$q", "baseWebService"];




    /* @ngInject */
    function demandRequestWebService($q, baseWebService) {

        var service = {
            postDemandRequestDataService: postDemandRequestDataService,
            getDemandRequestViewService: getDemandRequestViewService,
            postResourceMapAddService: postResourceMapAddService,
            getAllDemandRequestData: getAllDemandRequestData,
            getRRDMappingDetailService: getRRDMappingDetailService,
            postResourceMapUpdateService: postResourceMapUpdateService,
            getDemandRequestViewAllService: getDemandRequestViewAllService
        };

        return service;
        

        function postDemandRequestDataService(options) {
            var demandRequest = angular.extend({

                postDemandRequet: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/rrd/addrrd",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return demandRequest.postDemandRequet(options);

        }
        
        function getDemandRequestViewService(options) {
            var demandRequest = angular.extend({

                getDemandRequestView: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/rrd/viewrrd/"+options,
                        method: "GET",
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return demandRequest.getDemandRequestView(options);

        }
        
        function getDemandRequestViewAllService() {
            var demandRequestViewAll = angular.extend({

                getDemandRequestViewAll: function() {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/rrd/viewallrrd",
                        method: "GET",
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return demandRequestViewAll.getDemandRequestViewAll();

        }
        
        function postResourceMapAddService(options) {
            var resourceMap = angular.extend({

            	postResourceMapAdd: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/rrddemand/addrrddemand/",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return resourceMap.postResourceMapAdd(options);

        }
        
        function getAllDemandRequestData(options) {
        	var demandRequestView = angular.extend({

        		getDemandRequetView: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/rrd/viewrrdbyportfolioid/" + options.id,
                        method: "GET",
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);
        	
            return demandRequestView.getDemandRequetView(options);

        }
        
        function getRRDMappingDetailService(options){
        	var demandRequestRRDView = angular.extend({

        		getDemandRequestRRDView: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/rrddemand/viewrrddemandbydemandid/" + options,
                        method: "GET",
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);
        	
            return demandRequestRRDView.getDemandRequestRRDView(options);
        }
        
        function postResourceMapUpdateService(options){
        	var resourceMap = angular.extend({

            	postResourceMapAdd: function(options) {
                    var deferred = $q.defer();
                    this.callRestService({
                        url: "/rrddemand/updaterrddemand/",
                        method: "POST",
                        data: options.data,
                        apiDomain: "pmo"
                    }).then(function(response) {
                        deferred.resolve(response);
                    }, function(error) {
                       deferred.reject(error);

                    })
                   return deferred.promise;

                }
            }, baseWebService);

            return resourceMap.postResourceMapAdd(options);
        }
    }
})();
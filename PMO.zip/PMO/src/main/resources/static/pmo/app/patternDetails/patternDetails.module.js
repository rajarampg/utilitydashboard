(function(){

    angular.module("app.patternDetails",[]);

})();
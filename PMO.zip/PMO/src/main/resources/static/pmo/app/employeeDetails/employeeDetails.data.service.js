(function() {
    'use strict';

    angular
        .module('app.employeeDetails')
        .factory('employeeDetailsDataService', employeeDetailsDataService);

    employeeDetailsDataService.$inject = ["commonService"];

    /* @ngInject */
    function employeeDetailsDataService(commonService) {
        var service = {
    		getSelectModel: getSelectModel,
            getPortfolioOptions: getPortfolioOptions,
            getCareerlevelOptions: getCareerlevelOptions,
            getVisaListOptions: getVisaListOptions,
            getTermOptions: getTermOptions,
            getPrimarySkillOptions: getPrimarySkillOptions,
            getProficiencyLevel: getProficiencyLevel,
            getlockTypeOptions: getlockTypeOptions,
            getEmployeeStatusOptions: getEmployeeStatusOptions,
            getOnboardSelectModel: getOnboardSelectModel,
            getOffboardSelectModel: getOffboardSelectModel,
            getLocationOptions: getLocationOptions,
            prepareFinalSubmitDataCreate: prepareFinalSubmitDataCreate,
            createOffboardData: createOffboardData,
            getOnboardSelectModelReset: getOnboardSelectModelReset,
            prepareFinalSubmitDataUpdate: prepareFinalSubmitDataUpdate,
            createRollOffData: createRollOffData,
            getIdentifierOptions: getIdentifierOptions,
            getFloorDetails: getFloorDetails,
            getClientOptions: getClientOptions,
            getEmployeeTypeOptions: getEmployeeTypeOptions,
            prepareSubmitDataUpdate: prepareSubmitDataUpdate,
            prepareEmailCreate: prepareEmailCreate,
            prepareLoginDetails: prepareLoginDetails,
            getEmpClientDetails: getEmpClientDetails,
            getEmpDetails: getEmpDetails,
            prepareEmailOnboardCreate: prepareEmailOnboardCreate,
            prepareTaskDataCreate: prepareTaskDataCreate,
            prepareEmailOffboardCreate: prepareEmailOffboardCreate,
            prepareTaskDataOffboardCreate: prepareTaskDataOffboardCreate,
            prepareAllTaskDataCreate: prepareAllTaskDataCreate,
            createLoginData: createLoginData,
            createEmailRollOff: createEmailRollOff,
            createTaskRollOff: createTaskRollOff
        };
        return service;





        function getSelectModel() {
            var selectmodel = {
            		"employeeNumber": "",
            		  "portfolioId": "",
            		  "rrdId": "",
            		  "enterpriseId": "",
            		  "firstName": "",
            		  "lastName": "",
            		  "gender": "",
            		  "capability": "",
            		  "careerLevel": "",
            		  "supervisorEntId": "",
            		  "currentLocation": "",
            		  "deliveryCenter": "",
            		  "visaType": "",
            		  "durationStay": "",
            		  "phoneNo": "",
            		  "primarySkill": "",
            		  "secondarySkill": "",
            		  "proficiencyLevel": "",
            		  "lockType": "",
            		  "employeeStatus": "",
            		  "employeeType": "",
            		  "rollonDate": null,
            		  "rollonBy": "",
            		  "rolloffDate": null,
            		  "rolloffReason": "",
            		  "rolledoffBy": "",
            		  "createdBy": "",
            		  "createdOn": "",
            		  "modifiedBy": "",
            		  "modifiedOn": "",
            		  "active": false,
            		  "exit": false
            };


            return selectmodel;
        }
        
        function getFloorDetails(){
        	var floors = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15"];
        	return floors;
        }
        
        function getClientOptions(){
        	var client = [{
                clientId: "Walmart",
                clientName: "Walmart"
            }, {
            	clientId: "WAL-MART STORES INC.",
            	clientName: "WAL-MART STORES INC."
            }];
            return client;
        }
        
        function getEmployeeTypeOptions(){
        	var employeeType = [{
        		employeeTypeId: "Employee",
                employeeTypeName: "Employee"
            }, {
            	employeeTypeId: "PMO",
            	employeeTypeName: "PMO"
            }, {
            	employeeTypeId: "Leadership",
            	employeeTypeName: "Leadership"
            }, {
            	employeeTypeId: "Manager",
            	employeeTypeName: "Manager"
            }];
            return employeeType;
        }

        function getSkillsModel() {
            var skillsModel = {
                primarySkillModel: "",
                careerlevelModel: "",
                fulfillmentEntityModel: "",
                termModel: "",
                hardlockModel: "",
                wbseModel: "",
                numberModel: ""
            };
            return skillsModel;
        }

        function getPortfolioOptions() {
            var portfolios = [{
                id: 1,
                portfolioName: "Application Operations"
            }, {
                id: 2,
                portfolioName: "Application Stores Program"
            }, {
                id: 3,
                portfolioName: "Stores AD - Windows 2003 Elimination"
            }, {
                id: 4,
                portfolioName: "Walmart Captive"
            }];
            return portfolios;
        }
        
        function getLocationOptions(){
        	var location = [{
                locationId: "idc",
                locationName: "IDC"
            }, {
            	locationId: "onshore",
            	locationName: "Onshore"
            }];
            return location;
        }

        function getCareerlevelOptions() {
            var careerlevel = [

                "Accenture Leadership",
                "5",
                "6",
                "7",
                "8",
                "9",
                "10",
                "11",
                "12",
                "13",
                "Intern ASE",

            ];
            return careerlevel;
        }
        
        function getVisaListOptions() {
            var visaList = [
                "",
                "USA - B1",
                "USA - H1B",
                "USA - H1B Anticipatory Visa",
                "USA - H1B Regular",
                "USA - J1",
                "USA - L1 Blanket",
                "USA - L1A Blanket",
                "USA - L1B Blanket",
                "USA- L2 (EAD)",
                "USAGreen Card",
                "USA H-1B Amended",
                "USA H-1B Premium",
                "USA H-1B Regular",
                "USAH-1B Shift",
                "USA- H1B Extension",
                "USA- L1 (A) Individual extension",
                "USA-L1 (B) Blanket extension",
                "USA- L1 (B) Individual extension",
                "Work permit",
                "Work visa/ permit"
            ];
            return visaList;
        }
        
        function getTermOptions() {
            var term = [
                "Short Term",
                "Long Term",
            ];
            return term;
        }
        
        function getPrimarySkillOptions() {
            var primarySkill = [
                "C++ (UNIX)",
                "Java Enterprise Edition",
                "Mainframe",
                "Microsoft- .NET Architecture",
                "ASP.NET",
                "COBOL",
                "J2EE Architecture",
                "HTML 5",
                "AngularJS",
                "Java Platform Language and Class Libraries",
                "Java Standard Edition",
                "C (UNIX)",
            ];
            return primarySkill;
        }
        
        function getProficiencyLevel(){
        	var proficiencyLevel = [
                "P0",
                "P1",
                "P2",
                "P3",
                "P4"
            ];
            return proficiencyLevel;
        }
        
        function getlockTypeOptions(){
        	var lockType = [
                {
            	lockId: "HL",
                lockName: "Hard Lock"
            }, {
                lockId: "SL",
                lockName: "Soft Lock"
            }
            ];
            return lockType;
        }
        
        function getEmployeeStatusOptions(){
        	var lockType = [
                {
            	employeeStatusId: "1",
            	employeeStatusName: "Roll on - Initiated"
            }, {
            	employeeStatusId: "2",
                employeeStatusName: "Onboarding - initiated"
            }
            , {
            	employeeStatusId: "3",
                employeeStatusName: "Onboarding - Completed"
            }, {
            	employeeStatusId: "4",
                employeeStatusName: "Roll off - Initiated"
            }, {
            	employeeStatusId: "5",
                employeeStatusName: "Rolled off"
            }

            ];
            return lockType;
        }
        
        function getIdentifierOptions(){
        	var identifierOptions = [
				{
					identifierId: "enterpriseId",
					identifierName: "Enterprise Id"
				}, {
					identifierId: "passport",
					identifierName: "Passport"
				}
				, {
					identifierId: "drivingLicence",
					identifierName: "Driving Licence"
				}, {
					identifierId: "voterId",
					identifierName: "Voter Id"
				}, {
					identifierId: "panCard",
					identifierName: "Pan Card"
				}
             ];

        	return identifierOptions;
        }
        
        function getOffboardSelectModel(){
        	var selectmodel = {
            		
            		  "portfolioId": "",
            		  "enterpriseId": "",
            		  "wmtUserId": "",
            		  "rolloffDate": "",
            		  "exit": false,
            		  "rolloffReason": ""
            };


            return selectmodel;
        }
        
        function getOnboardSelectModel(){
        	var selectmodel = {
            		  "portfolioId": "",
            		  "resourceManager": "",
            		  "vicePresident": "",
            		  "directorId": "",
            		  "patternName": "",
            		  "primarySkill": "",
            		  "firstName": "",
            		  "lastName": "",
            		  "enterpriseId": "",
            		  "contractId": "",
            		  "rate": "",
            		  "employeeNumber": ""
            };

            return selectmodel;
        }
        
        function getOnboardSelectModelReset(){
        	var selectmodel = {
            		  "firstName": "",
            		  "lastName": "",
            		  "enterpriseId": "",
            		  "contractId": "",
            		  "rate": "",
            		  "employeeNumber": ""
            };

            return selectmodel;
        }
        
        function prepareFinalSubmitDataCreate(employeeModel){
        	var finalData = {
        			 "employeeNumber": employeeModel.employeeNumber,
        			  "portfolioId": employeeModel.portfolioId.id,
        			  "rrdId": employeeModel.rrdId,
        			  "enterpriseId": employeeModel.enterpriseId,
        			  "firstName": employeeModel.firstName,
        			  "lastName": employeeModel.lastName,
        			  "gender": employeeModel.gender,
        			  "capability": employeeModel.capability,
        			  "careerLevel": employeeModel.careerLevel,
        			  "supervisorEntId": employeeModel.supervisorEntId,
        			  "currentLocation": employeeModel.currentLocation,
        			  "deliveryCenter": employeeModel.deliveryCenter,
        			  "visaType": employeeModel.visaType,
        			  "durationStay": employeeModel.durationStay,
        			  "phoneNo": employeeModel.phoneNo,
        			  "primarySkill": employeeModel.primarySkill,
        			  "secondarySkill": employeeModel.secondarySkill,
        			  "proficiencyLevel": employeeModel.proficiencyLevel,
        			  "lockType": employeeModel.lockType.lockId,
        			  "employeeStatus": (employeeModel.employeeStatus !== null && employeeModel.employeeStatus.employeeStatusId !== undefined) ? employeeModel.employeeStatus.employeeStatusId : employeeModel.employeeStatus,
        			  "employeeType": (employeeModel.employeeType !== null && employeeModel.employeeType.employeeTypeName !== undefined) ? employeeModel.employeeType.employeeTypeName : employeeModel.employeeType,
        			  "rollonDate": new Date().getTime(),
        			  "rollonBy": commonService.getUserIdService(),
        			  "rolloffDate": 1488457164700,
        			  "rolloffReason": "NA",
        			  "rolledoffBy": "NA",
        			  "createdBy": commonService.getUserIdService(),
        			  "createdOn": new Date().getTime(),
        			  "modifiedBy": commonService.getUserIdService(),
        			  "modifiedOn": new Date().getTime(),
        			  "active": true,
        			  "exit": false
        	};
        	
        	return finalData;
        	
        	
        }
        
        function prepareSubmitDataUpdate(employeeModel){
        	var finalData = {
        				"id": employeeModel.id,
        			 "employeeNumber": employeeModel.employeeNumber,
        			  "portfolioId": employeeModel.portfolioId.id,
        			  "rrdId": employeeModel.rrdId,
        			  "enterpriseId": employeeModel.enterpriseId,
        			  "firstName": employeeModel.firstName,
        			  "lastName": employeeModel.lastName,
        			  "gender": employeeModel.gender,
        			  "capability": employeeModel.capability,
        			  "careerLevel": employeeModel.careerLevel,
        			  "supervisorEntId": employeeModel.supervisorEntId,
        			  "currentLocation": employeeModel.currentLocation,
        			  "deliveryCenter": employeeModel.deliveryCenter,
        			  "visaType": employeeModel.visaType,
        			  "durationStay": employeeModel.durationStay,
        			  "phoneNo": employeeModel.phoneNo,
        			  "primarySkill": employeeModel.primarySkill,
        			  "secondarySkill": employeeModel.secondarySkill,
        			  "proficiencyLevel": employeeModel.proficiencyLevel,
        			  "lockType": employeeModel.lockType.lockId,
        			  "employeeStatus": (employeeModel.employeeStatus !== null && employeeModel.employeeStatus.employeeStatusId !== undefined) ? employeeModel.employeeStatus.employeeStatusId : employeeModel.employeeStatus,
        			  "employeeType": (employeeModel.employeeType !== null && employeeModel.employeeType.employeeTypeName !== undefined) ? employeeModel.employeeType.employeeTypeName : employeeModel.employeeType,
        			  "rollonDate": new Date().getTime(),
        			  "rollonBy": commonService.getUserIdService(),
        			  "rolloffDate": 1488457164700,
        			  "rolloffReason": "NA",
        			  "rolledoffBy": "NA",
        			  "createdBy": commonService.getUserIdService(),
        			  "createdOn": new Date().getTime(),
        			  "modifiedBy": commonService.getUserIdService(),
        			  "modifiedOn": new Date().getTime(),
        			  "active": true,
        			  "exit": false
        	};
        	
        	return finalData;
        	
        	
        }
        
        function prepareFinalSubmitDataUpdate(clientmodel){
    		var finalData =  {
    				"id": clientmodel.id,
    				"employeeNumber": clientmodel.employeeNumber,
    				"clientManagerId": clientmodel.clientManagerId,
    				"patternId": clientmodel.patternId,
    				"roleId": clientmodel.roleId,
    				"wmtUserId": clientmodel.wmtUserId,
    				"wmtAccessDate": (clientmodel.wmtAccessDate !== null) ? new Date(clientmodel.wmtAccessDate).getTime() : null,
    				"wmtGrantDate": (clientmodel.wmtGrantDate !== null) ? new Date(clientmodel.wmtGrantDate).getTime() : null,
    				"contractType": clientmodel.contractType,
	        	  	"projectName": clientmodel.projectName,
	        	  	"projectDetails": clientmodel.projectDetails,
	        	  	"client": (clientmodel.client !== undefined && clientmodel.client !== null && clientmodel.client.clientName !== undefined) ? clientmodel.client.clientName : "",
	        	  	"departmentNumber": clientmodel.departmentNumber,
	        	  	"country": clientmodel.country,
	        	  	"workstation": clientmodel.workstation,
	        	  	"bayDetails": clientmodel.bayDetails,
	        	  	"floor": clientmodel.floor,
	        	  	"wbse": clientmodel.wbse,
	        	  	"identifierType": (clientmodel.identifierType !== undefined && clientmodel.identifierType !== null && clientmodel.identifierType.identifierId !== undefined) ? clientmodel.identifierType.identifierId : "",
	        	  	"identifierNumber": clientmodel.identifierNumber,
	        	  	"comments": clientmodel.comments,
	        	  	"onboardStartDate": clientmodel.onboardStartDate,
	        	  	"onboardTime": clientmodel.onboardTime,
	        	  	"onboardedBy": clientmodel.onboardedBy,
	        	  	"createdBy": clientmodel.createdBy,
	        	  	"createdOn": clientmodel.createdOn,
	        	  	"modifiedBy": commonService.getUserIdService(),
	        	  	"modifiedOn": new Date().getTime(),
	        	  	"active": true,
	        	  	"renew": clientmodel.renew
    		};
        		
    		return finalData;
        }
        
        function createOffboardData(selectmodel, clientDetails){
        	var finalData = {
        			  "id": selectmodel.enterpriseId.id,
        			  "employeeNumber": selectmodel.enterpriseId.employeeNumber,
        			  "portfolioId": selectmodel.portfolioId.id,
        			  "rrdId": selectmodel.enterpriseId.rrdId,
        			  "enterpriseId": selectmodel.enterpriseId.enterpriseId,
        			  "firstName": selectmodel.enterpriseId.firstName,
        			  "lastName": selectmodel.enterpriseId.lastName,
        			  "gender": selectmodel.enterpriseId.gender,
        			  "capability": selectmodel.enterpriseId.capability,
        			  "careerLevel": selectmodel.enterpriseId.careerLevel,
        			  "supervisorEntId": selectmodel.enterpriseId.supervisorEntId,
        			  "currentLocation": selectmodel.enterpriseId.currentLocation,
        			  "deliveryCenter": selectmodel.enterpriseId.deliveryCenter,
        			  "visaType": selectmodel.enterpriseId.visaType,
        			  "durationStay": selectmodel.enterpriseId.durationStay,
        			  "phoneNo": selectmodel.enterpriseId.phoneNo,
        			  "primarySkill": selectmodel.enterpriseId.primarySkill,
        			  "secondarySkill": selectmodel.enterpriseId.secondarySkill,
        			  "proficiencyLevel": selectmodel.enterpriseId.proficiencyLevel,
        			  "lockType": selectmodel.enterpriseId.lockType,
        			  "employeeStatus": 4,
        			  "employeeType": selectmodel.enterpriseId.employeeType,
        			  "rollonDate": selectmodel.enterpriseId.rollonDate,
        			  "rollonBy": selectmodel.enterpriseId.rollonBy,
        			  "rolloffDate": selectmodel.rolloffDate,
        			  "rolloffReason": selectmodel.rolloffReason,
        			  "rolledoffBy": commonService.getUserIdService(),
        			  "createdBy": selectmodel.enterpriseId.createdBy,
        			  "createdOn": selectmodel.enterpriseId.createdOn,
        			  "modifiedBy": commonService.getUserIdService(),
        			  "modifiedOn": new Date().getTime(),
        			  "active": true,
        			  "exit": selectmodel.exit
        			  
			
			};
        	return finalData;
        }
        
        function createRollOffData(selectmodel){
        	var finalData = {
        			"id": selectmodel.enterpriseId.id,
      			  "employeeNumber": selectmodel.enterpriseId.employeeNumber,
      			  "portfolioId": selectmodel.portfolioId.id,
      			  "rrdId": selectmodel.enterpriseId.rrdId,
      			  "enterpriseId": selectmodel.enterpriseId.enterpriseId,
      			  "firstName": selectmodel.enterpriseId.firstName,
      			  "lastName": selectmodel.enterpriseId.lastName,
      			  "gender": selectmodel.enterpriseId.gender,
      			  "capability": selectmodel.enterpriseId.capability,
      			  "careerLevel": selectmodel.enterpriseId.careerLevel,
      			  "supervisorEntId": selectmodel.enterpriseId.supervisorEntId,
      			  "currentLocation": selectmodel.enterpriseId.currentLocation,
      			  "deliveryCenter": selectmodel.enterpriseId.deliveryCenter,
      			  "visaType": selectmodel.enterpriseId.visaType,
      			  "durationStay": selectmodel.enterpriseId.durationStay,
      			  "phoneNo": selectmodel.enterpriseId.phoneNo,
      			  "primarySkill": selectmodel.enterpriseId.primarySkill,
      			  "secondarySkill": selectmodel.enterpriseId.secondarySkill,
      			  "proficiencyLevel": selectmodel.enterpriseId.proficiencyLevel,
      			  "lockType": selectmodel.enterpriseId.lockType,
      			  "employeeStatus": 5,
      			  "employeeType": selectmodel.enterpriseId.employeeType,
      			  "rollonDate": selectmodel.enterpriseId.rollonDate,
      			  "rollonBy": selectmodel.enterpriseId.rollonBy,
      			  "rolloffDate": selectmodel.enterpriseId.rolloffDate,
      			  "rolloffReason": selectmodel.enterpriseId.rolloffReason,
      			  "rolledoffBy": commonService.getUserIdService(),
      			  "createdBy": selectmodel.enterpriseId.createdBy,
      			  "createdOn": selectmodel.enterpriseId.createdOn,
      			  "modifiedBy": commonService.getUserIdService(),
      			  "modifiedOn": new Date().getTime(),
      			  "active": true,
      			  "exit": selectmodel.exit
        	}
        		
        		
        		return finalData;
        }
        
        function prepareEmailCreate(employeeRequestData) {
            var finalData = {
            		"fromAddress": "aswin.sundaramoorthi@accenture.com",
            		"toAddress": employeeRequestData.enterpriseId,
            		"cc": (employeeRequestData.supervisorEntId !== "") ? employeeRequestData.supervisorEntId +"@accenture.com" : "",
            		"bcc": "sample@accenture.com",
            		"createdDate": employeeRequestData.createdOn,
            		"createdBy": employeeRequestData.createdBy,
            		"sentDate": new Date().getTime(),
            		"status": "New",
            		"active": true
            	};

            return finalData;
        }
        
        function prepareEmailOffboardCreate(selectmodel, clientDetails) {
            var finalData = {
            		"fromAddress": "aswin.sundaramoorthi@accenture.com",
            		"toAddress": "pmo@accenture.com",
            		"cc": (selectmodel.enterpriseId.supervisorEntId !== undefined && selectmodel.enterpriseId.supervisorEntId !== "" && selectmodel.enterpriseId.supervisorEntId !== "NULL") ? selectmodel.enterpriseId.supervisorEntId +"@accenture.com" : "",
            		"bcc": "sample@accenture.com",
            		"createdDate": new Date().getTime(),
            		"createdBy": new Date().getTime(),
            		"sentDate": new Date().getTime(),
            		"status": "New",
            		"active": true
            	};

            return finalData;
        }
        
        function prepareEmailOnboardCreate(tableData) {
        	var emailData = [];
        	for (var i = 0; i < tableData.length; i++) {
                var tempSkill = tableData[i];
                var finalTempSkill = {
            		"id": null,
            	    "fromAddress": "pmo2portal@accenture.com",
            	    "toAddress": "pmo@accenture.com",
            	    "cc": (tempSkill.enterpriseId.supervisorEntId !== undefined && tempSkill.enterpriseId.supervisorEntId !== null && tempSkill.enterpriseId.supervisorEntId !== "NULL") ? tempSkill.enterpriseId.supervisorEntId : "",
            	    "bcc": "sample@accenture.com",
            	    "createdDate": new Date().getTime(),
            	    "createdBy": commonService.getUserIdService(),
            	    "sentDate": new Date().getTime(),
            	    "status": "New",
            	    "active": true,
            	    "toIds": null,
            	    "ccIds": null,
            	    "bccIds": null
                };

                emailData.push(finalTempSkill);
            };
        	
            return emailData;
        }
        
        function prepareLoginDetails(employeeRequestData, employeeModel) {
    		var finalData = {
        	  "employeeNumber": employeeRequestData.employeeNumber,
        	  "enterpriseId": employeeRequestData.enterpriseId,
        	  "password": employeeRequestData.employeeNumber,
        	  "userTypeId": 2,
        	  "lastLogin": null
        	};
	
    		if(employeeModel.employeeType !== null && employeeModel.employeeType.employeeTypeId !== undefined && employeeModel.employeeType.employeeTypeId === "PMO"){
        		finalData.userTypeId = 3;
        	}else if(employeeModel.employeeType !== null && employeeModel.employeeType.employeeTypeId !== undefined && (employeeModel.employeeType.employeeTypeId === "Manager" || employeeModel.employeeType.employeeTypeId === "Leadership")){
        		finalData.userTypeId = 4;
        	}

    		return finalData;
        }
        
        function getEmpClientDetails(selectmodel, tableData){
        	var clientData = [];
        	for (var i = 0; i < tableData.length; i++) {
                var tempSkill = tableData[i];
                var finalTempSkill = {
                		"id": (tempSkill.clientDetailsEmp.id !== undefined) ? tempSkill.clientDetailsEmp.id : "",
                	    "employeeNumber": tempSkill.enterpriseId.employeeNumber,
                	    "clientManagerId": tempSkill.resourceManager.id,
                	    "patternId": tempSkill.patternName.id,
                	    "roleId": tempSkill.roleId.id,
                	    "wmtUserId": (tempSkill.clientDetailsEmp.wmtUserId !== undefined && tempSkill.clientDetailsEmp.wmtUserId !== null && tempSkill.clientDetailsEmp.wmtUserId !== "NULL") ? tempSkill.clientDetailsEmp.wmtUserId : "",
                	    "wmtAccessDate": (tempSkill.clientDetailsEmp.wmtAccessDate !== undefined && tempSkill.clientDetailsEmp.wmtAccessDate !== null && tempSkill.clientDetailsEmp.wmtAccessDate !== "NULL") ? tempSkill.clientDetailsEmp.wmtAccessDate : null,
                	    "wmtGrantDate": (tempSkill.clientDetailsEmp.wmtGrantDate !== undefined && tempSkill.clientDetailsEmp.wmtGrantDate !== null && tempSkill.clientDetailsEmp.wmtGrantDate !== "NULL") ? tempSkill.clientDetailsEmp.wmtGrantDate : null,
                	    "contractType": tempSkill.contractId,
                	    "projectName": (tempSkill.clientDetailsEmp.projectName !== undefined && tempSkill.clientDetailsEmp.projectName !== null && tempSkill.clientDetailsEmp.projectName !== "NULL") ? tempSkill.clientDetailsEmp.projectName : "",
                	    "projectDetails": (tempSkill.clientDetailsEmp.projectDetails !== undefined && tempSkill.clientDetailsEmp.projectDetails !== null && tempSkill.clientDetailsEmp.projectDetails !== "NULL") ? tempSkill.clientDetailsEmp.projectDetails : "",
                	    "client": (tempSkill.clientDetailsEmp.client !== undefined && tempSkill.clientDetailsEmp.client !== null && tempSkill.clientDetailsEmp.client !== "NULL") ? tempSkill.clientDetailsEmp.client : "",
                	    "departmentNumber": (tempSkill.clientDetailsEmp.departmentNumber !== undefined && tempSkill.clientDetailsEmp.departmentNumber !== null && tempSkill.clientDetailsEmp.departmentNumber !== "NULL") ? tempSkill.clientDetailsEmp.departmentNumber : "",
                	    "country": (tempSkill.clientDetailsEmp.country !== undefined && tempSkill.clientDetailsEmp.country !== null && tempSkill.clientDetailsEmp.country !== "NULL") ? tempSkill.clientDetailsEmp.country : "",
                	    "workstation": (tempSkill.clientDetailsEmp.workstation !== undefined && tempSkill.clientDetailsEmp.workstation !== null && tempSkill.clientDetailsEmp.workstation !== "NULL") ? tempSkill.clientDetailsEmp.workstation : "",
                	    "bayDetails": (tempSkill.clientDetailsEmp.bayDetails !== undefined && tempSkill.clientDetailsEmp.bayDetails !== null && tempSkill.clientDetailsEmp.bayDetails !== "NULL") ? tempSkill.clientDetailsEmp.bayDetails : "",
                	    "floor": (tempSkill.clientDetailsEmp.floor !== undefined && tempSkill.clientDetailsEmp.floor !== null && tempSkill.clientDetailsEmp.floor !== "NULL") ? tempSkill.clientDetailsEmp.floor : "",
                	    "wbse": (tempSkill.clientDetailsEmp.wbse !== undefined && tempSkill.clientDetailsEmp.wbse !== null && tempSkill.clientDetailsEmp.wbse !== "NULL") ? tempSkill.clientDetailsEmp.wbse : "",
                	    "identifierType": (tempSkill.clientDetailsEmp.identifierType !== undefined && tempSkill.clientDetailsEmp.identifierType !== null && tempSkill.clientDetailsEmp.identifierType !== "NULL") ? tempSkill.clientDetailsEmp.identifierType : "",
                	    "identifierNumber": (tempSkill.clientDetailsEmp.identifierNumber !== undefined && tempSkill.clientDetailsEmp.identifierNumber !== null && tempSkill.clientDetailsEmp.identifierNumber !== "NULL") ? tempSkill.clientDetailsEmp.identifierNumber : "",
                	    "comments": (tempSkill.clientDetailsEmp.comments !== undefined && tempSkill.clientDetailsEmp.comments !== null && tempSkill.clientDetailsEmp.comments !== "NULL") ? tempSkill.clientDetailsEmp.comments : "",
                	    "onboardStartDate": new Date().getTime(),
                	    "onboardTime": new Date().getTime(),
                	    "onboardedBy": commonService.getUserIdService(),
                	    "createdBy": commonService.getUserIdService(),
                	    "createdOn": new Date().getTime(),
                	    "modifiedBy": commonService.getUserIdService(),
                	    "modifiedOn": new Date().getTime(),
                	    "active": true,
                	    "renew": false
                }

                clientData.push(finalTempSkill);
            };
            
            return clientData;
        }
        
        function getEmpDetails(selectmodel, tableData){
        	var employeeData = [];
        	for (var i = 0; i < tableData.length; i++) {
                var tempSkill = tableData[i];
                var finalTempSkill = {
            		 "id": tempSkill.enterpriseId.id,
            		 "employeeNumber": tempSkill.enterpriseId.employeeNumber,
            		 "portfolioId": tempSkill.enterpriseId.portfolioId,
            		 "rrdId": tempSkill.enterpriseId.rrdId,
    		         "enterpriseId": tempSkill.enterpriseId.enterpriseId,
    		         "firstName": tempSkill.enterpriseId.firstName,
    		         "lastName": tempSkill.enterpriseId.lastName,
    		         "gender": tempSkill.enterpriseId.gender,
    		         "capability": tempSkill.enterpriseId.capability,
    		         "careerLevel": tempSkill.enterpriseId.careerLevel,
    		         "supervisorEntId": tempSkill.enterpriseId.supervisorEntId,
    		         "currentLocation": tempSkill.enterpriseId.currentLocation,
    		         "deliveryCenter": tempSkill.enterpriseId.deliveryCenter,
    		         "visaType": tempSkill.enterpriseId.visaType,
    		         "durationStay": tempSkill.enterpriseId.durationStay,
    		         "phoneNo": tempSkill.enterpriseId.phoneNo,
    		         "primarySkill": tempSkill.enterpriseId.primarySkill,
    		         "secondarySkill": tempSkill.enterpriseId.secondarySkill,
    		         "proficiencyLevel": tempSkill.enterpriseId.proficiencyLevel,
    		         "lockType": tempSkill.enterpriseId.lockType,
    		         "employeeStatus": 2,
    		         "employeeType": tempSkill.enterpriseId.employeeType,
    		         "rollonDate": tempSkill.enterpriseId.rollonDate,
    		         "rollonBy": tempSkill.enterpriseId.rollonBy,
    		         "rolloffDate": tempSkill.enterpriseId.rolloffDate,
    		         "rolloffReason": tempSkill.enterpriseId.rolloffReason,
    		         "rolledoffBy": tempSkill.enterpriseId.rolledoffBy,
    		         "createdBy": tempSkill.enterpriseId.createdBy,
    		         "createdOn": tempSkill.enterpriseId.createdOn,
    		         "modifiedBy": commonService.getUserIdService(),
    		         "modifiedOn": new Date().getTime(),
    		         "active": true,
    		         "exit": false
                };

                employeeData.push(finalTempSkill);
            };
            
            return employeeData;
        	
        }
        
        function prepareTaskDataCreate(taskRequestData) {
            var finalData = {
        		"taskName": "Onboard Employee",
        		"taskDescription": "Onboard Employees",
        		"requestType": "Resource",
        		"subrequestType": "On boarding",
        		"approvedBy": "",
        		"approvedOn": "",
        		"approverComments": "",
        		"assignedTo": "",
        		"assignedOn": "",
        		"status": "New",
        		"comments": "Please onboard the employees",
        		"createdBy": commonService.getUserIdService(),
        		"createdOn": new Date().getTime(),
        		"active": true
            };
            console.log(finalData);

            return finalData;
        }
        
        function prepareTaskDataOffboardCreate(taskRequestData) {
            var finalData = {
        		"taskName": "Offboard - "+taskRequestData.enterpriseId.enterpriseId ,
        		"taskDescription": "Offboard below employee \n\tEnterprise Id - "+taskRequestData.enterpriseId.enterpriseId+"\n\tRoll Off Date - "+moment(taskRequestData.rolloffDate).format("MM-DD-YYYY")+"\n\tRoll off Reason - "+taskRequestData.rolloffReason,
        		"requestType": "Resource",
        		"subrequestType": "Off boarding",
        		"approvedBy": "",
        		"approvedOn": null,
        		"approverComments": "",
        		"assignedTo": "",
        		"assignedOn": null,
        		"status": "New",
        		"comments": "Please offboard the employee - "+taskRequestData.enterpriseId.enterpriseId,
        		"createdBy": commonService.getUserIdService(),
        		"createdOn": new Date().getTime(),
        		"active": true
            };
            console.log(finalData);

            return finalData;
        }
        
        function createTaskRollOff(rollOffData){
        	var finalData = {
            		"taskName": "Roll Off - "+rollOffData.enterpriseId ,
            		"taskDescription": "Roll Off below employee \n\tEnterprise Id - "+rollOffData.enterpriseId+"\n\tRoll Off Date - "+moment(rollOffData.rolloffDate).format("MM-DD-YYYY")+"\n\tRoll off Reason - "+rollOffData.rolloffReason,
            		"requestType": "Resource",
            		"subrequestType": "Roll Off",
            		"approvedBy": "",
            		"approvedOn": null,
            		"approverComments": "",
            		"assignedTo": "",
            		"assignedOn": null,
            		"status": "New",
            		"comments": "Please rolloff the employee - "+rollOffData.enterpriseId,
            		"createdBy": commonService.getUserIdService(),
            		"createdOn": new Date().getTime(),
            		"active": true
                };
                console.log(finalData);

                return finalData;
        }
        
        function prepareAllTaskDataCreate(tableData){
        	var taskData = [];
        	for (var i = 0; i < tableData.length; i++) {
                var tempSkill = tableData[i];
                var finalTempSkill = {
					"id": null ,
					"taskName": "Onboard - "+tempSkill.enterpriseId.enterpriseId,
					"taskDescription": "Onboard below employee \n\tEnterprise Id - "+tempSkill.enterpriseId.enterpriseId+"\n\tLocation - "+tempSkill.location.locationName+"\n\tResource Manager - "+tempSkill.resourceManager.resourceManager+"\n\tRole - "+tempSkill.roleId.role+"\n\tRate - "+tempSkill.roleId.rate,
					"requestType": "Resource",
					"subrequestType": "On Boarding",
					"approvedBy": "",
					"approvedOn": null,
					"approverComments": "",
					"assignedTo": "",
					"assignedOn": null,
					"status": "New",
					"comments": "Please onboard the employee - "+tempSkill.enterpriseId.enterpriseId,
					"createdBy": commonService.getUserIdService(),
					"createdOn": new Date().getTime(),
					"modifiedBy": commonService.getUserIdService(),
					"modifiedOn": new Date().getTime(),
					"active": true
                };

                taskData.push(finalTempSkill);
            };
            
            return taskData;
        }
        
        function createLoginData(rollOffData){
        	var loginFinalData = {
			  "id": rollOffData.id,
			  "employeeNumber": rollOffData.employeeNumber,
			  "enterpriseId": rollOffData.enterpriseId,
			  "password": rollOffData.employeeNumber,
			  "userTypeId": 6,
			  "lastLogin": new Date().getTime()
        	};
        	return loginFinalData;
        }
        
        function createEmailRollOff(rollOffData, selectmodel){
        	var finalData = {
            		"fromAddress": "pmo2@accenture.com",
            		"toAddress": "pmo@accenture.com",
            		"cc": (rollOffData.supervisorEntId !== undefined && rollOffData.supervisorEntId !== "" && rollOffData.supervisorEntId !== "NULL") ? rollOffData.supervisorEntId +"@accenture.com" : "",
            		"bcc": "sample@accenture.com",
            		"createdDate": new Date().getTime(),
            		"createdBy": new Date().getTime(),
            		"sentDate": new Date().getTime(),
            		"status": "New",
            		"active": true
            	};
        	if(selectmodel.notify === "true"){
        		finalData.cc = finalData.cc +";"+rollOffData.enterpriseId+"@accenture.com"
        	}

            return finalData;
        }
        
        
        
    }
})();
(function() {
    'use strict';
    angular
        .module('app.rollOn')
        .run(appRun);

    /* @ngInject */
    function appRun(routerHelper) {
        routerHelper.configureStates(getStates());
    }

    function getStates() {
        return [/*{
            state: 'rollOn',
            config: {
                url: '/rollOn',
                views: {
                    'main': {
                        templateUrl:"./roll-on/rollOn.html",
                        controller:"RollOnController as vm"
                    }
                }
            }
        },*/
        {
            state: 'rollOnCheckListAdd',
            config: {
                url: '/rollOnCheckListAdd',
                views: {
                    'main': {
                        templateUrl:"./app/roll-on/rollOnCheckListAdd.html",
                        controller:"RollOnCheckListAddController as vm"
                    }
                }
            }
        }];
    }
})();
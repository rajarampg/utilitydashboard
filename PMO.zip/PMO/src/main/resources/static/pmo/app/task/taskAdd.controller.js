(function() {

    angular
        .module('app.task')
        .controller('taskAddController', taskAddController);

    /**
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    taskAddController.$inject = ["taskDataService", "$mdToast", "taskWebService", "$state", "$stateParams", "emailWebService", "commonService", "loginWebService"];

    function taskAddController(taskDataService, $mdToast, taskWebService, $state, $stateParams, emailWebService, commonService, loginWebService) {
        var vm = this;
        vm.submitted = false;
        vm.editButtonEnable = false;
        vm.id = ($stateParams.id !== undefined) ? $stateParams.id : "create";
        vm.view = $stateParams.view;
        vm.assignedTo = [];
        vm.title = (vm.id === "create") ? "Task Add" : "Task Update";
        vm.userType = commonService.getUserTypeService();
        vm.userId = commonService.getUserIdService();
        vm.requestType = taskDataService.getRequestOptions();
        vm.subRequestTypeData = taskDataService.getSubRequestOptions();
        vm.selectmodel = taskDataService.getTaskModel();
        vm.onClickSubmitAllSkills = onClickSubmitAllSkills;
        vm.getSubRequestType = getSubRequestType;
        vm.statusType = taskDataService.getStatusOptions();
        if(vm.userType === "1" || vm.userType === "4"){
        	
        }
        vm.subRequestDisable = true;
        if(vm.id !== "create"){
        	taskWebService.gettaskWebService(vm.id).then(function(response){
        		vm.selectmodel = {};
            	vm.selectmodel = response;
            	vm.editButtonEnable = false;
            	vm.selectmodel.assignedOn = (response.assignedOn !== null) ? moment(new Date(response.assignedOn)).format("MM/DD/YYYY") : null;
            	if(vm.userType === "1" || vm.userType === "4"){
            		loginWebService.getViewAllWebService().then(function(responseAssignedTo){
                		vm.assignedTo = [];
                		angular.forEach(responseAssignedTo, function(value){
                			if(value.userTypeId === 3 || value.userTypeId === 4){
                				vm.assignedTo.push(value);
                				
                			}
                		});
                		angular.forEach(vm.assignedTo, function(value){
                			if(value.enterpriseId === response.assignedTo){
                				vm.selectmodel.assignedTo = {
                    					$$hashKey: value.$$hashKey,
                    					employeeNumber: value.employeeNumber,
                    					enterpriseId: value.enterpriseId,
                						id: value.id,
                    					lastLogin: value.lastLogin,
                    					password: value.password,
                    					userTypeId: value.userTypeId
                    			};
                			}
                		});
                	});
            	}
            	if(response.requestType !== ""){
            		angular.forEach(vm.requestType, function(value){
            			if(response.requestType === value.requestName){
            				vm.selectmodel.requestType = {
                					id: value.id,
                        			requestName : response.requestType
                        	};
            				vm.getSubRequestType(vm.selectmodel.requestType);
            			}
            		});
            	}
            	if(response.status !== ""){
            		angular.forEach(vm.statusType, function(value){
            			if(response.status === value.statusName){
            				vm.selectmodel.status = {
                					id: value.id,
                					statusName : response.status
                        	};
            			}
            		});
            	}
            	
            	console.log("vm.selectmodel", vm.selectmodel);
            });
        }
        
        function onClickSubmitAllSkills() {
    		if(vm.id === "create"){
    			if(vm.taskAddForm.$valid){
		    		vm.submitted = false;
		    		var createTaskData = taskDataService.prepareFinalSubmitDataCreate(vm.selectmodel);
		            taskWebService.posttaskWebService({
		                data: createTaskData
		            }).then(function(success) {
		                vm.showSimpleToast("Task Created Successfully");
		                var createEmailData =  taskDataService.prepareEmailCreate(createTaskData);
		            	createEmailData.subject = createTaskData.taskName+"-"+createTaskData.requestType+"("+createTaskData.subrequestType+")";
		            	createEmailData.contentDetails = "<html><title>"+createTaskData.taskName+"-"+createTaskData.requestType+"("
		                										+createTaskData.subrequestType+")"+"</title><body>Hi,</br></br>Task Name: "+
		                										createTaskData.taskName+"</br></br>Task Description: <p>"+createTaskData.taskDescription+".</p>" +
		        												"</br>Created By: "+createTaskData.createdBy+"</br>Created on: "+moment(createTaskData.createdOn).format("DD/MM/YYYY")+"</br></br>Thanks,</br>PMO Team.</body></html>";
		                    	
		            	emailWebService.postEmailWebServiceCreate({
		                    data: createEmailData
		                }).then(function(success) {
		                	$state.go("taskSearch", {
		                		getSearchData: createTaskData.createdBy,
		                        view: "search"
		                	});
		                }, function(error) {
		                	console.log(error);
		                });
		            }, function(error) {
		               	console.log(error);
		            });
    			}else{
            		vm.submitted = true;
    			}
        	}else if(vm.id !== "create"){
        		if(vm.editButtonEnable){
        			vm.editButtonEnable = false;
        		}else {
        			if(vm.taskAddForm.$valid){
            			var updateTaskData = taskDataService.prepareFinalSubmitDataUpdate(vm.selectmodel);
                        taskWebService.posttaskWebServiceUpdate({
                            data: updateTaskData
                        }).then(function(success) {
                            vm.showSimpleToast("Task Updated Successfully");
                            vm.editButtonEnable = true;
                            $state.go("taskSearch");
                        }, function(error) {
                        	console.log(error);
                        });
        			}else{
                		vm.submitted = true;
                	}
        		}
        	}
           /*var data = taskDataService.testData();
            $state.go("taskSearch", {
        		getSearchData: createDemandData.createdBy,
        		view: "search"
        	});*/
        }
        
        function getSubRequestType(requestType){
        	vm.subRequestDisable = false;
        	vm.subRequestType = vm.subRequestTypeData[0][requestType.id];
        }
        
        
        vm.showSimpleToast = function(message) {

            $mdToast.show(
                $mdToast.simple()
                .textContent(message)
                /*.position("center")*/
                .hideDelay(3000)
            );
        };
        
    }
})();
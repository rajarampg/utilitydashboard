(function () {
    'use strict';
    angular
        .module('app.patternDetails')
        .controller('patternDetailsAddController', patternDetailsAddController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    patternDetailsAddController.$inject = ["patternDetailsDataService", "$mdToast", "patternDetailsWebService", "$state", "$stateParams"];

    function patternDetailsAddController(patternDetailsDataService, $mdToast, patternDetailsWebService, $state, $stateParams) {

        var vm = this;

        vm.submitted = false;
        vm.editButtonEnable = false;
        vm.selectmodel = patternDetailsDataService.getPatternDetailsModel();
        vm.onClickSubmitPatternDetails = onClickSubmitPatternDetails;
        vm.portfolios = patternDetailsDataService.getPortfolioOptions();
        vm.id = ($stateParams.id !== undefined) ? $stateParams.id : "create";

        if (vm.id !== "create") {
            patternDetailsWebService.getPatternWebService(vm.id).then(function (response) {
                vm.selectmodel = {};
                vm.selectmodel = response;
                vm.editButtonEnable = false;
                vm.selectmodel.createdOn = new Date(moment(vm.selectmodel.createdOn).format());
                vm.selectmodel.modifiedOn = new Date(moment(vm.selectmodel.modifiedOn).format());
                angular.forEach(vm.portfolios, function(value){
                    if(value.id === response.portfolioId){
                        vm.selectmodel.portfoliosModel = {
                            id: value.id,
                            portfolioName: value.portfolioName
                        }
                    }
                });

            });
        }

        function onClickSubmitPatternDetails() {
            if (vm.id === "create") {
                if (vm.patternDetailsAddForm.$valid) {
                    vm.submitted = false;
                    var createPatternDetailsData = patternDetailsDataService.prepareFinalSubmitDataCreate(vm.selectmodel);
                    patternDetailsWebService.postPatternWebService({
                        data: createPatternDetailsData
                    }).then(function (success) {
                        vm.showSimpleToast("Pattern Details Submitted");
                        $state.go("patternDetailsSearch", {
                            getSearchData: createPatternDetailsData.createdBy,
                            view: "search"

                        }, function (error) {
                            console.log(error);
                        });
                    });
                } else {
                    vm.submitted = true;
                }
            }
            else if (vm.id !== "create") {
                if (vm.editButtonEnable) {
                    vm.editButtonEnable = false;
                } else {
                    if (vm.patternDetailsAddForm.$valid) {
                        var updatePatternDetailsData = patternDetailsDataService.prepareFinalSubmitDataUpdate(vm.selectmodel);
                        patternDetailsWebService.postPatternWebServiceUpdate({
                            data: updatePatternDetailsData
                        }).then(function (success) {
                            vm.showSimpleToast("Pattern Details Updated Successfully");
                            vm.editButtonEnable = true;
                            $state.go("patternDetailsSearch");
                        }, function (error) {
                            console.log(error);
                        });
                    } else {
                        vm.submitted = true;
                    }
                }

            }

        }
        vm.showSimpleToast = function (message) {
            $mdToast.show(
                $mdToast.simple()
                    .textContent(message)
                    /*.position("
                        center ")*/
                    .hideDelay(3000)
            );
        };
    }
})();
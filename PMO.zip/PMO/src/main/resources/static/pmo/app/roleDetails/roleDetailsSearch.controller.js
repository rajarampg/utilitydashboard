(function () {

	angular
		.module('app.roleDetails')
		.controller('roleDetailsSearchController', roleDetailsSearchController);

	/**
		 * Main Controller for the Angular Material Starter App
		 * @param $scope
		 * @param $mdSidenav
		 * @param avatarsService
		 * @constructor
		 */
	roleDetailsSearchController.$inject = ["roleDetailsDataService", "$timeout", "$scope", "$stateParams", "roleDetailsWebService", "$state"];

	function roleDetailsSearchController(roleDetailsDataService, $timeout, $scope, $stateParams, roleDetailsWebService, $state) {
		var vm = this;

		vm.roleDetailsfilterFlag = false;
		vm.exportToExcel = exportToExcel;
		vm.exportFile = exportFile;
		vm.navigateToAdd = navigateToAdd;
		vm.getSearchData = $stateParams.getSearchData;
		vm.view = $stateParams.view;
		vm.limitOptions = [5, 10, 15, 25];

		/*if (vm.view !== undefined && vm.view === "search") {
			roleDetailsWebService.getRoleDetailsWebService(vm.getSearchData).then(function (response) {
				vm.role_details = response;
				vm.roleDetailsFiltered = vm.role_details;
			});
		} else {*/
			roleDetailsWebService.getAllRoleDetailsRequest().then(function (response) {
				vm.role_details = response;
				angular.forEach(response, function(data){
                angular.forEach(vm.location, function (value) {
                    if (value.id === data.locationId) {
                        data.locationName = value.locationName;
                    }
                });
            });
			vm.roleDetailsFiltered = vm.role_details;

			});


		vm.fieldName = {
			"order": "-createdOn",
			"tableDetails": [
				{
					"type": "link",
					"label": "Role",
					"name": "role",
					"orderBy": true,
					"url": "roleDetailsView",
					"displayField": "role"
				}, {
					"type": "label",
					"label": "roleDescription",
					"name": "roleDescription",
					"orderBy": true,
					"displayField": "roleDescription"
				}, {
					"type": "label",
					"label": "Location",
					"name": "location",
					"orderBy": true,
					"displayField": "location"
				}, {
					"type": "label",
					"label": "Rate",
					"name": "rate",
					"orderBy": true,
					"displayField": "rate"
				}, {
					"type": "datelabel",
					"label": "Created On",
					"name": "createdOn",
					"orderBy": true,
					"displayField": "createdOn"
				}, {
					"type": "label",
					"label": "Created By",
					"name": "createdBy",
					"orderBy": true,
					"displayField": "createdBy"
				}, {
					"type": "edit",
					"label": "",
					"name": "",
					"orderBy": true,
					"url": "roleDetailsAdd",
					"urlParams": {
						view: "update"
					},
					"displayField": "Edit"
				}]
		};

		function exportToExcel(tableId) { // ex: '#my-table'
			var exportHref = ExporttoExcel.tableToExcel(tableId, 'WireWorkbenchDataExport');
			$timeout(function () { location.href = exportHref; }, 100); // trigger download
		}
		
		function navigateToAdd(){
			$state.go("roleDetailsAdd");
		}

		function exportFile() {
			console.log("vm.role_details", vm.role_details);
			angular.forEach(vm.role_details, function (value) {
				value.createdOn = moment(new Date(value.createdOn)).format("MM/DD/YYYY");
				value.modifiedOn = moment(new Date(value.modifiedOn)).format("MM/DD/YYYY");
			});
			var arrData = typeof vm.role_details != 'object' ? JSON.parse(vm.role_details) : vm.role_details;
			var CSV = '';
			CSV += "download" + '\r\n\n';
			var row = "";
			for (var index in arrData[0]) {
				row += index + ',';
			}
			row = row.slice(0, -1);
			CSV += row + '\r\n';
			for (var i = 0; i < arrData.length; i++) {
				var row = "";
				for (var index in arrData[i]) {
					row += '"' + arrData[i][index] + '",';
				}
				row.slice(0, row.length - 1);
				CSV += row + '\r\n';
			}
			if (CSV == '') {
				alert("Invalid data");
				return;
			}
			var fileName = "download";
			var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
			var link = document.createElement("a");
			link.href = uri;
			link.style = "visibility:hidden";
			link.download = fileName + ".csv";
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
		}

	}

})();
(function() {

    angular
        .module('app.task')
        .controller('taskViewController', taskViewController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    taskViewController.$inject = ["taskWebService", "$scope", "$stateParams", "$state", "$rootScope", "commonService"];

    function taskViewController(taskWebService, $scope, $stateParams, $state, $rootScope, commonService) {
        var vm = this;
        vm.editTaskDetails = editTaskDetails;
        vm.id = $stateParams.id;
        vm.userType = commonService.getUserTypeService();
        vm.userId = commonService.getUserIdService();
     
        taskWebService.gettaskWebService(vm.id).then(function(response){
        	vm.selectmodel = response;
        	vm.selectmodel.createdOn = moment(new Date(response.createdOn)).format("MM/DD/YYYY");
        	vm.selectmodel.assignedOn = (response.assignedOn !== null) ? moment(new Date(response.assignedOn)).format("MM/DD/YYYY") : null;
        });
        
        function editTaskDetails(){
        	
        	$state.go('taskAdd', {
        		id: vm.id,
        		view: "update"
        	});
        	
        };
    }
})();
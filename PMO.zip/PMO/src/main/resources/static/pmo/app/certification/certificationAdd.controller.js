(function () {

    angular
        .module('app.certification')
        .controller('certificationAddController', certificationAddController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    certificationAddController.$inject = ["certificationDataService", "$mdToast", "certificationWebService", "$state", "$stateParams"];

    function certificationAddController(certificationDataService, $mdToast, certificationWebService, $state, $stateParams) {

        var vm = this;

        vm.submitted = false;
        vm.editButtonEnable = false;
        vm.selectmodel = certificationDataService.getCertificationModel();
        vm.onClickSubmitCertificationDetails = onClickSubmitCertificationDetails;
        vm.id = ($stateParams.id !== undefined) ? $stateParams.id : "create";

        if (vm.id !== "create") {
            certificationWebService.getCertificationWebService(vm.id).then(function (response) {
                vm.selectmodel = {};
                vm.selectmodel = response;
                vm.selectmodel.certificationDate = new Date(moment(vm.selectmodel.certificationDate).format());
                vm.selectmodel.approvedOn = (vm.selectmodel.approvedOn !== null) ? new Date(moment(vm.selectmodel.approvedOn).format()) : vm.selectmodel.approvedOn;
                vm.selectmodel.createdOn = new Date(moment(vm.selectmodel.createdOn).format());
                vm.selectmodel.modifiedOn = new Date(moment(vm.selectmodel.modifiedOn).format());
                vm.editButtonEnable = false;

            });
        }

        function onClickSubmitCertificationDetails() {
            if (vm.id === "create") {
                if (vm.certificationAddForm.$valid) {
                    vm.submitted = false;
                    var createCertificationData = certificationDataService.prepareFinalSubmitDataCreate(vm.selectmodel);
                    certificationWebService.postCertificationWebService({
                        data: createCertificationData
                    }).then(function (success) {
                        vm.showSimpleToast("Certification Details Submitted");
                        $state.go("certificationSearch", {
                            getSearchData: createCertificationData.assignedTo,
                            view: "search"
                            
                    }, function (error) {
                        console.log(error);
                        });
                    });
                } else {
                    vm.submitted = true;
                }
            }
            else if (vm.id !== "create") {
                if (vm.editButtonEnable) {
                    vm.editButtonEnable = false;
                } else {
                    if (vm.certificationAddForm.$valid) {
                        var updateCertificationData = certificationDataService.prepareFinalSubmitDataUpdate(vm.selectmodel);
                        certificationWebService.postCertificationWebServiceUpdate({
                            data: updateCertificationData
                        }).then(function (success) {
                            vm.showSimpleToast("Certification Details Updated Successfully");
                            vm.editButtonEnable = true;
                            $state.go("certificationSearch");
                        }, function (error) {
                            console.log(error);
                        });
                    } else {
                        vm.submitted = true;
                    }
                }

            }
            vm.showSimpleToast = function (message) {

                $mdToast.show(
                    $mdToast.simple()
                        .textContent(message)
                        /*.position("
                            center ")*/
                        .hideDelay(3000)
                );
            };
        }
    }
})();
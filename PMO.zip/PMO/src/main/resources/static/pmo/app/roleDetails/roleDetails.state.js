(function(){
    'use strict';
    angular
        .module('app.roleDetails')
        .run(appRun);

    /* @ngInject */

    function appRun(routerHelper){
        routerHelper.configureStates(getStates());
    }

    function getStates(){

        return [
            {
                state: 'roleDetailsAdd',
                config: {
                    url: '/roleDetailsAdd?id&view',
                    views: {
                        'main': {
                            templateUrl: "./app/roleDetails/roleDetailsAdd.html",
                            controller: "roleDetailsAddController as vm"
                        }
                    }
                }
            }, {
                state: 'roleDetailsSearch',
                config: {
                    url: '/roleDetailsSearch?getSearchData&view',
                    views: {
                        'main': {
                            templateUrl: "./app/roleDetails/roleDetailsSearch.html",
                            controller: "roleDetailsSearchController as vm"
                        }
                    }
                }
            }, {
                state: 'roleDetailsView',
                config: {
                    url: '/roleDetailsView?id',
                    views: {
                        'main': {
                            templateUrl: "./app/roleDetails/roleDetailsView.html",
                            controller: "roleDetailsViewController as vm"
                        }
                    }
                }
            }
        ];
    }

})();
(function() {
    "use strict";

    angular.module("app.webservices").factory('baseWebService', baseWebService)

    baseWebService.$inject = ["$http", "$q"];

    function baseWebService($http, $q) {
        var service = {
            callRestService: callRestService
        };

        return service;


        function buildUrl(endPoint) {
            var appServices = "http://10.220.86.227:8080/PMO";
            return appServices + endPoint;
        }

        function callRestService(options) {
            var deferred = $q.defer();
            var request = {
                "url": buildUrl(options.url),
                "method": options.method,
                headers: {
                    "Content-Type": 'application/json'
                    
                }
            };

            if (options.method == "POST") {
                request.data = JSON.stringify(options.data);
            }

            $http(request).then(function(response) {

                deferred.resolve(response.data);

            }, function(error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }
    };
})();
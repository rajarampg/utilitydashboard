(function() {
    'use strict';
    angular
        .module('app.demandRequest')
        .run(appRun);

    /* @ngInject */
    function appRun(routerHelper) {
        routerHelper.configureStates(getStates());
    }

    function getStates() {
        return [{
            state: 'demandAdd',
            config: {
                url: '/demandAdd?id',
                views: {
                    'main': {
                        templateUrl:"./app/demand-request/demandRequest.html",
                        controller:"DemandRequestController as vm"
                    }

                }

            }
        },{
            state: 'demandView',
            config: {
                url: '/demandView?id&view',
                views: {
                    'main': {
                        templateUrl:"./app/demand-request/demandRequestView.html",
                        controller:"DemandRequestViewController as vm"
                    }

                }

            }
        },{
            state: 'demandSearch',
            config: {
                url: '/demandSearch',
                views: {
                    'main': {
                        templateUrl:"./app/demand-request/demandRequestSearch.html",
                        controller:"DemandRequestSearchController as vm"
                    }

                }

            }
        }];
    }
})();
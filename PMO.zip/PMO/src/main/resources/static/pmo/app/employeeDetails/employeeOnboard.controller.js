(function() {

    angular
        .module('app.employeeDetails')
        .controller('employeeOnboardController', employeeOnboardController);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    employeeOnboardController.$inject = ["$state", "employeeDetailsDataService", "employeeDetailWebService", "$mdToast", "taskWebService"];

    function employeeOnboardController($state, employeeDetailsDataService, employeeDetailWebService, $mdToast, taskWebService) {
        var vm = this;
        vm.getResourceManager= getResourceManager;
        vm.populateValueBasedRM = populateValueBasedRM;
        vm.populateEmployeeDetail = populateEmployeeDetail;
        vm.getRoleDetails = getRoleDetails;
        vm.onClickAddRow = onClickAddRow;
        vm.removeRow = removeRow;
        vm.addOnboardDetails = addOnboardDetails;
        vm.getRate = getRate;
        vm.selectmodel = employeeDetailsDataService.getOffboardSelectModel();
        vm.portfolios = employeeDetailsDataService.getPortfolioOptions();
        vm.primarySkill = employeeDetailsDataService.getPrimarySkillOptions();
        vm.locationOptions = employeeDetailsDataService.getLocationOptions();
        vm.resourceManager = [];
        vm.employee = [];
        vm.roleDetails = [];
        vm.contractDetails = [];
        vm.patternDetails =[];
        vm.array_table = [];
        vm.submitted = false;
        
        vm.limitOptions = [5, 10, 15, 25];
        
        vm.options = {
          rowSelection: true,
          multiSelect: true,
          autoSelect: true,
          decapitate: false,
          largeEditDialog: false,
          boundaryLinks: false,
          limitSelect: true,
          pageSelect: true
        };
        
        vm.query = {
          order: '-lastLogin',
          limit: 5,
          page: 1
        };
        
        
        function getResourceManager(portfolioModel){
        	if(portfolioModel !== undefined && portfolioModel !== ""){
        		vm.selectmodel.firstName = "";
        		vm.selectmodel.lastName = "";
        		vm.selectmodel.vicePresident =  "";
            	vm.selectmodel.directorId =  "";
            	vm.contractDetails = [];
            	employeeDetailWebService.getAllResourceManagerBasedOnportfolio(portfolioModel.id).then(function(resourceManager){
            		vm.resourceManager = [];
            		angular.forEach(resourceManager, function(value){
            			if(portfolioModel.id === value.portfolioId){
            				vm.resourceManager.push(value);
            			}
            		});
            	});
            	employeeDetailWebService.getAllPatternDetails().then(function(patternDetails){
            		vm.patternDetails = [];
            		angular.forEach(patternDetails, function(value){
            			if(portfolioModel.id === value.portfolioId){
            				vm.patternDetails.push(value);
            			}
            		});
            	});
            	employeeDetailWebService.getAllEmployeeDetailsWebService().then(function(response){
            		vm.employee = [];
            		angular.forEach(response, function(value){
            			if(portfolioModel.id === value.portfolioId){
            				vm.employee.push(value);
            			}
            		});
            	});
        	}else{
        		vm.selectmodel.firstName = "";
        		vm.selectmodel.lastName = "";
        		vm.selectmodel.vicePresident =  "";
            	vm.selectmodel.directorId =  "";
            	vm.resourceManager = [];
            	vm.patternDetails = [];
            	vm.employee = [];
            	vm.contractDetails = [];
        	}
        	
        }
        
        function populateValueBasedRM(resourceManagerModel){
        	vm.contractDetails = [];
        	vm.selectmodel.vicePresident =  resourceManagerModel.vicePresident;
        	vm.selectmodel.directorId =  resourceManagerModel.directorId;
        	vm.contractDetails.push(resourceManagerModel.contractId);
        }
        
        function populateEmployeeDetail(enterpriseIDModel){
        	vm.selectmodel.employeeNumber = enterpriseIDModel.employeeNumber;
        	vm.selectmodel.firstName = enterpriseIDModel.firstName;
        	vm.selectmodel.lastName = enterpriseIDModel.lastName;
        	employeeDetailWebService.getEmployeeClientDetailByEntIdWebService(enterpriseIDModel.employeeNumber).then(function(response){
        		vm.selectmodel.clientDetailsEmp = response;
        	});
        	
        }
        
        function getRoleDetails(locationModel){
        	employeeDetailWebService.getAllRoleDetails().then(function(response){
        		vm.roleDetails = [];
        		angular.forEach(response, function(value){
        			if(locationModel.locationName === value.location){
        				vm.roleDetails.push(value);
        			}
        		});
        	});
        }
        
        function onClickAddRow(){
        	if(vm.employeeOnboardForm.$valid){
        		vm.submitted = false;
        		vm.showSimpleToast("Employee Client Details updated to Table");
                vm.array_table.push(angular.copy(vm.selectmodel));
                vm.employeeOnboardForm.$setPristine();
                vm.employeeOnboardForm.$setUntouched();
                //vm.selectmodel = initSelectModel();
                vm.selectmodel.firstName = "";
                vm.selectmodel.lastName =  "";
                vm.selectmodel.enterpriseId =  "";
                vm.selectmodel.rate =  "";
                vm.selectmodel.employeeNumber = "";
                vm.selectmodel.location = "";
                vm.selectmodel.roleId = "";
                vm.roleDetails = [];
                //vm.getResourceManager();
        	}else{
        		vm.submitted = true;
        	}
        }
        
        function removeRow(item, event){
        	if(vm.array_table.length > 0){
        		angular.forEach(vm.array_table, function(value, key){
        			if(value.$$hashKey === item.$$hashKey){
        				vm.array_table.splice(key, 1);
        			}
        		});
        	}
        	console.log("vm.array_table", vm.array_table);
        	console.log("item", item);
        }
        
        function initSelectModel() {
        	vm.submitted = false;
            return angular.copy(employeeDetailsDataService.getOnboardSelectModelReset());
        }
        
        function getRate(roleModel){
        	vm.selectmodel.rate = "";
        	vm.selectmodel.rate = roleModel.rate;
        }
        
        function addOnboardDetails(selectmodel, tableData){
        	console.log("selectedmodel", selectmodel);
        	console.log("tableData", tableData);
        	var createOnboardClientData = employeeDetailsDataService.getEmpClientDetails(selectmodel, tableData);
        	employeeDetailWebService.postUpdateAllClientDetails({
                data: createOnboardClientData
            }).then(function(success) {
            	var createOnboardEmpData = employeeDetailsDataService.getEmpDetails(selectmodel, tableData);
            	employeeDetailWebService.postUpdateAllEmpDetails({
                   data: createOnboardEmpData
                }).then(function(success) {
                	vm.showSimpleToast("Employee Onboard Initiated");
                	var employeeMailCreate = employeeDetailsDataService.prepareEmailOnboardCreate(tableData);
                	employeeMailCreate.subject = "";
	                employeeMailCreate.contentDetails = ""
                	employeeDetailWebService.postAllEmailWebServiceCreate({
	                    data: employeeMailCreate
	                }).then(function(success) {
	                	var taskCreate = employeeDetailsDataService.prepareAllTaskDataCreate(tableData);
	                	employeeDetailWebService.postAllTaskWebService({
		                    data: taskCreate
		                }).then(function(success) {
		                	  $state.go("employeeDetailsSearch");
		                }, function(error) {
		                	console.log(error);
		                });
	                }, function(error) {
	                	console.log(error);
	                });
                }, function(error) {
                	console.log(error);
                });
            }, function(error) {
            	console.log(error);
            });
        }
        
        vm.showSimpleToast = function(message) {

            $mdToast.show(
                $mdToast.simple()
                .textContent(message)
                /*.position("
                    center ")*/
                .hideDelay(3000)
            );
        };
    }
})();
(function(){
    'use strict';
    angular
        .module('app.portfolioDetails')
        .run(appRun);

    /* @ngInject */

    function appRun(routerHelper){
        routerHelper.configureStates(getStates());
    }

    function getStates(){

        return [
            {
                state: 'portfolioDetailsAdd',
                config: {
                    url: '/portfolioDetailsAdd?id&view',
                    views: {
                        'main': {
                            templateUrl: "./app/portfolioDetails/portfolioDetailsAdd.html",
                            controller: "portfolioDetailsAddController as vm"
                        }
                    }
                }
            }, {
                state: 'portfolioDetailsSearch',
                config: {
                    url: '/portfolioDetailsSearch?getSearchData&view',
                    views: {
                        'main': {
                            templateUrl: "./app/portfolioDetails/portfolioDetailsSearch.html",
                            controller: "portfolioDetailsSearchController as vm"
                        }
                    }
                }
            }, {
                state: 'portfolioDetailsView',
                config: {
                    url: '/portfolioDetailsView?id',
                    views: {
                        'main': {
                            templateUrl: "./app/portfolioDetails/portfolioDetailsView.html",
                            controller: "portfolioDetailsViewController as vm"
                        }
                    }
                }
            }
        ];
    }

})();
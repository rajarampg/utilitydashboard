(function () {
    'use strict';

    angular
        .module('app.roleDetails')
        .factory('roleDetailsDataService', roleDetailsDataService);

    roleDetailsDataService.$inject = ["commonService"];

    /* @ngInject */
    function roleDetailsDataService(commonService) {
        var service = {
            getLocationOptions: getLocationOptions,
            getRoleModel: getRoleModel,
            prepareFinalSubmitDataCreate: prepareFinalSubmitDataCreate,
            prepareFinalSubmitDataUpdate: prepareFinalSubmitDataUpdate,
            testData: testData
        };
        return service;

        function getLocationOptions() {
            var location = [{
                id: "IDC",
                locationName: "IDC"
            }, {
                id: "Onshore",
                locationName: "Onshore"
            }];
            return location;
        }
        
        function getRoleModel() {
            var selectmodel = {
                role: "",
                roleDescription: "",
                location: "",
                rate: "",
                createdOn: null,
                createdBy: "",
                modifiedOn: null,
                modifiedBy: ""
            };
            return selectmodel;
        }
        function getFormatedDate(date) {
            var tempMoment = new Date(date).getTime();
            return tempMoment;
        };

        function prepareFinalSubmitDataCreate(roleDetailsRequest) {

            var finalData = {
                "role": roleDetailsRequest.role,
                "roleDescription": roleDetailsRequest.roleDescription,
                "location": roleDetailsRequest.location,
                "rate": roleDetailsRequest.rate,
                "createdBy": commonService.getUserIdService(),
                "createdOn": new Date().getTime(),
                "modifiedBy": commonService.getUserIdService(),
                "modifiedOn": new Date().getTime(),
                "active": "true"
            };
            console.log(finalData);
            return finalData;

        }

        function prepareFinalSubmitDataUpdate(roleDetailsRequest) {
            var finalData = {
                "id": roleDetailsRequest.id,
                "role": roleDetailsRequest.role,
                "roleDescription": roleDetailsRequest.roleDescription,
                "location": roleDetailsRequest.location,
                "rate": roleDetailsRequest.rate,
                "createdBy": roleDetailsRequest.createdBy,
                "createdOn": roleDetailsRequest.createdOn,
                "modifiedBy": commonService.getUserIdService(),
                "modifiedOn": new Date().getTime(),
                "active": roleDetailsRequest.active
            };
            console.log(finalData);
            return finalData;
        }

        function testData() {
            var data = {
                status: 200
            }
            return data;
        }
    }
})();
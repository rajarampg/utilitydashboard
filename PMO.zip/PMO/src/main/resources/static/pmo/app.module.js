(function () {
    'use strict';
    angular

        .module('app', ['ngMaterial', 'ui.router', 'md.data.table', 'app.blocks', 'app.webservices', 'app.login', 'app.sideNav', 'app.demandRequest', 'app.toolbar', 'app.task', 'app.widgets', 'app.asset', 'app.certification', 'app.employeeDetails','app.patternDetails', 'app.rollOn', 'app.roleDetails','app.portfolioDetails','app.employeeReport']).config(function ($mdThemingProvider, $mdIconProvider) {

            $mdIconProvider
                .defaultIconSet("./styles/images/avatars.svg", 128)
                .icon("menu", "./styles/images/menu.svg", 24)
                .icon("share", "./styles/images/share.svg", 24)
                .icon("google_plus", "./styles/images/google_plus.svg", 512)
                .icon("hangouts", "./styles/images/hangouts.svg", 512)
                .icon("twitter", "./styles/images/twitter.svg", 512)
                .icon("phone", "./styles/images/phone.svg", 512);

            $mdThemingProvider.theme('default')
                .primaryPalette('blue')
                .accentPalette('red');

        });

})();
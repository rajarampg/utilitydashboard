package com.accenture.mypmo.model;

import java.io.Serializable;
import java.sql.Date;

public class InnovationSkill implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int id;
	
	private String innovation_name;
	
	private String innovation_description;
	
	private String innovation_owner;
	
	private String approved_by;
	
	private Date approved_on;
	
	private String approver_comments;
	
	private String assigned_to;
	
	private Date assigned_on;
	
	private Date innovation_start_date;
	
	private Date innovation_end_date;
	
	private String status;
	
	private String comments;
	
	private String created_by;
	
	private Date created_on;
	
	private String modified_by;
	
	private Date modified_on;
	
	private boolean active;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getInnovation_name() {
		return innovation_name;
	}

	public void setInnovation_name(String innovation_name) {
		this.innovation_name = innovation_name;
	}

	public String getInnovation_description() {
		return innovation_description;
	}

	public void setInnovation_description(String innovation_description) {
		this.innovation_description = innovation_description;
	}

	public String getInnovation_owner() {
		return innovation_owner;
	}

	public void setInnovation_owner(String innovation_owner) {
		this.innovation_owner = innovation_owner;
	}

	public String getApproved_by() {
		return approved_by;
	}

	public void setApproved_by(String approved_by) {
		this.approved_by = approved_by;
	}

	public Date getApproved_on() {
		return approved_on;
	}

	public void setApproved_on(Date approved_on) {
		this.approved_on = approved_on;
	}

	public String getApprover_comments() {
		return approver_comments;
	}

	public void setApprover_comments(String approver_comments) {
		this.approver_comments = approver_comments;
	}

	public String getAssigned_to() {
		return assigned_to;
	}

	public void setAssigned_to(String assigned_to) {
		this.assigned_to = assigned_to;
	}

	public Date getAssigned_on() {
		return assigned_on;
	}

	public void setAssigned_on(Date assigned_on) {
		this.assigned_on = assigned_on;
	}

	public Date getInnovation_start_date() {
		return innovation_start_date;
	}

	public void setInnovation_start_date(Date innovation_start_date) {
		this.innovation_start_date = innovation_start_date;
	}

	public Date getInnovation_end_date() {
		return innovation_end_date;
	}

	public void setInnovation_end_date(Date innovation_end_date) {
		this.innovation_end_date = innovation_end_date;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}

	public String getModified_by() {
		return modified_by;
	}

	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}

	public Date getModified_on() {
		return modified_on;
	}

	public void setModified_on(Date modified_on) {
		this.modified_on = modified_on;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
	
}

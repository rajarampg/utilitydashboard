/**
 * 
 */
package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.CertificationDetails;
import com.accenture.mypmo.model.CertificationDetailsMapping;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class CertificationDetailsMapper {
	
	public CertificationDetailsMapping certificationDetailsMapper(CertificationDetails certDetails){
		
		CertificationDetailsMapping certMapping = new CertificationDetailsMapping();
		certMapping.setId(certDetails.getId());
		certMapping.setCertificationName(certDetails.getCertificationName());
		certMapping.setStream(certDetails.getStream());
		certMapping.setCertificationType(certDetails.getCertificationType());
		certMapping.setScore(certDetails.getScore());
		certMapping.setApprovedBy(certDetails.getApprovedBy());
		certMapping.setApprovedOn(certDetails.getApprovedOn());
		certMapping.setApproverComments(certDetails.getApproverComments());
		certMapping.setAssignedTo(certDetails.getAssignedTo());
		certMapping.setCertificationDate(certDetails.getCertificationDate());
		certMapping.setStatus(certDetails.getStatus());
		certMapping.setComments(certDetails.getComments());
		certMapping.setCreatedBy(certDetails.getCreatedBy());
		certMapping.setCreatedOn(certDetails.getCreatedOn());
		certMapping.setModifiedBy(certDetails.getModifiedBy());
		certMapping.setModifiedOn(certDetails.getModifiedOn());
		certMapping.setActive(certDetails.isActive());
		
		System.out.println(certMapping.toString());
		return certMapping;
	}
	

	public CertificationDetails certificationDetailsMapMapper(CertificationDetailsMapping certMapping){
		
		CertificationDetails certDetails = new CertificationDetails();
		certDetails.setId(certMapping.getId());
		certDetails.setCertificationName(certMapping.getCertificationName());
		certDetails.setStream(certMapping.getStream());
		certDetails.setCertificationType(certMapping.getCertificationType());
		certDetails.setScore(certMapping.getScore());
		certDetails.setApprovedBy(certMapping.getApprovedBy());
		certDetails.setApprovedOn(certMapping.getApprovedOn());
		certDetails.setApproverComments(certMapping.getApproverComments());
		certDetails.setAssignedTo(certMapping.getAssignedTo());
		certDetails.setCertificationDate(certMapping.getCertificationDate());
		certDetails.setStatus(certMapping.getStatus());
		certDetails.setComments(certMapping.getComments());
		certDetails.setCreatedBy(certMapping.getCreatedBy());
		certDetails.setCreatedOn(certMapping.getCreatedOn());
		certDetails.setModifiedBy(certMapping.getModifiedBy());
		certDetails.setModifiedOn(certMapping.getModifiedOn());
		certDetails.setActive(certMapping.isActive());
		
		System.out.println(certDetails.toString());
		return certDetails;
	}

	public List<CertificationDetailsMapping> certificationIterableCollection(Iterable<CertificationDetailsMapping> certificationDetailsResultSet){
		
		List <CertificationDetailsMapping> certificationDetailsMap = new ArrayList<CertificationDetailsMapping>();
		
		for(CertificationDetailsMapping certificationDetailsMapTemp:certificationDetailsResultSet){
			certificationDetailsMap.add(certificationDetailsMapTemp);
		}
		return certificationDetailsMap;
	}
	

	public List<CertificationDetails> certificationDetailsMapMapperCollection(List<CertificationDetailsMapping> certificationDetailsMap){
		List<CertificationDetails> certificationDetails = new  ArrayList<CertificationDetails>();
		System.out.println("certificationDetailsMapTemp - Before for loop");
		for (CertificationDetailsMapping certificationDetailsMapTemp : certificationDetailsMap) {
			System.out.println("certificationDetailsMapMapperCollection \n"+certificationDetailsMapTemp.toString()+"----");
			certificationDetails.add(certificationDetailsMapMapper(certificationDetailsMapTemp));
		}
		
		return certificationDetails;
	}
	
}

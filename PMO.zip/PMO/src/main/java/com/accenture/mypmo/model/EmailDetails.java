/**
 * 
 */
package com.accenture.mypmo.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Transient;

/**
 * @author p.senthilrajan
 *
 */
public class EmailDetails implements Serializable{

	public static final long serialVersionUID = 1L;

	private int id;

	private String fromAddress;
	
	private String toAddress;
	
	private String cc;
	
	private String bcc;
	
	private String subject;
	
	private String contentDetails;
	
	private Timestamp createdDate;
	
	private String createdBy;
	
	private Timestamp sentDate;
	
	private String status;
	
	private boolean active;
	
	@Transient
	private List<String> toIds;
	
	@Transient
	private List<String> ccIds;
	
	@Transient
	private List<String> bccIds;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFromAddress() {
		return fromAddress;
	}

	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}

	public String getToAddress() {
		return toAddress;
	}

	public void setToAddress(String toAddress) {
		this.toAddress = toAddress;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getBcc() {
		return bcc;
	}

	public void setBcc(String bcc) {
		this.bcc = bcc;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContentDetails() {
		return contentDetails;
	}

	public void setContentDetails(String contentDetails) {
		this.contentDetails = contentDetails;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getSentDate() {
		return sentDate;
	}

	public void setSentDate(Timestamp sentDate) {
		this.sentDate = sentDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public List<String> getToIds() {
		return toIds;
	}

	public void setToIds(List<String> toIds) {
		this.toIds = toIds;
	}

	public List<String> getCcIds() {
		return ccIds;
	}

	public void setCcIds(List<String> ccIds) {
		this.ccIds = ccIds;
	}

	public List<String> getBccIds() {
		return bccIds;
	}

	public void setBccIds(List<String> bccIds) {
		this.bccIds = bccIds;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EmailDetails [id=");
		builder.append(id);
		builder.append(", fromAddress=");
		builder.append(fromAddress);
		builder.append(", toAddress=");
		builder.append(toAddress);
		builder.append(", cc=");
		builder.append(cc);
		builder.append(", bcc=");
		builder.append(bcc);
		builder.append(", subject=");
		builder.append(subject);
		builder.append(", contentDetails=");
		builder.append(contentDetails);
		builder.append(", createdDate=");
		builder.append(createdDate);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", sentDate=");
		builder.append(sentDate);
		builder.append(", status=");
		builder.append(status);
		builder.append(", active=");
		builder.append(active);
		builder.append(", toIds=");
		builder.append(toIds);
		builder.append(", ccIds=");
		builder.append(ccIds);
		builder.append(", bccIds=");
		builder.append(bccIds);
		builder.append("]");
		return builder.toString();
	}

}

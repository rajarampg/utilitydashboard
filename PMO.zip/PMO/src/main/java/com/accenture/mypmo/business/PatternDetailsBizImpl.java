/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.PatternDetailsMapper;
import com.accenture.mypmo.model.PatternDetails;
import com.accenture.mypmo.model.PatternDetailsMapping;
import com.accenture.mypmo.repository.PatternDetailsRepository;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class PatternDetailsBizImpl implements PatternDetailsBiz {

	@Autowired
	PatternDetailsRepository patternDetailsRepo;

	@Autowired
	PatternDetailsMapper patternDetailsMapper;
	
	/* (non-Javadoc)
	 * @see com.accenture.mypmo.business.PatternDetailsBiz#capturePatternDetails(com.accenture.mypmo.model.PatternDetails)
	 */
	@Override
	public PMOResponse capturePatternDetails(PatternDetails patternDetails) {
		PMOResponse systemResponse = new PMOResponse();
		PatternDetailsMapping PatternDetailsMap = patternDetailsMapper.patternDetailsMapper(patternDetails);

		try {
			patternDetailsRepo.save(PatternDetailsMap);
		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}

		return systemResponse;
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.business.PatternDetailsBiz#viewPatternDetails(int)
	 */
	@Override
	public PatternDetails viewPatternDetails(int id) {
		PatternDetails patternDetails = new PatternDetails();

		try {
			patternDetails = patternDetailsMapper.patternDetailsMapMapper(patternDetailsRepo.findById(id));
		} catch (Exception e) {
			System.out.println("Error in DataFetch: " + e);
		}

		return patternDetails;
	}

	@Override
	public List<PatternDetails> viewPatternDetailsByPortfolioId(int portfolioId) {
		List<PatternDetails> patternDetails = new ArrayList<PatternDetails>();

		try {
			patternDetails = patternDetailsMapper.patternDetailsMapMapperCollection(patternDetailsRepo.findByPortfolioId(portfolioId));
		} catch (Exception e) {
			System.out.println("Error in DataFetch: " + e);
		}

		return patternDetails;
	}

	@Override
	public List<PatternDetails> viewAllPatternDetails() {
		List<PatternDetails> patternDetails = new ArrayList<PatternDetails>();

		try {
			patternDetails = patternDetailsMapper.patternDetailsMapMapperIterableCollection(patternDetailsRepo.findAll());
		} catch (Exception e) {
			System.out.println("Error in DataFetch: " + e);
		}

		return patternDetails;
	}

}

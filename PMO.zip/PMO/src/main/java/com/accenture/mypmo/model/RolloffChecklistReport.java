package com.accenture.mypmo.model;

import java.util.List;

import com.accenture.mypmo.response.PMOResponse;

public class RolloffChecklistReport extends PMOResponse{

	private List<RolloffChecklist> checklists;

	public List<RolloffChecklist> getChecklists() {
		return checklists;
	}

	public void setChecklists(List<RolloffChecklist> checklists) {
		this.checklists = checklists;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RolloffChecklistReport [checklists=");
		builder.append(checklists);
		builder.append("]");
		return builder.toString();
	}
	
}

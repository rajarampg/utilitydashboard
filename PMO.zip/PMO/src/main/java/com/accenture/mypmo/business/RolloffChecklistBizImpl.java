package com.accenture.mypmo.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.RolloffChecklistMapper;
import com.accenture.mypmo.model.RolloffChecklist;
import com.accenture.mypmo.model.RolloffChecklistMapping;
import com.accenture.mypmo.model.RolloffChecklistReport;
import com.accenture.mypmo.repository.RolloffChecklistRepository;
import com.accenture.mypmo.response.PMOResponse;

@Component
public class RolloffChecklistBizImpl implements RolloffChecklistBiz {

	@Autowired
	RolloffChecklistMapper mapper;

	@Autowired
	RolloffChecklistRepository rolloffChecklistRepository;

	@Override
	public PMOResponse captureRolloffChecklist(RolloffChecklist rolloffChecklist) {
		PMOResponse response = new PMOResponse();
		try {
			rolloffChecklistRepository.save(mapper.map(rolloffChecklist));
			response.setStatus("capture successfull!");
		} catch (Exception ex) {
			response.setId(500);
			response.setStatus(ex.getMessage());
			response.setDescription("Error");
		}
		return response;
	}

	@Override
	public PMOResponse fetchRolloffChecklist(int id) {
		PMOResponse response = null;
		RolloffChecklistMapping rolloffChecklistDetails = rolloffChecklistRepository
				.findById(id);
		if (null != rolloffChecklistDetails) {
			response = mapper.map(rolloffChecklistDetails);
			response.setDescription("Success");
		} else {
			response = new PMOResponse();
			response.setId(401);
			response.setStatus("No content found");
			response.setDescription("No detail found for checklist_id - " + id);
		}
		return response;
	}

	@Override
	public PMOResponse fetchRolloffChecklistByEmployee(int id) {
		PMOResponse response = null;
		RolloffChecklistMapping rolloffChecklistDetails = rolloffChecklistRepository
				.findByEmployeeNumber(id);
		if (null != rolloffChecklistDetails) {
			response = mapper.map(rolloffChecklistDetails);
			response.setDescription("Success");

		} else {
			response = new PMOResponse();
			response.setId(401);
			response.setStatus("No content found");
			response.setDescription("No detail found for employee_number - "
					+ id);
		}
		return response;
	}
	
	@Override
	public RolloffChecklistReport fetchAllChecklist() {
		RolloffChecklistReport report = new RolloffChecklistReport();
		try{
			Iterable<RolloffChecklistMapping> checklists = rolloffChecklistRepository
					.findAll();
			report.setChecklists(mapper.map(checklists));
			report.setDescription("Success");
			if(null == report.getChecklists() || report.getChecklists().isEmpty()){
				report.setId(401);
				report.setDescription("No content found");
			}
			
		}catch(Exception e){
			report.setDescription(e.getMessage());
			report.setId(500);
			report.setStatus("Internal server error");
		}
		return report;
	}

}

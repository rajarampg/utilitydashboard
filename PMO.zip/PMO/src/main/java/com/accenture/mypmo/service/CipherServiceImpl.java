package com.accenture.mypmo.service;

import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.response.PMOResponse;
import com.accenture.mypmo.utilities.AESencrp;

@CrossOrigin
@RestController
@RequestMapping(value = "/cipher")
public class CipherServiceImpl {

	@Qualifier(value = "aesEncryp")
	@Autowired
	AESencrp aesEncrypt;

	@RequestMapping(value = "/encrypt", method = RequestMethod.GET)
	public PMOResponse encrypt(@QueryParam(value = "pass") String pass
								, @QueryParam(value = "string") String string) {
		PMOResponse response = new PMOResponse();
		if (null != pass && pass.equals("pmo2")) {
			try {
				response.setDescription(aesEncrypt.encrypt(string));
			} catch (Exception e) {
				response.setId(500);
				response.setDescription("failure");
			}
		} else {
			response.setId(401);
			response.setDescription("Forbidden!");
		}
		return response;
	}

	@RequestMapping(value = "/decrypt", method = RequestMethod.GET)
	public PMOResponse decrypt(@QueryParam(value = "pass") String pass
								, @QueryParam(value = "string") String string) {
		PMOResponse response = new PMOResponse();
		if (null != pass && pass.equals("pmo2")) {
			try {
				response.setDescription(aesEncrypt.decrypt(string));
			} catch (Exception e) {
				response.setId(500);
				response.setDescription("failure");
			}
		}else{
			response.setId(401);
			response.setDescription("Forbidden!");
		}
		return response;
	}

}

package com.accenture.mypmo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.ACLReportMapping;

public interface ACLReportsRepository  extends CrudRepository<ACLReportMapping, Integer>{
	
	@Query(value = "select employeedetails.id as employeedetails_id, employeedetails.enterprise_id, employeedetails.first_name,"
			+ " employeedetails.last_name, employeedetails.current_location, employeedetails.portfolio_id,"
			+ " employeedetails.rollondate, employeedetails.rolloffdate, employeewmdetails.wmt_userid,"
			+ " employeewmdetails.wmt_accessdate, employeewmdetails.wmt_grantdate, employeewmdetails.role_id,"
			+ " roledetails.role, portfoliodetails.portfolio_name, rollonchecklist.updated_on from employeedetails left outer"
			+ " join employeewmdetails on employeedetails.employee_number = employeewmdetails.employee_number left outer"
			+ " join rollonchecklist on employeedetails.employee_number = rollonchecklist.employee_number left outer"
			+ " join portfoliodetails on employeedetails.portfolio_id = portfoliodetails.id left outer"
			+ " join roledetails on employeewmdetails.role_id = roledetails.id;"
			, nativeQuery = true)
	List<ACLReportMapping> fetchReports();
	

}

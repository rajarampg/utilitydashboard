package com.accenture.mypmo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.ResourceRequestDetailsBiz;
import com.accenture.mypmo.model.ResourceRequestDetails;
import com.accenture.mypmo.response.PMOResponse;

@CrossOrigin
@RestController
@RequestMapping(value = "/rrd")
public class ResourceRequestDetailsServiceImpl implements ResourceRequestDetailsService {

	@Autowired
	public ResourceRequestDetailsBiz resourceRequestBiz;

	@RequestMapping(value = "/addrrd", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse captureRRD(@RequestBody ResourceRequestDetails rrdDetails) {
		return resourceRequestBiz.captureResourceRequestsDetails(rrdDetails);
	}

	@Override
	@RequestMapping(value = "/updaterrd", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updateRRD(@RequestBody ResourceRequestDetails rrdDetails) {
		return resourceRequestBiz.captureResourceRequestsDetails(rrdDetails);
	}

	@RequestMapping(value = "/viewrrdbyportfolioid/{portfolioid}", method = RequestMethod.GET)
	public List<ResourceRequestDetails> viewRRDByPortfolioId(@PathVariable int portfolioid) {
		return resourceRequestBiz.viewRRDByPortfolioId(portfolioid);
	}

	@Override
	@RequestMapping(value = "/viewrrd/{Id}", method = RequestMethod.GET)
	public ResourceRequestDetails viewRRDById(@PathVariable int Id) {
		// TODO Auto-generated method stub
		return resourceRequestBiz.viewResourceRequestsDetails(Id);
	}

	@Override
	@RequestMapping(value = "/viewallrrd", method = RequestMethod.GET)
	public List<ResourceRequestDetails> viewAllRRD() {
		// TODO Auto-generated method stub
		return resourceRequestBiz.viewAllRRD();
	}

}

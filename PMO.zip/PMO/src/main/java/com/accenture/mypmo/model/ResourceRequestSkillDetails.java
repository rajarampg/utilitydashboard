package com.accenture.mypmo.model;

public class ResourceRequestSkillDetails {

	private String primarySkill;

	private String lockDuration;
	
	private boolean isHardlockready;
	
	private String fulfillmentEntity;
	
	private String careerLevel;
	
	private int resourceCount;
	
	private boolean status;
	
	private String wbseCode;
	
	private boolean active;
	
	private String term;

	public String getPrimarySkill() {
		return primarySkill;
	}

	public void setPrimarySkill(String primarySkill) {
		this.primarySkill = primarySkill;
	}

	public String getLockDuration() {
		return lockDuration;
	}

	public void setLockDuration(String lockDuration) {
		this.lockDuration = lockDuration;
	}

	public boolean isHardlockready() {
		return isHardlockready;
	}

	public void setHardlockready(boolean isHardlockready) {
		this.isHardlockready = isHardlockready;
	}

	public String getFulfillmentEntity() {
		return fulfillmentEntity;
	}

	public void setFulfillmentEntity(String fulfillmentEntity) {
		this.fulfillmentEntity = fulfillmentEntity;
	}

	public String getCareerLevel() {
		return careerLevel;
	}

	public void setCareerLevel(String careerLevel) {
		this.careerLevel = careerLevel;
	}

	public int getResourceCount() {
		return resourceCount;
	}

	public void setResourceCount(int resourceCount) {
		this.resourceCount = resourceCount;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getWbseCode() {
		return wbseCode;
	}

	public void setWbseCode(String wbseCode) {
		this.wbseCode = wbseCode;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	@Override
	public String toString() {
		return "ResourceRequestSkillDetails [primarySkill=" + primarySkill + ", lockDuration=" + lockDuration
				+ ", isHardlockready=" + isHardlockready + ", fulfillmentEntity=" + fulfillmentEntity + ", careerLevel="
				+ careerLevel + ", resourceCount=" + resourceCount + ", status=" + status + ", wbseCode=" + wbseCode
				+ ", active=" + active + ", term=" + term + "]";
	}
	

}

/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.RRDDemandBiz;
import com.accenture.mypmo.model.RRDDemand;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */

@CrossOrigin
@RestController
@RequestMapping(value = "/rrddemand")
public class RRDDemandServiceImpl implements RRDDemandService {

	@Autowired
	RRDDemandBiz rrdDemandBiz;

	
	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.RRDDemandService#captureRRDByDemandId(java.util.List)
	 */
	@Override
	@RequestMapping(value = "/addrrddemand", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse captureRRDByDemandId(@RequestBody List<RRDDemand> rrdDeman) {
		// TODO Auto-generated method stub
		return rrdDemandBiz.captureRRDByDemandId(rrdDeman);
	}

	@Override
	@RequestMapping(value = "/updaterrddemand", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updateRRDByDemandId(@RequestBody List<RRDDemand> rrdDeman) {
		// TODO Auto-generated method stub
		return rrdDemandBiz.captureRRDByDemandId(rrdDeman);
	}
	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.RRDDemandService#viewRRDByDemandId(java.lang.String)
	 */
	@Override
	@RequestMapping(value = "/viewrrddemandbydemandid/{demandId}", method = RequestMethod.GET)
	public List<RRDDemand> viewRRDByDemandId(@PathVariable String demandId) {
		// TODO Auto-generated method stub
		return rrdDemandBiz.viewRRDByDemandId(demandId);
	}

}

/**
 * 
 */
package com.accenture.mypmo.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author p.senthilrajan
 *
 */
@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)
@Table(name="patterndetails")
public class PatternDetailsMapping implements Serializable {

	public static final long serialVersionUID = 1L;

	@Id @GeneratedValue
	@Column(name = "id")
	private int id;

	@Column(name = "portfolio_id")
	private int portfolioId;
	
	@Column(name = "pattern_name")
	private String patternName;
	
	@Column(name = "pattern_description")
	private String patternDescription;
	
	@Column(name = "skill_team_details")
	private String skillTeamDetails;
	
	@Column(name = "clarity")
	private String clarity;
	
	@Column(name = "unix_boxes")
	private String unixBoxes;
	
	@Column(name = "teradata_access")
	private String teradataAccess;
	
	@Column(name = "ad_access")
	private String adAccess;
	
	@Column(name = "additional_access")
	private String additionalAccess;
	
	@Column(name = "specific_access")
	private String specificAccess;
	
	@Column(name = "business_justification")
	private String businessJustification;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_on")
	private Timestamp createdOn;
	
	@Column(name = "modified_by")
	private String modifiedBy;
	
	@Column(name = "modified_on")
	private Timestamp modifiedOn;
	
	@Column(name = "active")
	private boolean active;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(int portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getPatternName() {
		return patternName;
	}

	public void setPatternName(String patternName) {
		this.patternName = patternName;
	}

	public String getPatternDescription() {
		return patternDescription;
	}

	public void setPatternDescription(String patternDescription) {
		this.patternDescription = patternDescription;
	}

	public String getSkillTeamDetails() {
		return skillTeamDetails;
	}

	public void setSkillTeamDetails(String skillTeamDetails) {
		this.skillTeamDetails = skillTeamDetails;
	}

	public String getClarity() {
		return clarity;
	}

	public void setClarity(String clarity) {
		this.clarity = clarity;
	}

	public String getUnixBoxes() {
		return unixBoxes;
	}

	public void setUnixBoxes(String unixBoxes) {
		this.unixBoxes = unixBoxes;
	}

	public String getTeradataAccess() {
		return teradataAccess;
	}

	public void setTeradataAccess(String teradataAccess) {
		this.teradataAccess = teradataAccess;
	}

	public String getAdAccess() {
		return adAccess;
	}

	public void setAdAccess(String adAccess) {
		this.adAccess = adAccess;
	}

	public String getAdditionalAccess() {
		return additionalAccess;
	}

	public void setAdditionalAccess(String additionalAccess) {
		this.additionalAccess = additionalAccess;
	}

	public String getSpecificAccess() {
		return specificAccess;
	}

	public void setSpecificAccess(String specificAccess) {
		this.specificAccess = specificAccess;
	}

	public String getBusinessJustification() {
		return businessJustification;
	}

	public void setBusinessJustification(String businessJustification) {
		this.businessJustification = businessJustification;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "PatternDetailsMapping [id=" + id + ", portfolioId=" + portfolioId + ", patternName=" + patternName
				+ ", patternDescription=" + patternDescription + ", skillTeamDetails=" + skillTeamDetails + ", clarity="
				+ clarity + ", unixBoxes=" + unixBoxes + ", teradataAccess=" + teradataAccess + ", adAccess=" + adAccess
				+ ", additionalAccess=" + additionalAccess + ", specificAccess=" + specificAccess
				+ ", businessJustification=" + businessJustification + ", createdBy=" + createdBy + ", createdOn="
				+ createdOn + ", modifiedBy=" + modifiedBy + ", modifiedOn=" + modifiedOn + ", active=" + active + "]";
	}

}

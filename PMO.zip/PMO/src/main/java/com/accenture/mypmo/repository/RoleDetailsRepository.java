/**
 * 
 */
package com.accenture.mypmo.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.RoleDetailsMapping;
/**
 * @author p.senthilrajan
 *
 */
public interface RoleDetailsRepository extends CrudRepository<RoleDetailsMapping, String>, JpaSpecificationExecutor<RoleDetailsMapping>{

	public RoleDetailsMapping findById(int id);
}

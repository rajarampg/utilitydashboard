/**
 * 
 */
package com.accenture.mypmo.commons;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.accenture.mypmo.response.PMOResponse;

@ControllerAdvice
public class PMOExceptionHandler {

	
	@ExceptionHandler(PMOException.class)
	public @ResponseBody PMOResponse handleCustomException(PMOException ex) {
		PMOResponse response = new PMOResponse();
		response.setId(Integer.valueOf(ex.getErrCode()));
		//response.setErrorMessage(ex.getErrMsg());
		return response;

	}

}

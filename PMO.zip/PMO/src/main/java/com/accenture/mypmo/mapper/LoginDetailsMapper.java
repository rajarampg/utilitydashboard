package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.LoginDetails;
import com.accenture.mypmo.model.LoginDetailsMapping;

@Component
public class LoginDetailsMapper {
	
	public LoginDetailsMapping loginDetailsMapper(LoginDetails loginDetails){
		
		LoginDetailsMapping loginDetailsMapping = new LoginDetailsMapping();
		
		loginDetailsMapping.setId(loginDetails.getId());
		loginDetailsMapping.setEnterpriseId(loginDetails.getEnterpriseId());
		loginDetailsMapping.setEmployeeNumber(loginDetails.getEmployeeNumber());
		loginDetailsMapping.setPassword(loginDetails.getPassword());
		loginDetailsMapping.setUserTypeId(loginDetails.getUserTypeId());
		loginDetailsMapping.setLastLogin(loginDetails.getLastLogin());
		
		return loginDetailsMapping;
	}

	public LoginDetails loginDetailsMapMapper(LoginDetailsMapping loginDetailsMapping){
		
		LoginDetails loginDetails = new LoginDetails();
		
		loginDetails.setId(loginDetailsMapping.getId());
		loginDetails.setEnterpriseId(loginDetailsMapping.getEnterpriseId());
		loginDetails.setEmployeeNumber(loginDetailsMapping.getEmployeeNumber());
		loginDetails.setPassword(loginDetailsMapping.getPassword());
		loginDetails.setUserTypeId(loginDetailsMapping.getUserTypeId());
		loginDetails.setLastLogin(loginDetailsMapping.getLastLogin());
		
		return loginDetails;
	}
	
	public List<LoginDetails> loginDetailsMapMapperCollection (Iterable<LoginDetailsMapping> allLoginDetails){
		
		List<LoginDetails> loginDetails = new ArrayList<LoginDetails>();
		
		for(LoginDetailsMapping loginDetailsMappingTemp: allLoginDetails){
			loginDetails.add(loginDetailsMapMapper(loginDetailsMappingTemp));
		}
		
		return loginDetails;
	}}

package com.accenture.mypmo.model;

import java.sql.Timestamp;

import com.accenture.mypmo.response.PMOResponse;
import com.fasterxml.jackson.annotation.JsonProperty;

public class RolloffChecklist extends PMOResponse{

	@JsonProperty(value="checklist_id")
	private Integer checklistId;
	
	private Integer employeeNumber;
	
	private String checklistDetails;
	
	private String updatedby;
	
	private Timestamp updatedon;
	
	@JsonProperty(value="status")
	private Boolean statusValue;
	
	private Boolean active;

	public Integer getChecklistId() {
		return checklistId;
	}

	public void setChecklistId(Integer checklistId) {
		this.checklistId = checklistId;
	}

	public Integer getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(Integer employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getChecklistDetails() {
		return checklistDetails;
	}

	public void setChecklistDetails(String checklistDetails) {
		this.checklistDetails = checklistDetails;
	}

	public String getUpdatedby() {
		return updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

	public Timestamp getUpdatedon() {
		return updatedon;
	}

	public void setUpdatedon(Timestamp updatedon) {
		this.updatedon = updatedon;
	}

	public Boolean getStatusValue() {
		return statusValue;
	}

	public void setStatusValue(Boolean statusValue) {
		this.statusValue = statusValue;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RollonChecklist [checklistId=");
		builder.append(checklistId);
		builder.append(", employeeNumber=");
		builder.append(employeeNumber);
		builder.append(", checklistDetails=");
		builder.append(checklistDetails);
		builder.append(", updatedby=");
		builder.append(updatedby);
		builder.append(", updatedon=");
		builder.append(updatedon);
		builder.append(", statusValue=");
		builder.append(statusValue);
		builder.append(", active=");
		builder.append(active);
		builder.append("]");
		return builder.toString();
	}

}

package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.ACLReportMapping;

@Component
public class ACLReportMapper {
	
	public ACLReport map(ACLReportMapping mapping){
		ACLReport report = new ACLReport();
		report.setEmployeedetailsId(mapping.getEmployeedetails_id());
		report.setEnterpriseId(mapping.getEnterpriseId());
		report.setFirstName(mapping.getFirstName());
		report.setLastName(mapping.getLastName());
		report.setCurrentLocation(mapping.getCurrentLocation());
		report.setRollonDate(mapping.getRollonDate());
		report.setRolloffDate(mapping.getRolloffDate());
		report.setWmtUserid(mapping.getWmtUserid());
		report.setWmtAccessDate(mapping.getWmtAccessDate());
		report.setWmtGrantDate(mapping.getWmtGrantDate());
		report.setRole(mapping.getRole());
		report.setPortfolioName(mapping.getPortfolioName());
		report.setUpdatedOn(mapping.getUpdatedOn());
		return report;
	}
	
	public List<ACLReport> map(List<ACLReportMapping> mappings){
		List<ACLReport> reports = new ArrayList<ACLReport>();
		for(ACLReportMapping mapping : mappings){
			reports.add(map(mapping));
		}
		return reports;
	}
	
}

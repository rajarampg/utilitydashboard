package com.accenture.mypmo.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.RollonChecklistMapper;
import com.accenture.mypmo.model.RollonChecklist;
import com.accenture.mypmo.model.RollonChecklistMapping;
import com.accenture.mypmo.model.RollonChecklistReport;
import com.accenture.mypmo.repository.RollonChecklistRepository;
import com.accenture.mypmo.response.PMOResponse;

@Component
public class RollonChecklistBizImpl implements RollonChecklistBiz {

	@Autowired
	RollonChecklistMapper mapper;

	@Autowired
	RollonChecklistRepository rollonChecklistRepository;

	@Override
	public PMOResponse captureRolloncheck(RollonChecklist rollonChecklist) {
		PMOResponse response = new PMOResponse();
		try {
			rollonChecklistRepository.save(mapper
					.detailsMapper(rollonChecklist));
			response.setStatus("capture successfull!");
		} catch (Exception ex) {
			response.setId(500);
			response.setStatus(ex.getMessage());
		}
		return response;
	}

	@Override
	public PMOResponse fetchRollonChecklist(int id) {
		RollonChecklistMapping rollOnChecklistDetails = rollonChecklistRepository
				.findById(id);
		if (null != rollOnChecklistDetails) {
			return mapper.map(rollOnChecklistDetails);
		} else {
			PMOResponse response = new PMOResponse();
			response.setId(401);
			response.setStatus("No content found");
			return response;
		}
	}
	
	@Override
	public PMOResponse fetchChecklistDetailsByEmployee(Integer id) {
		PMOResponse response = null;
		RollonChecklistMapping rollOnChecklistDetails = rollonChecklistRepository
				.findByEmployeeNumber(id);
		if (null != rollOnChecklistDetails) {
			response = mapper.map(rollOnChecklistDetails);
			response.setDescription("Success");
		} else {
			response = new PMOResponse();
			response.setId(401);
			response.setStatus("No content found");
		}
		return response;
	}
	
	@Override
	public RollonChecklistReport fetchAllChecklist() {
		RollonChecklistReport report = new RollonChecklistReport();
		try{
		
		Iterable<RollonChecklistMapping> checklists = rollonChecklistRepository
				.findAll();
		report.setChecklists(mapper.map(checklists));
		report.setDescription("Success");
		if(null==report.getChecklists() || report.getChecklists().isEmpty()){
			report.setId(401);
			report.setDescription("No content found");
		}
		}catch(Exception e){
			report.setId(500);
			report.setDescription(e.getMessage());
			report.setStatus("Error fetching roll on checklist details");
		}
		return report;
	}

}

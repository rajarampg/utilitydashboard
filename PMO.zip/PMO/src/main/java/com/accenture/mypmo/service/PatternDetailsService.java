/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import com.accenture.mypmo.model.PatternDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface PatternDetailsService {

	PMOResponse capturePatternDetails(PatternDetails patternDetails);

	PMOResponse updatePatternDetails(PatternDetails patternDetails);

	PatternDetails viewPatternDetails(int  id);
	
	List<PatternDetails> viewPatternDetailsByPortfolioId(int portfolioId);
	
	List<PatternDetails> viewAllPatternDetails();
	
}

/**
 * 
 */
package com.accenture.mypmo.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author p.senthilrajan
 *
 */
@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmployeeCountReportMapping implements Serializable {

	private static final long serialVersionUID = 8043854847657054315L;

	@Id @Column(name = "sno")
	private int sno;
	
	@Column(name = "portfolio")
	private String portfolio;

	@Column(name = "countbase")
	private String countbase;
	
	@Column(name = "worklocation")
	private String worklocation;
	
	@Column(name = "countvalue")
	private String countvalue;

	
	public int getSno() {
		return sno;
	}

	public void setSno(int sno) {
		this.sno = sno;
	}

	public String getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(String portfolio) {
		this.portfolio = portfolio;
	}

	public String getCountbase() {
		return countbase;
	}

	public void setCountbase(String countbase) {
		this.countbase = countbase;
	}

	public String getWorklocation() {
		return worklocation;
	}

	public void setWorklocation(String worklocation) {
		this.worklocation = worklocation;
	}

	public String getCountvalue() {
		return countvalue;
	}

	public void setCountvalue(String countvalue) {
		this.countvalue = countvalue;
	}

	@Override
	public String toString() {
		return "EmployeeCountReportMapping [sno=" + sno + ", portfolio=" + portfolio + ", countbase=" + countbase
				+ ", worklocation=" + worklocation + ", countvalue=" + countvalue + "]";
	}


	
}

package com.accenture.mypmo.utilities;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.accenture.mypmo.mapper.EmailDetailsMapper;
import com.accenture.mypmo.model.EmailDetails;
import com.accenture.mypmo.model.EmailDetailsMapping;
import com.accenture.mypmo.repository.EmailDetailsRepository;

@Configuration
@EnableScheduling
public class ScheduleEmailTrigger {

	@Autowired
	TriggerEmail emailSender;
	
	@Autowired
	EmailDetailsMapper mapper;

	@Autowired
	EmailDetailsRepository emailRepo;

	@Scheduled(fixedDelay = 50000)
	public void processEmailRequests() {
		List<EmailDetails> emailDetails = mapper.emailDetailsMapMappingCollection(emailRepo
				.findByStatus("create"));
		System.out.println(emailDetails);
		List<EmailDetails> eligibleEmails = filterEmailByTimestamp(emailDetails);
		
//		TODO:: remove this call when moving into prod. 
		applyTestParams(eligibleEmails);
		
		for(EmailDetails email: emailDetails){
			try{
			emailSender.processEmail(email);
			EmailDetailsMapping emailMap = mapper.emailDetailsMapping(email);
			emailMap.setSentDate(new Timestamp(System.currentTimeMillis()));
			emailMap.setActive(false);
			emailMap.setStatus("manof the match");
			emailRepo.save(emailMap);
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Error sending email");
			}
		}
		
	}

	void applyTestParams(List<EmailDetails> emailDetails) {
		List<String> emailRecepients = new ArrayList<String>();
		emailRecepients.add("c.athinarayanan@accenture.com");
		emailRecepients.add("aswin.sundaramoorthi@accenture.com");
		emailRecepients.add("karthik.jeyapal@accenture.com");
		emailRecepients.add("p.senthilrajan@accenture.com");
		emailRecepients.add("bora.sumitha.reddy@accenture.com");

		for (EmailDetails emailDetail : emailDetails) {
			emailDetail.setSubject("TEST :" + emailDetail.getSubject());
			emailDetail.setToIds(emailRecepients);
			emailDetail.setCcIds(emailRecepients);
			emailDetail.setBccIds(emailRecepients);
		}
	}

	List<EmailDetails> filterEmailByTimestamp(List<EmailDetails> emailDetails) {
		List<EmailDetails> validEmails = new ArrayList<EmailDetails>();
		for (EmailDetails emailDetail : emailDetails) {
			if (true) {
				if (emailDetail.getSentDate().before(new Date())) {
					validEmails.add(emailDetail);
				}
			}
		}
		return validEmails;
	}

}

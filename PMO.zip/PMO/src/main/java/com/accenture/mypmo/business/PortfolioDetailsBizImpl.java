package com.accenture.mypmo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.PortfolioDetailsMapper;
import com.accenture.mypmo.model.PortfolioDetails;
import com.accenture.mypmo.model.PortfolioDetailsMapping;
import com.accenture.mypmo.repository.PortfolioDetailsRepository;
import com.accenture.mypmo.response.PMOResponse;

@Component
public class PortfolioDetailsBizImpl implements PortfolioDetailsBiz {
	
	@Autowired
	PortfolioDetailsRepository portfolioDetailsRepo;
	
	@Autowired
	PortfolioDetailsMapper portfolioDetailsMapper;
	

	@Override
	public PMOResponse capturePortfolioDetails(PortfolioDetails portfolioDetails) {
		PMOResponse systemResponse = new PMOResponse();
		PortfolioDetailsMapping portfolioDetailsMapping = portfolioDetailsMapper.portfolioDetailsMapper(portfolioDetails);
		try {
			portfolioDetailsRepo.save(portfolioDetailsMapping);
		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}

		return systemResponse;
	}


	@Override
	public PortfolioDetails viewPortfolioDetails(int id) {
		PortfolioDetails portfolioDetails = new PortfolioDetails();

		try {
			portfolioDetails = portfolioDetailsMapper.portfolioDetailsMapMapper(portfolioDetailsRepo.findById(id));
		} catch (Exception e) {
			System.out.println("Exception in SQL operation " + e);
		}

		return portfolioDetails;
	}


	@Override
	public List<PortfolioDetails> ViewAllPortfolioDetails() {
		List<PortfolioDetails> portfolioDetails = new ArrayList<PortfolioDetails>();

		try {
			portfolioDetails = portfolioDetailsMapper.portfolioDetailsIterableMapMapperCollection(portfolioDetailsRepo.findAll());
		} catch (Exception e) {
			System.out.println("Exception in SQL operation " + e);
		}

		return portfolioDetails;
	}
		
		
}

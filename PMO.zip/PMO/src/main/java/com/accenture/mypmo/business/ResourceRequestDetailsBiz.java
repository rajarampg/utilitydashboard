package com.accenture.mypmo.business;

import java.util.List;

import com.accenture.mypmo.model.ResourceRequestDetails;
import com.accenture.mypmo.response.PMOResponse;

public interface ResourceRequestDetailsBiz {

	PMOResponse captureResourceRequestsDetails(ResourceRequestDetails demandReq);

	List<ResourceRequestDetails> viewRRDByPortfolioId(int portfolioid);

	List<ResourceRequestDetails> viewAllRRD();

	ResourceRequestDetails viewResourceRequestsDetails (int id);
}

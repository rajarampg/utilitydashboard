package com.accenture.mypmo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;





import com.accenture.mypmo.business.InnovationSkillBiz;
import com.accenture.mypmo.model.InnovationSkill;
import com.accenture.mypmo.model.InnovationSkillMapping;



@CrossOrigin
@RestController
@RequestMapping(value = "/innovationdetails")
public class InnovationSkillServiceImpl implements InnovationSkillService{

	@Autowired
	InnovationSkillBiz innovationSkillBiz;
	
	@RequestMapping(value = "/userinput", method = RequestMethod.POST, headers = "Accept=application/json")
	public String captureInnovationDetails(@RequestBody InnovationSkill innovation) {

		return innovationSkillBiz.captureInnovationDetails(innovation);
	}
	
	@RequestMapping(value = "/getDetails/{id}", method = RequestMethod.GET)
	public List<InnovationSkillMapping> getInnovationDetails(
			@PathVariable int id) {

		return innovationSkillBiz.getInnovationDetails(id);
	}
}

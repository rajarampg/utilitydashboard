/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import com.accenture.mypmo.model.EmployeeCountReport;

/**
 * @author p.senthilrajan
 *
 */
public interface EmployeeCountReportService {
	
	List<EmployeeCountReport> empCountByPortfolio();
	
	List<EmployeeCountReport> empCountByEmpStatus();

	List<EmployeeCountReport> empCountByRolloff();

	List<EmployeeCountReport> empCountByCareerLevel();

}

/**
 * 
 */
package com.accenture.mypmo.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author p.senthilrajan
 *
 */
@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmployeeCustomDetailsMapping implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8225582531554803881L;

	@Id 
	@Column(name = "accenture_id")
	private int accentureId;

	@Column(name="accenture_employee_number")	
	private int accentureEmployeeNumber;
	
	@Column(name="accenture_portfolio_id")
	private int accenturePortfolioId;
	
	@Column(name="rrd_id")
	private String rrdId;
	
	@Column(name="enterprise_id")
	private String enterpriseId;
	
	@Column(name="first_name")
	private String firstName;
	
	@Column(name="last_name")
	private String lastName;
	
	@Column(name="gender")
	private String gender;
	
	@Column(name="capability")
	private String capability;
	
	@Column(name="career_level")
	private String careerLevel;
	
	@Column(name="supervisor_ent_id")
	private String supervisorEntId;
	
	@Column(name="current_location")
	private String currentLocation;
	
	@Column(name="delivery_center")
	private String deliveryCenter;
	
	@Column(name="visa_type")
	private String visaType;	
	
	@Column(name="duration_stay")
	private String durationStay;
	
	@Column(name="phone_no")
	private String phoneNo;
	
	@Column(name="primary_skill")
	private String primarySkill;
	
	@Column(name="secondary_skill")
	private String secondarySkill;
	
	@Column(name="proficiency_level")
	private String proficiencyLevel;
	
	@Column(name="lock_type")
	private String lockType;
	
	@Column(name="employee_status")
	private String employeeStatus;
	
	@Column(name = "employee_type")
	private String employeeType;

	@Column(name="rollondate")
	private Timestamp rollonDate;

	@Column(name="rollonby")
	private String rollonBy;
	
	@Column(name="rolloffdate")
	private Timestamp rolloffDate;
	
	@Column(name="rolloffreason")
	private String rolloffReason;
	
	@Column(name="rolledoffby")
	private String rolledoffBy;
	
	@Column(name="isexit")
	private boolean isExit;
	
	@Column(name="accenture_created_by")
	private String accentureCreatedBy;
	
	@Column(name="accenture_created_on")
	private Timestamp accentureCreatedOn;
	
	@Column(name="accenture_modified_by")
	private String accentureModifiedBy;
	
	@Column(name="accenture_modified_on")
	private Timestamp accentureModifiedOn;

	@Column(name="accenture_active")
	private boolean accentureActive;

	@Column(name = "client_id")
	private int clientId;
	
	@Column(name = "client_employee_number")
	private int clientEmployeeNumber;
	
	@Column(name = "client_client_manager_id")
	private int clientClientManagerId;
	
	@Column(name = "client_pattern_id")
	private int clientPatternId;
	
	@Column(name = "client_role_id")
	private int clientRoleId;
	
	@Column(name = "wmt_userid")
	private String wmtUserId;
	
	@Column(name = "wmt_accessdate")
	private Timestamp wmtAccessDate;

	@Column(name = "wmt_grantdate")
	private Timestamp wmtGrantDate;
	
	@Column(name = "contract_type")
	private String contractType;
	
	@Column(name = "projectname")
	private String projectName;
	
	@Column(name = "projectdetails")
	private String projectDetails;
	
	@Column(name = "client")
	private String client;
	
	@Column(name = "departmentnumber")
	private String departmentNumber;
	
	@Column(name = "country")
	private String country;
	
	@Column(name = "workstation")
	private String workstation;
	
	@Column(name = "bay_details")
	private String bayDetails;
	
	@Column(name = "floor")
	private String floor;
	
	@Column(name = "wbse")
	private String wbse;
	
	@Column(name = "identifiertype")
	private String identifierType;
	
	@Column(name = "identifiernumber")
	private String identifierNumber;
	
	@Column(name = "comments")
	private String comments;
	
	@Column(name = "onboardstartdate")
	private Timestamp onboardStartDate;
	
	@Column(name = "onboardtime")
	private Timestamp onboardTime;
	
	@Column(name = "onboardedby")
	private String onboardedBy;
	
	@Column(name = "isrenew")
	private boolean isRenew;
	
	@Column(name = "client_created_by")
	private String clientCreatedBy;
	
	@Column(name = "client_created_on")
	private Timestamp clientCreatedOn;
	
	@Column(name = "client_modified_by")
	private String clientModifiedBy;
	
	@Column(name = "client_modified_on")
	private Timestamp clientModifiedOn;
	
	@Column(name = "client_active")
	private boolean clientActive;


	@Column(name = "portfolioid")
	private int portfolioId;
	
	@Column(name="portfolio_name")
	private String portfolioName;
	
	@Column(name="portfolio_description")
	private String portfolioDescription;
	
	@Column(name="portfolio_created_by")
	private String portfolioCreatedBy;
	
	@Column(name="portfolio_created_on")
	private Timestamp portfolioCreatedOn;
	
	@Column(name="portfolio_modified_by")
	private String portfolioModifiedBy;
	
	@Column(name="portfolio_modified_on")
	private Timestamp portfolioModifiedOn;
	
	@Column(name="portfolio_active")
	private boolean portfolioActive;

	
	@Column(name = "client_manager_id")
	private int clientManagerId;
	
	@Column(name = "client_manager_portfolio_id")
	public int clientManagerPortfolioId;
	
	@Column(name = "team")
	public String team;
	
	@Column(name = "resource_manager")
	public String resourceManager;
	
	@Column(name = "vice_president")
	public String vicePresident;
	
	@Column(name = "director_id")
	public String directorId;
	
	@Column(name = "contract_id")
	public String contractId;
	
	@Column(name="client_manager_created_by")
	private String clientManagerCreatedBy;
	
	@Column(name="client_manager_created_on")
	private Timestamp clientManagerCreatedOn;
	
	@Column(name="client_manager_modified_by")
	private String clientManagerModifiedBy;
	
	@Column(name="client_manager_modified_on")
	private Timestamp clientManagerModifiedOn;
	
	@Column(name="client_manager_active")
	private boolean clientManagerActive;

	@Column(name = "role_id")
	private int roleId;
	
	@Column(name = "role")
	private String role;
	
	@Column(name = "role_description")
	private String roleDescription;
	
	@Column(name = "location")
	private String location;
	
	@Column(name = "rate")
	private double rate;

	@Column(name="role_created_by")
	private String roleCreatedBy;
	
	@Column(name="role_created_on")
	private Timestamp roleCreatedOn;
	
	@Column(name="role_modified_by")
	private String roleModifiedBy;
	
	@Column(name="role_modified_on")
	private Timestamp roleModifiedOn;
	
	@Column(name="role_active")
	private boolean roleActive;

	
	@Column(name = "pattern_id")
	private int patternId;

	@Column(name = "pattern_portfolio_id")
	private int patternPortfolioId;
	
	@Column(name = "pattern_name")
	private String patternName;
	
	@Column(name = "pattern_description")
	private String patternDescription;
	
	@Column(name = "skill_team_details")
	private String skillTeamDetails;
	
	@Column(name = "clarity")
	private String clarity;
	
	@Column(name = "unix_boxes")
	private String unixBoxes;
	
	@Column(name = "teradata_access")
	private String teradataAccess;
	
	@Column(name = "ad_access")
	private String adAccess;
	
	@Column(name = "additional_access")
	private String additionalAccess;
	
	@Column(name = "specific_access")
	private String specificAccess;
	
	@Column(name = "business_justification")
	private String businessJustification;
	
	@Column(name = "pattern_created_by")
	private String patternCreatedBy;
	
	@Column(name = "pattern_created_on")
	private Timestamp patternCreatedOn;
	
	@Column(name = "pattern_modified_by")
	private String patternModifiedBy;
	
	@Column(name = "pattern_modified_on")
	private Timestamp patternModifiedOn;
	
	@Column(name = "pattern_active")
	private boolean patternActive;

	public int getAccentureId() {
		return accentureId;
	}

	public void setAccentureId(int accentureId) {
		this.accentureId = accentureId;
	}

	public int getAccentureEmployeeNumber() {
		return accentureEmployeeNumber;
	}

	public void setAccentureEmployeeNumber(int accentureEmployeeNumber) {
		this.accentureEmployeeNumber = accentureEmployeeNumber;
	}

	public int getAccenturePortfolioId() {
		return accenturePortfolioId;
	}

	public void setAccenturePortfolioId(int accenturePortfolioId) {
		this.accenturePortfolioId = accenturePortfolioId;
	}

	public String getRrdId() {
		return rrdId;
	}

	public void setRrdId(String rrdId) {
		this.rrdId = rrdId;
	}

	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCapability() {
		return capability;
	}

	public void setCapability(String capability) {
		this.capability = capability;
	}

	public String getCareerLevel() {
		return careerLevel;
	}

	public void setCareerLevel(String careerLevel) {
		this.careerLevel = careerLevel;
	}

	public String getSupervisorEntId() {
		return supervisorEntId;
	}

	public void setSupervisorEntId(String supervisorEntId) {
		this.supervisorEntId = supervisorEntId;
	}

	public String getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}

	public String getDeliveryCenter() {
		return deliveryCenter;
	}

	public void setDeliveryCenter(String deliveryCenter) {
		this.deliveryCenter = deliveryCenter;
	}

	public String getVisaType() {
		return visaType;
	}

	public void setVisaType(String visaType) {
		this.visaType = visaType;
	}

	public String getDurationStay() {
		return durationStay;
	}

	public void setDurationStay(String durationStay) {
		this.durationStay = durationStay;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getPrimarySkill() {
		return primarySkill;
	}

	public void setPrimarySkill(String primarySkill) {
		this.primarySkill = primarySkill;
	}

	public String getSecondarySkill() {
		return secondarySkill;
	}

	public void setSecondarySkill(String secondarySkill) {
		this.secondarySkill = secondarySkill;
	}

	public String getProficiencyLevel() {
		return proficiencyLevel;
	}

	public void setProficiencyLevel(String proficiencyLevel) {
		this.proficiencyLevel = proficiencyLevel;
	}

	public String getLockType() {
		return lockType;
	}

	public void setLockType(String lockType) {
		this.lockType = lockType;
	}

	public String getEmployeeStatus() {
		return employeeStatus;
	}

	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	public Timestamp getRollonDate() {
		return rollonDate;
	}

	public void setRollonDate(Timestamp rollonDate) {
		this.rollonDate = rollonDate;
	}

	public String getRollonBy() {
		return rollonBy;
	}

	public void setRollonBy(String rollonBy) {
		this.rollonBy = rollonBy;
	}

	public Timestamp getRolloffDate() {
		return rolloffDate;
	}

	public void setRolloffDate(Timestamp rolloffDate) {
		this.rolloffDate = rolloffDate;
	}

	public String getRolloffReason() {
		return rolloffReason;
	}

	public void setRolloffReason(String rolloffReason) {
		this.rolloffReason = rolloffReason;
	}

	public String getRolledoffBy() {
		return rolledoffBy;
	}

	public void setRolledoffBy(String rolledoffBy) {
		this.rolledoffBy = rolledoffBy;
	}

	public boolean isExit() {
		return isExit;
	}

	public void setExit(boolean isExit) {
		this.isExit = isExit;
	}

	public String getAccentureCreatedBy() {
		return accentureCreatedBy;
	}

	public void setAccentureCreatedBy(String accentureCreatedBy) {
		this.accentureCreatedBy = accentureCreatedBy;
	}

	public Timestamp getAccentureCreatedOn() {
		return accentureCreatedOn;
	}

	public void setAccentureCreatedOn(Timestamp accentureCreatedOn) {
		this.accentureCreatedOn = accentureCreatedOn;
	}

	public String getAccentureModifiedBy() {
		return accentureModifiedBy;
	}

	public void setAccentureModifiedBy(String accentureModifiedBy) {
		this.accentureModifiedBy = accentureModifiedBy;
	}

	public Timestamp getAccentureModifiedOn() {
		return accentureModifiedOn;
	}

	public void setAccentureModifiedOn(Timestamp accentureModifiedOn) {
		this.accentureModifiedOn = accentureModifiedOn;
	}

	public boolean isAccentureActive() {
		return accentureActive;
	}

	public void setAccentureActive(boolean accentureActive) {
		this.accentureActive = accentureActive;
	}

	public int getClientId() {
		return clientId;
	}

	public void setClientId(int clientId) {
		this.clientId = clientId;
	}

	public int getClientEmployeeNumber() {
		return clientEmployeeNumber;
	}

	public void setClientEmployeeNumber(int clientEmployeeNumber) {
		this.clientEmployeeNumber = clientEmployeeNumber;
	}

	public int getClientClientManagerId() {
		return clientClientManagerId;
	}

	public void setClientClientManagerId(int clientClientManagerId) {
		this.clientClientManagerId = clientClientManagerId;
	}

	public int getClientPatternId() {
		return clientPatternId;
	}

	public void setClientPatternId(int clientPatternId) {
		this.clientPatternId = clientPatternId;
	}

	public int getClientRoleId() {
		return clientRoleId;
	}

	public void setClientRoleId(int clientRoleId) {
		this.clientRoleId = clientRoleId;
	}

	public String getWmtUserId() {
		return wmtUserId;
	}

	public void setWmtUserId(String wmtUserId) {
		this.wmtUserId = wmtUserId;
	}

	public Timestamp getWmtAccessDate() {
		return wmtAccessDate;
	}

	public void setWmtAccessDate(Timestamp wmtAccessDate) {
		this.wmtAccessDate = wmtAccessDate;
	}

	public Timestamp getWmtGrantDate() {
		return wmtGrantDate;
	}

	public void setWmtGrantDate(Timestamp wmtGrantDate) {
		this.wmtGrantDate = wmtGrantDate;
	}

	public String getContractType() {
		return contractType;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProjectDetails() {
		return projectDetails;
	}

	public void setProjectDetails(String projectDetails) {
		this.projectDetails = projectDetails;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getDepartmentNumber() {
		return departmentNumber;
	}

	public void setDepartmentNumber(String departmentNumber) {
		this.departmentNumber = departmentNumber;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getWorkstation() {
		return workstation;
	}

	public void setWorkstation(String workstation) {
		this.workstation = workstation;
	}

	public String getBayDetails() {
		return bayDetails;
	}

	public void setBayDetails(String bayDetails) {
		this.bayDetails = bayDetails;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public String getWbse() {
		return wbse;
	}

	public void setWbse(String wbse) {
		this.wbse = wbse;
	}

	public String getIdentifierType() {
		return identifierType;
	}

	public void setIdentifierType(String identifierType) {
		this.identifierType = identifierType;
	}

	public String getIdentifierNumber() {
		return identifierNumber;
	}

	public void setIdentifierNumber(String identifierNumber) {
		this.identifierNumber = identifierNumber;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Timestamp getOnboardStartDate() {
		return onboardStartDate;
	}

	public void setOnboardStartDate(Timestamp onboardStartDate) {
		this.onboardStartDate = onboardStartDate;
	}

	public Timestamp getOnboardTime() {
		return onboardTime;
	}

	public void setOnboardTime(Timestamp onboardTime) {
		this.onboardTime = onboardTime;
	}

	public String getOnboardedBy() {
		return onboardedBy;
	}

	public void setOnboardedBy(String onboardedBy) {
		this.onboardedBy = onboardedBy;
	}

	public boolean isRenew() {
		return isRenew;
	}

	public void setRenew(boolean isRenew) {
		this.isRenew = isRenew;
	}

	public String getClientCreatedBy() {
		return clientCreatedBy;
	}

	public void setClientCreatedBy(String clientCreatedBy) {
		this.clientCreatedBy = clientCreatedBy;
	}

	public Timestamp getClientCreatedOn() {
		return clientCreatedOn;
	}

	public void setClientCreatedOn(Timestamp clientCreatedOn) {
		this.clientCreatedOn = clientCreatedOn;
	}

	public String getClientModifiedBy() {
		return clientModifiedBy;
	}

	public void setClientModifiedBy(String clientModifiedBy) {
		this.clientModifiedBy = clientModifiedBy;
	}

	public Timestamp getClientModifiedOn() {
		return clientModifiedOn;
	}

	public void setClientModifiedOn(Timestamp clientModifiedOn) {
		this.clientModifiedOn = clientModifiedOn;
	}

	public boolean isClientActive() {
		return clientActive;
	}

	public void setClientActive(boolean clientActive) {
		this.clientActive = clientActive;
	}

	public int getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(int portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

	public String getPortfolioDescription() {
		return portfolioDescription;
	}

	public void setPortfolioDescription(String portfolioDescription) {
		this.portfolioDescription = portfolioDescription;
	}

	public String getPortfolioCreatedBy() {
		return portfolioCreatedBy;
	}

	public void setPortfolioCreatedBy(String portfolioCreatedBy) {
		this.portfolioCreatedBy = portfolioCreatedBy;
	}

	public Timestamp getPortfolioCreatedOn() {
		return portfolioCreatedOn;
	}

	public void setPortfolioCreatedOn(Timestamp portfolioCreatedOn) {
		this.portfolioCreatedOn = portfolioCreatedOn;
	}

	public String getPortfolioModifiedBy() {
		return portfolioModifiedBy;
	}

	public void setPortfolioModifiedBy(String portfolioModifiedBy) {
		this.portfolioModifiedBy = portfolioModifiedBy;
	}

	public Timestamp getPortfolioModifiedOn() {
		return portfolioModifiedOn;
	}

	public void setPortfolioModifiedOn(Timestamp portfolioModifiedOn) {
		this.portfolioModifiedOn = portfolioModifiedOn;
	}

	public boolean isPortfolioActive() {
		return portfolioActive;
	}

	public void setPortfolioActive(boolean portfolioActive) {
		this.portfolioActive = portfolioActive;
	}

	public int getClientManagerId() {
		return clientManagerId;
	}

	public void setClientManagerId(int clientManagerId) {
		this.clientManagerId = clientManagerId;
	}

	public int getClientManagerPortfolioId() {
		return clientManagerPortfolioId;
	}

	public void setClientManagerPortfolioId(int clientManagerPortfolioId) {
		this.clientManagerPortfolioId = clientManagerPortfolioId;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getResourceManager() {
		return resourceManager;
	}

	public void setResourceManager(String resourceManager) {
		this.resourceManager = resourceManager;
	}

	public String getVicePresident() {
		return vicePresident;
	}

	public void setVicePresident(String vicePresident) {
		this.vicePresident = vicePresident;
	}

	public String getDirectorId() {
		return directorId;
	}

	public void setDirectorId(String directorId) {
		this.directorId = directorId;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public String getClientManagerCreatedBy() {
		return clientManagerCreatedBy;
	}

	public void setClientManagerCreatedBy(String clientManagerCreatedBy) {
		this.clientManagerCreatedBy = clientManagerCreatedBy;
	}

	public Timestamp getClientManagerCreatedOn() {
		return clientManagerCreatedOn;
	}

	public void setClientManagerCreatedOn(Timestamp clientManagerCreatedOn) {
		this.clientManagerCreatedOn = clientManagerCreatedOn;
	}

	public String getClientManagerModifiedBy() {
		return clientManagerModifiedBy;
	}

	public void setClientManagerModifiedBy(String clientManagerModifiedBy) {
		this.clientManagerModifiedBy = clientManagerModifiedBy;
	}

	public Timestamp getClientManagerModifiedOn() {
		return clientManagerModifiedOn;
	}

	public void setClientManagerModifiedOn(Timestamp clientManagerModifiedOn) {
		this.clientManagerModifiedOn = clientManagerModifiedOn;
	}

	public boolean isClientManagerActive() {
		return clientManagerActive;
	}

	public void setClientManagerActive(boolean clientManagerActive) {
		this.clientManagerActive = clientManagerActive;
	}

	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public String getRoleCreatedBy() {
		return roleCreatedBy;
	}

	public void setRoleCreatedBy(String roleCreatedBy) {
		this.roleCreatedBy = roleCreatedBy;
	}

	public Timestamp getRoleCreatedOn() {
		return roleCreatedOn;
	}

	public void setRoleCreatedOn(Timestamp roleCreatedOn) {
		this.roleCreatedOn = roleCreatedOn;
	}

	public String getRoleModifiedBy() {
		return roleModifiedBy;
	}

	public void setRoleModifiedBy(String roleModifiedBy) {
		this.roleModifiedBy = roleModifiedBy;
	}

	public Timestamp getRoleModifiedOn() {
		return roleModifiedOn;
	}

	public void setRoleModifiedOn(Timestamp roleModifiedOn) {
		this.roleModifiedOn = roleModifiedOn;
	}

	public boolean isRoleActive() {
		return roleActive;
	}

	public void setRoleActive(boolean roleActive) {
		this.roleActive = roleActive;
	}

	public int getPatternId() {
		return patternId;
	}

	public void setPatternId(int patternId) {
		this.patternId = patternId;
	}

	public int getPatternPortfolioId() {
		return patternPortfolioId;
	}

	public void setPatternPortfolioId(int patternPortfolioId) {
		this.patternPortfolioId = patternPortfolioId;
	}

	public String getPatternName() {
		return patternName;
	}

	public void setPatternName(String patternName) {
		this.patternName = patternName;
	}

	public String getPatternDescription() {
		return patternDescription;
	}

	public void setPatternDescription(String patternDescription) {
		this.patternDescription = patternDescription;
	}

	public String getSkillTeamDetails() {
		return skillTeamDetails;
	}

	public void setSkillTeamDetails(String skillTeamDetails) {
		this.skillTeamDetails = skillTeamDetails;
	}

	public String getClarity() {
		return clarity;
	}

	public void setClarity(String clarity) {
		this.clarity = clarity;
	}

	public String getUnixBoxes() {
		return unixBoxes;
	}

	public void setUnixBoxes(String unixBoxes) {
		this.unixBoxes = unixBoxes;
	}

	public String getTeradataAccess() {
		return teradataAccess;
	}

	public void setTeradataAccess(String teradataAccess) {
		this.teradataAccess = teradataAccess;
	}

	public String getAdAccess() {
		return adAccess;
	}

	public void setAdAccess(String adAccess) {
		this.adAccess = adAccess;
	}

	public String getAdditionalAccess() {
		return additionalAccess;
	}

	public void setAdditionalAccess(String additionalAccess) {
		this.additionalAccess = additionalAccess;
	}

	public String getSpecificAccess() {
		return specificAccess;
	}

	public void setSpecificAccess(String specificAccess) {
		this.specificAccess = specificAccess;
	}

	public String getBusinessJustification() {
		return businessJustification;
	}

	public void setBusinessJustification(String businessJustification) {
		this.businessJustification = businessJustification;
	}

	public String getPatternCreatedBy() {
		return patternCreatedBy;
	}

	public void setPatternCreatedBy(String patternCreatedBy) {
		this.patternCreatedBy = patternCreatedBy;
	}

	public Timestamp getPatternCreatedOn() {
		return patternCreatedOn;
	}

	public void setPatternCreatedOn(Timestamp patternCreatedOn) {
		this.patternCreatedOn = patternCreatedOn;
	}

	public String getPatternModifiedBy() {
		return patternModifiedBy;
	}

	public void setPatternModifiedBy(String patternModifiedBy) {
		this.patternModifiedBy = patternModifiedBy;
	}

	public Timestamp getPatternModifiedOn() {
		return patternModifiedOn;
	}

	public void setPatternModifiedOn(Timestamp patternModifiedOn) {
		this.patternModifiedOn = patternModifiedOn;
	}

	public boolean isPatternActive() {
		return patternActive;
	}

	public void setPatternActive(boolean patternActive) {
		this.patternActive = patternActive;
	}

	@Override
	public String toString() {
		return "EmployeeCustomDetailsMapping [accentureId=" + accentureId + ", accentureEmployeeNumber="
				+ accentureEmployeeNumber + ", accenturePortfolioId=" + accenturePortfolioId + ", rrdId=" + rrdId
				+ ", enterpriseId=" + enterpriseId + ", firstName=" + firstName + ", lastName=" + lastName + ", gender="
				+ gender + ", capability=" + capability + ", careerLevel=" + careerLevel + ", supervisorEntId="
				+ supervisorEntId + ", currentLocation=" + currentLocation + ", deliveryCenter=" + deliveryCenter
				+ ", visaType=" + visaType + ", durationStay=" + durationStay + ", phoneNo=" + phoneNo
				+ ", primarySkill=" + primarySkill + ", secondarySkill=" + secondarySkill + ", proficiencyLevel="
				+ proficiencyLevel + ", lockType=" + lockType + ", employeeStatus=" + employeeStatus + ", employeeType="
				+ employeeType + ", rollonDate=" + rollonDate + ", rollonBy=" + rollonBy + ", rolloffDate="
				+ rolloffDate + ", rolloffReason=" + rolloffReason + ", rolledoffBy=" + rolledoffBy + ", isExit="
				+ isExit + ", accentureCreatedBy=" + accentureCreatedBy + ", accentureCreatedOn=" + accentureCreatedOn
				+ ", accentureModifiedBy=" + accentureModifiedBy + ", accentureModifiedOn=" + accentureModifiedOn
				+ ", accentureActive=" + accentureActive + ", clientId=" + clientId + ", clientEmployeeNumber="
				+ clientEmployeeNumber + ", clientClientManagerId=" + clientClientManagerId + ", clientPatternId="
				+ clientPatternId + ", clientRoleId=" + clientRoleId + ", wmtUserId=" + wmtUserId + ", wmtAccessDate="
				+ wmtAccessDate + ", wmtGrantDate=" + wmtGrantDate + ", contractType=" + contractType + ", projectName="
				+ projectName + ", projectDetails=" + projectDetails + ", client=" + client + ", departmentNumber="
				+ departmentNumber + ", country=" + country + ", workstation=" + workstation + ", bayDetails="
				+ bayDetails + ", floor=" + floor + ", wbse=" + wbse + ", identifierType=" + identifierType
				+ ", identifierNumber=" + identifierNumber + ", comments=" + comments + ", onboardStartDate="
				+ onboardStartDate + ", onboardTime=" + onboardTime + ", onboardedBy=" + onboardedBy + ", isRenew="
				+ isRenew + ", clientCreatedBy=" + clientCreatedBy + ", clientCreatedOn=" + clientCreatedOn
				+ ", clientModifiedBy=" + clientModifiedBy + ", clientModifiedOn=" + clientModifiedOn
				+ ", clientActive=" + clientActive + ", portfolioId=" + portfolioId + ", portfolioName=" + portfolioName
				+ ", portfolioDescription=" + portfolioDescription + ", portfolioCreatedBy=" + portfolioCreatedBy
				+ ", portfolioCreatedOn=" + portfolioCreatedOn + ", portfolioModifiedBy=" + portfolioModifiedBy
				+ ", portfolioModifiedOn=" + portfolioModifiedOn + ", portfolioActive=" + portfolioActive
				+ ", clientManagerId=" + clientManagerId + ", clientManagerPortfolioId=" + clientManagerPortfolioId
				+ ", team=" + team + ", resourceManager=" + resourceManager + ", vicePresident=" + vicePresident
				+ ", directorId=" + directorId + ", contractId=" + contractId + ", clientManagerCreatedBy="
				+ clientManagerCreatedBy + ", clientManagerCreatedOn=" + clientManagerCreatedOn
				+ ", clientManagerModifiedBy=" + clientManagerModifiedBy + ", clientManagerModifiedOn="
				+ clientManagerModifiedOn + ", clientManagerActive=" + clientManagerActive + ", roleId=" + roleId
				+ ", role=" + role + ", roleDescription=" + roleDescription + ", location=" + location + ", rate="
				+ rate + ", roleCreatedBy=" + roleCreatedBy + ", roleCreatedOn=" + roleCreatedOn + ", roleModifiedBy="
				+ roleModifiedBy + ", roleModifiedOn=" + roleModifiedOn + ", roleActive=" + roleActive + ", patternId="
				+ patternId + ", patternPortfolioId=" + patternPortfolioId + ", patternName=" + patternName
				+ ", patternDescription=" + patternDescription + ", skillTeamDetails=" + skillTeamDetails + ", clarity="
				+ clarity + ", unixBoxes=" + unixBoxes + ", teradataAccess=" + teradataAccess + ", adAccess=" + adAccess
				+ ", additionalAccess=" + additionalAccess + ", specificAccess=" + specificAccess
				+ ", businessJustification=" + businessJustification + ", patternCreatedBy=" + patternCreatedBy
				+ ", patternCreatedOn=" + patternCreatedOn + ", patternModifiedBy=" + patternModifiedBy
				+ ", patternModifiedOn=" + patternModifiedOn + ", patternActive=" + patternActive + "]";
	}

		
}

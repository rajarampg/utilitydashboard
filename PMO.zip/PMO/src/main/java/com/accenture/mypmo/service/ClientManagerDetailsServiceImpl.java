/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.ClientManagerDetailsBiz;
import com.accenture.mypmo.model.ClientManagerDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/clientmanagerdetails")
public class ClientManagerDetailsServiceImpl implements ClientManagerDetailsService {

	@Autowired
	ClientManagerDetailsBiz clientManagerDetailsBiz;
	
	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.ClientManagerDetailsService#addClientManagerDetails(com.accenture.mypmo.model.ClientManagerDetails)
	 */
	@Override
	@RequestMapping(value = "/addclientmanagerdetails", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse addClientManagerDetails(ClientManagerDetails clientManagerDetails) {
		// TODO Auto-generated method stub
		return clientManagerDetailsBiz.captureClientManagerDetails(clientManagerDetails);
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.ClientManagerDetailsService#updateClientManagerDetails(com.accenture.mypmo.model.ClientManagerDetails)
	 */
	@Override
	@RequestMapping(value = "/updateclientmanagerdetails", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updateClientManagerDetails(ClientManagerDetails clientManagerDetails) {
		// TODO Auto-generated method stub
		return clientManagerDetailsBiz.captureClientManagerDetails(clientManagerDetails);
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.ClientManagerDetailsService#viewClientManagerDetailsByPortfolioId(int)
	 */
	@Override
	@RequestMapping(value = "/viewclientmanagerdetailsbyportfolioid/{portfolioId}", method = RequestMethod.GET)
	public List<ClientManagerDetails> viewClientManagerDetailsByPortfolioId(@PathVariable int portfolioId) {
		// TODO Auto-generated method stub
		return clientManagerDetailsBiz.viewClientManagerDetailsByPortfolioId(portfolioId);
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.ClientManagerDetailsService#viewClientManagerDetails(int)
	 */
	@Override
	@RequestMapping(value = "/viewclientmanagerdetails/{id}", method = RequestMethod.GET)
	public ClientManagerDetails viewClientManagerDetails(@PathVariable int id) {
		// TODO Auto-generated method stub
		return clientManagerDetailsBiz.viewClientManagerDetails(id);
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.ClientManagerDetailsService#viewAllClientManagerDetails()
	 */
	@Override
	@RequestMapping(value = "/viewallclientmanagerdetails", method = RequestMethod.GET)
	public List<ClientManagerDetails> viewAllClientManagerDetails() {
		// TODO Auto-generated method stub
		return clientManagerDetailsBiz.viewAllClientManagerDetails();
	}

}

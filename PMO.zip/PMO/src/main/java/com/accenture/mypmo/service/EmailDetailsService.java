/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import com.accenture.mypmo.model.EmailDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface EmailDetailsService {

	PMOResponse CaptureEmailDetails(EmailDetails email);

	PMOResponse updateEmailDetails(EmailDetails email);

	PMOResponse updateAllEmailDetails(List<EmailDetails> email);

	EmailDetails viewEmailDetails(int emailId);
	
	List<EmailDetails> viewAllEmailDetails();
	
}

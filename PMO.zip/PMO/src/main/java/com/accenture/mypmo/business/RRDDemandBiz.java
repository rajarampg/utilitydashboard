package com.accenture.mypmo.business;

import java.util.List;

import com.accenture.mypmo.model.RRDDemand;
import com.accenture.mypmo.response.PMOResponse;

public interface RRDDemandBiz {

	PMOResponse captureRRDByDemandId (List<RRDDemand> rrdDeman);

	List<RRDDemand> viewRRDByDemandId(String demandId);
}

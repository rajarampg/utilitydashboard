package com.accenture.mypmo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.ACLReportsBizImpl;
import com.accenture.mypmo.mapper.ACLReport;

@CrossOrigin
@RestController
@RequestMapping(value = "/reports")
public class ACLReportServiceImpl {
	
	
	@Autowired
	@Qualifier(value="aclReportsBizImpl")
	ACLReportsBizImpl aclReportsBizImpl;
	
	@RequestMapping(value = "/acl", method = RequestMethod.GET)
	public List<ACLReport> fetchReports() {
		return aclReportsBizImpl.fetchReports();
	}
	
}

package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.PortfolioDetails;
import com.accenture.mypmo.model.PortfolioDetailsMapping;

@Component
public class PortfolioDetailsMapper {

	public PortfolioDetailsMapping portfolioDetailsMapper(PortfolioDetails portfolioDetails) {

		PortfolioDetailsMapping portfolioDetailsMapping = new PortfolioDetailsMapping();

		portfolioDetailsMapping.setId(portfolioDetails.getId());
		portfolioDetailsMapping.setPortfolioName(portfolioDetails.getPortfolioName());
		portfolioDetailsMapping.setPortfolioDescription(portfolioDetails.getPortfolioDescription());
		portfolioDetailsMapping.setCreatedOn(portfolioDetails.getCreatedOn());
		portfolioDetailsMapping.setCreatedBy(portfolioDetails.getCreatedBy());
		portfolioDetailsMapping.setModifiedOn(portfolioDetails.getModifiedOn());
		portfolioDetailsMapping.setModifiedBy(portfolioDetails.getModifiedBy());
		portfolioDetailsMapping.setActive(portfolioDetails.isActive());

		return portfolioDetailsMapping;
	}

	public PortfolioDetails portfolioDetailsMapMapper(PortfolioDetailsMapping portfolioDetailsMapping) {

		PortfolioDetails portfolioDetails = new PortfolioDetails();

		portfolioDetails.setId(portfolioDetailsMapping.getId());
		portfolioDetails.setPortfolioName(portfolioDetailsMapping.getPortfolioName());
		portfolioDetails.setPortfolioDescription(portfolioDetailsMapping.getPortfolioDescription());
		portfolioDetails.setCreatedOn(portfolioDetailsMapping.getCreatedOn());
		portfolioDetails.setCreatedBy(portfolioDetailsMapping.getCreatedBy());
		portfolioDetails.setModifiedOn(portfolioDetailsMapping.getModifiedOn());
		portfolioDetails.setModifiedBy(portfolioDetailsMapping.getModifiedBy());
		portfolioDetails.setActive(portfolioDetailsMapping.isActive());

		return portfolioDetails;
	}

	public List<PortfolioDetails> portfolioDetailsMapMapperCollection(List<PortfolioDetailsMapping> portfolioDetailsMapping) {

		List<PortfolioDetails> portfolioDetails = new ArrayList<PortfolioDetails>();
		
		for(PortfolioDetailsMapping portfolioDetailsMappingTemp: portfolioDetailsMapping ){
			portfolioDetails.add(portfolioDetailsMapMapper(portfolioDetailsMappingTemp));
		}

		return portfolioDetails;
	}
	
	public List<PortfolioDetails> portfolioDetailsIterableMapMapperCollection(Iterable<PortfolioDetailsMapping> portfolioDetailsMapping) {

		List<PortfolioDetails> portfolioDetails = new ArrayList<PortfolioDetails>();
		
		for(PortfolioDetailsMapping portfolioDetailsMappingTemp: portfolioDetailsMapping ){
			portfolioDetails.add(portfolioDetailsMapMapper(portfolioDetailsMappingTemp));
		}

		return portfolioDetails;
	}

}

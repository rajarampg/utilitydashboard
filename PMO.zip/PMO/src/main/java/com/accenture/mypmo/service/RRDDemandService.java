/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import com.accenture.mypmo.model.RRDDemand;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface RRDDemandService {

	PMOResponse captureRRDByDemandId (List<RRDDemand> rrdDeman);

	PMOResponse updateRRDByDemandId (List<RRDDemand> rrdDeman);

	List<RRDDemand> viewRRDByDemandId(String demandId);
}

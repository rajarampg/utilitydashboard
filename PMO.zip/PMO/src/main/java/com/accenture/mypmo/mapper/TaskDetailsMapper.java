/**
 * 
 */
package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.TaskDetails;
import com.accenture.mypmo.model.TaskDetailsMapping;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class TaskDetailsMapper {

	public TaskDetailsMapping taskDetailsMapper(TaskDetails taskObject) {

		TaskDetailsMapping taskMapperObject = new TaskDetailsMapping();

		taskMapperObject.setId(taskObject.getId());
		taskMapperObject.setTaskName(taskObject.getTaskName());
		taskMapperObject.setTaskDescription(taskObject.getTaskDescription());
		taskMapperObject.setRequestType(taskObject.getRequestType());
		taskMapperObject.setSubrequestType(taskObject.getSubrequestType());
		taskMapperObject.setApprovedBy(taskObject.getApprovedBy());
		taskMapperObject.setApprovedOn(taskObject.getApprovedOn());
		taskMapperObject.setApproverComments(taskObject.getApproverComments());
		taskMapperObject.setAssignedTo(taskObject.getAssignedTo());
		taskMapperObject.setAssignedOn(taskObject.getAssignedOn());
		taskMapperObject.setStatus(taskObject.getStatus());
		taskMapperObject.setComments(taskObject.getComments());
		taskMapperObject.setCreatedBy(taskObject.getCreatedBy());
		taskMapperObject.setCreatedOn(taskObject.getCreatedOn());
		taskMapperObject.setModifiedBy(taskObject.getModifiedBy());
		taskMapperObject.setModifiedOn(taskObject.getModifiedOn());
		taskMapperObject.setActive(taskObject.isActive());

		return taskMapperObject;
	}

	public TaskDetails taskDetailsMapMapper(TaskDetailsMapping taskMapObject) {

		TaskDetails taskObject = new TaskDetails();

		taskObject.setId(taskMapObject.getId());
		taskObject.setTaskName(taskMapObject.getTaskName());
		taskObject.setTaskDescription(taskMapObject.getTaskDescription());
		taskObject.setRequestType(taskMapObject.getRequestType());
		taskObject.setSubrequestType(taskMapObject.getSubrequestType());
		taskObject.setApprovedBy(taskMapObject.getApprovedBy());
		taskObject.setApprovedOn(taskMapObject.getApprovedOn());
		taskObject.setApproverComments(taskMapObject.getApproverComments());
		taskObject.setAssignedTo(taskMapObject.getAssignedTo());
		taskObject.setAssignedOn(taskMapObject.getAssignedOn());
		taskObject.setStatus(taskMapObject.getStatus());
		taskObject.setComments(taskMapObject.getComments());
		taskObject.setCreatedBy(taskMapObject.getCreatedBy());
		taskObject.setCreatedOn(taskMapObject.getCreatedOn());
		taskObject.setModifiedBy(taskMapObject.getModifiedBy());
		taskObject.setModifiedOn(taskMapObject.getModifiedOn());
		taskObject.setActive(taskMapObject.isActive());

		return taskObject;
	}

	public List<TaskDetailsMapping> taskDetailsMapperCollection(List<TaskDetails> taskDetails){
		List<TaskDetailsMapping> taskDetailsMapping = new ArrayList<TaskDetailsMapping>();
		
		for(TaskDetails taskDetailsTemp: taskDetails){
			taskDetailsMapping.add(taskDetailsMapper(taskDetailsTemp));
		}
		
		return taskDetailsMapping;	
	}

	public List<TaskDetails> taskDetailsMapMapperCollection(List<TaskDetailsMapping> taskDetailsMapping){
		List<TaskDetails> taskDetails = new ArrayList<TaskDetails>();
		
		for(TaskDetailsMapping taskDetailsMappingTemp: taskDetailsMapping){
			taskDetails.add(taskDetailsMapMapper(taskDetailsMappingTemp));
		}
		
		return taskDetails;	
	}

	public List<TaskDetails> taskDetailsIterableMapMapperCollection(Iterable<TaskDetailsMapping> taskDetailsMapping){
		List<TaskDetails> taskDetails = new ArrayList<TaskDetails>();
		
		for(TaskDetailsMapping taskDetailsMappingTemp: taskDetailsMapping){
			taskDetails.add(taskDetailsMapMapper(taskDetailsMappingTemp));
		}
		
		return taskDetails;	
	}
}

/**
 * 
 */
package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.EmployeeClientDetails;
import com.accenture.mypmo.model.EmployeeClientDetailsMapping;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class EmployeeClientDetailsMapper {

	public EmployeeClientDetailsMapping employeeClientDetailsMapper(EmployeeClientDetails employeeClientDetails) {
		EmployeeClientDetailsMapping employeeClientDetailsMapping = new EmployeeClientDetailsMapping();

		employeeClientDetailsMapping.setId(employeeClientDetails.getId());
		employeeClientDetailsMapping.setEmployeeNumber(employeeClientDetails.getEmployeeNumber());
		employeeClientDetailsMapping.setClientManagerId(employeeClientDetails.getClientManagerId());
		employeeClientDetailsMapping.setPatternId(employeeClientDetails.getPatternId());
		employeeClientDetailsMapping.setRoleId(employeeClientDetails.getRoleId());
		employeeClientDetailsMapping.setWmtUserId(employeeClientDetails.getWmtUserId());
		employeeClientDetailsMapping.setWmtAccessDate(employeeClientDetails.getWmtAccessDate());
		employeeClientDetailsMapping.setWmtGrantDate(employeeClientDetails.getWmtGrantDate());
		employeeClientDetailsMapping.setContractType(employeeClientDetails.getContractType());
		employeeClientDetailsMapping.setProjectName(employeeClientDetails.getProjectName());
		employeeClientDetailsMapping.setProjectDetails(employeeClientDetails.getProjectDetails());
		employeeClientDetailsMapping.setClient(employeeClientDetails.getClient());
		employeeClientDetailsMapping.setDepartmentNumber(employeeClientDetails.getDepartmentNumber());
		employeeClientDetailsMapping.setCountry(employeeClientDetails.getCountry());
		employeeClientDetailsMapping.setWorkstation(employeeClientDetails.getWorkstation());
		employeeClientDetailsMapping.setBayDetails(employeeClientDetails.getBayDetails());
		employeeClientDetailsMapping.setFloor(employeeClientDetails.getFloor());
		employeeClientDetailsMapping.setWbse(employeeClientDetails.getWbse());
		employeeClientDetailsMapping.setIdentifierType(employeeClientDetails.getIdentifierType());
		employeeClientDetailsMapping.setIdentifierNumber(employeeClientDetails.getIdentifierNumber());
		employeeClientDetailsMapping.setComments(employeeClientDetails.getComments());
		employeeClientDetailsMapping.setOnboardStartDate(employeeClientDetails.getOnboardStartDate());
		employeeClientDetailsMapping.setOnboardTime(employeeClientDetails.getOnboardTime());
		employeeClientDetailsMapping.setOnboardedBy(employeeClientDetails.getOnboardedBy());
		employeeClientDetailsMapping.setRenew(employeeClientDetails.isRenew());
		employeeClientDetailsMapping.setCreatedBy(employeeClientDetails.getCreatedBy());
		employeeClientDetailsMapping.setCreatedOn(employeeClientDetails.getCreatedOn());
		employeeClientDetailsMapping.setModifiedBy(employeeClientDetails.getModifiedBy());
		employeeClientDetailsMapping.setModifiedOn(employeeClientDetails.getModifiedOn());
		employeeClientDetailsMapping.setActive(employeeClientDetails.isActive());

		return employeeClientDetailsMapping;
	}

	public EmployeeClientDetails employeeClientDetailsMapMapper(
			EmployeeClientDetailsMapping employeeClientDetailsmapping) {
		EmployeeClientDetails employeeClientDetails = new EmployeeClientDetails();

		employeeClientDetails.setId(employeeClientDetailsmapping.getId());
		employeeClientDetails.setEmployeeNumber(employeeClientDetailsmapping.getEmployeeNumber());
		employeeClientDetails.setClientManagerId(employeeClientDetailsmapping.getClientManagerId());
		employeeClientDetails.setPatternId(employeeClientDetailsmapping.getPatternId());
		employeeClientDetails.setRoleId(employeeClientDetailsmapping.getRoleId());
		employeeClientDetails.setWmtUserId(employeeClientDetailsmapping.getWmtUserId());
		employeeClientDetails.setWmtAccessDate(employeeClientDetailsmapping.getWmtAccessDate());
		employeeClientDetails.setWmtGrantDate(employeeClientDetailsmapping.getWmtGrantDate());
		employeeClientDetails.setContractType(employeeClientDetailsmapping.getContractType());
		employeeClientDetails.setProjectName(employeeClientDetailsmapping.getProjectName());
		employeeClientDetails.setProjectDetails(employeeClientDetailsmapping.getProjectDetails());
		employeeClientDetails.setClient(employeeClientDetailsmapping.getClient());
		employeeClientDetails.setDepartmentNumber(employeeClientDetailsmapping.getDepartmentNumber());
		employeeClientDetails.setCountry(employeeClientDetailsmapping.getCountry());
		employeeClientDetails.setWorkstation(employeeClientDetailsmapping.getWorkstation());
		employeeClientDetails.setBayDetails(employeeClientDetailsmapping.getBayDetails());
		employeeClientDetails.setFloor(employeeClientDetailsmapping.getFloor());
		employeeClientDetails.setWbse(employeeClientDetailsmapping.getWbse());
		employeeClientDetails.setIdentifierType(employeeClientDetailsmapping.getIdentifierType());
		employeeClientDetails.setIdentifierNumber(employeeClientDetailsmapping.getIdentifierNumber());
		employeeClientDetails.setComments(employeeClientDetailsmapping.getComments());
		employeeClientDetails.setOnboardStartDate(employeeClientDetailsmapping.getOnboardStartDate());
		employeeClientDetails.setOnboardTime(employeeClientDetailsmapping.getOnboardTime());
		employeeClientDetails.setOnboardedBy(employeeClientDetailsmapping.getOnboardedBy());
		employeeClientDetails.setRenew(employeeClientDetailsmapping.isRenew());
		employeeClientDetails.setCreatedBy(employeeClientDetailsmapping.getCreatedBy());
		employeeClientDetails.setCreatedOn(employeeClientDetailsmapping.getCreatedOn());
		employeeClientDetails.setModifiedBy(employeeClientDetailsmapping.getModifiedBy());
		employeeClientDetails.setModifiedOn(employeeClientDetailsmapping.getModifiedOn());
		employeeClientDetails.setActive(employeeClientDetailsmapping.isActive());

		return employeeClientDetails;
	}

	public List<EmployeeClientDetails> employeeClientDetailsMapMapperCollection(
			List<EmployeeClientDetailsMapping> employeeClientDetailsmapping) {
		List<EmployeeClientDetails> employeeClientDetails = new ArrayList<EmployeeClientDetails>();

		for (EmployeeClientDetailsMapping employeeClientDetailsmappingTemp : employeeClientDetailsmapping) {
			employeeClientDetails.add(employeeClientDetailsMapMapper(employeeClientDetailsmappingTemp));
		}

		return employeeClientDetails;
	}

	public List<EmployeeClientDetailsMapping> employeeClientDetailsMapperCollection(
			List<EmployeeClientDetails> employeeClientDetails) {
		List<EmployeeClientDetailsMapping> employeeClientDetailsmapping = new ArrayList<EmployeeClientDetailsMapping>();

		for (EmployeeClientDetails employeeClientDetailsTemp : employeeClientDetails) {
			employeeClientDetailsmapping.add(employeeClientDetailsMapper(employeeClientDetailsTemp));
		}

		return employeeClientDetailsmapping;
	}

	public List<EmployeeClientDetails> employeeClientDetailsIterableMapMapper(
			Iterable<EmployeeClientDetailsMapping> employeeClientDetailsmapping) {
		List<EmployeeClientDetails> employeeClientDetails = new ArrayList<EmployeeClientDetails>();

		for (EmployeeClientDetailsMapping employeeClientDetailsmappingTemp : employeeClientDetailsmapping) {
			employeeClientDetails.add(employeeClientDetailsMapMapper(employeeClientDetailsmappingTemp));
		}

		return employeeClientDetails;
	}
}

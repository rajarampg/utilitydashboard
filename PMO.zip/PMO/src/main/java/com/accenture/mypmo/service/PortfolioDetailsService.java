/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import com.accenture.mypmo.model.PortfolioDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface PortfolioDetailsService {

	PMOResponse addPortfolioDetails(PortfolioDetails portfolioDetails);
	
	PMOResponse updatePortfolioDetails(PortfolioDetails portfolioDetails);

	PortfolioDetails viewPortfolioDetails(int id);
	
	List<PortfolioDetails> ViewAllPortfolioDetails();


}

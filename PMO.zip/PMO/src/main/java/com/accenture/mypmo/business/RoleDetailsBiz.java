package com.accenture.mypmo.business;

import java.util.List;

import com.accenture.mypmo.model.RoleDetails;
import com.accenture.mypmo.response.PMOResponse;

public interface RoleDetailsBiz {

	PMOResponse captureTaskDetails(RoleDetails roleDetails);
	
	RoleDetails viewRoleDetails(int id);
	
	List<RoleDetails> ViewAllRoleDetails();

}

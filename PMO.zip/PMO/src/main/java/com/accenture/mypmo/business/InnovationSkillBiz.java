package com.accenture.mypmo.business;



import java.util.List;

import com.accenture.mypmo.model.InnovationSkill;
import com.accenture.mypmo.model.InnovationSkillMapping;

public interface InnovationSkillBiz {

	 String captureInnovationDetails(InnovationSkill innovation);

	 List<InnovationSkillMapping> getInnovationDetails(int id);

}

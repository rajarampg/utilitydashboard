/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.List;

import com.accenture.mypmo.model.EmployeeCountReport;

/**
 * @author p.senthilrajan
 *
 */
public interface EmployeeCountReportBiz {

	List<EmployeeCountReport> empCountByPortfolio();
	
	List<EmployeeCountReport> empCountByEmpStatus();

	List<EmployeeCountReport> empCountByRolloff();

	List<EmployeeCountReport> empCountByCareerLevel();
}

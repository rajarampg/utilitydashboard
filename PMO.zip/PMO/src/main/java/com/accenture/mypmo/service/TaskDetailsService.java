/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import com.accenture.mypmo.model.TaskDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface TaskDetailsService {

	PMOResponse captureTaskDetails(TaskDetails taskDetails);

	PMOResponse updateTaskDetails(TaskDetails taskDetails);

	PMOResponse updateAllTaskDetails(List<TaskDetails> taskDetails);

	TaskDetails viewTaskDetails(int taskId);
	
	List<TaskDetails> ViewAllTaskDetails();

	List<TaskDetails> ViewTaskDetailsByCreatedBy(String createdBy);

	List<TaskDetails> ViewTaskDetailsByAssignedTo(String assignedTo);
}

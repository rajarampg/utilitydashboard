package com.accenture.mypmo.utilities;

import java.util.Arrays;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.EmailDetails;

@Component
public class TriggerEmail {

	Properties emailProperties;
	
//	TODO: Now heres an hardcoding, that is never required to be moved to property file
	public TriggerEmail() {
		String emailHost ="ind.smtp.accenture.com";
		String emailPort ="25";
		emailProperties = System.getProperties();
		emailProperties.setProperty("mail.smtp.host", emailHost);
		emailProperties.put("mail.smtp.port", emailPort);
		emailProperties.put("mail.smtp.socketFactory.port", emailPort);
	}
	
	void processEmail(EmailDetails emailDetails) throws AddressException, MessagingException{
		emailDetails.setToIds(Arrays.asList(emailDetails.getToAddress().split(";")));
		emailDetails.setCcIds(Arrays.asList(emailDetails.getCc().split(";")));
		emailDetails.setBccIds(Arrays.asList(emailDetails.getBcc().split(";")));
		MimeMessage mimeMessage = createEmailMessage(emailDetails);
		System.out.println("now the mailer should have been sent... this is it");
		Transport.send(mimeMessage);
	}


	public MimeMessage createEmailMessage(EmailDetails emailDetails) throws AddressException,
	MessagingException {
		Session mailSession = null;
		MimeMessage emailMessage = null;

		mailSession = Session.getDefaultInstance(emailProperties, null);
		emailMessage = new MimeMessage(mailSession);
       
		for (String to : emailDetails.getToIds()) {
			if(!to.isEmpty())
				emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
		}
		
		for (String cc : emailDetails.getCcIds()) {
			if(!cc.isEmpty())
				emailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(cc));
		}
		
		for (String bcc : emailDetails.getBccIds()) {
			if(!bcc.isEmpty())
				emailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(bcc));
		}
		
		emailMessage.setFrom(new InternetAddress(emailDetails.getFromAddress()));
		emailMessage.setSubject(emailDetails.getSubject());
		emailMessage.setContent(generateMailContent(emailDetails), "text/html");//for a html email
		return emailMessage;
	}
	
	
//	TODO HANDLE TEMPLATE CONTENT HERE...
	String generateMailContent(EmailDetails emailDetails){
		return emailDetails.getContentDetails();
	}

}

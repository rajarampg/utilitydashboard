/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.RoleDetailsMapper;
import com.accenture.mypmo.model.RoleDetails;
import com.accenture.mypmo.model.RoleDetailsMapping;
import com.accenture.mypmo.repository.RoleDetailsRepository;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class RoleDetailsBizImpl implements RoleDetailsBiz {

	@Autowired
	RoleDetailsMapper roleDetailsMapper;
	
	@Autowired
	RoleDetailsRepository roleDetailsRepo;
	
	/* (non-Javadoc)
	 * @see com.accenture.mypmo.business.RoleDetailsBiz#captureTaskDetails(com.accenture.mypmo.model.RoleDetails)
	 */
	@Override
	public PMOResponse captureTaskDetails(RoleDetails roleDetails) {

		PMOResponse systemResponse = new PMOResponse();
		RoleDetailsMapping roleDetailsMapping = roleDetailsMapper.roleDetailsMapper(roleDetails);
		try {
			roleDetailsRepo.save(roleDetailsMapping);
		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}

		return systemResponse;
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.business.RoleDetailsBiz#viewRoleDetails(int)
	 */
	@Override
	public RoleDetails viewRoleDetails(int id) {
		RoleDetails roleDetails = new RoleDetails();

		try {
			roleDetails = roleDetailsMapper.roleDetailsMapMapper(roleDetailsRepo.findById(id));
		} catch (Exception e) {
			System.out.println("Exception in SQL operation " + e);
		}

		return roleDetails;
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.business.RoleDetailsBiz#ViewAllRoleDetails()
	 */
	@Override
	public List<RoleDetails> ViewAllRoleDetails() {
		List<RoleDetails> roleDetails = new ArrayList<RoleDetails>();

		try {
			roleDetails = roleDetailsMapper.roleDetailsIterableMapMapper(roleDetailsRepo.findAll());
		} catch (Exception e) {
			System.out.println("Exception in SQL operation " + e);
		}

		return roleDetails;
	}

}

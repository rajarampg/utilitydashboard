/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.AssertDetailsBiz;
import com.accenture.mypmo.model.AssertDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/assertdetails")
public class AssertDetailsServiceImpl implements AssertDetailsService {

	@Autowired
	public AssertDetailsBiz assertDetailsBiz;
	
	@Override
	@RequestMapping(value = "/addassertdetails", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse captureAssertDetails(@RequestBody AssertDetails assertDetails) {
		// TODO Auto-generated method stub
		return assertDetailsBiz.captureAssertDetails(assertDetails);
	}

	@Override
	@RequestMapping(value = "/updateassertdetails", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updateAssertDetails(@RequestBody AssertDetails assertDetails) {
		// TODO Auto-generated method stub
		return assertDetailsBiz.captureAssertDetails(assertDetails);
	}

	@Override
	@RequestMapping(value = "/viewassertdetails/{id}", method = RequestMethod.GET)
	public AssertDetails viewAssertDetails(@PathVariable int id) {
		// TODO Auto-generated method stub
		return assertDetailsBiz.viewAssertDetails(id);
	}
	
	@Override
	@RequestMapping(value = "/viewassertdetailsbyassignedto", method = RequestMethod.GET)
	public List<AssertDetails> viewAssertDetailsByAssignedTo(@QueryParam("assignedTo") String assignedTo) {
		// TODO Auto-generated method stub
		return assertDetailsBiz.viewAssertDetailsByAssignedTo(assignedTo);
	}

	@Override
	@RequestMapping(value = "/viewallassertdetails", method = RequestMethod.GET)
	public List<AssertDetails> viewAllAssertDetails() {
		// TODO Auto-generated method stub
		return assertDetailsBiz.viewAllAssertDetails();
	}

}

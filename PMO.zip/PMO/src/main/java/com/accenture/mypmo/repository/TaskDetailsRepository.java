/**
 * 
 */
package com.accenture.mypmo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.TaskDetailsMapping;

/**
 * @author p.senthilrajan
 *
 */
public interface TaskDetailsRepository extends CrudRepository<TaskDetailsMapping, String>, JpaSpecificationExecutor<TaskDetailsMapping>{

	public TaskDetailsMapping findById(int id);
	
	public List<TaskDetailsMapping> findByCreatedBy(String createdBy);
	
	public List<TaskDetailsMapping> findByAssignedTo(String assignedTo);
}

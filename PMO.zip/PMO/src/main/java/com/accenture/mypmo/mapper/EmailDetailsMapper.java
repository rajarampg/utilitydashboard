/**
 * 
 */
package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.EmailDetails;
import com.accenture.mypmo.model.EmailDetailsMapping;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class EmailDetailsMapper {
	
	public EmailDetailsMapping emailDetailsMapping(EmailDetails email){
		
		System.out.println("inside Mapping :"+email.getSubject());
		
		EmailDetailsMapping emailMapping = new EmailDetailsMapping();
		
		emailMapping.setId(email.getId());
		emailMapping.setFromAddress(email.getFromAddress());
		emailMapping.setToAddress(email.getToAddress());
		emailMapping.setCc(email.getCc());
		emailMapping.setBcc(email.getBcc());
		emailMapping.setSubject(email.getSubject());
		emailMapping.setContentDetails(email.getContentDetails());
		emailMapping.setCreatedDate(email.getCreatedDate());
		emailMapping.setCreatedBy(email.getCreatedBy());
		emailMapping.setSentDate(email.getSentDate());
		emailMapping.setStatus(email.getStatus());
		emailMapping.setActive(email.isActive());
		System.out.println("after Mapping :"+emailMapping.getSubject());
		
		return emailMapping;
	}

	public EmailDetails emailDetailsMapMapping(EmailDetailsMapping emailMapping){

		EmailDetails email = new EmailDetails();
		email.setId(emailMapping.getId());
		email.setFromAddress(emailMapping.getFromAddress());
		email.setToAddress(emailMapping.getToAddress());
		email.setCc(emailMapping.getCc());
		email.setBcc(emailMapping.getBcc());
		email.setSubject(emailMapping.getSubject());
		email.setContentDetails(emailMapping.getContentDetails());
		email.setCreatedDate(emailMapping.getCreatedDate());
		email.setCreatedBy(emailMapping.getCreatedBy());
		email.setSentDate(emailMapping.getSentDate());
		email.setStatus(emailMapping.getStatus());
		email.setActive(emailMapping.isActive());
		return email;
		
	}
	
	public List<EmailDetails> emailDetailsMapMappingCollection(List<EmailDetailsMapping> emailDetailsMappings){
		List<EmailDetails> emailDetails = new ArrayList<EmailDetails>();
		for(EmailDetailsMapping emailDetailsMappingTemp : emailDetailsMappings){
			emailDetails.add(emailDetailsMapMapping(emailDetailsMappingTemp));
		}
		return emailDetails;
	}
	
	public List<EmailDetails> emailDetailsIterableMapMappingCollection(Iterable<EmailDetailsMapping> emailDetailsMappings){
		List<EmailDetails> emailDetails = new ArrayList<EmailDetails>();
		for(EmailDetailsMapping emailDetailsMappingTemp : emailDetailsMappings){
			emailDetails.add(emailDetailsMapMapping(emailDetailsMappingTemp));
		}
		return emailDetails;
	}
	
	public List<EmailDetailsMapping> emailDetailsMappingCollection(List<EmailDetails> emailDetails){
		List<EmailDetailsMapping> emailDetailsMapping = new ArrayList<EmailDetailsMapping>();
		for(EmailDetails emailDetailsTemp : emailDetails){
			emailDetailsMapping.add(emailDetailsMapping(emailDetailsTemp));
		}
		return emailDetailsMapping;
	}
	
}

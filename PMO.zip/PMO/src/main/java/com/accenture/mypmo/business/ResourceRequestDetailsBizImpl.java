package com.accenture.mypmo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.ResourceRequestDetailsMapper;
import com.accenture.mypmo.model.ResourceRequestDetailsMapping;
import com.accenture.mypmo.model.ResourceRequestDetails;
import com.accenture.mypmo.repository.ResourceRequestRepository;
import com.accenture.mypmo.response.PMOResponse;

@Component
public class ResourceRequestDetailsBizImpl implements ResourceRequestDetailsBiz {

	@Autowired
	ResourceRequestRepository resourceRequestRepository;

	@Autowired
	ResourceRequestDetailsMapper resourceRequestDetailsMapper;

	@Override
	public PMOResponse captureResourceRequestsDetails(ResourceRequestDetails rrdDetails) {

		PMOResponse systemResponse = new PMOResponse();
		List<ResourceRequestDetailsMapping> rrdMappingDetails = resourceRequestDetailsMapper.rrdMapper(rrdDetails);

		try {
			resourceRequestRepository.save(rrdMappingDetails);
		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}

		return systemResponse;
	}

	@Override
	public List<ResourceRequestDetails> viewRRDByPortfolioId(int portfolioId) {

		List<ResourceRequestDetails> resourceDetails = new ArrayList<ResourceRequestDetails>();
		try {
			resourceDetails = resourceRequestDetailsMapper.rrdMapMapperCollection(resourceRequestRepository.findByPortfolioId(portfolioId));
		} catch (Exception e) {
			System.out.println("Exception" + e);
		}

		return resourceDetails;
	}

	@Override
	public ResourceRequestDetails viewResourceRequestsDetails(int id) {
		ResourceRequestDetails resourceDetails = new ResourceRequestDetails();

		try {

			resourceDetails = resourceRequestDetailsMapper.rrdMapMapper(resourceRequestRepository.findById(id));

		} catch (Exception e) {
			System.out.println("Exception" + e);
		}
		return resourceDetails;
	}

	@Override
	public List<ResourceRequestDetails> viewAllRRD() {
		List<ResourceRequestDetails> resourceDetails = new ArrayList<ResourceRequestDetails>();
		try {
			resourceDetails = resourceRequestDetailsMapper.rrdMapMapperIterableCollection(resourceRequestRepository.findAll());
		} catch (Exception e) {
			System.out.println("Exception" + e);
		}

		return resourceDetails;
	}

	
}

/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.List;

import com.accenture.mypmo.model.ClientManagerDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface ClientManagerDetailsBiz {

	PMOResponse captureClientManagerDetails(ClientManagerDetails clientManagerDetails);
	
	List<ClientManagerDetails> viewClientManagerDetailsByPortfolioId(int portfolioId);

	ClientManagerDetails viewClientManagerDetails(int id);

	List<ClientManagerDetails> viewAllClientManagerDetails();

}

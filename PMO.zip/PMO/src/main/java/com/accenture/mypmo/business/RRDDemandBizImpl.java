/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.RRDDemandMapper;
import com.accenture.mypmo.model.RRDDemand;
import com.accenture.mypmo.model.RRDDemandMapping;
import com.accenture.mypmo.repository.RRDDemandRepository;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class RRDDemandBizImpl implements RRDDemandBiz {

	@Autowired
	RRDDemandRepository rrdDemandRepo;

	@Autowired
	RRDDemandMapper rrdDemandMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.accenture.mypmo.business.RRDDemandBiz#captureRRDByDemandId(java.util.
	 * List)
	 */
	@Override
	public PMOResponse captureRRDByDemandId(List<RRDDemand> rrdDeman) {
		PMOResponse systemResponse = new PMOResponse();
		List<RRDDemandMapping> rrdDemandMapping = rrdDemandMapper.rrdDemandMapperCollection(rrdDeman);

		try {
			rrdDemandRepo.save(rrdDemandMapping);
		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}

		return systemResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.accenture.mypmo.business.RRDDemandBiz#viewRRDByDemandId(java.lang.
	 * String)
	 */
	@Override
	public List<RRDDemand> viewRRDByDemandId(String demandId) {
		List<RRDDemand> rrdDemandDetails = new ArrayList<RRDDemand>();
		try {
			System.out.println(demandId);
			rrdDemandDetails = rrdDemandMapper.rrdDemandMapMapperCollection(rrdDemandRepo.findByDemandId(demandId));
		} catch (Exception e) {
			System.out.println(e);
		}
		return rrdDemandDetails;
	}

}

package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.RRDDemand;
import com.accenture.mypmo.model.RRDDemandMapping;

@Component
public class RRDDemandMapper {

	public RRDDemandMapping rrdDemandMapper(RRDDemand rrdDemand){
		RRDDemandMapping rrdDemandMapping = new RRDDemandMapping();
		
		rrdDemandMapping.setId(rrdDemand.getId());
		rrdDemandMapping.setRrdId(rrdDemand.getRrdId());
		rrdDemandMapping.setDemandId(rrdDemand.getDemandId());
		rrdDemandMapping.setCreatedBy(rrdDemand.getCreatedBy());
		rrdDemandMapping.setCreatedOn(rrdDemand.getCreatedOn());
		rrdDemandMapping.setUpdatedBy(rrdDemand.getUpdatedBy());
		rrdDemandMapping.setUpdatedOn(rrdDemand.getUpdatedOn());
		rrdDemandMapping.setActive(rrdDemand.isActive());

		return rrdDemandMapping;
	}


	public List<RRDDemandMapping> rrdDemandMapperCollection(List<RRDDemand> rrdDemand){
		List<RRDDemandMapping> rrdDemandMapping = new ArrayList<RRDDemandMapping>();
		
		for(RRDDemand rrdDemandTemp: rrdDemand){
			rrdDemandMapping.add(rrdDemandMapper(rrdDemandTemp));
		}
		
		return rrdDemandMapping;
	}

	public List<RRDDemand> rrdDemandMapMapperCollection(List<RRDDemandMapping> rrdDemandMapping){
		List<RRDDemand> rrdDemand = new ArrayList<RRDDemand>();
		
		for(RRDDemandMapping rrdDemandMapTemp: rrdDemandMapping){
			rrdDemand.add(rrdDemandMapMapper(rrdDemandMapTemp));
		}
		
		return rrdDemand;
	}

	public RRDDemand rrdDemandMapMapper(RRDDemandMapping rrdDemandMapping){
		RRDDemand rrdDemand = new RRDDemand();
		
		rrdDemand.setId(rrdDemandMapping.getId());
		rrdDemand.setRrdId(rrdDemandMapping.getRrdId());
		rrdDemand.setDemandId(rrdDemandMapping.getDemandId());
		rrdDemand.setCreatedBy(rrdDemandMapping.getCreatedBy());
		rrdDemand.setCreatedOn(rrdDemandMapping.getCreatedOn());
		rrdDemand.setUpdatedBy(rrdDemandMapping.getUpdatedBy());
		rrdDemand.setUpdatedOn(rrdDemandMapping.getUpdatedOn());
		rrdDemand.setActive(rrdDemandMapping.isActive());

		return rrdDemand;
	}
}

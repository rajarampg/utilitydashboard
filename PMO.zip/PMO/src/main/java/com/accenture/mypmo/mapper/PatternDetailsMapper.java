/**
 * 
 */
package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.PatternDetails;
import com.accenture.mypmo.model.PatternDetailsMapping;

/**
 * @author p.senthilrajan
 *
 */

@Component
public class PatternDetailsMapper {
	
	public PatternDetailsMapping patternDetailsMapper(PatternDetails patternDetails){
		PatternDetailsMapping patternDetailsMapping = new PatternDetailsMapping();
		
		patternDetailsMapping.setId(patternDetails.getId());
		patternDetailsMapping.setPortfolioId(patternDetails.getPortfolioId());
		patternDetailsMapping.setPatternName(patternDetails.getPatternName());
		patternDetailsMapping.setPatternDescription(patternDetails.getPatternDescription());
		patternDetailsMapping.setSkillTeamDetails(patternDetails.getSkillTeamDetails());
		patternDetailsMapping.setClarity(patternDetails.getClarity());
		patternDetailsMapping.setUnixBoxes(patternDetails.getUnixBoxes());
		patternDetailsMapping.setTeradataAccess(patternDetails.getTeradataAccess());
		patternDetailsMapping.setAdAccess(patternDetails.getAdAccess());
		patternDetailsMapping.setAdditionalAccess(patternDetails.getAdditionalAccess());
		patternDetailsMapping.setSpecificAccess(patternDetails.getSpecificAccess());
		patternDetailsMapping.setBusinessJustification(patternDetails.getBusinessJustification());
		patternDetailsMapping.setCreatedBy(patternDetails.getCreatedBy());
		patternDetailsMapping.setCreatedOn(patternDetails.getCreatedOn());
		patternDetailsMapping.setModifiedBy(patternDetails.getModifiedBy());
		patternDetailsMapping.setModifiedOn(patternDetails.getModifiedOn());
		patternDetailsMapping.setActive(patternDetails.isActive());

		return patternDetailsMapping;
		
	}

	public PatternDetails patternDetailsMapMapper(PatternDetailsMapping patternDetailsMapping){
		PatternDetails patternDetails = new PatternDetails();
		
		patternDetails.setId(patternDetailsMapping.getId());
		patternDetails.setPortfolioId(patternDetailsMapping.getPortfolioId());
		patternDetails.setPatternName(patternDetailsMapping.getPatternName());
		patternDetails.setPatternDescription(patternDetailsMapping.getPatternDescription());
		patternDetails.setSkillTeamDetails(patternDetailsMapping.getSkillTeamDetails());
		patternDetails.setClarity(patternDetailsMapping.getClarity());
		patternDetails.setUnixBoxes(patternDetailsMapping.getUnixBoxes());
		patternDetails.setTeradataAccess(patternDetailsMapping.getTeradataAccess());
		patternDetails.setAdAccess(patternDetailsMapping.getAdAccess());
		patternDetails.setAdditionalAccess(patternDetailsMapping.getAdditionalAccess());
		patternDetails.setSpecificAccess(patternDetailsMapping.getSpecificAccess());
		patternDetails.setBusinessJustification(patternDetailsMapping.getBusinessJustification());
		patternDetails.setCreatedBy(patternDetailsMapping.getCreatedBy());
		patternDetails.setCreatedOn(patternDetailsMapping.getCreatedOn());
		patternDetails.setModifiedBy(patternDetailsMapping.getModifiedBy());
		patternDetails.setModifiedOn(patternDetailsMapping.getModifiedOn());
		patternDetails.setActive(patternDetailsMapping.isActive());

		return patternDetails;
		
	}

	public List<PatternDetails> patternDetailsMapMapperCollection(List<PatternDetailsMapping> patternDetailsMapping){
		List<PatternDetails> patternDetails = new ArrayList<PatternDetails>();
		
		for(PatternDetailsMapping patternDetailsMappingTemp: patternDetailsMapping){
			patternDetails.add(patternDetailsMapMapper(patternDetailsMappingTemp));
		}
		
		return patternDetails;
	}

	public List<PatternDetails> patternDetailsMapMapperIterableCollection(Iterable<PatternDetailsMapping> patternDetailsMapping){
		List<PatternDetails> patternDetails = new ArrayList<PatternDetails>();
		
		for(PatternDetailsMapping patternDetailsMappingTemp: patternDetailsMapping){
			patternDetails.add(patternDetailsMapMapper(patternDetailsMappingTemp));
		}
		
		return patternDetails;
	}

}

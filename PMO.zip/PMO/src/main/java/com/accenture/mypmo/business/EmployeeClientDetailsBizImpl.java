/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.EmployeeClientDetailsMapper;
import com.accenture.mypmo.model.EmployeeClientDetails;
import com.accenture.mypmo.model.EmployeeClientDetailsMapping;
import com.accenture.mypmo.repository.EmployeeClientDetailsRepository;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class EmployeeClientDetailsBizImpl implements EmployeeClientDetailsBiz {

	@Autowired
	EmployeeClientDetailsRepository employeeClientDetailsRepository;

	@Autowired
	EmployeeClientDetailsMapper employeeClientDetailsMapper;

	@Override
	public PMOResponse captureEmployeeClientDetails(EmployeeClientDetails empClientDetails) {
		PMOResponse systemResponse = new PMOResponse();
		EmployeeClientDetailsMapping employeeinfo = employeeClientDetailsMapper
				.employeeClientDetailsMapper(empClientDetails);

		try {

			employeeClientDetailsRepository.save(employeeinfo);

		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}

		return systemResponse;
	}

	@Override
	public PMOResponse captureAllEmployeeClientDetails(List<EmployeeClientDetails> empClientDetails) {
		PMOResponse systemResponse = new PMOResponse();
		List<EmployeeClientDetailsMapping> empClientDetailsMapping = employeeClientDetailsMapper
				.employeeClientDetailsMapperCollection(empClientDetails);

		try {

			employeeClientDetailsRepository.save(empClientDetailsMapping);

		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}

		return systemResponse;
	}

	@Override
	public EmployeeClientDetails viewEmployeeClientDetails(int id) {
		EmployeeClientDetails employeeDetails = new EmployeeClientDetails();

		try {
			employeeDetails = employeeClientDetailsMapper
					.employeeClientDetailsMapMapper(employeeClientDetailsRepository.findById(id));

		} catch (Exception e) {
			System.out.println("Exception" + e);
		}

		return employeeDetails;
	}

	@Override
	public EmployeeClientDetails viewEmployeeClientDetailsByEmployeeId(int employeeNumber) {
		EmployeeClientDetails employeeDetails = new EmployeeClientDetails();

		try {
			employeeDetails = employeeClientDetailsMapper.employeeClientDetailsMapMapper(
					employeeClientDetailsRepository.findByEmployeeNumber(employeeNumber));

		} catch (Exception e) {
			System.out.println("Exception" + e);
		}

		return employeeDetails;
	}

	@Override
	public List<EmployeeClientDetails> viewAllEmployeeClientDetails() {
		List<EmployeeClientDetails> employeeClientDetails = new ArrayList<EmployeeClientDetails>();

		try {
			employeeClientDetails = employeeClientDetailsMapper
					.employeeClientDetailsIterableMapMapper(employeeClientDetailsRepository.findAll());
		} catch (Exception e) {
			System.out.println("Exception" + e);
		}

		return employeeClientDetails;
	}

}

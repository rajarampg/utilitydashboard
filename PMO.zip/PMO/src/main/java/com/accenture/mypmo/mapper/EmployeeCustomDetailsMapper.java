/**
 * 
 */
package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.ClientManagerDetails;
import com.accenture.mypmo.model.EmployeeClientDetails;
import com.accenture.mypmo.model.EmployeeClientDetailsMapping;
import com.accenture.mypmo.model.EmployeeCustomDetails;
import com.accenture.mypmo.model.EmployeeCustomDetailsMapping;
import com.accenture.mypmo.model.EmployeeDetails;
import com.accenture.mypmo.model.PatternDetails;
import com.accenture.mypmo.model.PortfolioDetails;
import com.accenture.mypmo.model.RoleDetails;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class EmployeeCustomDetailsMapper {
	
	public EmployeeCustomDetails employeeCustomDetailsMapper(EmployeeCustomDetailsMapping empDetailsMapping){

		EmployeeCustomDetails employeeCustomDetails = new EmployeeCustomDetails();
		EmployeeDetails employeeDetails = new EmployeeDetails();
		EmployeeClientDetails employeeClientDetails = new EmployeeClientDetails();
		PortfolioDetails portfolioDetails = new PortfolioDetails();
		ClientManagerDetails clientManagerDetails = new ClientManagerDetails();
		RoleDetails roleDetails = new RoleDetails();
		PatternDetails patternDetails = new PatternDetails();

		employeeDetails.setId(empDetailsMapping.getAccentureId());
		employeeDetails.setEmployeeNumber(empDetailsMapping.getAccentureEmployeeNumber());
		employeeDetails.setPortfolioId(empDetailsMapping.getAccenturePortfolioId());
		employeeDetails.setRrdId(empDetailsMapping.getRrdId());
		employeeDetails.setEnterpriseId(empDetailsMapping.getEnterpriseId());
		employeeDetails.setFirstName(empDetailsMapping.getFirstName());
		employeeDetails.setLastName(empDetailsMapping.getLastName());
		employeeDetails.setGender(empDetailsMapping.getGender());
		employeeDetails.setCapability(empDetailsMapping.getCapability());
		employeeDetails.setCareerLevel(empDetailsMapping.getCareerLevel());
		employeeDetails.setSupervisorEntId(empDetailsMapping.getSupervisorEntId());
		employeeDetails.setCurrentLocation(empDetailsMapping.getCurrentLocation());
		employeeDetails.setDeliveryCenter(empDetailsMapping.getDeliveryCenter());
		employeeDetails.setVisaType(empDetailsMapping.getVisaType());
		employeeDetails.setDurationStay(empDetailsMapping.getDurationStay());
		employeeDetails.setPhoneNo(empDetailsMapping.getPhoneNo());
		employeeDetails.setPrimarySkill(empDetailsMapping.getPrimarySkill());
		employeeDetails.setSecondarySkill(empDetailsMapping.getSecondarySkill());
		employeeDetails.setProficiencyLevel(empDetailsMapping.getProficiencyLevel());
		employeeDetails.setLockType(empDetailsMapping.getLockType());
		employeeDetails.setEmployeeStatus(empDetailsMapping.getEmployeeStatus());
		employeeDetails.setEmployeeType(empDetailsMapping.getEmployeeType());
		employeeDetails.setRollonDate(empDetailsMapping.getRollonDate());
		employeeDetails.setRollonBy(empDetailsMapping.getRollonBy());
		employeeDetails.setRolloffDate(empDetailsMapping.getRolloffDate());
		employeeDetails.setRolloffReason(empDetailsMapping.getRolloffReason());
		employeeDetails.setRolledoffBy(empDetailsMapping.getRolledoffBy());
		employeeDetails.setExit(empDetailsMapping.isExit());
		employeeDetails.setCreatedBy(empDetailsMapping.getAccentureCreatedBy());
		employeeDetails.setCreatedOn(empDetailsMapping.getAccentureCreatedOn());
		employeeDetails.setModifiedBy(empDetailsMapping.getAccentureModifiedBy());
		employeeDetails.setModifiedOn(empDetailsMapping.getAccentureModifiedOn());
		employeeDetails.setActive(empDetailsMapping.isAccentureActive());

		employeeClientDetails.setId(empDetailsMapping.getClientId());
		employeeClientDetails.setEmployeeNumber(empDetailsMapping.getClientEmployeeNumber());
		employeeClientDetails.setClientManagerId(empDetailsMapping.getClientClientManagerId());
		employeeClientDetails.setPatternId(empDetailsMapping.getClientPatternId());
		employeeClientDetails.setRoleId(empDetailsMapping.getClientRoleId());
		employeeClientDetails.setWmtUserId(empDetailsMapping.getWmtUserId());
		employeeClientDetails.setWmtAccessDate(empDetailsMapping.getWmtAccessDate());
		employeeClientDetails.setWmtGrantDate(empDetailsMapping.getWmtGrantDate());
		employeeClientDetails.setContractType(empDetailsMapping.getContractType());
		employeeClientDetails.setProjectName(empDetailsMapping.getProjectName());
		employeeClientDetails.setProjectDetails(empDetailsMapping.getProjectDetails());
		employeeClientDetails.setClient(empDetailsMapping.getClient());
		employeeClientDetails.setDepartmentNumber(empDetailsMapping.getDepartmentNumber());
		employeeClientDetails.setCountry(empDetailsMapping.getCountry());
		employeeClientDetails.setWorkstation(empDetailsMapping.getWorkstation());
		employeeClientDetails.setBayDetails(empDetailsMapping.getBayDetails());
		employeeClientDetails.setFloor(empDetailsMapping.getFloor());
		employeeClientDetails.setWbse(empDetailsMapping.getWbse());
		employeeClientDetails.setIdentifierType(empDetailsMapping.getIdentifierType());
		employeeClientDetails.setIdentifierNumber(empDetailsMapping.getIdentifierNumber());
		employeeClientDetails.setComments(empDetailsMapping.getComments());
		employeeClientDetails.setOnboardStartDate(empDetailsMapping.getOnboardStartDate());
		employeeClientDetails.setOnboardTime(empDetailsMapping.getOnboardTime());
		employeeClientDetails.setOnboardedBy(empDetailsMapping.getOnboardedBy());
		employeeClientDetails.setRenew(empDetailsMapping.isRenew());
		employeeClientDetails.setCreatedBy(empDetailsMapping.getClientCreatedBy());
		employeeClientDetails.setCreatedOn(empDetailsMapping.getClientCreatedOn());
		employeeClientDetails.setModifiedBy(empDetailsMapping.getClientModifiedBy());
		employeeClientDetails.setModifiedOn(empDetailsMapping.getClientModifiedOn());
		employeeClientDetails.setActive(empDetailsMapping.isClientActive());

		portfolioDetails.setId(empDetailsMapping.getPortfolioId());
		portfolioDetails.setPortfolioName(empDetailsMapping.getPortfolioName());
		portfolioDetails.setPortfolioDescription(empDetailsMapping.getPortfolioDescription());
		portfolioDetails.setCreatedOn(empDetailsMapping.getPortfolioCreatedOn());
		portfolioDetails.setCreatedBy(empDetailsMapping.getPortfolioCreatedBy());
		portfolioDetails.setModifiedOn(empDetailsMapping.getPortfolioModifiedOn());
		portfolioDetails.setModifiedBy(empDetailsMapping.getPortfolioModifiedBy());
		portfolioDetails.setActive(empDetailsMapping.isPortfolioActive());

		
		clientManagerDetails.setId(empDetailsMapping.getClientClientManagerId());
		clientManagerDetails.setPortfolioId(empDetailsMapping.getClientManagerPortfolioId());
		clientManagerDetails.setTeam(empDetailsMapping.getTeam());
		clientManagerDetails.setResourceManager(empDetailsMapping.getResourceManager());
		clientManagerDetails.setVicePresident(empDetailsMapping.getVicePresident());
		clientManagerDetails.setDirectorId(empDetailsMapping.getDirectorId());
		clientManagerDetails.setContractId(empDetailsMapping.getContractId());
		clientManagerDetails.setCreatedBy(empDetailsMapping.getClientManagerCreatedBy());
		clientManagerDetails.setCreatedOn(empDetailsMapping.getClientManagerCreatedOn());
		clientManagerDetails.setModifiedBy(empDetailsMapping.getClientManagerModifiedBy());
		clientManagerDetails.setModifiedOn(empDetailsMapping.getClientManagerModifiedOn());
		clientManagerDetails.setActive(empDetailsMapping.isClientManagerActive());

		patternDetails.setId(empDetailsMapping.getPatternId());
		patternDetails.setPortfolioId(empDetailsMapping.getPatternPortfolioId());
		patternDetails.setPatternName(empDetailsMapping.getPatternName());
		patternDetails.setPatternDescription(empDetailsMapping.getPatternDescription());
		patternDetails.setSkillTeamDetails(empDetailsMapping.getSkillTeamDetails());
		patternDetails.setClarity(empDetailsMapping.getClarity());
		patternDetails.setUnixBoxes(empDetailsMapping.getUnixBoxes());
		patternDetails.setTeradataAccess(empDetailsMapping.getTeradataAccess());
		patternDetails.setAdAccess(empDetailsMapping.getAdAccess());
		patternDetails.setAdditionalAccess(empDetailsMapping.getAdditionalAccess());
		patternDetails.setSpecificAccess(empDetailsMapping.getSpecificAccess());
		patternDetails.setBusinessJustification(empDetailsMapping.getBusinessJustification());
		patternDetails.setCreatedBy(empDetailsMapping.getPatternCreatedBy());
		patternDetails.setCreatedOn(empDetailsMapping.getPatternCreatedOn());
		patternDetails.setModifiedBy(empDetailsMapping.getPatternModifiedBy());
		patternDetails.setModifiedOn(empDetailsMapping.getPatternModifiedOn());
		patternDetails.setActive(empDetailsMapping.isPatternActive());

		
		roleDetails.setId(empDetailsMapping.getRoleId());
		roleDetails.setRole(empDetailsMapping.getRole());
		roleDetails.setRoleDescription(empDetailsMapping.getRoleDescription());
		roleDetails.setLocation(empDetailsMapping.getLocation());
		roleDetails.setRate(empDetailsMapping.getRate());
		roleDetails.setCreatedBy(empDetailsMapping.getRoleCreatedBy());
		roleDetails.setCreatedOn(empDetailsMapping.getRoleCreatedOn());
		roleDetails.setModifiedBy(empDetailsMapping.getRoleModifiedBy());
		roleDetails.setModifiedOn(empDetailsMapping.getRoleModifiedOn());
		roleDetails.setActive(empDetailsMapping.isRoleActive());

		
		employeeCustomDetails.setEmployeeDetails(employeeDetails);
		employeeCustomDetails.setEmployeeClientDetails(employeeClientDetails);
		employeeCustomDetails.setPortfolioDetails(portfolioDetails);
		employeeCustomDetails.setClientManagerDetails(clientManagerDetails);
		employeeCustomDetails.setPatternDetails(patternDetails);
		employeeCustomDetails.setRoleDetails(roleDetails);
		

		return employeeCustomDetails;
	}


	public List<EmployeeCustomDetails> employeeCustomDetailsMapperCollection(List<EmployeeCustomDetailsMapping> empDetailsMapping){

		List<EmployeeCustomDetails> employeeCustomDetails = new ArrayList<EmployeeCustomDetails>();
		
		for(EmployeeCustomDetailsMapping empDetailsMappingTemp: empDetailsMapping){
			employeeCustomDetails.add(employeeCustomDetailsMapper(empDetailsMappingTemp));
		}
		
		return employeeCustomDetails;
	}

}

/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.CertificationDetailsMapper;
import com.accenture.mypmo.model.CertificationDetails;
import com.accenture.mypmo.model.CertificationDetailsMapping;
import com.accenture.mypmo.repository.CertificationDetailsRepository;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class CertificationDetailsBizImpl implements CertificationDetailsBiz {

	@Autowired
	CertificationDetailsRepository certDetailsRepo;

	@Autowired
	CertificationDetailsMapper certDetailsMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.accenture.mypmo.business.CertificationDetailsBiz#
	 * captureCertificationDetails(com.accenture.mypmo.model.
	 * CertificationDetails)
	 */
	@Override
	public PMOResponse captureCertificationDetails(CertificationDetails certificationDetails) {

		PMOResponse systemResponse = new PMOResponse();
		CertificationDetailsMapping certDetailsMapping = certDetailsMapper
				.certificationDetailsMapper(certificationDetails);

		try {
			certDetailsRepo.save(certDetailsMapping);
		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}
		return systemResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.accenture.mypmo.business.CertificationDetailsBiz#
	 * viewCertificationDetails(int)
	 */
	@Override
	public CertificationDetails viewCertificationDetails(int id) {

		CertificationDetails certDetails = new CertificationDetails();

		try {
			System.out.println("Id value :"+id);
			certDetails = certDetailsMapper
					.certificationDetailsMapMapper(certDetailsRepo.findById(id));
			System.out.println(certDetails.toString());
		} catch (Exception e) {
			System.out.println("Exception : " + e);
		}
		return certDetails;
	}

	@Override
	public List<CertificationDetails> viewCertificationDetailsByAssignedTo(String assignedTo) {
		List<CertificationDetails> certDetails = new ArrayList<CertificationDetails>();

		try {
			certDetails = certDetailsMapper
					.certificationDetailsMapMapperCollection(certDetailsRepo.findByAssignedTo(assignedTo));
		} catch (Exception e) {
			System.out.println("Exception : " + e);
		}
		return certDetails;
	}

	@Override
	public List<CertificationDetails> viewAllCertificationDetails() {
		List<CertificationDetails> certDetails = new ArrayList<CertificationDetails>();

		try {
			certDetails = certDetailsMapper.certificationDetailsMapMapperCollection(
					certDetailsMapper.certificationIterableCollection((certDetailsRepo.findAll())));
		} catch (Exception e) {
			System.out.println("Exception : " + e);
		}
		return certDetails;
	}

}

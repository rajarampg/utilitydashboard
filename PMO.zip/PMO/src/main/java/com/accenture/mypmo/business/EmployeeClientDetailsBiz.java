/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.List;

import com.accenture.mypmo.model.EmployeeClientDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface EmployeeClientDetailsBiz {

	PMOResponse captureEmployeeClientDetails(EmployeeClientDetails empClientDetails);
	
	PMOResponse captureAllEmployeeClientDetails(List<EmployeeClientDetails> empClientDetails);
	
	EmployeeClientDetails viewEmployeeClientDetails(int id);

	EmployeeClientDetails viewEmployeeClientDetailsByEmployeeId(int employeeNumber);

	//EmployeeClientDetails viewEmployeeClientDetailsByRRDId(String rrdId);

	List<EmployeeClientDetails> viewAllEmployeeClientDetails();

}

package com.accenture.mypmo.utilities;

public class CommonUtilities {

}

/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.EmployeeClientDetailsBiz;
import com.accenture.mypmo.model.EmployeeClientDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/empclientdetails")
public class EmployeeClientDetailsServiceImpl implements EmployeeClientDetailsService {

	@Autowired
	public EmployeeClientDetailsBiz employeeClientDetailsBiz;

	@RequestMapping(value = "/addempclientdetails", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse captureEmployeeClientDetails(@RequestBody EmployeeClientDetails empClientDetails) {
		// TODO Auto-generated method stub
		return employeeClientDetailsBiz.captureEmployeeClientDetails(empClientDetails);
	}

	@RequestMapping(value = "/updateempclientdetails", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updateEmployeeClientDetails(@RequestBody EmployeeClientDetails empClientDetails) {
		// TODO Auto-generated method stub
		return employeeClientDetailsBiz.captureEmployeeClientDetails(empClientDetails);
	}

	@Override
	@RequestMapping(value = "/updateallempclientdetails", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updateAllEmployeeClientDetails(@RequestBody List<EmployeeClientDetails> empClientDetails) {
		// TODO Auto-generated method stub
		return employeeClientDetailsBiz.captureAllEmployeeClientDetails(empClientDetails);
	}

	@RequestMapping(value = "/viewempclientdetails/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public EmployeeClientDetails viewEmployeeClientDetails(@PathVariable int id) {
		// TODO Auto-generated method stub
		return employeeClientDetailsBiz.viewEmployeeClientDetails(id);
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.EmployeeClientDetailsService#viewEmployeeClientDetailsByEmployeeId(int)
	 */
	@Override
	@RequestMapping(value = "/viewempclientdetailsbyemployeeid/{employeeId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public EmployeeClientDetails viewEmployeeClientDetailsByEmployeeId(@PathVariable int employeeId) {
		// TODO Auto-generated method stub
		return employeeClientDetailsBiz.viewEmployeeClientDetailsByEmployeeId(employeeId);
	}

	@RequestMapping(value = "/viewallempclientdetails", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<EmployeeClientDetails> viewAllEmployeeClientDetails() {
		// TODO Auto-generated method stub
		return employeeClientDetailsBiz.viewAllEmployeeClientDetails();
	}


}

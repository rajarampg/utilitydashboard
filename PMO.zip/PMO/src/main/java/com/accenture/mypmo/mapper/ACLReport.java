package com.accenture.mypmo.mapper;

import java.io.Serializable;
import java.sql.Timestamp;


public class ACLReport implements Serializable{

	private static final long serialVersionUID = 7931146188793863602L;

	private Integer employeedetailsId;
	
	private String enterpriseId;
	
	private String firstName;
	
	private String lastName;
	
	private String currentLocation;
	
	private Timestamp rollonDate;
	
	private Timestamp rolloffDate;
	
	private String wmtUserid;
	
	private Timestamp wmtAccessDate;
	
	private Timestamp wmtGrantDate;
	
	private String role;
	
	private String portfolioName;
	
	private Timestamp updatedOn;

	public Integer getEmployeedetailsId() {
		return employeedetailsId;
	}

	public void setEmployeedetailsId(Integer employeedetailsId) {
		this.employeedetailsId = employeedetailsId;
	}

	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}

	public Timestamp getRollonDate() {
		return rollonDate;
	}

	public void setRollonDate(Timestamp rollonDate) {
		this.rollonDate = rollonDate;
	}

	public Timestamp getRolloffDate() {
		return rolloffDate;
	}

	public void setRolloffDate(Timestamp rolloffDate) {
		this.rolloffDate = rolloffDate;
	}

	public String getWmtUserid() {
		return wmtUserid;
	}

	public void setWmtUserid(String wmtUserid) {
		this.wmtUserid = wmtUserid;
	}

	public Timestamp getWmtAccessDate() {
		return wmtAccessDate;
	}

	public void setWmtAccessDate(Timestamp wmtAccessDate) {
		this.wmtAccessDate = wmtAccessDate;
	}

	public Timestamp getWmtGrantDate() {
		return wmtGrantDate;
	}

	public void setWmtGrantDate(Timestamp wmtGrantDate) {
		this.wmtGrantDate = wmtGrantDate;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

	public Timestamp getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Timestamp updatedOn) {
		this.updatedOn = updatedOn;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("JoinRollonEmployee [employeedetailsId=");
		builder.append(employeedetailsId);
		builder.append(", enterpriseId=");
		builder.append(enterpriseId);
		builder.append(", firstName=");
		builder.append(firstName);
		builder.append(", lastName=");
		builder.append(lastName);
		builder.append(", currentLocation=");
		builder.append(currentLocation);
		builder.append(", rollonDate=");
		builder.append(rollonDate);
		builder.append(", rolloffDate=");
		builder.append(rolloffDate);
		builder.append(", wmtUserid=");
		builder.append(wmtUserid);
		builder.append(", wmtAccessDate=");
		builder.append(wmtAccessDate);
		builder.append(", wmtGrantDate=");
		builder.append(wmtGrantDate);
		builder.append(", role=");
		builder.append(role);
		builder.append(", portfolioName=");
		builder.append(portfolioName);
		builder.append(", updatedOn=");
		builder.append(updatedOn);
		builder.append("]");
		return builder.toString();
	}

}

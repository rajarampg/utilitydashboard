/**
 * 
 */
package com.accenture.mypmo.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author p.senthilrajan
 *
 */

@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)
@Table(name="assertdetails")
public class AssertDetailsMapping implements Serializable {

	public static final long serialVersionUID = 1L;

	@Id @GeneratedValue
	@Column(name = "id")
	private int id;

	@Column(name = "assigned_to")
	private String assignedTo;
	
	@Column(name = "assert_type")
	private String assertType;
	
	@Column(name = "assert_id")
	private String assertId;
	
	@Column(name = "asset_tag")
	private String assetTag;
	
	@Column(name = "assert_own_type")
	private String assertOwnType;
	
	@Column(name = "comments")
	private String comments;
	
	@Column(name = "service_provider")
	private String serviceProvider;
	
	@Column(name = "bill_details")
	private String billDetails;
	
	@Column(name = "issued_date")
	private Timestamp issuedDate;
	
	@Column(name = "issued_by")
	private String issuedBy;
	
	@Column(name = "validity")
	private Timestamp validity;

	@Column(name = "return_date")
	private Timestamp returnDate;
	
	@Column(name = "return_by")
	private String returnBy;
	
	@Column(name = "active")
	private boolean active;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getAssertType() {
		return assertType;
	}

	public void setAssertType(String assertType) {
		this.assertType = assertType;
	}

	public String getAssertId() {
		return assertId;
	}

	public void setAssertId(String assertId) {
		this.assertId = assertId;
	}

	public String getAssetTag() {
		return assetTag;
	}

	public void setAssetTag(String assetTag) {
		this.assetTag = assetTag;
	}

	public String getAssertOwnType() {
		return assertOwnType;
	}

	public void setAssertOwnType(String assertOwnType) {
		this.assertOwnType = assertOwnType;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getServiceProvider() {
		return serviceProvider;
	}

	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}

	public String getBillDetails() {
		return billDetails;
	}

	public void setBillDetails(String billDetails) {
		this.billDetails = billDetails;
	}

	public Timestamp getIssuedDate() {
		return issuedDate;
	}

	public void setIssuedDate(Timestamp issuedDate) {
		this.issuedDate = issuedDate;
	}

	public String getIssuedBy() {
		return issuedBy;
	}

	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}

	public Timestamp getValidity() {
		return validity;
	}

	public void setValidity(Timestamp validity) {
		this.validity = validity;
	}

	public Timestamp getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Timestamp returnDate) {
		this.returnDate = returnDate;
	}

	public String getReturnBy() {
		return returnBy;
	}

	public void setReturnBy(String returnBy) {
		this.returnBy = returnBy;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "AssertDetailsMapping [id=" + id + ", assignedTo=" + assignedTo + ", assertType=" + assertType
				+ ", assertId=" + assertId + ", assetTag=" + assetTag + ", assertOwnType=" + assertOwnType
				+ ", comments=" + comments + ", serviceProvider=" + serviceProvider + ", billDetails=" + billDetails
				+ ", issuedDate=" + issuedDate + ", issuedBy=" + issuedBy + ", validity=" + validity + ", returnDate="
				+ returnDate + ", returnBy=" + returnBy + ", active=" + active + "]";
	}

	
}

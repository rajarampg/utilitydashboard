package com.accenture.mypmo.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class LoginDetails implements Serializable{

	public static final long serialVersionUID = 1L;
	
	private int id;
	
	private int employeeNumber;
	
	private String enterpriseId;
	
	private String password;
	
	private int userTypeId;
	
	private Timestamp lastLogin;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getUserTypeId() {
		return userTypeId;
	}

	public void setUserTypeId(int userTypeId) {
		this.userTypeId = userTypeId;
	}

	public Timestamp getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Timestamp lastLogin) {
		this.lastLogin = lastLogin;
	}

	@Override
	public String toString() {
		return "LoginDetails [id=" + id + ", employeeNumber=" + employeeNumber + ", enterpriseId=" + enterpriseId
				+ ", password=" + password + ", userTypeId=" + userTypeId + ", lastLogin=" + lastLogin + "]";
	}

	
}

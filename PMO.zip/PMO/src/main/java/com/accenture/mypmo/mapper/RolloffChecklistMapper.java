package com.accenture.mypmo.mapper;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.RolloffChecklist;
import com.accenture.mypmo.model.RolloffChecklistMapping;

@Component
public class RolloffChecklistMapper {
	
	
	public RolloffChecklist map(RolloffChecklistMapping rolloffChecklistMapping){
		RolloffChecklist rolloffChecklist = new RolloffChecklist();
		rolloffChecklist.setId(rolloffChecklistMapping.getId());
		rolloffChecklist.setChecklistDetails(rolloffChecklistMapping.getChecklistDetails());
		rolloffChecklist.setActive(rolloffChecklistMapping.getActive());
		rolloffChecklist.setUpdatedby(rolloffChecklistMapping.getUpdatedby());
		rolloffChecklist.setUpdatedon(rolloffChecklistMapping.getUpdatedon());
		rolloffChecklist.setStatusValue(rolloffChecklistMapping.getStatus());
		rolloffChecklist.setEmployeeNumber(rolloffChecklistMapping.getEmployeeNumber());
		return rolloffChecklist;
	}
	
	public RolloffChecklistMapping map(RolloffChecklist Rolloffdetails){
		
		
		RolloffChecklistMapping mapperobj= new RolloffChecklistMapping();
		
		mapperobj.setActive(Rolloffdetails.getActive());
		mapperobj.setChecklistDetails(Rolloffdetails.getChecklistDetails());
		mapperobj.setEmployeeNumber(Rolloffdetails.getEmployeeNumber());
		mapperobj.setId(Rolloffdetails.getId());
		mapperobj.setStatus(Rolloffdetails.getStatusValue());
		mapperobj.setUpdatedby(Rolloffdetails.getUpdatedby());
		mapperobj.setUpdatedon(Rolloffdetails.getUpdatedon()!=null? new Timestamp(Rolloffdetails.getUpdatedon().getTime()): new Timestamp(System.currentTimeMillis()));
		
		return mapperobj;
		
	}
	
	public List<RolloffChecklist> map(Iterable<RolloffChecklistMapping> checklists){
		List<RolloffChecklist> checklistsVO = new ArrayList<RolloffChecklist>();
		for(RolloffChecklistMapping checklist : checklists){
			checklistsVO.add(map(checklist));
		}
		return checklistsVO;
	}

}

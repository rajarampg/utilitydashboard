package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.ClientManagerDetails;
import com.accenture.mypmo.model.ClientManagerDetailsMapping;

@Component
public class ClientManagerDetailsMapper {

	public ClientManagerDetailsMapping clientManagerDetailsMapper(ClientManagerDetails clientManagerDetails) {
		ClientManagerDetailsMapping clientManagerDetailsMapping = new ClientManagerDetailsMapping();

		clientManagerDetailsMapping.setId(clientManagerDetails.getId());
		clientManagerDetailsMapping.setPortfolioId(clientManagerDetails.getPortfolioId());
		clientManagerDetailsMapping.setTeam(clientManagerDetails.getTeam());
		clientManagerDetailsMapping.setResourceManager(clientManagerDetails.getResourceManager());
		clientManagerDetailsMapping.setVicePresident(clientManagerDetails.getVicePresident());
		clientManagerDetailsMapping.setDirectorId(clientManagerDetails.getDirectorId());
		clientManagerDetailsMapping.setContractId(clientManagerDetails.getContractId());
		clientManagerDetailsMapping.setCreatedBy(clientManagerDetails.getCreatedBy());
		clientManagerDetailsMapping.setCreatedOn(clientManagerDetails.getCreatedOn());
		clientManagerDetailsMapping.setModifiedBy(clientManagerDetails.getModifiedBy());
		clientManagerDetailsMapping.setModifiedOn(clientManagerDetails.getModifiedOn());
		clientManagerDetailsMapping.setActive(clientManagerDetails.isActive());

		return clientManagerDetailsMapping;
	}

	public ClientManagerDetails clientManagerDetailsMapMapper(ClientManagerDetailsMapping clientManagerDetailsMapping) {
		ClientManagerDetails clientManagerDetails = new ClientManagerDetails();

		clientManagerDetails.setId(clientManagerDetailsMapping.getId());
		clientManagerDetails.setPortfolioId(clientManagerDetailsMapping.getPortfolioId());
		clientManagerDetails.setTeam(clientManagerDetailsMapping.getTeam());
		clientManagerDetails.setResourceManager(clientManagerDetailsMapping.getResourceManager());
		clientManagerDetails.setVicePresident(clientManagerDetailsMapping.getVicePresident());
		clientManagerDetails.setDirectorId(clientManagerDetailsMapping.getDirectorId());
		clientManagerDetails.setContractId(clientManagerDetailsMapping.getContractId());
		clientManagerDetails.setCreatedBy(clientManagerDetailsMapping.getCreatedBy());
		clientManagerDetails.setCreatedOn(clientManagerDetailsMapping.getCreatedOn());
		clientManagerDetails.setModifiedBy(clientManagerDetailsMapping.getModifiedBy());
		clientManagerDetails.setModifiedOn(clientManagerDetailsMapping.getModifiedOn());
		clientManagerDetails.setActive(clientManagerDetailsMapping.isActive());

		return clientManagerDetails;
	}

	public List<ClientManagerDetails> clientManagerDetailsMapMapperCollection(List<ClientManagerDetailsMapping> clientManagerDetailsMapping) {
		List<ClientManagerDetails> clientManagerDetails = new ArrayList<ClientManagerDetails>();

		for(ClientManagerDetailsMapping clientManagerDetailsMappingTemp: clientManagerDetailsMapping){
			clientManagerDetails.add(clientManagerDetailsMapMapper(clientManagerDetailsMappingTemp));
		}

		return clientManagerDetails;
	}

	public List<ClientManagerDetails> clientManagerDetailsIterableMapMapper(Iterable<ClientManagerDetailsMapping> clientManagerDetailsMapping) {
		List<ClientManagerDetails> clientManagerDetails = new ArrayList<ClientManagerDetails>();

		for(ClientManagerDetailsMapping clientManagerDetailsMappingTemp: clientManagerDetailsMapping){
			clientManagerDetails.add(clientManagerDetailsMapMapper(clientManagerDetailsMappingTemp));
		}

		return clientManagerDetails;
	}
}

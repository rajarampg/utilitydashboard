/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.List;

import com.accenture.mypmo.model.CertificationDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface CertificationDetailsBiz {

	PMOResponse captureCertificationDetails(CertificationDetails certificationDetails);

	CertificationDetails viewCertificationDetails(int id);
	
	List<CertificationDetails> viewCertificationDetailsByAssignedTo(String assignedTo);

	List<CertificationDetails> viewAllCertificationDetails();
}

package com.accenture.mypmo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.InnovationSkillMapping;

public interface InnovationSkillRepository extends CrudRepository<InnovationSkillMapping, Integer>{

	List<InnovationSkillMapping> findById(int id);

}

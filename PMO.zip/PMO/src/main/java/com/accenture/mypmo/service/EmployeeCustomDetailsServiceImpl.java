/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.EmployeeCustomDetailsBiz;
import com.accenture.mypmo.model.EmployeeCustomDetails;

/**
 * @author p.senthilrajan
 *
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/employeecustomdetails")
public class EmployeeCustomDetailsServiceImpl implements EmployeeCustomDetailsService {

	@Autowired
	public EmployeeCustomDetailsBiz employeeCustomDetailsBiz;

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.EmployeeCustomDetailsService#findAllEmployeeDetails()
	 */
	@Override
	@RequestMapping(value = "/viewallemployeecustomdetails", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<EmployeeCustomDetails> findAllEmployeeDetails() {
		// TODO Auto-generated method stub
		return employeeCustomDetailsBiz.findAllEmployeeDetails();
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.EmployeeCustomDetailsService#findFullEmployeeDetailsByEmpNumner(int)
	 */
	@Override
	@RequestMapping(value = "/viewallemployeecustomdetailsbyempnumber/{employeeNumber}", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<EmployeeCustomDetails> findFullEmployeeDetailsByEmpNumner(@PathVariable int employeeNumber) {
		// TODO Auto-generated method stub
		return employeeCustomDetailsBiz.findFullEmployeeDetailsByEmpNumner(employeeNumber);
	}

}

/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import com.accenture.mypmo.model.AssertDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface AssertDetailsService {

	PMOResponse captureAssertDetails(AssertDetails assertEmpDetails);
	
	PMOResponse updateAssertDetails(AssertDetails assertEmpDetails);
	
	List<AssertDetails> viewAssertDetailsByAssignedTo(String assignedTo);

	AssertDetails viewAssertDetails(int id);
	
	List<AssertDetails> viewAllAssertDetails();
}

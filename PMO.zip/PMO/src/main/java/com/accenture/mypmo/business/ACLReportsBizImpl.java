package com.accenture.mypmo.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.ACLReport;
import com.accenture.mypmo.mapper.ACLReportMapper;
import com.accenture.mypmo.model.ACLReportMapping;
import com.accenture.mypmo.repository.ACLReportsRepository;

@Component(value="aclReportsBizImpl")
public class ACLReportsBizImpl implements ACLReportsBiz{

	@Autowired
	ACLReportMapper mapper;

	@Autowired
	ACLReportsRepository joinRollonEmployeeRepository;

	@Override
	public List<ACLReport> fetchReports() {
		List<ACLReportMapping> mappings = joinRollonEmployeeRepository.fetchReports();
		return mapper.map(mappings);
	}
	

}

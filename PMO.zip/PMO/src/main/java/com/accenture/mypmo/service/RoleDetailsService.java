/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import com.accenture.mypmo.model.RoleDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface RoleDetailsService {

	PMOResponse addTaskDetails(RoleDetails roleDetails);
	
	PMOResponse updateTaskDetails(RoleDetails roleDetails);

	RoleDetails viewRoleDetails(int id);
	
	List<RoleDetails> ViewAllRoleDetails();

}

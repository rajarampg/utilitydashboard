/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import com.accenture.mypmo.model.EmployeeClientDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface EmployeeClientDetailsService {

	PMOResponse captureEmployeeClientDetails(EmployeeClientDetails empClientDetails);
	
	PMOResponse updateEmployeeClientDetails(EmployeeClientDetails empClientDetails);
	
	PMOResponse updateAllEmployeeClientDetails(List<EmployeeClientDetails> empClientDetails);

	EmployeeClientDetails viewEmployeeClientDetails(int id);

	EmployeeClientDetails viewEmployeeClientDetailsByEmployeeId(int employeeId);

	List<EmployeeClientDetails> viewAllEmployeeClientDetails();
}

package com.accenture.mypmo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.ResourceRequestDetailsMapping;

public interface ResourceRequestRepository  extends CrudRepository<ResourceRequestDetailsMapping, String>,JpaSpecificationExecutor<ResourceRequestDetailsMapping> {
	
	public List<ResourceRequestDetailsMapping> findByPortfolioId(int portfolioId);
	
	public ResourceRequestDetailsMapping findById(int id);

}

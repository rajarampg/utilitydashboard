package com.accenture.mypmo.mapper;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.RollonChecklist;
import com.accenture.mypmo.model.RollonChecklistMapping;

@Component
public class RollonChecklistMapper {
	
	
	public RollonChecklist map(RollonChecklistMapping rollOnChecklistMapping){
		RollonChecklist rollOnChecklist = new RollonChecklist();
		rollOnChecklist.setId(rollOnChecklistMapping.getId());
		rollOnChecklist.setChecklistDetails(rollOnChecklistMapping.getChecklistDetails());
		rollOnChecklist.setActive(rollOnChecklistMapping.getActive());
		rollOnChecklist.setUpdatedby(rollOnChecklistMapping.getUpdatedby());
		rollOnChecklist.setUpdatedon(rollOnChecklistMapping.getUpdatedon());
		rollOnChecklist.setStatusValue(rollOnChecklistMapping.getStatus());
		rollOnChecklist.setEmployeeNumber(rollOnChecklistMapping.getEmployeeNumber());
		return rollOnChecklist;
	}
	
	public RollonChecklistMapping detailsMapper(RollonChecklist rollondetails){
		
		
		RollonChecklistMapping mapperobj= new RollonChecklistMapping();
		
		mapperobj.setActive(rollondetails.getActive());
		mapperobj.setChecklistDetails(rollondetails.getChecklistDetails());
		mapperobj.setEmployeeNumber(rollondetails.getEmployeeNumber());
		mapperobj.setId(rollondetails.getId());
		mapperobj.setStatus(rollondetails.getStatusValue());
		mapperobj.setUpdatedby(rollondetails.getUpdatedby());
		mapperobj.setUpdatedon(rollondetails.getUpdatedon()!=null? new Timestamp(rollondetails.getUpdatedon().getTime()): new Timestamp(System.currentTimeMillis()));
		
		return mapperobj;
		
	}
	
	public List<RollonChecklist> map(Iterable<RollonChecklistMapping> checklists){
		List<RollonChecklist> checklistsVO = new ArrayList<RollonChecklist>();
		for(RollonChecklistMapping checklist : checklists){
			checklistsVO.add(map(checklist));
		}
		return checklistsVO;
	}

}

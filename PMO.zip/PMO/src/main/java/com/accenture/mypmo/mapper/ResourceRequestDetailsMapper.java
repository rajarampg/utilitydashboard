package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.ResourceRequestPrimaryDetails;
import com.accenture.mypmo.model.ResourceRequestSkillDetails;
import com.accenture.mypmo.model.ResourceRequestDetailsMapping;
import com.accenture.mypmo.model.ResourceRequestDetails;
import com.accenture.mypmo.utilities.PmoUtilities;

@Component
public class ResourceRequestDetailsMapper {


	public ResourceRequestDetails rrdMapMapper(
			ResourceRequestDetailsMapping rrdDetailsMap) {
		
		ResourceRequestDetails rrdDetails = new ResourceRequestDetails();

		ResourceRequestPrimaryDetails rrdPrimaryDetails = new ResourceRequestPrimaryDetails();
		List<ResourceRequestSkillDetails> rrdSkillDetails = new ArrayList<ResourceRequestSkillDetails>();
		ResourceRequestSkillDetails rrdSkillDetailsTemp = new ResourceRequestSkillDetails();


		rrdPrimaryDetails.setId(rrdDetailsMap.getId());
		rrdPrimaryDetails.setDemandId(rrdDetailsMap.getDemandId());
		rrdPrimaryDetails.setPortfolioId(rrdDetailsMap.getPortfolioId());
		rrdSkillDetailsTemp.setPrimarySkill(rrdDetailsMap.getPrimarySkill());
		rrdPrimaryDetails.setDemandPriority(rrdDetailsMap.getDemandPriority());
		rrdPrimaryDetails.setDemandEndDate(rrdDetailsMap.getDemandEndDate());
		rrdPrimaryDetails.setDemandSegment(rrdDetailsMap.getDemandSegment());
		rrdPrimaryDetails.setDemandFullfillDate(rrdDetailsMap.getDemandFullfillDate());
		rrdSkillDetailsTemp.setLockDuration(rrdDetailsMap.getLockDuration());
		rrdSkillDetailsTemp.setHardlockready(rrdDetailsMap.isHardlockReady());
		rrdSkillDetailsTemp.setFulfillmentEntity(rrdDetailsMap.getFulfillmentEntity());
		rrdPrimaryDetails.setResourceStartDate(rrdDetailsMap.getResourceStartDate());
		rrdPrimaryDetails.setClientInterview(rrdDetailsMap.isClientInterview());
		rrdPrimaryDetails.setSourceLocation(rrdDetailsMap.getSourceLocation());
		rrdPrimaryDetails.setWorkLocation(rrdDetailsMap.getWorkLocation());
		rrdSkillDetailsTemp.setCareerLevel(rrdDetailsMap.getCareerLevel());
		rrdPrimaryDetails.setOnsiteComponent(rrdDetailsMap.isOnsiteComponent());
		rrdPrimaryDetails.setVisaType(rrdDetailsMap.getVisaType());
		rrdPrimaryDetails.setVisaReady(rrdDetailsMap.isVisaReady());
		rrdSkillDetailsTemp.setResourceCount(rrdDetailsMap.getResourceCount());
		rrdSkillDetailsTemp.setStatus(rrdDetailsMap.isStatus());
		rrdSkillDetailsTemp.setWbseCode(rrdDetailsMap.getWbseCode());
		rrdPrimaryDetails.setCreatedBy(rrdDetailsMap.getCreatedBy());
		rrdPrimaryDetails.setUpdatedBy(rrdDetailsMap.getUpdatedBy());
		rrdPrimaryDetails.setCreatedOn(rrdDetailsMap.getCreatedOn());
		rrdPrimaryDetails.setUpdatedOn(rrdDetailsMap.getUpdatedOn());
		rrdSkillDetailsTemp.setActive(rrdDetailsMap.isActive());
		
		rrdSkillDetails.add(rrdSkillDetailsTemp);
		rrdDetails.setPrimaryDetails(rrdPrimaryDetails);
		rrdDetails.setSkillsDetails(rrdSkillDetails);
	return rrdDetails;
	}
	
	public List<ResourceRequestDetailsMapping> rrdMapper(
			ResourceRequestDetails rrdDetails) {

		List<ResourceRequestDetailsMapping> rrdDetailsMap = new ArrayList<ResourceRequestDetailsMapping>();

		ResourceRequestPrimaryDetails rrdPrimaryDetails = rrdDetails.getPrimaryDetails();

		List<ResourceRequestSkillDetails> rrdSkillDetails = rrdDetails.getSkillsDetails();
		
		int i = 0;

		PmoUtilities util = new PmoUtilities();
		String requestId = util.randomNumber();
		
		for (ResourceRequestSkillDetails rrdSkillDetail : rrdSkillDetails) {

			// Use existing demand id for update.
			String demandId = rrdPrimaryDetails.getDemandId();
			if(demandId == null || demandId.isEmpty()){
				//Creating Random demand id for insert.
				demandId = requestId.concat("-"+Integer.toString(i++));
				rrdPrimaryDetails.setDemandId(demandId);
			}

			ResourceRequestDetailsMapping rrdMapTemp = new ResourceRequestDetailsMapping();

			rrdMapTemp.setId(rrdPrimaryDetails.getId());
			rrdMapTemp.setDemandId(rrdPrimaryDetails.getDemandId());
			rrdMapTemp.setPortfolioId(rrdPrimaryDetails.getPortfolioId());
			rrdMapTemp.setPrimarySkill(rrdSkillDetail.getPrimarySkill());
			rrdMapTemp.setDemandPriority(rrdPrimaryDetails.getDemandPriority());
			rrdMapTemp.setDemandEndDate(rrdPrimaryDetails.getDemandEndDate());
			rrdMapTemp.setDemandSegment(rrdPrimaryDetails.getDemandSegment());
			rrdMapTemp.setDemandFullfillDate(rrdPrimaryDetails.getDemandFullfillDate());
			rrdMapTemp.setLockDuration(rrdSkillDetail.getLockDuration());
			rrdMapTemp.setHardlockReady(rrdSkillDetail.isHardlockready());
			rrdMapTemp.setFulfillmentEntity(rrdSkillDetail.getFulfillmentEntity());
			rrdMapTemp.setResourceStartDate(rrdPrimaryDetails.getResourceStartDate());
			rrdMapTemp.setClientInterview(rrdPrimaryDetails.isClientInterview());
			rrdMapTemp.setSourceLocation(rrdPrimaryDetails.getSourceLocation());
			rrdMapTemp.setWorkLocation(rrdPrimaryDetails.getWorkLocation());
			rrdMapTemp.setCareerLevel(rrdSkillDetail.getCareerLevel());
			rrdMapTemp.setOnsiteComponent(rrdPrimaryDetails.isOnsiteComponent());
			rrdMapTemp.setVisaType(rrdPrimaryDetails.getVisaType());
			rrdMapTemp.setVisaReady(rrdPrimaryDetails.isVisaReady());
			rrdMapTemp.setResourceCount(rrdSkillDetail.getResourceCount());
			rrdMapTemp.setStatus(rrdSkillDetail.isStatus());
			rrdMapTemp.setWbseCode(rrdSkillDetail.getWbseCode());
			rrdMapTemp.setCreatedBy(rrdPrimaryDetails.getCreatedBy());
			rrdMapTemp.setUpdatedBy(rrdPrimaryDetails.getUpdatedBy());
			rrdMapTemp.setCreatedOn(rrdPrimaryDetails.getCreatedOn());
			rrdMapTemp.setUpdatedOn(rrdPrimaryDetails.getUpdatedOn());
			rrdMapTemp.setActive(rrdSkillDetail.isActive());
			
			rrdDetailsMap.add(rrdMapTemp);

		}
		return rrdDetailsMap;
	}
	
	public List<ResourceRequestDetails> rrdMapMapperCollection(List<ResourceRequestDetailsMapping> rrdDetailsMap){
		
		List<ResourceRequestDetails> rrdDetails = new  ArrayList<ResourceRequestDetails>();
		for (ResourceRequestDetailsMapping rrdDetailsMapTemp : rrdDetailsMap) {
			rrdDetails.add(rrdMapMapper(rrdDetailsMapTemp));
		}
		
		return rrdDetails;
	}

	public List<ResourceRequestDetails> rrdMapMapperIterableCollection(Iterable<ResourceRequestDetailsMapping> rrdDetailsMap){
		
		List<ResourceRequestDetails> rrdDetails = new  ArrayList<ResourceRequestDetails>();
		for (ResourceRequestDetailsMapping rrdDetailsMapTemp : rrdDetailsMap) {
			rrdDetails.add(rrdMapMapper(rrdDetailsMapTemp));
		}
		
		return rrdDetails;
	}
}

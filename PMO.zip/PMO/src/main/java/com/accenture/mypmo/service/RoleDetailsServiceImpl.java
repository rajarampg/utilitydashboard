/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.RoleDetailsBiz;
import com.accenture.mypmo.model.RoleDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/roledetails")
public class RoleDetailsServiceImpl implements RoleDetailsService {

	@Autowired
	RoleDetailsBiz roleDetailsBiz;
	
	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.RoleDetailsService#addTaskDetails(com.accenture.mypmo.model.RoleDetails)
	 */
	@Override
	@RequestMapping(value = "/addrole", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse addTaskDetails(@RequestBody RoleDetails roleDetails) {
		// TODO Auto-generated method stub
		return roleDetailsBiz.captureTaskDetails(roleDetails);
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.RoleDetailsService#updateTaskDetails(com.accenture.mypmo.model.RoleDetails)
	 */
	@Override
	@RequestMapping(value = "/updaterole", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updateTaskDetails(@RequestBody RoleDetails roleDetails) {
		// TODO Auto-generated method stub
		return roleDetailsBiz.captureTaskDetails(roleDetails);
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.RoleDetailsService#viewRoleDetails(int)
	 */
	@Override
	@RequestMapping(value = "/viewrole/{id}", method = RequestMethod.GET)
	public RoleDetails viewRoleDetails(@PathVariable int id) {
		// TODO Auto-generated method stub
		return roleDetailsBiz.viewRoleDetails(id);
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.RoleDetailsService#ViewAllRoleDetails()
	 */
	@Override
	@RequestMapping(value = "/viewallrole", method = RequestMethod.GET)
	public List<RoleDetails> ViewAllRoleDetails() {
		// TODO Auto-generated method stub
		return roleDetailsBiz.ViewAllRoleDetails();
	}

}

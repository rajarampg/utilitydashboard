package com.accenture.mypmo.model;

import java.io.Serializable;
import java.util.List;

public class ResourceRequestDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5654269667670971942L;
	
	private ResourceRequestPrimaryDetails primaryDetails;
	
	private List<ResourceRequestSkillDetails> skillsDetails;		



	public ResourceRequestPrimaryDetails getPrimaryDetails() {
		return primaryDetails;
	}

	public void setPrimaryDetails(ResourceRequestPrimaryDetails primaryDetails) {
		this.primaryDetails = primaryDetails;
	}

	public List<ResourceRequestSkillDetails> getSkillsDetails() {
		return skillsDetails;
	}

	public void setSkillsDetails(List<ResourceRequestSkillDetails> skillsDetails) {
		this.skillsDetails = skillsDetails;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "ResourceRequestDetails [primaryDetails=" + primaryDetails + ", skillsDetails=" + skillsDetails + "]";
	}
	
	
}

/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import com.accenture.mypmo.model.EmployeeCustomDetails;

/**
 * @author p.senthilrajan
 *
 */
public interface EmployeeCustomDetailsService {

	List<EmployeeCustomDetails> findAllEmployeeDetails();
	
	List<EmployeeCustomDetails> findFullEmployeeDetailsByEmpNumner(int employeeNumber);
}

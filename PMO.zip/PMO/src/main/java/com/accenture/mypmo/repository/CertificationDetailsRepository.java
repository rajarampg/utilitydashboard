/**
 * 
 */
package com.accenture.mypmo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.CertificationDetailsMapping;

/**
 * @author p.senthilrajan
 *
 */
public interface CertificationDetailsRepository extends JpaSpecificationExecutor<CertificationDetailsMapping>,
		CrudRepository<CertificationDetailsMapping, String> {

	public CertificationDetailsMapping findById(int id);

	public List<CertificationDetailsMapping> findByAssignedTo(String assignedTo);
}

package com.accenture.mypmo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.EmployeeDetailsBiz;
import com.accenture.mypmo.model.EmployeeDetails;
import com.accenture.mypmo.response.PMOResponse;

@CrossOrigin
@RestController
@RequestMapping(value = "/empdetails")
public class EmployeeDetailsServiceImpl implements EmployeeDetailsService {

	@Autowired
	public EmployeeDetailsBiz employeeDetailsBiz;

	@RequestMapping(value = "/addempdetails", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse captureEmployeeDetails(
			@RequestBody EmployeeDetails empdetails) {

		return employeeDetailsBiz.captureEmployeeDetails(empdetails);
	}
	
	@RequestMapping(value = "/updateempdetails", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updateEmployeeDetails(
			@RequestBody EmployeeDetails empdetails) {

		return employeeDetailsBiz.captureEmployeeDetails(empdetails);
	}

	
	@RequestMapping(value = "/updateallempdetails", method = RequestMethod.POST, headers = "Accept=application/json")
	@Override
	public PMOResponse updateAllEmployeeDetails(@RequestBody List<EmployeeDetails> empdetails) {
		// TODO Auto-generated method stub
		return employeeDetailsBiz.captureAllEmployeeDetails(empdetails);
	}
	
	@RequestMapping(value = "/viewempdetails/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public EmployeeDetails viewEmployeeDetails(
			@PathVariable int id) {			

		return employeeDetailsBiz.viewEmployeeDetails(id);
	}

	@Override
	@RequestMapping(value = "/viewempdetailsbyemployeeid/{employeeId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public EmployeeDetails viewEmployeeDetailsByEmployeeId(@PathVariable int employeeId) {
		// TODO Auto-generated method stub
		return employeeDetailsBiz.viewEmployeeDetailsByEmployeeId(employeeId);
	}

	@Override
	@RequestMapping(value = "/viewempdetailsbyportfolioid/{portfolioId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<EmployeeDetails> viewEmployeeDetailsByPortfolioId(@PathVariable int portfolioId) {
		// TODO Auto-generated method stub
		return employeeDetailsBiz.viewEmployeeDetailsByPortfolioId(portfolioId);
	}

	@Override
	@RequestMapping(value = "/viewallempdetails", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<EmployeeDetails> viewAllEmployeeDetails() {
		// TODO Auto-generated method stub
		return employeeDetailsBiz.viewAllEmployeeDetails();
	}

	@RequestMapping(value = "/viewempdetailsbyrrdid/{rrdId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public EmployeeDetails viewEmployeeDetailsByRRDId(@PathVariable String rrdId) {
		// TODO Auto-generated method stub
		return employeeDetailsBiz.viewEmployeeDetailsByRRDId(rrdId);
	}

	
}
	
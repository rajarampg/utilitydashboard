/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import com.accenture.mypmo.model.ClientManagerDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface ClientManagerDetailsService {

	PMOResponse addClientManagerDetails(ClientManagerDetails clientManagerDetails);
	
	PMOResponse updateClientManagerDetails(ClientManagerDetails clientManagerDetails);

	List<ClientManagerDetails> viewClientManagerDetailsByPortfolioId(int portfolioId);

	ClientManagerDetails viewClientManagerDetails(int id);

	List<ClientManagerDetails> viewAllClientManagerDetails();


}

/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.ClientManagerDetailsMapper;
import com.accenture.mypmo.model.ClientManagerDetails;
import com.accenture.mypmo.model.ClientManagerDetailsMapping;
import com.accenture.mypmo.repository.ClientManagerDetailsRepository;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class ClientManagerDetailsBizImpl implements ClientManagerDetailsBiz {

	@Autowired
	ClientManagerDetailsRepository clientManagerDetailsRepo;

	@Autowired
	ClientManagerDetailsMapper clientManagerDetailsMapper;

	
	/* (non-Javadoc)
	 * @see com.accenture.mypmo.business.ClientManagerDetailsBiz#captureAssertDetails(com.accenture.mypmo.model.ClientManagerDetails)
	 */
	@Override
	public PMOResponse captureClientManagerDetails(ClientManagerDetails clientManagerDetails) {
		PMOResponse systemResponse = new PMOResponse();
		ClientManagerDetailsMapping clientManagerDetailsMapping = clientManagerDetailsMapper
				.clientManagerDetailsMapper(clientManagerDetails);

		try {
			clientManagerDetailsRepo.save(clientManagerDetailsMapping);
		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}

		return systemResponse;
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.business.ClientManagerDetailsBiz#viewClientManagerDetailsByPortfolioId(int)
	 */
	@Override
	public List<ClientManagerDetails> viewClientManagerDetailsByPortfolioId(int portfolioId) {
		List<ClientManagerDetails> clientManagerDetails = new ArrayList<ClientManagerDetails>();
		try {
			clientManagerDetails = clientManagerDetailsMapper
					.clientManagerDetailsMapMapperCollection(clientManagerDetailsRepo.findByPortfolioId(portfolioId));
		} catch (Exception e) {

		}
		return clientManagerDetails;
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.business.ClientManagerDetailsBiz#viewClientManagerDetails(int)
	 */
	@Override
	public ClientManagerDetails viewClientManagerDetails(int id) {
		ClientManagerDetails clientManagerDetails = new ClientManagerDetails();
		try {
			clientManagerDetails = clientManagerDetailsMapper
					.clientManagerDetailsMapMapper(clientManagerDetailsRepo.findById(id));
		} catch (Exception e) {

		}
		return clientManagerDetails;
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.business.ClientManagerDetailsBiz#viewAllClientManagerDetails()
	 */
	@Override
	public List<ClientManagerDetails> viewAllClientManagerDetails() {
		List<ClientManagerDetails> clientManagerDetails = new ArrayList<ClientManagerDetails>();
		try {
			clientManagerDetails = clientManagerDetailsMapper
					.clientManagerDetailsIterableMapMapper(clientManagerDetailsRepo.findAll());
		} catch (Exception e) {

		}
		return clientManagerDetails;
	}

}

package com.accenture.mypmo.business;

import java.util.List;

import com.accenture.mypmo.model.LoginDetails;
import com.accenture.mypmo.response.PMOResponse;

public interface LoginDetailsBiz {

	PMOResponse captureLoginDetails(LoginDetails loginDetails);

	LoginDetails viewLoginDetails(int id);
	
	LoginDetails viewLoginDetailsByEnterpriseId(String enterpriseId);
	

	List<LoginDetails> viewAllLoginDetails();

}

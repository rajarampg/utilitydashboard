package com.accenture.mypmo.model;

import java.sql.Timestamp;

public class ResourceRequestPrimaryDetails {

	private int id;

	private String demandId;
	
	private int portfolioId;
	
	private String demandSegment;
	
	private String sourceLocation;
	
	private String demandPriority;
	
	private Timestamp resourceStartDate;
	
	private Timestamp demandFullfillDate;
	
	private Timestamp demandEndDate;
	
	private boolean clientInterview;
	
	private boolean onsiteComponent;
	
	private String visaType;
	
	private boolean visaReady;
	
	private String workLocation;
	
	private String createdBy;
	
	private Timestamp createdOn;
	
	private String updatedBy;
	
	private Timestamp updatedOn;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDemandId() {
		return demandId;
	}

	public void setDemandId(String demandId) {
		this.demandId = demandId;
	}

	public int getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(int portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getDemandSegment() {
		return demandSegment;
	}

	public void setDemandSegment(String demandSegment) {
		this.demandSegment = demandSegment;
	}

	public String getSourceLocation() {
		return sourceLocation;
	}

	public void setSourceLocation(String sourceLocation) {
		this.sourceLocation = sourceLocation;
	}

	public String getDemandPriority() {
		return demandPriority;
	}

	public void setDemandPriority(String demandPriority) {
		this.demandPriority = demandPriority;
	}

	public Timestamp getResourceStartDate() {
		return resourceStartDate;
	}

	public void setResourceStartDate(Timestamp resourceStartDate) {
		this.resourceStartDate = resourceStartDate;
	}

	public Timestamp getDemandFullfillDate() {
		return demandFullfillDate;
	}

	public void setDemandFullfillDate(Timestamp demandFullfillDate) {
		this.demandFullfillDate = demandFullfillDate;
	}

	public Timestamp getDemandEndDate() {
		return demandEndDate;
	}

	public void setDemandEndDate(Timestamp demandEndDate) {
		this.demandEndDate = demandEndDate;
	}

	public boolean isClientInterview() {
		return clientInterview;
	}

	public void setClientInterview(boolean clientInterview) {
		this.clientInterview = clientInterview;
	}

	public boolean isOnsiteComponent() {
		return onsiteComponent;
	}

	public void setOnsiteComponent(boolean onsiteComponent) {
		this.onsiteComponent = onsiteComponent;
	}

	public String getVisaType() {
		return visaType;
	}

	public void setVisaType(String visaType) {
		this.visaType = visaType;
	}

	public boolean isVisaReady() {
		return visaReady;
	}

	public void setVisaReady(boolean visaReady) {
		this.visaReady = visaReady;
	}

	public String getWorkLocation() {
		return workLocation;
	}

	public void setWorkLocation(String workLocation) {
		this.workLocation = workLocation;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Timestamp getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Timestamp updatedOn) {
		this.updatedOn = updatedOn;
	}

	@Override
	public String toString() {
		return "ResourceRequestPrimaryDetails [id=" + id + ", demandId=" + demandId + ", portfolioId=" + portfolioId
				+ ", demandSegment=" + demandSegment + ", sourceLocation=" + sourceLocation + ", demandPriority="
				+ demandPriority + ", resourceStartDate=" + resourceStartDate + ", demandFullfillDate="
				+ demandFullfillDate + ", demandEndDate=" + demandEndDate + ", clientInterview=" + clientInterview
				+ ", onsiteComponent=" + onsiteComponent + ", visaType=" + visaType + ", visaReady=" + visaReady
				+ ", workLocation=" + workLocation + ", createdBy=" + createdBy + ", createdOn=" + createdOn
				+ ", updatedBy=" + updatedBy + ", updatedOn=" + updatedOn + "]";
	}
	
	
}

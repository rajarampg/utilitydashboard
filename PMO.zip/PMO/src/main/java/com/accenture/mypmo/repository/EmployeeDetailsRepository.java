package com.accenture.mypmo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.EmployeeDetailsMapping;

public interface EmployeeDetailsRepository extends
		CrudRepository<EmployeeDetailsMapping, Integer>,JpaSpecificationExecutor<EmployeeDetailsMapping>{
	
	public EmployeeDetailsMapping findByEmployeeNumber(int employeeId);

	public EmployeeDetailsMapping findById(int id);
	
	public EmployeeDetailsMapping findByRrdId(String rrdId);

	public List<EmployeeDetailsMapping> findByPortfolioId(int portfolioId);
}

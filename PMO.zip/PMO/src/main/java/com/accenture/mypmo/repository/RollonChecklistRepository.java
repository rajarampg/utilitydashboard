package com.accenture.mypmo.repository;

import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.RollonChecklistMapping;

public interface RollonChecklistRepository  extends CrudRepository<RollonChecklistMapping, Integer>{
	
	public RollonChecklistMapping findById(int id);
	
	public RollonChecklistMapping findByEmployeeNumber(int id);
	
}

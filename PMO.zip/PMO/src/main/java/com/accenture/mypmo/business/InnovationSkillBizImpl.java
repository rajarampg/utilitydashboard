package com.accenture.mypmo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.InnovationSkillMapper;
import com.accenture.mypmo.model.InnovationSkill;
import com.accenture.mypmo.model.InnovationSkillMapping;
import com.accenture.mypmo.repository.InnovationSkillRepository;

@Component
public class InnovationSkillBizImpl implements InnovationSkillBiz{

	@Autowired
	InnovationSkillRepository innovationRepo;
	@Autowired
	InnovationSkillMapper innovationMapper;
	@Override
	public String captureInnovationDetails(InnovationSkill innovation) {
	
		

		InnovationSkillMapping innovationinfo = innovationMapper
				.detailsMapper(innovation);

		try {

			innovationRepo.save(innovationinfo);
			String result = "true";

		} catch (Exception e) {
			System.out.println("Exception" + e);
		}

		String result=null;
		return result;
	}
	
	

	@Override
	public List<InnovationSkillMapping> getInnovationDetails(int id) {
		
		List<InnovationSkillMapping> innovation = new ArrayList<InnovationSkillMapping>();
		
		try{
			
			innovation = innovationRepo.findById(id);
		}catch (Exception e) {
			System.out.println("Exception" + e);
		}
		
		return innovation;
	}	
		
		
		
	
}

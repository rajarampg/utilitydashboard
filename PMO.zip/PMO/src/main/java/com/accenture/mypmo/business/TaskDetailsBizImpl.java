/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.TaskDetailsMapper;
import com.accenture.mypmo.model.TaskDetails;
import com.accenture.mypmo.model.TaskDetailsMapping;
import com.accenture.mypmo.repository.TaskDetailsRepository;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class TaskDetailsBizImpl implements TaskDetailsBiz {

	@Autowired
	TaskDetailsRepository taskDetailsRepo;

	@Autowired
	TaskDetailsMapper taskDetailsMapper;

	@Override
	/** 
	 * Method to Capture the task details
	 * if the id (primary key) is not specified insert operation will happened 
	 * otherwise update operation will happened based on id.
	 * @param model object of Task
	 * @return Status of the SQL operation as string
	 * 
	 */
	public PMOResponse captureTaskDetails(TaskDetails task){
		
		PMOResponse systemResponse = new PMOResponse();
		TaskDetailsMapping taskDetailsMap = taskDetailsMapper.taskDetailsMapper(task);
		try {
			taskDetailsRepo.save(taskDetailsMap);
		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}
		
		return systemResponse;
	}

	@Override
	public PMOResponse captureAllTaskDetails(List<TaskDetails> taskDetails) {
		PMOResponse systemResponse = new PMOResponse();
		List<TaskDetailsMapping> taskDetailsMap = taskDetailsMapper.taskDetailsMapperCollection(taskDetails);
		try {
			taskDetailsRepo.save(taskDetailsMap);
		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}
		
		return systemResponse;
	}

	@Override
	public TaskDetails viewTaskDetails(int id) {
		TaskDetails task = new TaskDetails();

		try {
			task = taskDetailsMapper.taskDetailsMapMapper(taskDetailsRepo.findById(id));
		} catch (Exception e) {
			System.out.println("Exception in SQL operation " + e);
		}

		return task;
	}

	@Override
	public List<TaskDetails> ViewAllTaskDetails() {
		List<TaskDetails> task = new ArrayList<TaskDetails>();

		try {
			task = taskDetailsMapper.taskDetailsIterableMapMapperCollection(taskDetailsRepo.findAll());
		} catch (Exception e) {
			System.out.println("Exception in SQL operation " + e);
		}

		return task;
	}

	@Override
	public List<TaskDetails> ViewTaskDetailsByCreatedBy(String createdBy) {
		List<TaskDetails> task = new ArrayList<TaskDetails>();

		try {
			task = taskDetailsMapper.taskDetailsMapMapperCollection(taskDetailsRepo.findByCreatedBy(createdBy));
		} catch (Exception e) {
			System.out.println("Exception in SQL operation " + e);
		}

		return task;
	}

	@Override
	public List<TaskDetails> ViewTaskDetailsByAssignedTo(String assignedTo) {
		List<TaskDetails> taskDetails = new ArrayList<TaskDetails>();

		try {
			taskDetails = taskDetailsMapper.taskDetailsMapMapperCollection(taskDetailsRepo.findByAssignedTo(assignedTo));
		} catch (Exception e) {
			System.out.println("Exception in SQL operation " + e);
		}

		return taskDetails;
	}

}

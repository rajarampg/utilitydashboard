/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.CertificationDetailsBiz;
import com.accenture.mypmo.model.CertificationDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/certdetails")
public class CertificationDetailsServiceImpl implements CertificationDetailsService {
	
	@Autowired
	public CertificationDetailsBiz certDetailbiz;

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.CertificationDetailsService#captureCertificationDetails(com.accenture.mypmo.model.CertificationDetails)
	 */
	@Override
	@RequestMapping(value = "/addcert", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse captureCertificationDetails(@RequestBody CertificationDetails certificationDetails) {
		// TODO Auto-generated method stub
		
		return certDetailbiz.captureCertificationDetails(certificationDetails);
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.CertificationDetailsService#updateCertificationDetails(com.accenture.mypmo.model.CertificationDetails)
	 */
	@Override
	@RequestMapping(value = "/updatecert", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updateCertificationDetails(@RequestBody CertificationDetails certificationDetails) {
		// TODO Auto-generated method stub
		return certDetailbiz.captureCertificationDetails(certificationDetails);
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.CertificationDetailsService#viewCertificationDetails(int)
	 */
	@Override
	@RequestMapping(value = "/viewcert/{id}", method = RequestMethod.GET)
	public CertificationDetails viewCertificationDetails(@PathVariable int id) {
		return certDetailbiz.viewCertificationDetails(id);
	}

	@Override
	@RequestMapping(value = "/viewcertbyassignedto", method = RequestMethod.GET)
	public List<CertificationDetails> viewCertificationDetailsByAssignedTo(@QueryParam("assignedTo") String assignedTo) {
		return certDetailbiz.viewCertificationDetailsByAssignedTo(assignedTo);
	}

	@Override
	@RequestMapping(value = "/viewallcert", method = RequestMethod.GET)
	public List<CertificationDetails> viewAllCertificationDetails() {
		// TODO Auto-generated method stub
		return certDetailbiz.viewAllCertificationDetails();
	}



}

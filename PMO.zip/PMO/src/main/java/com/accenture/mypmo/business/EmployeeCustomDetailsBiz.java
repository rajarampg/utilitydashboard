/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.List;

import com.accenture.mypmo.model.EmployeeCustomDetails;

/**
 * @author p.senthilrajan
 *
 */
public interface EmployeeCustomDetailsBiz {

	String FIND_ALL_EMPLOYEE_DETAILS = "SELECT [employeedetails].[id] AS accenture_id, [employeedetails].[employee_number] AS accenture_employee_number, [employeedetails].[portfolio_id] AS accenture_portfolio_id, [rrd_id],[enterprise_id],[first_name],[last_name],[gender],[capability],[career_level], [supervisor_ent_id], [current_location],"
			+ " [delivery_center],[visa_type],[duration_stay],[phone_no],[primary_skill],[secondary_skill],[proficiency_level], [lock_type],[employee_status],[employee_type],[rollondate],[rollonby],[rolloffdate],[rolloffreason],[rolledoffby], [isexit],[employeedetails].[created_by] AS accenture_created_by,"
			+ " [employeedetails].[created_on] AS accenture_created_on,[employeedetails].[modified_by] AS accenture_modified_by,[employeedetails].[modified_on] AS accenture_modified_on,[employeedetails].[active] AS accenture_active,"
			+ " ISNULL([employeewmdetails].[id],0) AS client_id, ISNULL([employeewmdetails].[employee_number],0) AS client_employee_number, ISNULL([employeewmdetails].[client_manager_id],0) AS client_client_manager_id, ISNULL([pattern_id],0) AS client_pattern_id, ISNULL([role_id],0) AS client_role_id,[wmt_userid],[wmt_accessdate],[wmt_grantdate],[contract_type],[projectname],"
			+ " [projectdetails],[client],[departmentnumber],[country],[workstation],[bay_details],[floor],[wbse],[identifiertype],[identifiernumber],[comments],[onboardstartdate],[onboardtime],[onboardedby],ISNULL([isrenew],0) AS isrenew,[employeewmdetails].[created_by] AS client_created_by,[employeewmdetails].[created_on] AS client_created_on,[employeewmdetails].[modified_by] AS client_modified_by,[employeewmdetails].[modified_on] AS client_modified_on,"
			+ " ISNULL([employeewmdetails].[active], 0) AS client_active, ISNULL([portfoliodetails].[id],0) AS portfolioid,[portfolio_name],[portfolio_description]"
			+ " ,ISNULL([portfoliodetails].[active],0) AS portfolio_active, [portfoliodetails].[created_by] AS portfolio_created_by, [portfoliodetails].[created_on] AS portfolio_created_on"
			+ " ,[portfoliodetails].[modified_by] AS portfolio_modified_by, [portfoliodetails].[modified_on] AS portfolio_modified_on,"
			+ " ISNULL([clientmanagerdetails].[id],0) AS client_manager_id, ISNULL([clientmanagerdetails].[portfolio_id],0) AS client_manager_portfolio_id, [team],[resource_manager],[vice_president],[director_id],[contract_id],[clientmanagerdetails].[created_by] AS client_manager_created_by,[clientmanagerdetails].[created_on] AS client_manager_created_on,"
			+ " [clientmanagerdetails].[modified_by] AS client_manager_modified_by,[clientmanagerdetails].[modified_on] AS client_manager_modified_on, ISNULL([clientmanagerdetails].[active],0) AS client_manager_active, "
			+ " ISNULL([roledetails].[id],0) AS role_id, [role], [role_description], [location],ISNULL([rate],0) AS rate, [roledetails].[created_by] AS role_created_by,[roledetails].[created_on] AS role_created_on "
			+ " ,[roledetails].[modified_by] AS role_modified_by,[roledetails].[modified_on] AS role_modified_on,ISNULL([roledetails].[active],0) AS role_active, "
			+ " ISNULL([patterndetails].[id],0) AS pattern_id, ISNULL([patterndetails].[portfolio_id],0) AS pattern_portfolio_id,[pattern_name],[pattern_description],[skill_team_details],[clarity],[unix_boxes]"
			+ " ,[teradata_access],[ad_access],[additional_access],[specific_access],[business_justification]"
			+ " ,[patterndetails].[created_by] AS pattern_created_by,[patterndetails].[created_on] AS pattern_created_on, [patterndetails].[modified_by] AS pattern_modified_by, [patterndetails].[modified_on] AS pattern_modified_on"
			+ " ,ISNULL([patterndetails].[active],0) AS pattern_active"
			+ " FROM employeedetails"
			+ " LEFT JOIN employeewmdetails ON employeedetails.employee_number = employeewmdetails.employee_number AND employeewmdetails.active = 1"
			+ " LEFT JOIN portfoliodetails ON employeedetails.portfolio_id = portfoliodetails.id"
			+ " LEFT JOIN clientmanagerdetails ON employeewmdetails.client_manager_id = clientmanagerdetails.id "
			+ " LEFT JOIN roledetails ON employeewmdetails.role_id = roledetails.id "
			+ " LEFT JOIN patterndetails ON employeewmdetails.pattern_id = patterndetails.id"
			+ " WHERE employeedetails.active = 1 ";
			
	List<EmployeeCustomDetails> findAllEmployeeDetails();

	List<EmployeeCustomDetails> findFullEmployeeDetailsByEmpNumner(int employeeNumber);
}

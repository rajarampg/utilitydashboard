package com.accenture.mypmo.service;

import com.accenture.mypmo.model.InnovationSkill;

public interface InnovationSkillService {

	String captureInnovationDetails(InnovationSkill innovation);
	
}

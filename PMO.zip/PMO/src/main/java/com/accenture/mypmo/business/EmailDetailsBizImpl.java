/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.EmailDetailsMapper;
import com.accenture.mypmo.model.EmailDetails;
import com.accenture.mypmo.model.EmailDetailsMapping;
import com.accenture.mypmo.repository.EmailDetailsRepository;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class EmailDetailsBizImpl implements EmailDetailsBiz {

	@Autowired
	EmailDetailsMapper emailMapper;

	@Autowired
	EmailDetailsRepository emailRepo;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.accenture.mypmo.business.EmailDetailsBiz#CaptureEmailDetails(com.
	 * accenture.mypmo.model.EmailDetails)
	 */
	@Override
	public PMOResponse CaptureEmailDetails(EmailDetails email) {
		PMOResponse systemResponse = new PMOResponse();
		EmailDetailsMapping emailMap = emailMapper.emailDetailsMapping(email);
		
		try {
			emailRepo.save(emailMap);
		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}
		return systemResponse;
	}

	@Override
	public PMOResponse CaptureAllEmailDetails(List<EmailDetails> emailDetails) {
		PMOResponse systemResponse = new PMOResponse();
		List<EmailDetailsMapping> emailDetailsMapping = emailMapper.emailDetailsMappingCollection(emailDetails);
		
		try {
			emailRepo.save(emailDetailsMapping);
		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}
		return systemResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.accenture.mypmo.business.EmailDetailsBiz#viewEmailDetails(int)
	 */
	@Override
	public EmailDetails viewEmailDetails(int emailId) {
		// TODO Auto-generated method stub
		EmailDetails email = emailMapper.emailDetailsMapMapping(emailRepo.findById(emailId));
		return email;
	}

	@Override
	public List<EmailDetails> viewAllEmailDetails() {
		// TODO Auto-generated method stub
		List<EmailDetails> emailDetails = emailMapper.emailDetailsIterableMapMappingCollection(emailRepo.findAll());
		return emailDetails;
	}

}

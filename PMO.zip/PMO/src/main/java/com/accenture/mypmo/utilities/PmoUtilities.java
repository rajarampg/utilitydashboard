package com.accenture.mypmo.utilities;

import java.util.Random;

public class PmoUtilities {

	public String randomNumber() {
		Random r = new Random(System.currentTimeMillis());
		int randVal = 10000 + r.nextInt(20000);
		return "D" + Integer.toString(randVal);
	}

}

package com.accenture.mypmo.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.PortfolioDetailsMapping;

public interface PortfolioDetailsRepository
		extends CrudRepository<PortfolioDetailsMapping, String>, JpaSpecificationExecutor<PortfolioDetailsMapping> {

	public PortfolioDetailsMapping findById(int id);

}

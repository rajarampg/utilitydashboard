/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.TaskDetailsBiz;
import com.accenture.mypmo.model.TaskDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/taskdetails")
public class TaskDetailsServiceImpl implements TaskDetailsService {

	@Autowired
	public TaskDetailsBiz taskDetailsBiz;

	@RequestMapping(value = "/addtask", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse captureTaskDetails(@RequestBody TaskDetails taskDetails){
		 return taskDetailsBiz.captureTaskDetails(taskDetails);
	}

	@RequestMapping(value = "/updatetask", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updateTaskDetails(@RequestBody TaskDetails taskDetails){
		return taskDetailsBiz.captureTaskDetails(taskDetails);
	}

	@Override
	@RequestMapping(value = "/updatealltask", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updateAllTaskDetails(@RequestBody List<TaskDetails> taskDetails) {
		// TODO Auto-generated method stub
		return taskDetailsBiz.captureAllTaskDetails(taskDetails);
	}
	@RequestMapping(value = "/viewtask/{id}", method = RequestMethod.GET)
	public TaskDetails viewTaskDetails(@PathVariable int id) {
		return taskDetailsBiz.viewTaskDetails(id);
	}

	@Override
	@RequestMapping(value = "/viewalltask", method = RequestMethod.GET)
	public List<TaskDetails> ViewAllTaskDetails() {
		// TODO Auto-generated method stub
		return taskDetailsBiz.ViewAllTaskDetails();
	}

	@Override
	@RequestMapping(value = "/viewtaskbycreatedby", method = RequestMethod.GET)
	public List<TaskDetails> ViewTaskDetailsByCreatedBy(@QueryParam("createdBy") String createdBy) {
		// TODO Auto-generated method stub
		return taskDetailsBiz.ViewTaskDetailsByCreatedBy(createdBy);
	}

	@Override
	@RequestMapping(value = "/viewtaskbyassignedto", method = RequestMethod.GET)
	public List<TaskDetails> ViewTaskDetailsByAssignedTo(@QueryParam("assignedTo") String assignedTo) {
		// TODO Auto-generated method stub
		return taskDetailsBiz.ViewTaskDetailsByAssignedTo(assignedTo);
	}

}

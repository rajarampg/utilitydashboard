package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.EmployeeDetails;
import com.accenture.mypmo.model.EmployeeDetailsMapping;

@Component
public class EmployeeDetailsMapper {

	public EmployeeDetailsMapping employeeDetailsMapper(EmployeeDetails empDetails) {

		EmployeeDetailsMapping empDetailsMapping = new EmployeeDetailsMapping();

		empDetailsMapping.setId(empDetails.getId());
		empDetailsMapping.setEmployeeNumber(empDetails.getEmployeeNumber());
		empDetailsMapping.setPortfolioId(empDetails.getPortfolioId());
		empDetailsMapping.setRrdId(empDetails.getRrdId());
		empDetailsMapping.setEnterpriseId(empDetails.getEnterpriseId());
		empDetailsMapping.setFirstName(empDetails.getFirstName());
		empDetailsMapping.setLastName(empDetails.getLastName());
		empDetailsMapping.setGender(empDetails.getGender());
		empDetailsMapping.setCapability(empDetails.getCapability());
		empDetailsMapping.setCareerLevel(empDetails.getCareerLevel());
		empDetailsMapping.setSupervisorEntId(empDetails.getSupervisorEntId());
		empDetailsMapping.setCurrentLocation(empDetails.getCurrentLocation());
		empDetailsMapping.setDeliveryCenter(empDetails.getDeliveryCenter());
		empDetailsMapping.setVisaType(empDetails.getVisaType());
		empDetailsMapping.setDurationStay(empDetails.getDurationStay());
		empDetailsMapping.setPhoneNo(empDetails.getPhoneNo());
		empDetailsMapping.setPrimarySkill(empDetails.getPrimarySkill());
		empDetailsMapping.setSecondarySkill(empDetails.getSecondarySkill());
		empDetailsMapping.setProficiencyLevel(empDetails.getProficiencyLevel());
		empDetailsMapping.setLockType(empDetails.getLockType());
		empDetailsMapping.setEmployeeStatus(empDetails.getEmployeeStatus());
		empDetailsMapping.setEmployeeType(empDetails.getEmployeeType());
		empDetailsMapping.setRollonDate(empDetails.getRollonDate());
		empDetailsMapping.setRollonBy(empDetails.getRollonBy());
		empDetailsMapping.setRolloffDate(empDetails.getRolloffDate());
		empDetailsMapping.setRolloffReason(empDetails.getRolloffReason());
		empDetailsMapping.setRolledoffBy(empDetails.getRolledoffBy());
		empDetailsMapping.setExit(empDetails.isExit());
		empDetailsMapping.setCreatedBy(empDetails.getCreatedBy());
		empDetailsMapping.setCreatedOn(empDetails.getCreatedOn());
		empDetailsMapping.setModifiedBy(empDetails.getModifiedBy());
		empDetailsMapping.setModifiedOn(empDetails.getModifiedOn());
		empDetailsMapping.setActive(empDetails.isActive());

		return empDetailsMapping;
	}

	public EmployeeDetails employeeDetailsMapMapper(EmployeeDetailsMapping empDetailsMapping) {

		EmployeeDetails empDetails = new EmployeeDetails();

		empDetails.setId(empDetailsMapping.getId());
		empDetails.setEmployeeNumber(empDetailsMapping.getEmployeeNumber());
		empDetails.setPortfolioId(empDetailsMapping.getPortfolioId());
		empDetails.setRrdId(empDetailsMapping.getRrdId());
		empDetails.setEnterpriseId(empDetailsMapping.getEnterpriseId());
		empDetails.setFirstName(empDetailsMapping.getFirstName());
		empDetails.setLastName(empDetailsMapping.getLastName());
		empDetails.setGender(empDetailsMapping.getGender());
		empDetails.setCapability(empDetailsMapping.getCapability());
		empDetails.setCareerLevel(empDetailsMapping.getCareerLevel());
		empDetails.setSupervisorEntId(empDetailsMapping.getSupervisorEntId());
		empDetails.setCurrentLocation(empDetailsMapping.getCurrentLocation());
		empDetails.setDeliveryCenter(empDetailsMapping.getDeliveryCenter());
		empDetails.setVisaType(empDetailsMapping.getVisaType());
		empDetails.setDurationStay(empDetailsMapping.getDurationStay());
		empDetails.setPhoneNo(empDetailsMapping.getPhoneNo());
		empDetails.setPrimarySkill(empDetailsMapping.getPrimarySkill());
		empDetails.setSecondarySkill(empDetailsMapping.getSecondarySkill());
		empDetails.setProficiencyLevel(empDetailsMapping.getProficiencyLevel());
		empDetails.setLockType(empDetailsMapping.getLockType());
		empDetails.setEmployeeStatus(empDetailsMapping.getEmployeeStatus());
		empDetails.setEmployeeType(empDetailsMapping.getEmployeeType());
		empDetails.setRollonDate(empDetailsMapping.getRollonDate());
		empDetails.setRollonBy(empDetailsMapping.getRollonBy());
		empDetails.setRolloffDate(empDetailsMapping.getRolloffDate());
		empDetails.setRolloffReason(empDetailsMapping.getRolloffReason());
		empDetails.setRolledoffBy(empDetailsMapping.getRolledoffBy());
		empDetails.setExit(empDetailsMapping.isExit());
		empDetails.setCreatedBy(empDetailsMapping.getCreatedBy());
		empDetails.setCreatedOn(empDetailsMapping.getCreatedOn());
		empDetails.setModifiedBy(empDetailsMapping.getModifiedBy());
		empDetails.setModifiedOn(empDetailsMapping.getModifiedOn());
		empDetails.setActive(empDetailsMapping.isActive());

		return empDetails;
	}

	public List<EmployeeDetails> employeeDetailsMapMapperCollection(List<EmployeeDetailsMapping> empDetailsMapping) {

		List<EmployeeDetails> empDetails = new ArrayList<EmployeeDetails>();

		for (EmployeeDetailsMapping empDetailsMappingTemp : empDetailsMapping) {
			empDetails.add(employeeDetailsMapMapper(empDetailsMappingTemp));
		}

		return empDetails;
	}

	public List<EmployeeDetails> employeeDetailsIterableMapMapper(Iterable<EmployeeDetailsMapping> empDetailsMapping) {

		List<EmployeeDetails> empDetails = new ArrayList<EmployeeDetails>();

		for (EmployeeDetailsMapping empDetailsMappingTemp : empDetailsMapping) {
			empDetails.add(employeeDetailsMapMapper(empDetailsMappingTemp));
		}

		return empDetails;
	}

	public List<EmployeeDetailsMapping> employeeDetailsMapperCollection(List<EmployeeDetails> empDetails) {

		List<EmployeeDetailsMapping> empDetailsMapping = new ArrayList<EmployeeDetailsMapping>();

		for (EmployeeDetails empDetailsTemp : empDetails) {
			empDetailsMapping.add(employeeDetailsMapper(empDetailsTemp));
		}

		return empDetailsMapping;
	}

}

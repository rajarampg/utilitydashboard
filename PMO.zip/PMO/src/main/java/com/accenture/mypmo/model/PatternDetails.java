/**
 * 
 */
package com.accenture.mypmo.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author p.senthilrajan
 *
 */
public class PatternDetails implements Serializable {

	public static final long serialVersionUID = 1L;

	private int id;

	private int portfolioId;
	
	private String patternName;
	
	private String patternDescription;
	
	private String skillTeamDetails;
	
	private String clarity;
	
	private String unixBoxes;
	
	private String teradataAccess;
	
	private String adAccess;
	
	private String additionalAccess;
	
	private String specificAccess;
	
	private String businessJustification;
	
	private String createdBy;
	
	private Timestamp createdOn;
	
	private String modifiedBy;
	
	private Timestamp modifiedOn;
	
	private boolean active;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(int portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getPatternName() {
		return patternName;
	}

	public void setPatternName(String patternName) {
		this.patternName = patternName;
	}

	public String getPatternDescription() {
		return patternDescription;
	}

	public void setPatternDescription(String patternDescription) {
		this.patternDescription = patternDescription;
	}

	public String getSkillTeamDetails() {
		return skillTeamDetails;
	}

	public void setSkillTeamDetails(String skillTeamDetails) {
		this.skillTeamDetails = skillTeamDetails;
	}

	public String getClarity() {
		return clarity;
	}

	public void setClarity(String clarity) {
		this.clarity = clarity;
	}

	public String getUnixBoxes() {
		return unixBoxes;
	}

	public void setUnixBoxes(String unixBoxes) {
		this.unixBoxes = unixBoxes;
	}

	public String getTeradataAccess() {
		return teradataAccess;
	}

	public void setTeradataAccess(String teradataAccess) {
		this.teradataAccess = teradataAccess;
	}

	public String getAdAccess() {
		return adAccess;
	}

	public void setAdAccess(String adAccess) {
		this.adAccess = adAccess;
	}

	public String getAdditionalAccess() {
		return additionalAccess;
	}

	public void setAdditionalAccess(String additionalAccess) {
		this.additionalAccess = additionalAccess;
	}

	public String getSpecificAccess() {
		return specificAccess;
	}

	public void setSpecificAccess(String specificAccess) {
		this.specificAccess = specificAccess;
	}

	public String getBusinessJustification() {
		return businessJustification;
	}

	public void setBusinessJustification(String businessJustification) {
		this.businessJustification = businessJustification;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "PatternDetails [id=" + id + ", portfolioId=" + portfolioId + ", patternName=" + patternName
				+ ", patternDescription=" + patternDescription + ", skillTeamDetails=" + skillTeamDetails + ", clarity="
				+ clarity + ", unixBoxes=" + unixBoxes + ", teradataAccess=" + teradataAccess + ", adAccess=" + adAccess
				+ ", additionalAccess=" + additionalAccess + ", specificAccess=" + specificAccess
				+ ", businessJustification=" + businessJustification + ", createdBy=" + createdBy + ", createdOn="
				+ createdOn + ", modifiedBy=" + modifiedBy + ", modifiedOn=" + modifiedOn + ", active=" + active + "]";
	}

	
	
}

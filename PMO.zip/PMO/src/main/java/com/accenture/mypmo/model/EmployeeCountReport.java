/**
 * 
 */
package com.accenture.mypmo.model;

import java.io.Serializable;

/**
 * @author p.senthilrajan
 *
 */
public class EmployeeCountReport implements Serializable {

	private static final long serialVersionUID = 7261336881630862015L;

	private int sno;
	
	private String portfolio;
	
	private String countbase;
	
	private String worklocation;
	
	private String countvalue;
	
	

	public int getSno() {
		return sno;
	}

	public void setSno(int sno) {
		this.sno = sno;
	}

	public String getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(String portfolio) {
		this.portfolio = portfolio;
	}

	public String getCountbase() {
		return countbase;
	}

	public void setCountbase(String countbase) {
		this.countbase = countbase;
	}

	public String getWorklocation() {
		return worklocation;
	}

	public void setWorklocation(String worklocation) {
		this.worklocation = worklocation;
	}

	public String getCountvalue() {
		return countvalue;
	}

	public void setCountvalue(String countvalue) {
		this.countvalue = countvalue;
	}

	@Override
	public String toString() {
		return "EmployeeCountReport [sno=" + sno + ", portfolio=" + portfolio + ", countbase=" + countbase
				+ ", worklocation=" + worklocation + ", countvalue=" + countvalue + "]";
	}


	
	
}

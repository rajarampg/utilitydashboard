/**
 * 
 */
package com.accenture.mypmo.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author p.senthilrajan
 *
 */
public class TaskDetails implements Serializable {

	public static final long serialVersionUID = 1L;

	private int id;

	private String taskName;

	private String taskDescription;

	private String requestType;

	private String subrequestType;

	private String approvedBy;

	private Timestamp approvedOn;

	private String approverComments;

	private String assignedTo;

	private Timestamp assignedOn;

	private String status;

	private String comments;

	private String createdBy;

	private Timestamp createdOn;

	private String modifiedBy;

	private Timestamp modifiedOn;

	private boolean active;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getTaskDescription() {
		return taskDescription;
	}

	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getSubrequestType() {
		return subrequestType;
	}

	public void setSubrequestType(String subrequestType) {
		this.subrequestType = subrequestType;
	}

	public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Timestamp getApprovedOn() {
		return approvedOn;
	}

	public void setApprovedOn(Timestamp approvedOn) {
		this.approvedOn = approvedOn;
	}

	public String getApproverComments() {
		return approverComments;
	}

	public void setApproverComments(String approverComments) {
		this.approverComments = approverComments;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public Timestamp getAssignedOn() {
		return assignedOn;
	}

	public void setAssignedOn(Timestamp assignedOn) {
		this.assignedOn = assignedOn;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "TaskDetails [id=" + id + ", taskName=" + taskName + ", taskDescription=" + taskDescription
				+ ", requestType=" + requestType + ", subrequestType=" + subrequestType + ", approvedBy=" + approvedBy
				+ ", approvedOn=" + approvedOn + ", approverComments=" + approverComments + ", assignedTo=" + assignedTo
				+ ", assignedOn=" + assignedOn + ", status=" + status + ", comments=" + comments + ", createdBy="
				+ createdBy + ", createdOn=" + createdOn + ", modifiedBy=" + modifiedBy + ", modifiedOn=" + modifiedOn
				+ ", active=" + active + "]";
	}


}

/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.EmployeeCountReportBiz;
import com.accenture.mypmo.model.EmployeeCountReport;

/**
 * @author p.senthilrajan
 *
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/empcount")
public class EmployeeCountReportServiceImpl implements EmployeeCountReportService {
	
	@Autowired
	EmployeeCountReportBiz employeeCountReportBiz;

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.EmployeeCountReportService#empCountByPortfolio()
	 */
	@Override
	@RequestMapping(value = "/empcountbyportfolio", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<EmployeeCountReport> empCountByPortfolio() {
		// TODO Auto-generated method stub
		return employeeCountReportBiz.empCountByPortfolio();
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.EmployeeCountReportService#empCountByEmpStatus()
	 */
	@Override
	@RequestMapping(value = "/empcountbyempstatus", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<EmployeeCountReport> empCountByEmpStatus() {
		// TODO Auto-generated method stub
		return employeeCountReportBiz.empCountByEmpStatus();
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.EmployeeCountReportService#empCountByRolloff()
	 */
	@Override
	@RequestMapping(value = "/empcountbyrolloff", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<EmployeeCountReport> empCountByRolloff() {
		// TODO Auto-generated method stub
		return employeeCountReportBiz.empCountByRolloff();
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.EmployeeCountReportService#empCountByCareerLevel()
	 */
	@Override
	@RequestMapping(value = "/empcountbycareerlevel", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<EmployeeCountReport> empCountByCareerLevel() {
		// TODO Auto-generated method stub
		return employeeCountReportBiz.empCountByCareerLevel();
	}

}

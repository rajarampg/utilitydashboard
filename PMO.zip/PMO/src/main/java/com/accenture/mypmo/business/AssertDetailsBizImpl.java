/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.AssertDetailsMapper;
import com.accenture.mypmo.model.AssertDetails;
import com.accenture.mypmo.model.AssertDetailsMapping;
import com.accenture.mypmo.repository.AssertDetailsRepository;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class AssertDetailsBizImpl implements AssertDetailsBiz {

	@Autowired
	AssertDetailsRepository assertDetailsRepo;

	@Autowired
	AssertDetailsMapper assertDetailsMapper;

	@Override
	public PMOResponse captureAssertDetails(AssertDetails assertDetails) {
		PMOResponse systemResponse = new PMOResponse();
		AssertDetailsMapping assertDetailsMapping = assertDetailsMapper
				.assertDetailsMapper(assertDetails);

		try {
			assertDetailsRepo.save(assertDetailsMapping);
		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}

		return systemResponse;
	}

	@Override
	public List<AssertDetails> viewAssertDetailsByAssignedTo(String assignedTo) {

		List<AssertDetails> assertDetails = new ArrayList<AssertDetails>();
		try {
			assertDetails = assertDetailsMapper
					.assertDetailsMapMapperCollection(assertDetailsRepo.findByAssignedTo(assignedTo));
		} catch (Exception e) {

		}
		return assertDetails;
	}

	@Override
	public AssertDetails viewAssertDetails(int id) {
		AssertDetails assertDetails = new AssertDetails();
		try {
			assertDetails = assertDetailsMapper.assertDetailsMapMapper(assertDetailsRepo.findById(id));
		} catch (Exception e) {

		}
		return assertDetails;
	}

	@Override
	public List<AssertDetails> viewAllAssertDetails() {
		List<AssertDetails> assertDetails = new ArrayList<AssertDetails>();
		try {
			assertDetails = assertDetailsMapper.assertDetailsMapMapperCollection(
					assertDetailsMapper.assertIterableCollection(assertDetailsRepo.findAll()));
		} catch (Exception e) {

		}
		return assertDetails;
	}

}

package com.accenture.mypmo.model;

import java.util.List;

import com.accenture.mypmo.response.PMOResponse;

public class RollonChecklistReport extends PMOResponse{

			
	private List<RollonChecklist> checklists;

	public List<RollonChecklist> getChecklists() {
		return checklists;
	}

	public void setChecklists(List<RollonChecklist> checklists) {
		this.checklists = checklists;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RollonChecklistReport [checklists=");
		builder.append(checklists);
		builder.append("]");
		return builder.toString();
	}
	
}

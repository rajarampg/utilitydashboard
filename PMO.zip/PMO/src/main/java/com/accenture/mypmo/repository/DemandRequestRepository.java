package com.accenture.mypmo.repository;

import org.springframework.data.repository.CrudRepository;
//import org.springframework.data.repository.Repository;

import com.accenture.mypmo.model.RRDDemandMapping;

public interface DemandRequestRepository extends
		CrudRepository<RRDDemandMapping, String> {

}

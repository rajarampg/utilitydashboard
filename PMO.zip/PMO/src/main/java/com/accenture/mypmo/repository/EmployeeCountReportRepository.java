/**
 * 
 */
package com.accenture.mypmo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.EmployeeCountReportMapping;

/**
 * @author p.senthilrajan
 *
 */
public interface EmployeeCountReportRepository extends CrudRepository<EmployeeCountReportMapping, String> {
	
	String EMP_COUNT_BY_PORTFOLIO = " SELECT row_number() OVER (ORDER BY portfolio_name ) AS sno, ISNULL(portfolio_name,'') AS portfolio, ISNULL(portfolio_name,'') AS countbase, delivery_center AS worklocation, COUNT(delivery_center) AS countvalue "
			+ " FROM employeedetails LEFT JOIN portfoliodetails ON employeedetails.portfolio_id = portfoliodetails.id WHERE employeedetails.active = 1 "
			+ " GROUP BY portfolio_name, delivery_center ORDER BY portfolio_name, delivery_center ";

	String EMP_COUNT_BY_EMPSTATUS = " SELECT row_number() OVER (ORDER BY portfolio_name ) AS sno, ISNULL(portfolio_name,'') AS portfolio, employee_status AS countbase, [delivery_center] AS worklocation, COUNT(employee_status) AS countvalue "
			+ " FROM employeedetails LEFT JOIN portfoliodetails ON employeedetails.portfolio_id = portfoliodetails.id WHERE employeedetails.active = 1 "
			+ " GROUP BY portfolio_name, delivery_center, employee_status ORDER BY portfolio_name ";

	String EMP_COUNT_BY_ROLLOFF = " SELECT row_number() OVER (ORDER BY portfolio_name ) AS sno, DATENAME(YY, rolloffdate), DATENAME(MM, rolloffdate), DatePart(M, rolloffdate), ISNULL(portfolio_name,'') AS portfolio, "
			+ " DATENAME(YY, rolloffdate) +' - '+ DATENAME(MM, rolloffdate) AS countbase, delivery_center AS worklocation,  COUNT(rolloffdate) AS countvalue"
			+ " FROM employeedetails LEFT JOIN portfoliodetails ON employeedetails.portfolio_id = portfoliodetails.id"
			+ " WHERE employeedetails.active = 1 AND employee_status = 5 GROUP BY portfolio_name, DATENAME(YY, rolloffdate), DATENAME(MM, rolloffdate), "
			+ " DatePart(M, rolloffdate), delivery_center, DATENAME(YY, rolloffdate) +' - '+ DATENAME(MM, rolloffdate) ORDER BY DATENAME(YY, rolloffdate) DESC, DatePart(M, rolloffdate) DESC";

	
	String EMP_COUNT_BY_CAREERLEVEL = "SELECT row_number() OVER (ORDER BY portfolio_name ) AS sno, ISNULL(portfolio_name,'') AS portfolio, career_level AS countbase, [delivery_center] AS worklocation, COUNT([delivery_center]) AS countvalue"
			+ " FROM [employeedetails] LEFT JOIN portfoliodetails ON [employeedetails].portfolio_id = portfoliodetails.id"
			+ " WHERE employeedetails.active = 1 GROUP BY portfolio_name, career_level, delivery_center ORDER BY portfolio_name ,career_level, delivery_center";


	@Query(value = EMP_COUNT_BY_PORTFOLIO, nativeQuery = true)
	List<EmployeeCountReportMapping> empCountByPortfolio();

	@Query(value = EMP_COUNT_BY_EMPSTATUS, nativeQuery = true)
	List<EmployeeCountReportMapping> empCountByEmpStatus();

	@Query(value = EMP_COUNT_BY_ROLLOFF, nativeQuery = true)
	List<EmployeeCountReportMapping> empCountByRolloff();

	@Query(value = EMP_COUNT_BY_CAREERLEVEL, nativeQuery = true)
	List<EmployeeCountReportMapping> empCountByCareerLevel();

}

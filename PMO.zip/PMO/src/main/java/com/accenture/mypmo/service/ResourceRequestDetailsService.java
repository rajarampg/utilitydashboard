package com.accenture.mypmo.service;

import java.util.List;

import com.accenture.mypmo.model.ResourceRequestDetails;
import com.accenture.mypmo.response.PMOResponse;

public interface ResourceRequestDetailsService {

	PMOResponse captureRRD(ResourceRequestDetails rrdDetails);

	PMOResponse updateRRD(ResourceRequestDetails rrdDetails);

	List<ResourceRequestDetails> viewRRDByPortfolioId(int portfolioid);

	ResourceRequestDetails viewRRDById(int Id);

	List<ResourceRequestDetails> viewAllRRD();

}

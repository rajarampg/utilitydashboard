package com.accenture.mypmo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.EmployeeDetailsMapper;
import com.accenture.mypmo.model.EmployeeDetails;
import com.accenture.mypmo.model.EmployeeDetailsMapping;
import com.accenture.mypmo.repository.EmployeeDetailsRepository;
import com.accenture.mypmo.response.PMOResponse;

@Component
public class EmployeeDetailsBizImpl implements EmployeeDetailsBiz {

	@Autowired
	EmployeeDetailsRepository employeeDetailsRepository;

	@Autowired
	EmployeeDetailsMapper employeeDetailsMapper;

	@Override
	public PMOResponse captureEmployeeDetails(EmployeeDetails employeeDetails) {

		PMOResponse systemResponse = new PMOResponse();
		EmployeeDetailsMapping employeeinfo = employeeDetailsMapper.employeeDetailsMapper(employeeDetails);

		try {

			employeeDetailsRepository.save(employeeinfo);

		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}

		return systemResponse;
	}

	@Override
	public PMOResponse captureAllEmployeeDetails(List<EmployeeDetails> empdetails) {
	
		PMOResponse systemResponse = new PMOResponse();
		List<EmployeeDetailsMapping> employeeinfo = employeeDetailsMapper.employeeDetailsMapperCollection(empdetails);

		try {

			employeeDetailsRepository.save(employeeinfo);

		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}

		return systemResponse;
	}

	@Override
	public EmployeeDetails viewEmployeeDetails(int id) {

		EmployeeDetails employeeDetails = new EmployeeDetails();

		try {
			employeeDetails = employeeDetailsMapper.employeeDetailsMapMapper(employeeDetailsRepository.findById(id));

		} catch (Exception e) {
			System.out.println("Exception" + e);
		}

		return employeeDetails;
	}

	@Override
	public EmployeeDetails viewEmployeeDetailsByEmployeeId(int employeeId) {
		EmployeeDetails employeeDetails = new EmployeeDetails();

		try {
			employeeDetails = employeeDetailsMapper
					.employeeDetailsMapMapper(employeeDetailsRepository.findByEmployeeNumber(employeeId));

		} catch (Exception e) {
			System.out.println("Exception" + e);
		}

		return employeeDetails;
	}

	@Override
	public List<EmployeeDetails> viewEmployeeDetailsByPortfolioId(int portfolioId) {
		List<EmployeeDetails> employeeDetails = new ArrayList<EmployeeDetails>();

		try {
			employeeDetails = employeeDetailsMapper
					.employeeDetailsMapMapperCollection(employeeDetailsRepository.findByPortfolioId(portfolioId));
		} catch (Exception e) {
			System.out.println("Exception" + e);
		}

		return employeeDetails;
	}

	@Override
	public List<EmployeeDetails> viewAllEmployeeDetails() {
		List<EmployeeDetails> employeeDetails = new ArrayList<EmployeeDetails>();

		try {
			employeeDetails = employeeDetailsMapper
					.employeeDetailsIterableMapMapper(employeeDetailsRepository.findAll());
		} catch (Exception e) {
			System.out.println("Exception" + e);
		}

		return employeeDetails;
	}

	@Override
	public EmployeeDetails viewEmployeeDetailsByRRDId(String rrdId) {
		EmployeeDetails employeeDetails = new EmployeeDetails();

		try {
			employeeDetails = employeeDetailsMapper
					.employeeDetailsMapMapper(employeeDetailsRepository.findByRrdId(rrdId));

		} catch (Exception e) {
			System.out.println("Exception" + e);
		}

		return employeeDetails;
	}

}

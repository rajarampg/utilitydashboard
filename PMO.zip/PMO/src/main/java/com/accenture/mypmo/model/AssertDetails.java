/**
 * 
 */
package com.accenture.mypmo.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author p.senthilrajan
 *
 */
public class AssertDetails implements Serializable{

	public static final long serialVersionUID = 1L;

	int id;

	private String assignedTo;
	
	private String assertType;
	
	private String assertId;
	
	private String assetTag;
	
	private String assertOwnType;
	
	private String comments;
	
	private String serviceProvider;
	
	private String billDetails;
	
	private Timestamp issuedDate;
	
	private String issuedBy;
	
	private Timestamp validity;

	private Timestamp returnDate;
	
	private String returnBy;
	
	private boolean active;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getAssertType() {
		return assertType;
	}

	public void setAssertType(String assertType) {
		this.assertType = assertType;
	}

	public String getAssertId() {
		return assertId;
	}

	public void setAssertId(String assertId) {
		this.assertId = assertId;
	}

	public String getAssetTag() {
		return assetTag;
	}

	public void setAssetTag(String assetTag) {
		this.assetTag = assetTag;
	}

	public String getAssertOwnType() {
		return assertOwnType;
	}

	public void setAssertOwnType(String assertOwnType) {
		this.assertOwnType = assertOwnType;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getServiceProvider() {
		return serviceProvider;
	}

	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}

	public String getBillDetails() {
		return billDetails;
	}

	public void setBillDetails(String billDetails) {
		this.billDetails = billDetails;
	}

	public Timestamp getIssuedDate() {
		return issuedDate;
	}

	public void setIssuedDate(Timestamp issuedDate) {
		this.issuedDate = issuedDate;
	}

	public String getIssuedBy() {
		return issuedBy;
	}

	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}

	public Timestamp getValidity() {
		return validity;
	}

	public void setValidity(Timestamp validity) {
		this.validity = validity;
	}

	public Timestamp getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Timestamp returnDate) {
		this.returnDate = returnDate;
	}

	public String getReturnBy() {
		return returnBy;
	}

	public void setReturnBy(String returnBy) {
		this.returnBy = returnBy;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "AssertDetails [id=" + id + ", assignedTo=" + assignedTo + ", assertType=" + assertType + ", assertId="
				+ assertId + ", assetTag=" + assetTag + ", assertOwnType=" + assertOwnType + ", comments=" + comments
				+ ", serviceProvider=" + serviceProvider + ", billDetails=" + billDetails + ", issuedDate=" + issuedDate
				+ ", issuedBy=" + issuedBy + ", validity=" + validity + ", returnDate=" + returnDate + ", returnBy="
				+ returnBy + ", active=" + active + "]";
	}

	
}

/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import com.accenture.mypmo.model.CertificationDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface CertificationDetailsService {

	PMOResponse captureCertificationDetails(CertificationDetails certificationDetails);

	PMOResponse updateCertificationDetails(CertificationDetails certificationDetails);

	CertificationDetails viewCertificationDetails(int id);
	
	List<CertificationDetails> viewCertificationDetailsByAssignedTo(String assignedTo);

	List<CertificationDetails> viewAllCertificationDetails();

}

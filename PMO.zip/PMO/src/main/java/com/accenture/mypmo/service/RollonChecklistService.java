package com.accenture.mypmo.service;

import com.accenture.mypmo.model.RollonChecklist;
import com.accenture.mypmo.response.PMOResponse;

public interface RollonChecklistService {
	
	PMOResponse fetchChecklistDetailsByChecklistID(Integer id);
	
	PMOResponse fetchChecklistDetails(Integer employeeNumber);
	
	PMOResponse captureRollOnChecklist(RollonChecklist rollOnChecklist);

	

}

package com.accenture.mypmo.business;

import java.util.List;

import com.accenture.mypmo.mapper.ACLReport;

public interface ACLReportsBiz {

	List<ACLReport> fetchReports();


}

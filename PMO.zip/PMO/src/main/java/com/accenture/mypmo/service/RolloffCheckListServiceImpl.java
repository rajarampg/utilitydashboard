package com.accenture.mypmo.service;

import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.RolloffChecklistBiz;
import com.accenture.mypmo.model.RolloffChecklist;
import com.accenture.mypmo.response.PMOResponse;

@CrossOrigin
@RestController
@RequestMapping(value = "/rolloff")
public class RolloffCheckListServiceImpl implements RolloffChecklistService {
	
	
	@Autowired
	RolloffChecklistBiz rolloffChecklistBiz;
	
	@Override
	@RequestMapping(value = "/checklist/{id}", method = RequestMethod.GET)
	public PMOResponse fetchChecklistByChecklistID(@PathVariable Integer id) {
		return rolloffChecklistBiz.fetchRolloffChecklist(id);
	}
	
	
	@Override
	@RequestMapping(value = "/checklist", method = RequestMethod.GET)
	public PMOResponse fetchChecklistDetails(@QueryParam(value="employee_number") Integer employee_number) {
		if(null!=employee_number){
			return rolloffChecklistBiz.fetchRolloffChecklistByEmployee(employee_number);	
		}else{
			return rolloffChecklistBiz.fetchAllChecklist();	
		}
		
	}
	
	@Override
	@RequestMapping(value = "checklist", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse captureRollOffChecklist(@RequestBody RolloffChecklist rollOffChecklist) {
		return rolloffChecklistBiz.captureRolloffChecklist(rollOffChecklist);
	}
	



}

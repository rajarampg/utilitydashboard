/**
 * 
 */
package com.accenture.mypmo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.RRDDemandMapping;
import java.lang.String;

/**
 * @author p.senthilrajan
 *
 */
public interface RRDDemandRepository
		extends CrudRepository<RRDDemandMapping, String>, JpaSpecificationExecutor<RRDDemandMapping> {

	List<RRDDemandMapping> findByDemandId(String demandId);
}


package com.accenture.mypmo.commons;

public interface Constants {
	
	public String VALIDATION_ = "WAT";

}

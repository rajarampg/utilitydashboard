/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.EmployeeCustomDetailsMapper;
import com.accenture.mypmo.model.EmployeeCustomDetails;
import com.accenture.mypmo.model.EmployeeCustomDetailsMapping;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class EmployeeCustomDetailsBizImpl implements EmployeeCustomDetailsBiz {

	@Autowired
	EntityManager entityManager;

	@Autowired
	EmployeeCustomDetailsMapper employeeCustomDetailsMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.accenture.mypmo.business.EmployeeCustomDetailsBiz#
	 * findAllEmployeeDetails()
	 */
	@Override
	public List<EmployeeCustomDetails> findAllEmployeeDetails() {

		Query selectQuery = entityManager.createNativeQuery(FIND_ALL_EMPLOYEE_DETAILS,
				EmployeeCustomDetailsMapping.class);

		List<EmployeeCustomDetailsMapping> empDetailsMapping = selectQuery.getResultList();

		return employeeCustomDetailsMapper.employeeCustomDetailsMapperCollection(empDetailsMapping);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.accenture.mypmo.business.EmployeeCustomDetailsBiz#
	 * findFullEmployeeDetailsByEmpNumner(int)
	 */
	@Override
	public List<EmployeeCustomDetails> findFullEmployeeDetailsByEmpNumner(int employeeNumber) {

		String WHERE_CLAUSE = " AND employeedetails.employee_number = " + employeeNumber;

		Query selectQuery = entityManager.createNativeQuery(FIND_ALL_EMPLOYEE_DETAILS + WHERE_CLAUSE,
				EmployeeCustomDetailsMapping.class);

		List<EmployeeCustomDetailsMapping> empDetailsMapping = selectQuery.getResultList();

		return employeeCustomDetailsMapper.employeeCustomDetailsMapperCollection(empDetailsMapping);
	}

}

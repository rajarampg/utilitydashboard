package com.accenture.mypmo.service;

import java.util.List;

import com.accenture.mypmo.model.EmployeeDetails;
import com.accenture.mypmo.response.PMOResponse;

public interface EmployeeDetailsService {

	PMOResponse captureEmployeeDetails(EmployeeDetails empdetails);
	
	PMOResponse updateEmployeeDetails(EmployeeDetails empdetails);
	
	PMOResponse updateAllEmployeeDetails(List<EmployeeDetails> empdetails);

	EmployeeDetails viewEmployeeDetails(int id);

	EmployeeDetails viewEmployeeDetailsByEmployeeId(int employeeId);

	EmployeeDetails viewEmployeeDetailsByRRDId(String rrdId);

	List<EmployeeDetails> viewEmployeeDetailsByPortfolioId(int portfolioId);

	List<EmployeeDetails> viewAllEmployeeDetails();
}

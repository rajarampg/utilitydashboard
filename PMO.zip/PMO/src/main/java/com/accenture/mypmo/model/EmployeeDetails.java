package com.accenture.mypmo.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class EmployeeDetails implements Serializable {

	private static final long serialVersionUID = 7261336881630862015L;

	private int id;

	private int employeeNumber;

	private int portfolioId;

	private String rrdId;

	private String enterpriseId;

	private String firstName;

	private String lastName;

	private String gender;

	private String capability;

	private String careerLevel;

	private String supervisorEntId;

	private String currentLocation;

	private String deliveryCenter;

	private String visaType;

	private String durationStay;

	private String phoneNo;

	private String primarySkill;

	private String secondarySkill;

	private String proficiencyLevel;

	private String lockType;

	private String employeeStatus;

	private String employeeType;

	private Timestamp rollonDate;

	private String rollonBy;
	
	private Timestamp rolloffDate;
	
	private String rolloffReason;
	
	private String rolledoffBy;
	
	private boolean isExit;

	private String createdBy;

	private Timestamp createdOn;

	private String modifiedBy;

	private Timestamp modifiedOn;

	private boolean active;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public int getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(int portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getRrdId() {
		return rrdId;
	}

	public void setRrdId(String rrdId) {
		this.rrdId = rrdId;
	}

	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCapability() {
		return capability;
	}

	public void setCapability(String capability) {
		this.capability = capability;
	}

	public String getCareerLevel() {
		return careerLevel;
	}

	public void setCareerLevel(String careerLevel) {
		this.careerLevel = careerLevel;
	}

	public String getSupervisorEntId() {
		return supervisorEntId;
	}

	public void setSupervisorEntId(String supervisorEntId) {
		this.supervisorEntId = supervisorEntId;
	}

	public String getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}

	public String getDeliveryCenter() {
		return deliveryCenter;
	}

	public void setDeliveryCenter(String deliveryCenter) {
		this.deliveryCenter = deliveryCenter;
	}

	public String getVisaType() {
		return visaType;
	}

	public void setVisaType(String visaType) {
		this.visaType = visaType;
	}

	public String getDurationStay() {
		return durationStay;
	}

	public void setDurationStay(String durationStay) {
		this.durationStay = durationStay;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getPrimarySkill() {
		return primarySkill;
	}

	public void setPrimarySkill(String primarySkill) {
		this.primarySkill = primarySkill;
	}

	public String getSecondarySkill() {
		return secondarySkill;
	}

	public void setSecondarySkill(String secondarySkill) {
		this.secondarySkill = secondarySkill;
	}

	public String getProficiencyLevel() {
		return proficiencyLevel;
	}

	public void setProficiencyLevel(String proficiencyLevel) {
		this.proficiencyLevel = proficiencyLevel;
	}

	public String getLockType() {
		return lockType;
	}

	public void setLockType(String lockType) {
		this.lockType = lockType;
	}

	public String getEmployeeStatus() {
		return employeeStatus;
	}

	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	public Timestamp getRollonDate() {
		return rollonDate;
	}

	public void setRollonDate(Timestamp rollonDate) {
		this.rollonDate = rollonDate;
	}

	public String getRollonBy() {
		return rollonBy;
	}

	public void setRollonBy(String rollonBy) {
		this.rollonBy = rollonBy;
	}

	public Timestamp getRolloffDate() {
		return rolloffDate;
	}

	public void setRolloffDate(Timestamp rolloffDate) {
		this.rolloffDate = rolloffDate;
	}

	public String getRolloffReason() {
		return rolloffReason;
	}

	public void setRolloffReason(String rolloffReason) {
		this.rolloffReason = rolloffReason;
	}

	public String getRolledoffBy() {
		return rolledoffBy;
	}

	public void setRolledoffBy(String rolledoffBy) {
		this.rolledoffBy = rolledoffBy;
	}

	public boolean isExit() {
		return isExit;
	}

	public void setExit(boolean isExit) {
		this.isExit = isExit;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "EmployeeDetails [id=" + id + ", employeeNumber=" + employeeNumber + ", portfolioId=" + portfolioId
				+ ", rrdId=" + rrdId + ", enterpriseId=" + enterpriseId + ", firstName=" + firstName + ", lastName="
				+ lastName + ", gender=" + gender + ", capability=" + capability + ", careerLevel=" + careerLevel
				+ ", supervisorEntId=" + supervisorEntId + ", currentLocation=" + currentLocation + ", deliveryCenter="
				+ deliveryCenter + ", visaType=" + visaType + ", durationStay=" + durationStay + ", phoneNo=" + phoneNo
				+ ", primarySkill=" + primarySkill + ", secondarySkill=" + secondarySkill + ", proficiencyLevel="
				+ proficiencyLevel + ", lockType=" + lockType + ", employeeStatus=" + employeeStatus + ", employeeType="
				+ employeeType + ", rollonDate=" + rollonDate + ", rollonBy=" + rollonBy + ", rolloffDate="
				+ rolloffDate + ", rolloffReason=" + rolloffReason + ", rolledoffBy=" + rolledoffBy + ", isExit="
				+ isExit + ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", modifiedBy=" + modifiedBy
				+ ", modifiedOn=" + modifiedOn + ", active=" + active + "]";
	}

}

package com.accenture.mypmo.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;
@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)
@Table(name = "employeedetails")
public class EmployeeDetailsMapping implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8225582531554803881L;

	@Id @GeneratedValue
	@Column(name = "id")
	private int id;

	@Column(name="employee_number")	
	private int employeeNumber;
	
	@Column(name="portfolio_id")
	private int portfolioId;
	
	@Column(name="rrd_id")
	private String rrdId;
	
	@Column(name="enterprise_id")
	private String enterpriseId;
	
	@Column(name="first_name")
	private String firstName;
	
	@Column(name="last_name")
	private String lastName;
	
	@Column(name="gender")
	private String gender;
	
	@Column(name="capability")
	private String capability;
	
	@Column(name="career_level")
	private String careerLevel;
	
	@Column(name="supervisor_ent_id")
	private String supervisorEntId;
	
	@Column(name="current_location")
	private String currentLocation;
	
	@Column(name="delivery_center")
	private String deliveryCenter;
	
	@Column(name="visa_type")
	private String visaType;	
	
	@Column(name="duration_stay")
	private String durationStay;
	
	@Column(name="phone_no")
	private String phoneNo;
	
	@Column(name="primary_skill")
	private String primarySkill;
	
	@Column(name="secondary_skill")
	private String secondarySkill;
	
	@Column(name="proficiency_level")
	private String proficiencyLevel;
	
	@Column(name="lock_type")
	private String lockType;
	
	@Column(name="employee_status")
	private String employeeStatus;
	
	@Column(name = "employee_type")
	private String employeeType;

	@Column(name="rollondate")
	private Timestamp rollonDate;

	@Column(name="rollonby")
	private String rollonBy;
	
	@Column(name="rolloffdate")
	private Timestamp rolloffDate;
	
	@Column(name="rolloffreason")
	private String rolloffReason;
	
	@Column(name="rolledoffby")
	private String rolledoffBy;
	
	@Column(name="isexit")
	private boolean isExit;
	
	@Column(name="created_by")
	private String createdBy;
	
	@Column(name="created_on")
	private Timestamp createdOn;
	
	@Column(name="modified_by")
	private String modifiedBy;
	
	@Column(name="modified_on")
	private Timestamp modifiedOn;

	@Column(name="active")
	private boolean active;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public int getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(int portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getRrdId() {
		return rrdId;
	}

	public void setRrdId(String rrdId) {
		this.rrdId = rrdId;
	}

	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCapability() {
		return capability;
	}

	public void setCapability(String capability) {
		this.capability = capability;
	}

	public String getCareerLevel() {
		return careerLevel;
	}

	public void setCareerLevel(String careerLevel) {
		this.careerLevel = careerLevel;
	}

	public String getSupervisorEntId() {
		return supervisorEntId;
	}

	public void setSupervisorEntId(String supervisorEntId) {
		this.supervisorEntId = supervisorEntId;
	}

	public String getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}

	public String getDeliveryCenter() {
		return deliveryCenter;
	}

	public void setDeliveryCenter(String deliveryCenter) {
		this.deliveryCenter = deliveryCenter;
	}

	public String getVisaType() {
		return visaType;
	}

	public void setVisaType(String visaType) {
		this.visaType = visaType;
	}

	public String getDurationStay() {
		return durationStay;
	}

	public void setDurationStay(String durationStay) {
		this.durationStay = durationStay;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getPrimarySkill() {
		return primarySkill;
	}

	public void setPrimarySkill(String primarySkill) {
		this.primarySkill = primarySkill;
	}

	public String getSecondarySkill() {
		return secondarySkill;
	}

	public void setSecondarySkill(String secondarySkill) {
		this.secondarySkill = secondarySkill;
	}

	public String getProficiencyLevel() {
		return proficiencyLevel;
	}

	public void setProficiencyLevel(String proficiencyLevel) {
		this.proficiencyLevel = proficiencyLevel;
	}

	public String getLockType() {
		return lockType;
	}

	public void setLockType(String lockType) {
		this.lockType = lockType;
	}

	public String getEmployeeStatus() {
		return employeeStatus;
	}

	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	public Timestamp getRollonDate() {
		return rollonDate;
	}

	public void setRollonDate(Timestamp rollonDate) {
		this.rollonDate = rollonDate;
	}

	public String getRollonBy() {
		return rollonBy;
	}

	public void setRollonBy(String rollonBy) {
		this.rollonBy = rollonBy;
	}

	public Timestamp getRolloffDate() {
		return rolloffDate;
	}

	public void setRolloffDate(Timestamp rolloffDate) {
		this.rolloffDate = rolloffDate;
	}

	public String getRolloffReason() {
		return rolloffReason;
	}

	public void setRolloffReason(String rolloffReason) {
		this.rolloffReason = rolloffReason;
	}

	public String getRolledoffBy() {
		return rolledoffBy;
	}

	public void setRolledoffBy(String rolledoffBy) {
		this.rolledoffBy = rolledoffBy;
	}

	public boolean isExit() {
		return isExit;
	}

	public void setExit(boolean isExit) {
		this.isExit = isExit;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "EmployeeDetailsMapping [id=" + id + ", employeeNumber=" + employeeNumber + ", portfolioId="
				+ portfolioId + ", rrdId=" + rrdId + ", enterpriseId=" + enterpriseId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", gender=" + gender + ", capability=" + capability + ", careerLevel="
				+ careerLevel + ", supervisorEntId=" + supervisorEntId + ", currentLocation=" + currentLocation
				+ ", deliveryCenter=" + deliveryCenter + ", visaType=" + visaType + ", durationStay=" + durationStay
				+ ", phoneNo=" + phoneNo + ", primarySkill=" + primarySkill + ", secondarySkill=" + secondarySkill
				+ ", proficiencyLevel=" + proficiencyLevel + ", lockType=" + lockType + ", employeeStatus="
				+ employeeStatus + ", employeeType=" + employeeType + ", rollonDate=" + rollonDate + ", rollonBy="
				+ rollonBy + ", rolloffDate=" + rolloffDate + ", rolloffReason=" + rolloffReason + ", rolledoffBy="
				+ rolledoffBy + ", isExit=" + isExit + ", createdBy=" + createdBy + ", createdOn=" + createdOn
				+ ", modifiedBy=" + modifiedBy + ", modifiedOn=" + modifiedOn + ", active=" + active + "]";
	}


	
}

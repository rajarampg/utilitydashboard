/**
 * 
 */
package com.accenture.mypmo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.ClientManagerDetailsMapping;

/**
 * @author p.senthilrajan
 *
 */
public interface ClientManagerDetailsRepository extends CrudRepository<ClientManagerDetailsMapping, String>, JpaSpecificationExecutor<ClientManagerDetailsMapping> {

	public ClientManagerDetailsMapping findById(int id);

	public List<ClientManagerDetailsMapping> findByPortfolioId(int portfolioId);

}

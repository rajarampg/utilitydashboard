package com.accenture.mypmo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.LoginDetailsMapper;
import com.accenture.mypmo.model.LoginDetails;
import com.accenture.mypmo.model.LoginDetailsMapping;
import com.accenture.mypmo.repository.LoginDetailsRepository;
import com.accenture.mypmo.response.PMOResponse;


@Component
public class LoginDetailsBizImpl implements LoginDetailsBiz {

	@Autowired
	public LoginDetailsRepository loginDetailsRepo;
	
	@Autowired
	public LoginDetailsMapper loginMapper;
	
	
	@Override
	public PMOResponse captureLoginDetails(LoginDetails loginDetails) {
		PMOResponse systemResponse = new PMOResponse();
		LoginDetailsMapping loginDetailsMapping = loginMapper.loginDetailsMapper(loginDetails);
		try {
			loginDetailsRepo.save(loginDetailsMapping);
		} catch (Exception e) {
			systemResponse.setId(500);
			systemResponse.setStatus("Error");
			systemResponse.setDescription(e.toString());
		}

		return systemResponse;
		
	}

	@Override
	public LoginDetails viewLoginDetails(int id) {
		LoginDetails loginDetails = new LoginDetails();
		
		try{
			
			loginDetails = loginMapper.loginDetailsMapMapper(loginDetailsRepo.findById(id));
		}catch (Exception e) {
			System.out.println("Exception" + e);
		}
		
		return loginDetails;
	}


	@Override
	public List<LoginDetails> viewAllLoginDetails() {
		List<LoginDetails> loginDetails = new ArrayList<LoginDetails>();
		
		try{
			
			loginDetails = loginMapper.loginDetailsMapMapperCollection(loginDetailsRepo.findAll());
		}catch (Exception e) {
			System.out.println("Exception" + e);
		}
		
		return loginDetails;
	}

	@Override
	public LoginDetails viewLoginDetailsByEnterpriseId(String enterpriseId) {
		LoginDetails loginDetails = new LoginDetails();
		
		try{
			
			loginDetails = loginMapper.loginDetailsMapMapper(loginDetailsRepo.findByEnterpriseId(enterpriseId));
		}catch (Exception e) {
			System.out.println("Exception" + e);
		}
		
		return loginDetails;
	}

}

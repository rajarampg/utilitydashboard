/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.List;

import com.accenture.mypmo.model.PatternDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface PatternDetailsBiz {

	PMOResponse capturePatternDetails(PatternDetails patternDetails);

	PatternDetails viewPatternDetails(int  patternId);
	
	List<PatternDetails> viewPatternDetailsByPortfolioId(int portfolioId);

	List<PatternDetails> viewAllPatternDetails();

}

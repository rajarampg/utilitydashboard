package com.accenture.mypmo.business;

import com.accenture.mypmo.model.RollonChecklist;
import com.accenture.mypmo.model.RollonChecklistReport;
import com.accenture.mypmo.response.PMOResponse;

public interface RollonChecklistBiz {
	
	PMOResponse fetchRollonChecklist(int id);
	
	PMOResponse captureRolloncheck(RollonChecklist rollonChecklist);

	PMOResponse fetchChecklistDetailsByEmployee(Integer id);

	RollonChecklistReport fetchAllChecklist();

}

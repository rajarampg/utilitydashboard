package com.accenture.mypmo.repository;

import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.LoginDetailsMapping;

public interface LoginDetailsRepository extends CrudRepository<LoginDetailsMapping, Integer>{

	LoginDetailsMapping findById(int id);

	LoginDetailsMapping findByEnterpriseId(String enterpriseId);
}

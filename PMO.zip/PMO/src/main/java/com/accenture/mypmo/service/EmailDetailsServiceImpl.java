/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.EmailDetailsBiz;
import com.accenture.mypmo.model.EmailDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */

@CrossOrigin
@RestController
@RequestMapping(value = "/emaildetails")
public class EmailDetailsServiceImpl implements EmailDetailsService {
	
	@Autowired
	public EmailDetailsBiz emailBiz;

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.EmailDetailsService#CaptureEmailDetails(com.accenture.mypmo.model.EmailDetails)
	 */
	@RequestMapping(value = "/addemail", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse CaptureEmailDetails(@RequestBody EmailDetails email) {
		// TODO Auto-generated method stub
		return emailBiz.CaptureEmailDetails(email);
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.EmailDetailsService#viewEmailDetails(int)
	 */
	@RequestMapping(value = "/viewemail/{emailId}", method = RequestMethod.GET)
	public EmailDetails viewEmailDetails(@PathVariable int emailId) {
		// TODO Auto-generated method stub
		return emailBiz.viewEmailDetails(emailId);
	}

	@RequestMapping(value = "/updateemail", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updateEmailDetails(@RequestBody EmailDetails email) {
		// TODO Auto-generated method stub
		return emailBiz.CaptureEmailDetails(email);
	}

	@Override
	@RequestMapping(value = "/updateallemail", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updateAllEmailDetails(@RequestBody List<EmailDetails> email) {
		// TODO Auto-generated method stub
		return emailBiz.CaptureAllEmailDetails(email);
	}

	@Override
	@RequestMapping(value = "/viewallemail", method = RequestMethod.GET)
	public List<EmailDetails> viewAllEmailDetails() {
		// TODO Auto-generated method stub
		return emailBiz.viewAllEmailDetails();
	}

}

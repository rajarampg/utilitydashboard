/**
 * 
 */
package com.accenture.mypmo.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author p.senthilrajan
 *
 */
@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)
@Table(name = "employeewmdetails")
public class EmployeeClientDetailsMapping implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id @GeneratedValue
	@Column(name = "id")
	private int id;
	
	@Column(name = "employee_number")
	private int employeeNumber;
	
	@Column(name = "client_manager_id")
	private int clientManagerId;
	
	@Column(name = "pattern_id")
	private int patternId;
	
	@Column(name = "role_id")
	private int roleId;
	
	@Column(name = "wmt_userid")
	private String wmtUserId;
	
	@Column(name = "wmt_accessdate")
	private Timestamp wmtAccessDate;

	@Column(name = "wmt_grantdate")
	private Timestamp wmtGrantDate;
	
	@Column(name = "contract_type")
	private String contractType;
	
	@Column(name = "projectname")
	private String projectName;
	
	@Column(name = "projectdetails")
	private String projectDetails;
	
	@Column(name = "client")
	private String client;
	
	@Column(name = "departmentnumber")
	private String departmentNumber;
	
	@Column(name = "country")
	private String country;
	
	@Column(name = "workstation")
	private String workstation;
	
	@Column(name = "bay_details")
	private String bayDetails;
	
	@Column(name = "floor")
	private String floor;
	
	@Column(name = "wbse")
	private String wbse;
	
	@Column(name = "identifiertype")
	private String identifierType;
	
	@Column(name = "identifiernumber")
	private String identifierNumber;
	
	@Column(name = "comments")
	private String comments;
	
	@Column(name = "onboardstartdate")
	private Timestamp onboardStartDate;
	
	@Column(name = "onboardtime")
	private Timestamp onboardTime;
	
	@Column(name = "onboardedby")
	private String onboardedBy;
	
	@Column(name = "isrenew")
	private boolean isRenew;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_on")
	private Timestamp createdOn;
	
	@Column(name = "modified_by")
	private String modifiedBy;
	
	@Column(name = "modified_on")
	private Timestamp modifiedOn;
	
	@Column(name = "active")
	private boolean active;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public int getClientManagerId() {
		return clientManagerId;
	}

	public void setClientManagerId(int clientManagerId) {
		this.clientManagerId = clientManagerId;
	}

	public int getPatternId() {
		return patternId;
	}

	public void setPatternId(int patternId) {
		this.patternId = patternId;
	}

	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public String getWmtUserId() {
		return wmtUserId;
	}

	public void setWmtUserId(String wmtUserId) {
		this.wmtUserId = wmtUserId;
	}

	public Timestamp getWmtAccessDate() {
		return wmtAccessDate;
	}

	public void setWmtAccessDate(Timestamp wmtAccessDate) {
		this.wmtAccessDate = wmtAccessDate;
	}

	public Timestamp getWmtGrantDate() {
		return wmtGrantDate;
	}

	public void setWmtGrantDate(Timestamp wmtGrantDate) {
		this.wmtGrantDate = wmtGrantDate;
	}

	public String getContractType() {
		return contractType;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProjectDetails() {
		return projectDetails;
	}

	public void setProjectDetails(String projectDetails) {
		this.projectDetails = projectDetails;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getDepartmentNumber() {
		return departmentNumber;
	}

	public void setDepartmentNumber(String departmentNumber) {
		this.departmentNumber = departmentNumber;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getWorkstation() {
		return workstation;
	}

	public void setWorkstation(String workstation) {
		this.workstation = workstation;
	}

	public String getBayDetails() {
		return bayDetails;
	}

	public void setBayDetails(String bayDetails) {
		this.bayDetails = bayDetails;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public String getWbse() {
		return wbse;
	}

	public void setWbse(String wbse) {
		this.wbse = wbse;
	}

	public String getIdentifierType() {
		return identifierType;
	}

	public void setIdentifierType(String identifierType) {
		this.identifierType = identifierType;
	}

	public String getIdentifierNumber() {
		return identifierNumber;
	}

	public void setIdentifierNumber(String identifierNumber) {
		this.identifierNumber = identifierNumber;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Timestamp getOnboardStartDate() {
		return onboardStartDate;
	}

	public void setOnboardStartDate(Timestamp onboardStartDate) {
		this.onboardStartDate = onboardStartDate;
	}

	public Timestamp getOnboardTime() {
		return onboardTime;
	}

	public void setOnboardTime(Timestamp onboardTime) {
		this.onboardTime = onboardTime;
	}

	public String getOnboardedBy() {
		return onboardedBy;
	}

	public void setOnboardedBy(String onboardedBy) {
		this.onboardedBy = onboardedBy;
	}

	public boolean isRenew() {
		return isRenew;
	}

	public void setRenew(boolean isRenew) {
		this.isRenew = isRenew;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "EmployeeClientDetailsMapping [id=" + id + ", employeeNumber=" + employeeNumber + ", clientManagerId="
				+ clientManagerId + ", patternId=" + patternId + ", roleId=" + roleId + ", wmtUserId=" + wmtUserId
				+ ", wmtAccessDate=" + wmtAccessDate + ", wmtGrantDate=" + wmtGrantDate + ", contractType="
				+ contractType + ", projectName=" + projectName + ", projectDetails=" + projectDetails + ", client="
				+ client + ", departmentNumber=" + departmentNumber + ", country=" + country + ", workstation="
				+ workstation + ", bayDetails=" + bayDetails + ", floor=" + floor + ", wbse=" + wbse
				+ ", identifierType=" + identifierType + ", identifierNumber=" + identifierNumber + ", comments="
				+ comments + ", onboardStartDate=" + onboardStartDate + ", onboardTime=" + onboardTime
				+ ", onboardedBy=" + onboardedBy + ", isRenew=" + isRenew + ", createdBy=" + createdBy + ", createdOn="
				+ createdOn + ", modifiedBy=" + modifiedBy + ", modifiedOn=" + modifiedOn + ", active=" + active + "]";
	}

	
}

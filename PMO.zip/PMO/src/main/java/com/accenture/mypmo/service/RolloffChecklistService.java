package com.accenture.mypmo.service;

import com.accenture.mypmo.model.RolloffChecklist;
import com.accenture.mypmo.response.PMOResponse;

public interface RolloffChecklistService {
	
	PMOResponse fetchChecklistByChecklistID(Integer employeeNumber);
	
	PMOResponse fetchChecklistDetails(Integer employeeNumber);
	
	PMOResponse captureRollOffChecklist(RolloffChecklist rollOffChecklist);

}

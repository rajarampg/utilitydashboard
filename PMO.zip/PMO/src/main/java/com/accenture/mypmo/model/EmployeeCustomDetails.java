package com.accenture.mypmo.model;
/**
 * 
 */

/**
 * @author p.senthilrajan
 *
 */
public class EmployeeCustomDetails {
	
	EmployeeDetails employeeDetails;
	
	EmployeeClientDetails employeeClientDetails;
	
	PortfolioDetails portfolioDetails;
	
	ClientManagerDetails clientManagerDetails;
	
	RoleDetails roleDetails;
	
	PatternDetails patternDetails;

	public EmployeeDetails getEmployeeDetails() {
		return employeeDetails;
	}

	public void setEmployeeDetails(EmployeeDetails employeeDetails) {
		this.employeeDetails = employeeDetails;
	}

	public EmployeeClientDetails getEmployeeClientDetails() {
		return employeeClientDetails;
	}

	public void setEmployeeClientDetails(EmployeeClientDetails employeeClientDetails) {
		this.employeeClientDetails = employeeClientDetails;
	}

	public PortfolioDetails getPortfolioDetails() {
		return portfolioDetails;
	}

	public void setPortfolioDetails(PortfolioDetails portfolioDetails) {
		this.portfolioDetails = portfolioDetails;
	}

	public ClientManagerDetails getClientManagerDetails() {
		return clientManagerDetails;
	}

	public void setClientManagerDetails(ClientManagerDetails clientManagerDetails) {
		this.clientManagerDetails = clientManagerDetails;
	}

	public RoleDetails getRoleDetails() {
		return roleDetails;
	}

	public void setRoleDetails(RoleDetails roleDetails) {
		this.roleDetails = roleDetails;
	}

	public PatternDetails getPatternDetails() {
		return patternDetails;
	}

	public void setPatternDetails(PatternDetails patternDetails) {
		this.patternDetails = patternDetails;
	}

	@Override
	public String toString() {
		return "EmployeeCustomDetails [employeeDetails=" + employeeDetails + ", employeeClientDetails="
				+ employeeClientDetails + ", portfolioDetails=" + portfolioDetails + ", clientManagerDetails="
				+ clientManagerDetails + ", roleDetails=" + roleDetails + ", patternDetails=" + patternDetails + "]";
	}

	
	

}

/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accenture.mypmo.mapper.EmployeeCountReportMapper;
import com.accenture.mypmo.model.EmployeeCountReport;
import com.accenture.mypmo.repository.EmployeeCountReportRepository;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class EmployeeCountReportBizImpl implements EmployeeCountReportBiz {

	@Autowired
	EmployeeCountReportRepository employeeCountReportRepository;

	@Autowired
	EmployeeCountReportMapper employeeCountReportMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.accenture.mypmo.business.EmployeeCountReportBiz#empCountByPortfolio()
	 */
	@Override
	public List<EmployeeCountReport> empCountByPortfolio() {
		List<EmployeeCountReport> employeeCountReport = new ArrayList<EmployeeCountReport>();

		try {
			employeeCountReport = employeeCountReportMapper
					.employeeCountReportMapMappingCollection(employeeCountReportRepository.empCountByPortfolio());
		} catch (Exception e) {
			System.out.println("Exception" + e);
		}

		return employeeCountReport;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.accenture.mypmo.business.EmployeeCountReportBiz#empCountByEmpStatus()
	 */
	@Override
	public List<EmployeeCountReport> empCountByEmpStatus() {
		List<EmployeeCountReport> employeeCountReport = new ArrayList<EmployeeCountReport>();

		try {
			employeeCountReport = employeeCountReportMapper
					.employeeCountReportMapMappingCollection(employeeCountReportRepository.empCountByEmpStatus());
		} catch (Exception e) {
			System.out.println("Exception" + e);
		}

		return employeeCountReport;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.accenture.mypmo.business.EmployeeCountReportBiz#empCountByRolloff()
	 */
	@Override
	public List<EmployeeCountReport> empCountByRolloff() {
		List<EmployeeCountReport> employeeCountReport = new ArrayList<EmployeeCountReport>();

		try {
			employeeCountReport = employeeCountReportMapper
					.employeeCountReportMapMappingCollection(employeeCountReportRepository.empCountByRolloff());
		} catch (Exception e) {
			System.out.println("Exception" + e);
		}

		return employeeCountReport;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.accenture.mypmo.business.EmployeeCountReportBiz#empCountByCareerLevel
	 * ()
	 */
	@Override
	public List<EmployeeCountReport> empCountByCareerLevel() {
		List<EmployeeCountReport> employeeCountReport = new ArrayList<EmployeeCountReport>();

		try {
			employeeCountReport = employeeCountReportMapper
					.employeeCountReportMapMappingCollection(employeeCountReportRepository.empCountByCareerLevel());
		} catch (Exception e) {
			System.out.println("Exception" + e);
		}

		return employeeCountReport;
	}

}

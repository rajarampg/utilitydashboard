package com.accenture.mypmo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.AssertDetailsMapping;

public interface AssertDetailsRepository
		extends CrudRepository<AssertDetailsMapping, String>, JpaSpecificationExecutor<AssertDetailsMapping> {

	public AssertDetailsMapping findById(int assertID);

	public List<AssertDetailsMapping> findByAssignedTo(String assignedTo);
}

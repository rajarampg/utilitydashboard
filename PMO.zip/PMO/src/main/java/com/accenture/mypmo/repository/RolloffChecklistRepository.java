package com.accenture.mypmo.repository;

import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.RolloffChecklistMapping;

public interface RolloffChecklistRepository  extends CrudRepository<RolloffChecklistMapping, Integer>{
	
	public RolloffChecklistMapping findById(int id);
	
	public RolloffChecklistMapping findByEmployeeNumber(int id);
	

}

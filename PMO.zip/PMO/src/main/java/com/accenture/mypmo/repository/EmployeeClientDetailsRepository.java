/**
 * 
 */
package com.accenture.mypmo.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.EmployeeClientDetailsMapping;

/**
 * @author p.senthilrajan
 *
 */
public interface EmployeeClientDetailsRepository extends
CrudRepository<EmployeeClientDetailsMapping, Integer>,JpaSpecificationExecutor<EmployeeClientDetailsMapping>{

	public EmployeeClientDetailsMapping findByEmployeeNumber(int employeeNumber);
	
	public EmployeeClientDetailsMapping findByWmtUserId(String wmtUserId);

	public EmployeeClientDetailsMapping findById(int id);

}

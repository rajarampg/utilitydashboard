package com.accenture.mypmo.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)
@Table(name = "rollonchecklist")
public class RollonChecklistMapping  implements Serializable{
	
	private static final long serialVersionUID = -7318740248112410410L;

	@Id @GeneratedValue
	@Column(name="id")
	private Integer id;
	
	@Column(name="employee_number")	
	private Integer employeeNumber;
	
	@Column(name="checklist_details")
	private String checklistDetails;
	
	@Column(name="updatedby")
	private String updatedby;
	
	@Column(name="updated_on")
	private Timestamp updatedon;
	
	@Column(name="status")
	private Boolean status;
	
	@Column(name="active")
	private Boolean active;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(Integer employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getChecklistDetails() {
		return checklistDetails;
	}

	public void setChecklistDetails(String checklistDetails) {
		this.checklistDetails = checklistDetails;
	}

	public String getUpdatedby() {
		return updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

	public Timestamp getUpdatedon() {
		return updatedon;
	}

	public void setUpdatedon(Timestamp updatedon) {
		this.updatedon = updatedon;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RollonchecklistDetailsMapping [id=");
		builder.append(id);
		builder.append(", employeeNumber=");
		builder.append(employeeNumber);
		builder.append(", checklistDetails=");
		builder.append(checklistDetails);
		builder.append(", updatedby=");
		builder.append(updatedby);
		builder.append(", updatedon=");
		builder.append(updatedon);
		builder.append(", status=");
		builder.append(status);
		builder.append(", active=");
		builder.append(active);
		builder.append("]");
		return builder.toString();
	}

}

package com.accenture.mypmo.business;

import java.util.List;

import com.accenture.mypmo.model.PortfolioDetails;
import com.accenture.mypmo.response.PMOResponse;

public interface PortfolioDetailsBiz {

	PMOResponse capturePortfolioDetails(PortfolioDetails portfolioDetails);
	
	PortfolioDetails viewPortfolioDetails(int id);
	
	List<PortfolioDetails> ViewAllPortfolioDetails();



}

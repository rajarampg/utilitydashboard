package com.accenture.mypmo.service;

import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.RollonChecklistBiz;
import com.accenture.mypmo.model.RollonChecklist;
import com.accenture.mypmo.response.PMOResponse;

@CrossOrigin
@RestController
@RequestMapping(value = "/rollon")
public class RollonCheckListServiceImpl implements RollonChecklistService {
	
	
	@Autowired
	RollonChecklistBiz rollOnChecklistBiz;
	
	@Override
	@RequestMapping(value = "/checklist/{id}", method = RequestMethod.GET)
	public PMOResponse fetchChecklistDetailsByChecklistID(@PathVariable Integer id) {
		return rollOnChecklistBiz.fetchRollonChecklist(id);
	}
	
	@Override
	@RequestMapping(value = "/checklist", method = RequestMethod.GET)
	public PMOResponse fetchChecklistDetails(@QueryParam(value="employee_number") Integer employee_number) {
		if(null!=employee_number){
			return rollOnChecklistBiz.fetchChecklistDetailsByEmployee(employee_number);	
		}else{
			return rollOnChecklistBiz.fetchAllChecklist();	
		}
		
	}
	
	
	@RequestMapping(value = "checklist", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse captureRollOnChecklist(
			@RequestBody RollonChecklist rollOnChecklist) {
		return rollOnChecklistBiz.captureRolloncheck(rollOnChecklist);
	}
	



}

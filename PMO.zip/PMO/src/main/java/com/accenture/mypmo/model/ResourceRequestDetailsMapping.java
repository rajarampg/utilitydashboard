package com.accenture.mypmo.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)
@Table(name = "resourcerequestdetails")
public class ResourceRequestDetailsMapping implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2184304440772382929L;

	@Id
	@GeneratedValue
	@Column(name = "id")
	private int id;

	@Column(name = "demand_id")
	private String demandId;
	
	@Column(name = "portfolio_Id")
	private int portfolioId;
	
	@Column(name = "primary_skill")
	private String primarySkill;
	
	@Column(name = "demand_priority")
	private String demandPriority;
	
	@Column(name = "demand_end_date")
	private Timestamp demandEndDate;
	
	@Column(name = "demand_segment")
	private String demandSegment;
	
	@Column(name = "demand_fullfill_date")
	private Timestamp demandFullfillDate;
	
	@Column(name = "lock_duration")
	private String lockDuration;
	
	@Column(name = "is_hardlock_ready")
	private boolean isHardlockReady;
	
	@Column(name = "fulfillment_entity")
	private String fulfillmentEntity;
	
	@Column(name = "work_location")
	private String workLocation;
	
	@Column(name = "career_level")
	private String careerLevel;
	
	@Column(name = "onsite_component")
	private boolean onsiteComponent;
	
	@Column(name = "resource_count")
	private int resourceCount;
	
	@Column(name = "status")
	private boolean status;
	
	@Column(name = "wbse_code")
	private String wbseCode;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_on")
	private Timestamp createdOn;
	
	@Column(name = "updated_by")
	private String updatedBy;
	
	@Column(name = "updated_on")
	private Timestamp updatedOn;
	
	@Column(name = "active")
	private boolean active;
	
	@Column(name = "source_location")
	private String sourceLocation;
	
	@Column(name = "visa_type")
	private String visaType;
	
	@Column(name = "visa_ready")
	private boolean visaReady;
	
	@Column(name = "resource_start_date")
	private Timestamp resourceStartDate;
	
	@Column(name = "client_interview")
	private boolean clientInterview;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDemandId() {
		return demandId;
	}
	public void setDemandId(String demandId) {
		this.demandId = demandId;
	}
	public int getPortfolioId() {
		return portfolioId;
	}
	public void setPortfolioId(int portfolioId) {
		this.portfolioId = portfolioId;
	}
	public String getPrimarySkill() {
		return primarySkill;
	}
	public void setPrimarySkill(String primarySkill) {
		this.primarySkill = primarySkill;
	}
	public String getDemandPriority() {
		return demandPriority;
	}
	public void setDemandPriority(String demandPriority) {
		this.demandPriority = demandPriority;
	}
	public Timestamp getDemandEndDate() {
		return demandEndDate;
	}
	public void setDemandEndDate(Timestamp demandEndDate) {
		this.demandEndDate = demandEndDate;
	}
	public String getDemandSegment() {
		return demandSegment;
	}
	public void setDemandSegment(String demandSegment) {
		this.demandSegment = demandSegment;
	}
	public Timestamp getDemandFullfillDate() {
		return demandFullfillDate;
	}
	public void setDemandFullfillDate(Timestamp demandFullfillDate) {
		this.demandFullfillDate = demandFullfillDate;
	}
	public String getLockDuration() {
		return lockDuration;
	}
	public void setLockDuration(String lockDuration) {
		this.lockDuration = lockDuration;
	}
	public boolean isHardlockReady() {
		return isHardlockReady;
	}
	public void setHardlockReady(boolean isHardlockReady) {
		this.isHardlockReady = isHardlockReady;
	}
	public String getFulfillmentEntity() {
		return fulfillmentEntity;
	}
	public void setFulfillmentEntity(String fulfillmentEntity) {
		this.fulfillmentEntity = fulfillmentEntity;
	}
	public String getWorkLocation() {
		return workLocation;
	}
	public void setWorkLocation(String workLocation) {
		this.workLocation = workLocation;
	}
	public String getCareerLevel() {
		return careerLevel;
	}
	public void setCareerLevel(String careerLevel) {
		this.careerLevel = careerLevel;
	}
	public boolean isOnsiteComponent() {
		return onsiteComponent;
	}
	public void setOnsiteComponent(boolean onsiteComponent) {
		this.onsiteComponent = onsiteComponent;
	}
	public int getResourceCount() {
		return resourceCount;
	}
	public void setResourceCount(int resourceCount) {
		this.resourceCount = resourceCount;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getWbseCode() {
		return wbseCode;
	}
	public void setWbseCode(String wbseCode) {
		this.wbseCode = wbseCode;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Timestamp getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Timestamp updatedOn) {
		this.updatedOn = updatedOn;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getSourceLocation() {
		return sourceLocation;
	}
	public void setSourceLocation(String sourceLocation) {
		this.sourceLocation = sourceLocation;
	}
	public String getVisaType() {
		return visaType;
	}
	public void setVisaType(String visaType) {
		this.visaType = visaType;
	}
	public boolean isVisaReady() {
		return visaReady;
	}
	public void setVisaReady(boolean visaReady) {
		this.visaReady = visaReady;
	}
	public Timestamp getResourceStartDate() {
		return resourceStartDate;
	}
	public void setResourceStartDate(Timestamp resourceStartDate) {
		this.resourceStartDate = resourceStartDate;
	}
	public boolean isClientInterview() {
		return clientInterview;
	}
	public void setClientInterview(boolean clientInterview) {
		this.clientInterview = clientInterview;
	}
	@Override
	public String toString() {
		return "ResourceRequestDetailsMapping [id=" + id + ", demandId=" + demandId + ", portfolioId=" + portfolioId
				+ ", primarySkill=" + primarySkill + ", demandPriority=" + demandPriority + ", demandEndDate="
				+ demandEndDate + ", demandSegment=" + demandSegment + ", demandFullfillDate=" + demandFullfillDate
				+ ", lockDuration=" + lockDuration + ", isHardlockReady=" + isHardlockReady + ", fulfillmentEntity="
				+ fulfillmentEntity + ", workLocation=" + workLocation + ", careerLevel=" + careerLevel
				+ ", onsiteComponent=" + onsiteComponent + ", resourceCount=" + resourceCount + ", status=" + status
				+ ", wbseCode=" + wbseCode + ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", updatedBy="
				+ updatedBy + ", updatedOn=" + updatedOn + ", active=" + active + ", sourceLocation=" + sourceLocation
				+ ", visaType=" + visaType + ", visaReady=" + visaReady + ", resourceStartDate=" + resourceStartDate
				+ ", clientInterview=" + clientInterview + "]";
	}


}

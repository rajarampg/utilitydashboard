/**
 * 
 */
package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.EmployeeCountReport;
import com.accenture.mypmo.model.EmployeeCountReportMapping;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class EmployeeCountReportMapper {

	public EmployeeCountReport employeeCountReportMapMapping (EmployeeCountReportMapping employeeCountReportMapping) {
		
		EmployeeCountReport employeeCountReport = new EmployeeCountReport();
		
		employeeCountReport.setSno(employeeCountReportMapping.getSno());
		employeeCountReport.setPortfolio(employeeCountReportMapping.getPortfolio());
		employeeCountReport.setCountbase(employeeCountReportMapping.getCountbase());
		employeeCountReport.setCountvalue(employeeCountReportMapping.getCountvalue());
		employeeCountReport.setWorklocation(employeeCountReportMapping.getWorklocation());
		
		return employeeCountReport;
	}
	
	public List<EmployeeCountReport> employeeCountReportMapMappingCollection (List<EmployeeCountReportMapping> employeeCountReportMapping) {
		
		List<EmployeeCountReport> employeeCountReport = new ArrayList<EmployeeCountReport>();
		
		for(EmployeeCountReportMapping employeeCountReportMappingTemp: employeeCountReportMapping){
			employeeCountReport.add(employeeCountReportMapMapping(employeeCountReportMappingTemp));
		}
		
		return employeeCountReport;

	}
}

/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.PatternDetailsBiz;
import com.accenture.mypmo.model.PatternDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/patterndetails")
public class PatternDetailsServiceImpl implements PatternDetailsService {
	
	@Autowired
	public PatternDetailsBiz patternDetailsBiz;
	

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.PatternDetailsService#capturePatternDetails(com.accenture.mypmo.model.PatternDetails)
	 */
	@Override
	@RequestMapping(value = "/addpattern", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse capturePatternDetails(@RequestBody PatternDetails patternDetails) {
		// TODO Auto-generated method stub
		return patternDetailsBiz.capturePatternDetails(patternDetails);
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.PatternDetailsService#updatePatternDetails(com.accenture.mypmo.model.PatternDetails)
	 */
	@Override
	@RequestMapping(value = "/updatepattern", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updatePatternDetails(@RequestBody PatternDetails patternDetails) {
		// TODO Auto-generated method stub
		return patternDetailsBiz.capturePatternDetails(patternDetails);
	}

	/* (non-Javadoc)
	 * @see com.accenture.mypmo.service.PatternDetailsService#viewPatternDetails(int)
	 */
	@Override
	@RequestMapping(value = "/viewpattern/{id}", method = RequestMethod.GET)
	public PatternDetails viewPatternDetails(@PathVariable int id) {
		// TODO Auto-generated method stub
		return patternDetailsBiz.viewPatternDetails(id);
	}

	@Override
	@RequestMapping(value = "/viewpatternbyportfolioid/{portfolioId}", method = RequestMethod.GET)
	public List<PatternDetails> viewPatternDetailsByPortfolioId(@PathVariable int portfolioId) {
		// TODO Auto-generated method stub
		return patternDetailsBiz.viewPatternDetailsByPortfolioId(portfolioId);
	}

	@Override
	@RequestMapping(value = "/viewallpattern", method = RequestMethod.GET)
	public List<PatternDetails> viewAllPatternDetails() {
		// TODO Auto-generated method stub
		return patternDetailsBiz.viewAllPatternDetails();
	}

}
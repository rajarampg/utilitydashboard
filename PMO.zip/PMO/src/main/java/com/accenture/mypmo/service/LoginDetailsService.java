/**
 * 
 */
package com.accenture.mypmo.service;

import java.util.List;

import com.accenture.mypmo.model.LoginDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface LoginDetailsService {
	
	PMOResponse capturLoginDetails(LoginDetails loginDetails);
	
	PMOResponse updateLoginDetails(LoginDetails loginDetails);
	
	LoginDetails viewLoginDetails(int id);
	
	List<LoginDetails> viewAllLoginDetails();

	LoginDetails viewLoginDetailsByEnterpriseId(String enterpriseId);

}

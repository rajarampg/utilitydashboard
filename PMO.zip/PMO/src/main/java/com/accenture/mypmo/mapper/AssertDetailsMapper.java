/**
 * 
 */
package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.AssertDetails;
import com.accenture.mypmo.model.AssertDetailsMapping;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class AssertDetailsMapper {


	public AssertDetailsMapping assertDetailsMapper(AssertDetails assertDetails){
		AssertDetailsMapping assertDetailsMap = new AssertDetailsMapping();
		
		assertDetailsMap.setId(assertDetails.getId());
		assertDetailsMap.setAssignedTo(assertDetails.getAssignedTo());
		assertDetailsMap.setAssertType(assertDetails.getAssertType());
		assertDetailsMap.setAssertId(assertDetails.getAssertId());
		assertDetailsMap.setAssetTag(assertDetails.getAssetTag());
		assertDetailsMap.setAssertOwnType(assertDetails.getAssertOwnType());
		assertDetailsMap.setComments(assertDetails.getComments());
		assertDetailsMap.setServiceProvider(assertDetails.getServiceProvider());
		assertDetailsMap.setBillDetails(assertDetails.getBillDetails());
		assertDetailsMap.setIssuedDate(assertDetails.getIssuedDate());
		assertDetailsMap.setIssuedBy(assertDetails.getIssuedBy());
		assertDetailsMap.setValidity(assertDetails.getValidity());
		assertDetailsMap.setReturnDate(assertDetails.getReturnDate());
		assertDetailsMap.setReturnBy(assertDetails.getReturnBy());
		assertDetailsMap.setActive(assertDetails.isActive());
		
		return assertDetailsMap;
	}

	public AssertDetails assertDetailsMapMapper(AssertDetailsMapping assertDetailsMap){
		AssertDetails assertDetails = new AssertDetails();
		
		assertDetails.setId(assertDetailsMap.getId());
		assertDetails.setAssignedTo(assertDetailsMap.getAssignedTo());
		assertDetails.setAssertType(assertDetailsMap.getAssertType());
		assertDetails.setAssertId(assertDetailsMap.getAssertId());
		assertDetails.setAssetTag(assertDetailsMap.getAssetTag());
		assertDetails.setAssertOwnType(assertDetailsMap.getAssertOwnType());
		assertDetails.setComments(assertDetailsMap.getComments());
		assertDetails.setServiceProvider(assertDetailsMap.getServiceProvider());
		assertDetails.setBillDetails(assertDetailsMap.getBillDetails());
		assertDetails.setIssuedDate(assertDetailsMap.getIssuedDate());
		assertDetails.setIssuedBy(assertDetailsMap.getIssuedBy());
		assertDetails.setValidity(assertDetailsMap.getValidity());
		assertDetails.setReturnDate(assertDetailsMap.getReturnDate());
		assertDetails.setReturnBy(assertDetailsMap.getReturnBy());
		assertDetails.setActive(assertDetailsMap.isActive());
		
		return assertDetails;
	}


	public List<AssertDetails> assertDetailsMapMapperCollection(List<AssertDetailsMapping> assertDetailsMap){
		List<AssertDetails> assertDetails = new  ArrayList<AssertDetails>();
		int count = 0;
		for (AssertDetailsMapping assertDetailsMapTemp : assertDetailsMap) {
			System.out.println(count++);
			assertDetails.add(assertDetailsMapMapper(assertDetailsMapTemp));
		}
		
		return assertDetails;
	}
	
	public List<AssertDetailsMapping> assertIterableCollection(Iterable<AssertDetailsMapping> assertDetailsResultSet){
		
		List <AssertDetailsMapping> assertDetailsMap = new ArrayList<AssertDetailsMapping>();
		
		for(AssertDetailsMapping assertDetailsMapTemp:assertDetailsResultSet){
			assertDetailsMap.add(assertDetailsMapTemp);
		}
		
		return assertDetailsMap;
	}

}

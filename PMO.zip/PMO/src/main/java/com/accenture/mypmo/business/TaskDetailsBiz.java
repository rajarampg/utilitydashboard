/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.List;

import com.accenture.mypmo.model.TaskDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface TaskDetailsBiz {

	PMOResponse captureTaskDetails(TaskDetails task);
	
	PMOResponse captureAllTaskDetails(List<TaskDetails> taskDetails);

	TaskDetails viewTaskDetails(int taskId);
	
	List<TaskDetails> ViewAllTaskDetails();

	List<TaskDetails> ViewTaskDetailsByCreatedBy(String createdBy);

	List<TaskDetails> ViewTaskDetailsByAssignedTo(String assignedTo);
}

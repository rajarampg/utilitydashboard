/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.List;

import com.accenture.mypmo.model.AssertDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface AssertDetailsBiz {
	
	PMOResponse captureAssertDetails(AssertDetails assertEmpDetails);
	
	List<AssertDetails> viewAssertDetailsByAssignedTo(String assignedTo);

	AssertDetails viewAssertDetails(int id);

	List<AssertDetails> viewAllAssertDetails();
}

/**
 * 
 */
package com.accenture.mypmo.business;

import java.util.List;

import com.accenture.mypmo.model.EmailDetails;
import com.accenture.mypmo.response.PMOResponse;

/**
 * @author p.senthilrajan
 *
 */
public interface EmailDetailsBiz {


	PMOResponse CaptureEmailDetails(EmailDetails email);
	
	PMOResponse CaptureAllEmailDetails(List<EmailDetails> email);

	EmailDetails viewEmailDetails(int emailId);

	List<EmailDetails> viewAllEmailDetails();
}

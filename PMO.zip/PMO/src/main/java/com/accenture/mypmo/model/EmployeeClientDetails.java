/**
 * 
 */
package com.accenture.mypmo.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author p.senthilrajan
 *
 */
public class EmployeeClientDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int id;
	
	private int employeeNumber;
	
	private int clientManagerId;
	
	private int patternId;
	
	private int roleId;
	
	private String wmtUserId;
	
	private Timestamp wmtAccessDate;

	private Timestamp wmtGrantDate;
	
	private String contractType;
	
	private String projectName;
	
	private String projectDetails;
	
	private String client;
	
	private String departmentNumber;
	
	private String country;
	
	private String workstation;
	
	private String bayDetails;
	
	private String floor;
	
	private String wbse;
	
	private String identifierType;
	
	private String identifierNumber;
	
	private String comments;
	
	private Timestamp onboardStartDate;
	
	private Timestamp onboardTime;
	
	private String onboardedBy;
	
	private boolean isRenew;
	
	private String createdBy;
	
	private Timestamp createdOn;
	
	private String modifiedBy;
	
	private Timestamp modifiedOn;
	
	private boolean active;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public int getClientManagerId() {
		return clientManagerId;
	}

	public void setClientManagerId(int clientManagerId) {
		this.clientManagerId = clientManagerId;
	}

	public int getPatternId() {
		return patternId;
	}

	public void setPatternId(int patternId) {
		this.patternId = patternId;
	}

	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public String getWmtUserId() {
		return wmtUserId;
	}

	public void setWmtUserId(String wmtUserId) {
		this.wmtUserId = wmtUserId;
	}

	public Timestamp getWmtAccessDate() {
		return wmtAccessDate;
	}

	public void setWmtAccessDate(Timestamp wmtAccessDate) {
		this.wmtAccessDate = wmtAccessDate;
	}

	public Timestamp getWmtGrantDate() {
		return wmtGrantDate;
	}

	public void setWmtGrantDate(Timestamp wmtGrantDate) {
		this.wmtGrantDate = wmtGrantDate;
	}

	public String getContractType() {
		return contractType;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProjectDetails() {
		return projectDetails;
	}

	public void setProjectDetails(String projectDetails) {
		this.projectDetails = projectDetails;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getDepartmentNumber() {
		return departmentNumber;
	}

	public void setDepartmentNumber(String departmentNumber) {
		this.departmentNumber = departmentNumber;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getWorkstation() {
		return workstation;
	}

	public void setWorkstation(String workstation) {
		this.workstation = workstation;
	}

	public String getBayDetails() {
		return bayDetails;
	}

	public void setBayDetails(String bayDetails) {
		this.bayDetails = bayDetails;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public String getWbse() {
		return wbse;
	}

	public void setWbse(String wbse) {
		this.wbse = wbse;
	}

	public String getIdentifierType() {
		return identifierType;
	}

	public void setIdentifierType(String identifierType) {
		this.identifierType = identifierType;
	}

	public String getIdentifierNumber() {
		return identifierNumber;
	}

	public void setIdentifierNumber(String identifierNumber) {
		this.identifierNumber = identifierNumber;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Timestamp getOnboardStartDate() {
		return onboardStartDate;
	}

	public void setOnboardStartDate(Timestamp onboardStartDate) {
		this.onboardStartDate = onboardStartDate;
	}

	public Timestamp getOnboardTime() {
		return onboardTime;
	}

	public void setOnboardTime(Timestamp onboardTime) {
		this.onboardTime = onboardTime;
	}

	public String getOnboardedBy() {
		return onboardedBy;
	}

	public void setOnboardedBy(String onboardedBy) {
		this.onboardedBy = onboardedBy;
	}

	public boolean isRenew() {
		return isRenew;
	}

	public void setRenew(boolean isRenew) {
		this.isRenew = isRenew;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "EmployeeClientDetails [id=" + id + ", employeeNumber=" + employeeNumber + ", clientManagerId="
				+ clientManagerId + ", patternId=" + patternId + ", roleId=" + roleId + ", wmtUserId=" + wmtUserId
				+ ", wmtAccessDate=" + wmtAccessDate + ", wmtGrantDate=" + wmtGrantDate + ", contractType="
				+ contractType + ", projectName=" + projectName + ", projectDetails=" + projectDetails + ", client="
				+ client + ", departmentNumber=" + departmentNumber + ", country=" + country + ", workstation="
				+ workstation + ", bayDetails=" + bayDetails + ", floor=" + floor + ", wbse=" + wbse
				+ ", identifierType=" + identifierType + ", identifierNumber=" + identifierNumber + ", comments="
				+ comments + ", onboardStartDate=" + onboardStartDate + ", onboardTime=" + onboardTime
				+ ", onboardedBy=" + onboardedBy + ", isRenew=" + isRenew + ", createdBy=" + createdBy + ", createdOn="
				+ createdOn + ", modifiedBy=" + modifiedBy + ", modifiedOn=" + modifiedOn + ", active=" + active + "]";
	}


}

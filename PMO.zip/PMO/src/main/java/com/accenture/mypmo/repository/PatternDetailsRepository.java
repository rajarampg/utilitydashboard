/**
 * 
 */
package com.accenture.mypmo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

import com.accenture.mypmo.model.PatternDetailsMapping;

/**
 * @author p.senthilrajan
 *
 */
public interface PatternDetailsRepository
		extends CrudRepository<PatternDetailsMapping, String>, JpaSpecificationExecutor<PatternDetailsMapping> {

	public PatternDetailsMapping findById(int id);
	
	public List<PatternDetailsMapping> findByPortfolioId(int portfolioId);
}

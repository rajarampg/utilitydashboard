package com.accenture.mypmo.business;

import com.accenture.mypmo.model.RolloffChecklist;
import com.accenture.mypmo.model.RolloffChecklistReport;
import com.accenture.mypmo.response.PMOResponse;

public interface RolloffChecklistBiz {
	
	PMOResponse fetchRolloffChecklist(int id);
	
	PMOResponse fetchRolloffChecklistByEmployee(int id);
	
	PMOResponse captureRolloffChecklist(RolloffChecklist rolloffChecklist);

	RolloffChecklistReport fetchAllChecklist();

}

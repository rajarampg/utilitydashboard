/**
 * 
 */
package com.accenture.mypmo.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.accenture.mypmo.model.RoleDetails;
import com.accenture.mypmo.model.RoleDetailsMapping;

/**
 * @author p.senthilrajan
 *
 */
@Component
public class RoleDetailsMapper {
	
	public RoleDetailsMapping roleDetailsMapper(RoleDetails roleDetails){
		RoleDetailsMapping roleDetailsMapping = new RoleDetailsMapping();
		
		roleDetailsMapping.setId(roleDetails.getId());
		roleDetailsMapping.setRole(roleDetails.getRole());
		roleDetailsMapping.setRoleDescription(roleDetails.getRoleDescription());
		roleDetailsMapping.setLocation(roleDetails.getLocation());
		roleDetailsMapping.setRate(roleDetails.getRate());
		roleDetailsMapping.setCreatedBy(roleDetails.getCreatedBy());
		roleDetailsMapping.setCreatedOn(roleDetails.getCreatedOn());
		roleDetailsMapping.setModifiedBy(roleDetails.getModifiedBy());
		roleDetailsMapping.setModifiedOn(roleDetails.getModifiedOn());
		roleDetailsMapping.setActive(roleDetails.isActive());
		
		return roleDetailsMapping;
	}

	public RoleDetails roleDetailsMapMapper(RoleDetailsMapping roleDetailsMapping){
		RoleDetails roleDetails = new RoleDetails();
		
		roleDetails.setId(roleDetailsMapping.getId());
		roleDetails.setRole(roleDetailsMapping.getRole());
		roleDetails.setRoleDescription(roleDetailsMapping.getRoleDescription());
		roleDetails.setLocation(roleDetailsMapping.getLocation());
		roleDetails.setRate(roleDetailsMapping.getRate());
		roleDetails.setCreatedBy(roleDetailsMapping.getCreatedBy());
		roleDetails.setCreatedOn(roleDetailsMapping.getCreatedOn());
		roleDetails.setModifiedBy(roleDetailsMapping.getModifiedBy());
		roleDetails.setModifiedOn(roleDetailsMapping.getModifiedOn());
		roleDetails.setActive(roleDetailsMapping.isActive());
		
		return roleDetails;
	}

	public List<RoleDetails> roleDetailsMapMapperCollection(List<RoleDetailsMapping> roleDetailsMapping){
		List<RoleDetails> roleDetails = new ArrayList<RoleDetails>();
		
		for(RoleDetailsMapping roleDetailsMappingTemp: roleDetailsMapping){
			roleDetails.add(roleDetailsMapMapper(roleDetailsMappingTemp));
		}
		
		return roleDetails;
	}

	public List<RoleDetails> roleDetailsIterableMapMapper(Iterable<RoleDetailsMapping> roleDetailsMapping){
		List<RoleDetails> roleDetails = new ArrayList<RoleDetails>();
		
		for(RoleDetailsMapping roleDetailsMappingTemp: roleDetailsMapping){
			roleDetails.add(roleDetailsMapMapper(roleDetailsMappingTemp));
		}
		
		return roleDetails;
	}
}

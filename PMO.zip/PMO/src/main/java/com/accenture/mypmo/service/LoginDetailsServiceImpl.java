package com.accenture.mypmo.service;

import java.util.List;

import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.LoginDetailsBiz;
import com.accenture.mypmo.model.LoginDetails;
import com.accenture.mypmo.response.PMOResponse;

@CrossOrigin
@RestController
@RequestMapping(value = "/logindetails")
public class LoginDetailsServiceImpl implements LoginDetailsService {

	@Autowired
	LoginDetailsBiz loginDetailsBiz;

	@Override
	@RequestMapping(value = "/addlogindetails", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse capturLoginDetails(@RequestBody LoginDetails loginDetails) {
		// TODO Auto-generated method stub
		return loginDetailsBiz.captureLoginDetails(loginDetails);
	}

	@Override
	@RequestMapping(value = "/updatelogindetails", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updateLoginDetails(@RequestBody LoginDetails loginDetails) {
		// TODO Auto-generated method stub
		return loginDetailsBiz.captureLoginDetails(loginDetails);
	}

	@Override
	@RequestMapping(value = "/viewlogindetails/{id}", method = RequestMethod.GET)
	public LoginDetails viewLoginDetails(@PathVariable int id) {
		return loginDetailsBiz.viewLoginDetails(id);
	}

	@Override
	@RequestMapping(value = "/viewlogindetailsbyenterpriseid", method = RequestMethod.GET)
	public LoginDetails viewLoginDetailsByEnterpriseId(@QueryParam("enterpriseId") String enterpriseId) {
		return loginDetailsBiz.viewLoginDetailsByEnterpriseId(enterpriseId);
	}

	@Override
	@RequestMapping(value = "/viewalllogindetails", method = RequestMethod.GET)
	public List<LoginDetails> viewAllLoginDetails() {
		return loginDetailsBiz.viewAllLoginDetails();
	}

}

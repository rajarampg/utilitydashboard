package com.accenture.mypmo.commons;

public enum ExceptionCode {
	
	ROLL_ON_CHECKLIST_ID_NOT_FOUND("1001","rollon_checklist is not avaliable for the mentioned id"),
	
	ROLL_ON_CHECKLIST_ID_INVALID("1002","mentioned id is invalid"),
	
	SQL_EXCEPTION("1003","Exception in SQL operation!");
	

	private String errorCode;
	
	private String errorMessage;

	ExceptionCode(String errorCode, String errorMessage) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
}

package com.accenture.mypmo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.mypmo.business.PortfolioDetailsBiz;
import com.accenture.mypmo.model.PortfolioDetails;
import com.accenture.mypmo.response.PMOResponse;

@CrossOrigin
@RestController
@RequestMapping(value = "/portfoliodetails")
public class PortfolioDetailsServiceImpl implements PortfolioDetailsService{

	@Autowired
	PortfolioDetailsBiz portfolioDetailsBiz;
	
	@Override
	@RequestMapping(value = "/addportfolio", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse addPortfolioDetails(@RequestBody PortfolioDetails portfolioDetails) {
		// TODO Auto-generated method stub
		return portfolioDetailsBiz.capturePortfolioDetails(portfolioDetails);
	}

	@Override
	@RequestMapping(value = "/updateportfolio", method = RequestMethod.POST, headers = "Accept=application/json")
	public PMOResponse updatePortfolioDetails(@RequestBody PortfolioDetails portfolioDetails) {
		// TODO Auto-generated method stub
		return portfolioDetailsBiz.capturePortfolioDetails(portfolioDetails);
	}

	@Override
	@RequestMapping(value = "/viewportfolio/{id}", method = RequestMethod.GET)
	public PortfolioDetails viewPortfolioDetails(@PathVariable int id) {
		// TODO Auto-generated method stub
		return portfolioDetailsBiz.viewPortfolioDetails(id);
	}

	@Override
	@RequestMapping(value = "/viewallportfolio", method = RequestMethod.GET)
	public List<PortfolioDetails> ViewAllPortfolioDetails() {
		// TODO Auto-generated method stub
		return portfolioDetailsBiz.ViewAllPortfolioDetails();
	}
}
